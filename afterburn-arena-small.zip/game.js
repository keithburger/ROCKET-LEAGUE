var Xh=0,Rl=1,qh=2;var ah=1,Yh=2,Pn=3,ti=0,Ee=1,Ve=2;var $n=0,Kn=1,mn=2,Cl=3,Pl=4,Zh=5,mi=100,Jh=101,$h=102,Ll=103,Il=104,Kh=200,Qh=201,jh=202,tu=203,po=204,mo=205,eu=206,nu=207,iu=208,su=209,ru=210,au=211,ou=212,lu=213,cu=214,hu=0,uu=1,du=2,Er=3,fu=4,pu=5,mu=6,gu=7,oh=0,_u=1,xu=2,Qn=0,yu=1,vu=2,Mu=3,ol=4,bu=5,Su=6;var lh=300,$i=301,Ki=302,go=303,_o=304,ra=306,Ps=1e3,fn=1001,xo=1002,He=1003,Dl=1004;var La=1005;var Ke=1006,Eu=1007;var Ls=1008;var jn=1009,wu=1010,Tu=1011,ll=1012,ch=1013,Zn=1014,Jn=1015,Is=1016,hh=1017,uh=1018,_i=1020,Au=1021,pn=1023,Ru=1024,Cu=1025,xi=1026,Qi=1027,Pu=1028,dh=1029,Lu=1030,fh=1031,ph=1033,Ia=33776,Da=33777,Ua=33778,Na=33779,Ul=35840,Nl=35841,Fl=35842,Ol=35843,mh=36196,zl=37492,Bl=37496,kl=37808,Hl=37809,Vl=37810,Gl=37811,Wl=37812,Xl=37813,ql=37814,Yl=37815,Zl=37816,Jl=37817,$l=37818,Kl=37819,Ql=37820,jl=37821,Fa=36492,tc=36494,ec=36495,Iu=36283,nc=36284,ic=36285,sc=36286;var wr=2300,Tr=2301,Oa=2302,rc=2400,ac=2401,oc=2402;var gh=3e3,yi=3001,Du=3200,Uu=3201,_h=0,Nu=1,Qe="",_e="srgb",Dn="srgb-linear",cl="display-p3",aa="display-p3-linear",Ar="linear",re="srgb",Rr="rec709",Cr="p3";var Ai=7680;var lc=519,Fu=512,Ou=513,zu=514,xh=515,Bu=516,ku=517,Hu=518,Vu=519,cc=35044;var hc="300 es",yo=1035,In=2e3,Pr=2001,ei=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let i=this._listeners[t];if(i!==void 0){let r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let i=n.slice(0);for(let r=0,a=i.length;r<a;r++)i[r].call(this,t);t.target=null}}},Ie=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];var za=Math.PI/180,vo=180/Math.PI;function rs(){let s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ie[s&255]+Ie[s>>8&255]+Ie[s>>16&255]+Ie[s>>24&255]+"-"+Ie[t&255]+Ie[t>>8&255]+"-"+Ie[t>>16&15|64]+Ie[t>>24&255]+"-"+Ie[e&63|128]+Ie[e>>8&255]+"-"+Ie[e>>16&255]+Ie[e>>24&255]+Ie[n&255]+Ie[n>>8&255]+Ie[n>>16&255]+Ie[n>>24&255]).toLowerCase()}function Ue(s,t,e){return Math.max(t,Math.min(e,s))}function Gu(s,t){return(s%t+t)%t}function Ba(s,t,e){return(1-e)*s+e*t}function uc(s){return(s&s-1)===0&&s!==0}function Mo(s){return Math.pow(2,Math.floor(Math.log(s)/Math.LN2))}function _s(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function Ge(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}var _t=class s{constructor(t=0,e=0){s.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ue(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*i+t.x,this.y=r*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Yt=class s{constructor(t,e,n,i,r,a,o,l,c){s.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c)}set(t,e,n,i,r,a,o,l,c){let h=this.elements;return h[0]=t,h[1]=i,h[2]=o,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],p=n[5],g=n[8],y=i[0],m=i[3],f=i[6],x=i[1],_=i[4],M=i[7],E=i[2],w=i[5],A=i[8];return r[0]=a*y+o*x+l*E,r[3]=a*m+o*_+l*w,r[6]=a*f+o*M+l*A,r[1]=c*y+h*x+u*E,r[4]=c*m+h*_+u*w,r[7]=c*f+h*M+u*A,r[2]=d*y+p*x+g*E,r[5]=d*m+p*_+g*w,r[8]=d*f+p*M+g*A,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8];return e*a*h-e*o*c-n*r*h+n*o*l+i*r*c-i*a*l}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=h*a-o*c,d=o*l-h*r,p=c*r-a*l,g=e*u+n*d+i*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let y=1/g;return t[0]=u*y,t[1]=(i*c-h*n)*y,t[2]=(o*n-i*a)*y,t[3]=d*y,t[4]=(h*e-i*l)*y,t[5]=(i*r-o*e)*y,t[6]=p*y,t[7]=(n*l-c*e)*y,t[8]=(a*e-n*r)*y,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,a,o){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-i*c,i*l,-i*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(ka.makeScale(t,e)),this}rotate(t){return this.premultiply(ka.makeRotation(-t)),this}translate(t,e){return this.premultiply(ka.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},ka=new Yt;function yh(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function Lr(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function Wu(){let s=Lr("canvas");return s.style.display="block",s}var dc={};function ws(s){s in dc||(dc[s]=!0,console.warn(s))}var fc=new Yt().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),pc=new Yt().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Js={[Dn]:{transfer:Ar,primaries:Rr,toReference:s=>s,fromReference:s=>s},[_e]:{transfer:re,primaries:Rr,toReference:s=>s.convertSRGBToLinear(),fromReference:s=>s.convertLinearToSRGB()},[aa]:{transfer:Ar,primaries:Cr,toReference:s=>s.applyMatrix3(pc),fromReference:s=>s.applyMatrix3(fc)},[cl]:{transfer:re,primaries:Cr,toReference:s=>s.convertSRGBToLinear().applyMatrix3(pc),fromReference:s=>s.applyMatrix3(fc).convertLinearToSRGB()}},Xu=new Set([Dn,aa]),Qt={enabled:!0,_workingColorSpace:Dn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(s){if(!Xu.has(s))throw new Error(`Unsupported working color space, "${s}".`);this._workingColorSpace=s},convert:function(s,t,e){if(this.enabled===!1||t===e||!t||!e)return s;let n=Js[t].toReference,i=Js[e].fromReference;return i(n(s))},fromWorkingColorSpace:function(s,t){return this.convert(s,this._workingColorSpace,t)},toWorkingColorSpace:function(s,t){return this.convert(s,t,this._workingColorSpace)},getPrimaries:function(s){return Js[s].primaries},getTransfer:function(s){return s===Qe?Ar:Js[s].transfer}};function Zi(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Ha(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}var Ri,Ir=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Ri===void 0&&(Ri=Lr("canvas")),Ri.width=t.width,Ri.height=t.height;let n=Ri.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Ri}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=Lr("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let a=0;a<r.length;a++)r[a]=Zi(r[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Zi(e[n]/255)*255):e[n]=Zi(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},qu=0,Dr=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:qu++}),this.uuid=rs(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let a=0,o=i.length;a<o;a++)i[a].isDataTexture?r.push(Va(i[a].image)):r.push(Va(i[a]))}else r=Va(i);n.url=r}return e||(t.images[this.uuid]=n),n}};function Va(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Ir.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Yu=0,tn=class s extends ei{constructor(t=s.DEFAULT_IMAGE,e=s.DEFAULT_MAPPING,n=fn,i=fn,r=Ke,a=Ls,o=pn,l=jn,c=s.DEFAULT_ANISOTROPY,h=Qe){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Yu++}),this.uuid=rs(),this.name="",this.source=new Dr(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new _t(0,0),this.repeat=new _t(1,1),this.center=new _t(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Yt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(ws("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===yi?_e:Qe),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==lh)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Ps:t.x=t.x-Math.floor(t.x);break;case fn:t.x=t.x<0?0:1;break;case xo:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Ps:t.y=t.y-Math.floor(t.y);break;case fn:t.y=t.y<0?0:1;break;case xo:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return ws("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===_e?yi:gh}set encoding(t){ws("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===yi?_e:Qe}};tn.DEFAULT_IMAGE=null;tn.DEFAULT_MAPPING=lh;tn.DEFAULT_ANISOTROPY=1;var oe=class s{constructor(t=0,e=0,n=0,i=1){s.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r,l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],p=l[5],g=l[9],y=l[2],m=l[6],f=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-y)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+y)<.1&&Math.abs(g+m)<.1&&Math.abs(c+p+f-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let _=(c+1)/2,M=(p+1)/2,E=(f+1)/2,w=(h+d)/4,A=(u+y)/4,U=(g+m)/4;return _>M&&_>E?_<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(_),i=w/n,r=A/n):M>E?M<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(M),n=w/i,r=U/i):E<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(E),n=A/r,i=U/r),this.set(n,i,r,e),this}let x=Math.sqrt((m-g)*(m-g)+(u-y)*(u-y)+(d-h)*(d-h));return Math.abs(x)<.001&&(x=1),this.x=(m-g)/x,this.y=(u-y)/x,this.z=(d-h)/x,this.w=Math.acos((c+p+f-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},bo=class extends ei{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new oe(0,0,t,e),this.scissorTest=!1,this.viewport=new oe(0,0,t,e);let i={width:t,height:e,depth:1};n.encoding!==void 0&&(ws("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===yi?_e:Qe),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ke,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new tn(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new Dr(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Un=class extends bo{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},Ur=class extends tn{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=He,this.minFilter=He,this.wrapR=fn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var So=class extends tn{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=He,this.minFilter=He,this.wrapR=fn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var $t=class{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,a,o){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3],d=r[a+0],p=r[a+1],g=r[a+2],y=r[a+3];if(o===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=d,t[e+1]=p,t[e+2]=g,t[e+3]=y;return}if(u!==y||l!==d||c!==p||h!==g){let m=1-o,f=l*d+c*p+h*g+u*y,x=f>=0?1:-1,_=1-f*f;if(_>Number.EPSILON){let E=Math.sqrt(_),w=Math.atan2(E,f*x);m=Math.sin(m*w)/E,o=Math.sin(o*w)/E}let M=o*x;if(l=l*m+d*M,c=c*m+p*M,h=h*m+g*M,u=u*m+y*M,m===1-o){let E=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=E,c*=E,h*=E,u*=E}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,r,a){let o=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=r[a],d=r[a+1],p=r[a+2],g=r[a+3];return t[e]=o*g+h*u+l*p-c*d,t[e+1]=l*g+h*d+c*u-o*p,t[e+2]=c*g+h*p+o*d-l*u,t[e+3]=h*g-o*u-l*d-c*p,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,i=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(i/2),u=o(r/2),d=l(n/2),p=l(i/2),g=l(r/2);switch(a){case"XYZ":this._x=d*h*u+c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u-d*p*g;break;case"YXZ":this._x=d*h*u+c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u+d*p*g;break;case"ZXY":this._x=d*h*u-c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u-d*p*g;break;case"ZYX":this._x=d*h*u-c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u+d*p*g;break;case"YZX":this._x=d*h*u+c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u-d*p*g;break;case"XZY":this._x=d*h*u-c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u+d*p*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],i=e[4],r=e[8],a=e[1],o=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=n+o+u;if(d>0){let p=.5/Math.sqrt(d+1);this._w=.25/p,this._x=(h-l)*p,this._y=(r-c)*p,this._z=(a-i)*p}else if(n>o&&n>u){let p=2*Math.sqrt(1+n-o-u);this._w=(h-l)/p,this._x=.25*p,this._y=(i+a)/p,this._z=(r+c)/p}else if(o>u){let p=2*Math.sqrt(1+o-n-u);this._w=(r-c)/p,this._x=(i+a)/p,this._y=.25*p,this._z=(l+h)/p}else{let p=2*Math.sqrt(1+u-n-o);this._w=(a-i)/p,this._x=(r+c)/p,this._y=(l+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ue(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,i=t._y,r=t._z,a=t._w,o=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+a*o+i*c-r*l,this._y=i*h+a*l+r*o-n*c,this._z=r*h+a*c+n*l-i*o,this._w=a*h-n*o-i*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,i=this._y,r=this._z,a=this._w,o=a*t._w+n*t._x+i*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=n,this._y=i,this._z=r,this;let l=1-o*o;if(l<=Number.EPSILON){let p=1-e;return this._w=p*a+e*this._w,this._x=p*n+e*this._x,this._y=p*i+e*this._y,this._z=p*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-e)*h)/c,d=Math.sin(e*h)/c;return this._w=a*u+this._w*d,this._x=n*u+this._x*d,this._y=i*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),i=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(i),n*Math.sin(r),n*Math.cos(r),e*Math.sin(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},C=class s{constructor(t=0,e=0,n=0){s.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(mc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(mc.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*a,this}applyQuaternion(t){let e=this.x,n=this.y,i=this.z,r=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*i-o*n),h=2*(o*e-r*i),u=2*(r*n-a*e);return this.x=e+l*c+a*u-o*h,this.y=n+l*h+o*c-r*u,this.z=i+l*u+r*h-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,i=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=i*l-r*o,this.y=r*a-n*l,this.z=n*o-i*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Ga.copy(this).projectOnVector(t),this.sub(Ga)}reflect(t){return this.sub(Ga.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ue(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Ga=new C,mc=new $t,Nn=class{constructor(t=new C(1/0,1/0,1/0),e=new C(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(hn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(hn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=hn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,hn):hn.fromBufferAttribute(r,a),hn.applyMatrix4(t.matrixWorld),this.expandByPoint(hn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),$s.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),$s.copy(n.boundingBox)),$s.applyMatrix4(t.matrixWorld),this.union($s)}let i=t.children;for(let r=0,a=i.length;r<a;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,hn),hn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(xs),Ks.subVectors(this.max,xs),Ci.subVectors(t.a,xs),Pi.subVectors(t.b,xs),Li.subVectors(t.c,xs),Gn.subVectors(Pi,Ci),Wn.subVectors(Li,Pi),hi.subVectors(Ci,Li);let e=[0,-Gn.z,Gn.y,0,-Wn.z,Wn.y,0,-hi.z,hi.y,Gn.z,0,-Gn.x,Wn.z,0,-Wn.x,hi.z,0,-hi.x,-Gn.y,Gn.x,0,-Wn.y,Wn.x,0,-hi.y,hi.x,0];return!Wa(e,Ci,Pi,Li,Ks)||(e=[1,0,0,0,1,0,0,0,1],!Wa(e,Ci,Pi,Li,Ks))?!1:(Qs.crossVectors(Gn,Wn),e=[Qs.x,Qs.y,Qs.z],Wa(e,Ci,Pi,Li,Ks))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,hn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(hn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(wn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),wn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),wn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),wn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),wn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),wn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),wn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),wn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(wn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},wn=[new C,new C,new C,new C,new C,new C,new C,new C],hn=new C,$s=new Nn,Ci=new C,Pi=new C,Li=new C,Gn=new C,Wn=new C,hi=new C,xs=new C,Ks=new C,Qs=new C,ui=new C;function Wa(s,t,e,n,i){for(let r=0,a=s.length-3;r<=a;r+=3){ui.fromArray(s,r);let o=i.x*Math.abs(ui.x)+i.y*Math.abs(ui.y)+i.z*Math.abs(ui.z),l=t.dot(ui),c=e.dot(ui),h=n.dot(ui);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}var Zu=new Nn,ys=new C,Xa=new C,ni=class{constructor(t=new C,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):Zu.setFromPoints(t).getCenter(n);let i=0;for(let r=0,a=t.length;r<a;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;ys.subVectors(t,this.center);let e=ys.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(ys,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Xa.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(ys.copy(t.center).add(Xa)),this.expandByPoint(ys.copy(t.center).sub(Xa))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},Tn=new C,qa=new C,js=new C,Xn=new C,Ya=new C,tr=new C,Za=new C,Nr=class{constructor(t=new C,e=new C(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Tn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=Tn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Tn.copy(this.origin).addScaledVector(this.direction,e),Tn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){qa.copy(t).add(e).multiplyScalar(.5),js.copy(e).sub(t).normalize(),Xn.copy(this.origin).sub(qa);let r=t.distanceTo(e)*.5,a=-this.direction.dot(js),o=Xn.dot(this.direction),l=-Xn.dot(js),c=Xn.lengthSq(),h=Math.abs(1-a*a),u,d,p,g;if(h>0)if(u=a*l-o,d=a*o-l,g=r*h,u>=0)if(d>=-g)if(d<=g){let y=1/h;u*=y,d*=y,p=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=r,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-a*r+o)),d=u>0?-r:Math.min(Math.max(-r,-l),r),p=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),p=d*(d+2*l)+c):(u=Math.max(0,-(a*r+o)),d=u>0?r:Math.min(Math.max(-r,-l),r),p=-u*u+d*(d+2*l)+c);else d=a>0?-r:r,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(qa).addScaledVector(js,d),p}intersectSphere(t,e){Tn.subVectors(t.center,this.origin);let n=Tn.dot(this.direction),i=Tn.dot(Tn)-n*n,r=t.radius*t.radius;if(i>r)return null;let a=Math.sqrt(r-i),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,a,o,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(t.min.x-d.x)*c,i=(t.max.x-d.x)*c):(n=(t.max.x-d.x)*c,i=(t.min.x-d.x)*c),h>=0?(r=(t.min.y-d.y)*h,a=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,a=(t.min.y-d.y)*h),n>a||r>i||((r>n||isNaN(n))&&(n=r),(a<i||isNaN(i))&&(i=a),u>=0?(o=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(o=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),n>l||o>i)||((o>n||n!==n)&&(n=o),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,Tn)!==null}intersectTriangle(t,e,n,i,r){Ya.subVectors(e,t),tr.subVectors(n,t),Za.crossVectors(Ya,tr);let a=this.direction.dot(Za),o;if(a>0){if(i)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Xn.subVectors(this.origin,t);let l=o*this.direction.dot(tr.crossVectors(Xn,tr));if(l<0)return null;let c=o*this.direction.dot(Ya.cross(Xn));if(c<0||l+c>a)return null;let h=-o*Xn.dot(Za);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},le=class s{constructor(t,e,n,i,r,a,o,l,c,h,u,d,p,g,y,m){s.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c,h,u,d,p,g,y,m)}set(t,e,n,i,r,a,o,l,c,h,u,d,p,g,y,m){let f=this.elements;return f[0]=t,f[4]=e,f[8]=n,f[12]=i,f[1]=r,f[5]=a,f[9]=o,f[13]=l,f[2]=c,f[6]=h,f[10]=u,f[14]=d,f[3]=p,f[7]=g,f[11]=y,f[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new s().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,i=1/Ii.setFromMatrixColumn(t,0).length(),r=1/Ii.setFromMatrixColumn(t,1).length(),a=1/Ii.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,i=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let d=a*h,p=a*u,g=o*h,y=o*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=p+g*c,e[5]=d-y*c,e[9]=-o*l,e[2]=y-d*c,e[6]=g+p*c,e[10]=a*l}else if(t.order==="YXZ"){let d=l*h,p=l*u,g=c*h,y=c*u;e[0]=d+y*o,e[4]=g*o-p,e[8]=a*c,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=p*o-g,e[6]=y+d*o,e[10]=a*l}else if(t.order==="ZXY"){let d=l*h,p=l*u,g=c*h,y=c*u;e[0]=d-y*o,e[4]=-a*u,e[8]=g+p*o,e[1]=p+g*o,e[5]=a*h,e[9]=y-d*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){let d=a*h,p=a*u,g=o*h,y=o*u;e[0]=l*h,e[4]=g*c-p,e[8]=d*c+y,e[1]=l*u,e[5]=y*c+d,e[9]=p*c-g,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){let d=a*l,p=a*c,g=o*l,y=o*c;e[0]=l*h,e[4]=y-d*u,e[8]=g*u+p,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-c*h,e[6]=p*u+g,e[10]=d-y*u}else if(t.order==="XZY"){let d=a*l,p=a*c,g=o*l,y=o*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+y,e[5]=a*h,e[9]=p*u-g,e[2]=g*u-p,e[6]=o*h,e[10]=y*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Ju,t,$u)}lookAt(t,e,n){let i=this.elements;return Xe.subVectors(t,e),Xe.lengthSq()===0&&(Xe.z=1),Xe.normalize(),qn.crossVectors(n,Xe),qn.lengthSq()===0&&(Math.abs(n.z)===1?Xe.x+=1e-4:Xe.z+=1e-4,Xe.normalize(),qn.crossVectors(n,Xe)),qn.normalize(),er.crossVectors(Xe,qn),i[0]=qn.x,i[4]=er.x,i[8]=Xe.x,i[1]=qn.y,i[5]=er.y,i[9]=Xe.y,i[2]=qn.z,i[6]=er.z,i[10]=Xe.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],p=n[13],g=n[2],y=n[6],m=n[10],f=n[14],x=n[3],_=n[7],M=n[11],E=n[15],w=i[0],A=i[4],U=i[8],v=i[12],b=i[1],F=i[5],k=i[9],nt=i[13],L=i[2],N=i[6],V=i[10],et=i[14],Y=i[3],J=i[7],D=i[11],j=i[15];return r[0]=a*w+o*b+l*L+c*Y,r[4]=a*A+o*F+l*N+c*J,r[8]=a*U+o*k+l*V+c*D,r[12]=a*v+o*nt+l*et+c*j,r[1]=h*w+u*b+d*L+p*Y,r[5]=h*A+u*F+d*N+p*J,r[9]=h*U+u*k+d*V+p*D,r[13]=h*v+u*nt+d*et+p*j,r[2]=g*w+y*b+m*L+f*Y,r[6]=g*A+y*F+m*N+f*J,r[10]=g*U+y*k+m*V+f*D,r[14]=g*v+y*nt+m*et+f*j,r[3]=x*w+_*b+M*L+E*Y,r[7]=x*A+_*F+M*N+E*J,r[11]=x*U+_*k+M*V+E*D,r[15]=x*v+_*nt+M*et+E*j,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],a=t[1],o=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],p=t[14],g=t[3],y=t[7],m=t[11],f=t[15];return g*(+r*l*u-i*c*u-r*o*d+n*c*d+i*o*p-n*l*p)+y*(+e*l*p-e*c*d+r*a*d-i*a*p+i*c*h-r*l*h)+m*(+e*c*u-e*o*p-r*a*u+n*a*p+r*o*h-n*c*h)+f*(-i*o*h-e*l*u+e*o*d+i*a*u-n*a*d+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],p=t[11],g=t[12],y=t[13],m=t[14],f=t[15],x=u*m*c-y*d*c+y*l*p-o*m*p-u*l*f+o*d*f,_=g*d*c-h*m*c-g*l*p+a*m*p+h*l*f-a*d*f,M=h*y*c-g*u*c+g*o*p-a*y*p-h*o*f+a*u*f,E=g*u*l-h*y*l-g*o*d+a*y*d+h*o*m-a*u*m,w=e*x+n*_+i*M+r*E;if(w===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/w;return t[0]=x*A,t[1]=(y*d*r-u*m*r-y*i*p+n*m*p+u*i*f-n*d*f)*A,t[2]=(o*m*r-y*l*r+y*i*c-n*m*c-o*i*f+n*l*f)*A,t[3]=(u*l*r-o*d*r-u*i*c+n*d*c+o*i*p-n*l*p)*A,t[4]=_*A,t[5]=(h*m*r-g*d*r+g*i*p-e*m*p-h*i*f+e*d*f)*A,t[6]=(g*l*r-a*m*r-g*i*c+e*m*c+a*i*f-e*l*f)*A,t[7]=(a*d*r-h*l*r+h*i*c-e*d*c-a*i*p+e*l*p)*A,t[8]=M*A,t[9]=(g*u*r-h*y*r-g*n*p+e*y*p+h*n*f-e*u*f)*A,t[10]=(a*y*r-g*o*r+g*n*c-e*y*c-a*n*f+e*o*f)*A,t[11]=(h*o*r-a*u*r-h*n*c+e*u*c+a*n*p-e*o*p)*A,t[12]=E*A,t[13]=(h*y*i-g*u*i+g*n*d-e*y*d-h*n*m+e*u*m)*A,t[14]=(g*o*i-a*y*i-g*n*l+e*y*l+a*n*m-e*o*m)*A,t[15]=(a*u*i-h*o*i+h*n*l-e*u*l-a*n*d+e*o*d)*A,this}scale(t){let e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),i=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,c=r*a,h=r*o;return this.set(c*a+n,c*o-i*l,c*l+i*o,0,c*o+i*l,h*o+n,h*l-i*a,0,c*l-i*o,h*l+i*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,a){return this.set(1,n,r,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){let i=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,c=r+r,h=a+a,u=o+o,d=r*c,p=r*h,g=r*u,y=a*h,m=a*u,f=o*u,x=l*c,_=l*h,M=l*u,E=n.x,w=n.y,A=n.z;return i[0]=(1-(y+f))*E,i[1]=(p+M)*E,i[2]=(g-_)*E,i[3]=0,i[4]=(p-M)*w,i[5]=(1-(d+f))*w,i[6]=(m+x)*w,i[7]=0,i[8]=(g+_)*A,i[9]=(m-x)*A,i[10]=(1-(d+y))*A,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){let i=this.elements,r=Ii.set(i[0],i[1],i[2]).length(),a=Ii.set(i[4],i[5],i[6]).length(),o=Ii.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],un.copy(this);let c=1/r,h=1/a,u=1/o;return un.elements[0]*=c,un.elements[1]*=c,un.elements[2]*=c,un.elements[4]*=h,un.elements[5]*=h,un.elements[6]*=h,un.elements[8]*=u,un.elements[9]*=u,un.elements[10]*=u,e.setFromRotationMatrix(un),n.x=r,n.y=a,n.z=o,this}makePerspective(t,e,n,i,r,a,o=In){let l=this.elements,c=2*r/(e-t),h=2*r/(n-i),u=(e+t)/(e-t),d=(n+i)/(n-i),p,g;if(o===In)p=-(a+r)/(a-r),g=-2*a*r/(a-r);else if(o===Pr)p=-a/(a-r),g=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=p,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,i,r,a,o=In){let l=this.elements,c=1/(e-t),h=1/(n-i),u=1/(a-r),d=(e+t)*c,p=(n+i)*h,g,y;if(o===In)g=(a+r)*u,y=-2*u;else if(o===Pr)g=r*u,y=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-p,l[2]=0,l[6]=0,l[10]=y,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},Ii=new C,un=new le,Ju=new C(0,0,0),$u=new C(1,1,1),qn=new C,er=new C,Xe=new C,gc=new le,_c=new $t,Fr=class s{constructor(t=0,e=0,n=0,i=s.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let i=t.elements,r=i[0],a=i[4],o=i[8],l=i[1],c=i[5],h=i[9],u=i[2],d=i[6],p=i[10];switch(e){case"XYZ":this._y=Math.asin(Ue(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Ue(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ue(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Ue(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,p),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Ue(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Ue(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return gc.makeRotationFromQuaternion(t),this.setFromRotationMatrix(gc,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return _c.setFromEuler(this),this.setFromQuaternion(_c,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Fr.DEFAULT_ORDER="XYZ";var Or=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Ku=0,xc=new C,Di=new $t,An=new le,nr=new C,vs=new C,Qu=new C,ju=new $t,yc=new C(1,0,0),vc=new C(0,1,0),Mc=new C(0,0,1),td={type:"added"},ed={type:"removed"},we=class s extends ei{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ku++}),this.uuid=rs(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=s.DEFAULT_UP.clone();let t=new C,e=new Fr,n=new $t,i=new C(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new le},normalMatrix:{value:new Yt}}),this.matrix=new le,this.matrixWorld=new le,this.matrixAutoUpdate=s.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=s.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Or,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Di.setFromAxisAngle(t,e),this.quaternion.multiply(Di),this}rotateOnWorldAxis(t,e){return Di.setFromAxisAngle(t,e),this.quaternion.premultiply(Di),this}rotateX(t){return this.rotateOnAxis(yc,t)}rotateY(t){return this.rotateOnAxis(vc,t)}rotateZ(t){return this.rotateOnAxis(Mc,t)}translateOnAxis(t,e){return xc.copy(t).applyQuaternion(this.quaternion),this.position.add(xc.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(yc,t)}translateY(t){return this.translateOnAxis(vc,t)}translateZ(t){return this.translateOnAxis(Mc,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(An.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?nr.copy(t):nr.set(t,e,n);let i=this.parent;this.updateWorldMatrix(!0,!1),vs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?An.lookAt(vs,nr,this.up):An.lookAt(nr,vs,this.up),this.quaternion.setFromRotationMatrix(An),i&&(An.extractRotation(i.matrixWorld),Di.setFromRotationMatrix(An),this.quaternion.premultiply(Di.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(td)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(ed)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),An.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),An.multiply(t.parent.matrixWorld)),t.applyMatrix4(An),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){let a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let i=this.children;for(let r=0,a=i.length;r<a;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(vs,t,Qu),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(vs,ju,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,i=e.length;n<i;n++){let r=e[n];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let i=this.children;for(let r=0,a=i.length;r<a;r++){let o=i[r];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),i.maxGeometryCount=this._maxGeometryCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(t.materials,this.material[l]));i.material=o}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];i.animations.push(r(t.animations,l))}}if(e){let o=a(t.geometries),l=a(t.materials),c=a(t.textures),h=a(t.images),u=a(t.shapes),d=a(t.skeletons),p=a(t.animations),g=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=i,n;function a(o){let l=[];for(let c in o){let h=o[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let i=t.children[n];this.add(i.clone())}return this}};we.DEFAULT_UP=new C(0,1,0);we.DEFAULT_MATRIX_AUTO_UPDATE=!0;we.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var dn=new C,Rn=new C,Ja=new C,Cn=new C,Ui=new C,Ni=new C,bc=new C,$a=new C,Ka=new C,Qa=new C,ir=!1,Wi=class s{constructor(t=new C,e=new C,n=new C){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),dn.subVectors(t,e),i.cross(dn);let r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){dn.subVectors(i,e),Rn.subVectors(n,e),Ja.subVectors(t,e);let a=dn.dot(dn),o=dn.dot(Rn),l=dn.dot(Ja),c=Rn.dot(Rn),h=Rn.dot(Ja),u=a*c-o*o;if(u===0)return r.set(0,0,0),null;let d=1/u,p=(c*l-o*h)*d,g=(a*h-o*l)*d;return r.set(1-p-g,g,p)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,Cn)===null?!1:Cn.x>=0&&Cn.y>=0&&Cn.x+Cn.y<=1}static getUV(t,e,n,i,r,a,o,l){return ir===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),ir=!0),this.getInterpolation(t,e,n,i,r,a,o,l)}static getInterpolation(t,e,n,i,r,a,o,l){return this.getBarycoord(t,e,n,i,Cn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Cn.x),l.addScaledVector(a,Cn.y),l.addScaledVector(o,Cn.z),l)}static isFrontFacing(t,e,n,i){return dn.subVectors(n,e),Rn.subVectors(t,e),dn.cross(Rn).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return dn.subVectors(this.c,this.b),Rn.subVectors(this.a,this.b),dn.cross(Rn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return s.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return s.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,i,r){return ir===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),ir=!0),s.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}getInterpolation(t,e,n,i,r){return s.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return s.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return s.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,i=this.b,r=this.c,a,o;Ui.subVectors(i,n),Ni.subVectors(r,n),$a.subVectors(t,n);let l=Ui.dot($a),c=Ni.dot($a);if(l<=0&&c<=0)return e.copy(n);Ka.subVectors(t,i);let h=Ui.dot(Ka),u=Ni.dot(Ka);if(h>=0&&u<=h)return e.copy(i);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),e.copy(n).addScaledVector(Ui,a);Qa.subVectors(t,r);let p=Ui.dot(Qa),g=Ni.dot(Qa);if(g>=0&&p<=g)return e.copy(r);let y=p*c-l*g;if(y<=0&&c>=0&&g<=0)return o=c/(c-g),e.copy(n).addScaledVector(Ni,o);let m=h*g-p*u;if(m<=0&&u-h>=0&&p-g>=0)return bc.subVectors(r,i),o=(u-h)/(u-h+(p-g)),e.copy(i).addScaledVector(bc,o);let f=1/(m+y+d);return a=y*f,o=d*f,e.copy(n).addScaledVector(Ui,a).addScaledVector(Ni,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},vh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Yn={h:0,s:0,l:0},sr={h:0,s:0,l:0};function ja(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}var Ct=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=_e){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Qt.toWorkingColorSpace(this,e),this}setRGB(t,e,n,i=Qt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Qt.toWorkingColorSpace(this,i),this}setHSL(t,e,n,i=Qt.workingColorSpace){if(t=Gu(t,1),e=Ue(e,0,1),n=Ue(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=ja(a,r,t+1/3),this.g=ja(a,r,t),this.b=ja(a,r,t-1/3)}return Qt.toWorkingColorSpace(this,i),this}setStyle(t,e=_e){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=i[1],o=i[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=i[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=_e){let n=vh[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Zi(t.r),this.g=Zi(t.g),this.b=Zi(t.b),this}copyLinearToSRGB(t){return this.r=Ha(t.r),this.g=Ha(t.g),this.b=Ha(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=_e){return Qt.fromWorkingColorSpace(De.copy(this),t),Math.round(Ue(De.r*255,0,255))*65536+Math.round(Ue(De.g*255,0,255))*256+Math.round(Ue(De.b*255,0,255))}getHexString(t=_e){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Qt.workingColorSpace){Qt.fromWorkingColorSpace(De.copy(this),e);let n=De.r,i=De.g,r=De.b,a=Math.max(n,i,r),o=Math.min(n,i,r),l,c,h=(o+a)/2;if(o===a)l=0,c=0;else{let u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case n:l=(i-r)/u+(i<r?6:0);break;case i:l=(r-n)/u+2;break;case r:l=(n-i)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=Qt.workingColorSpace){return Qt.fromWorkingColorSpace(De.copy(this),e),t.r=De.r,t.g=De.g,t.b=De.b,t}getStyle(t=_e){Qt.fromWorkingColorSpace(De.copy(this),t);let e=De.r,n=De.g,i=De.b;return t!==_e?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(Yn),this.setHSL(Yn.h+t,Yn.s+e,Yn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Yn),t.getHSL(sr);let n=Ba(Yn.h,sr.h,e),i=Ba(Yn.s,sr.s,e),r=Ba(Yn.l,sr.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},De=new Ct;Ct.NAMES=vh;var nd=0,ii=class extends ei{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:nd++}),this.uuid=rs(),this.name="",this.type="Material",this.blending=Kn,this.side=ti,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=po,this.blendDst=mo,this.blendEquation=mi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ct(0,0,0),this.blendAlpha=0,this.depthFunc=Er,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=lc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ai,this.stencilZFail=Ai,this.stencilZPass=Ai,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Kn&&(n.blending=this.blending),this.side!==ti&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==po&&(n.blendSrc=this.blendSrc),this.blendDst!==mo&&(n.blendDst=this.blendDst),this.blendEquation!==mi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Er&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==lc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ai&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ai&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ai&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){let a=[];for(let o in r){let l=r[o];delete l.metadata,a.push(l)}return a}if(e){let r=i(t.textures),a=i(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},pe=class extends ii{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ct(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=oh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var ge=new C,rr=new _t,jt=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=cc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Jn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)rr.fromBufferAttribute(this,e),rr.applyMatrix3(t),this.setXY(e,rr.x,rr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.applyMatrix3(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.applyMatrix4(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.applyNormalMatrix(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)ge.fromBufferAttribute(this,e),ge.transformDirection(t),this.setXYZ(e,ge.x,ge.y,ge.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=_s(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=Ge(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=_s(e,this.array)),e}setX(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=_s(e,this.array)),e}setY(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=_s(e,this.array)),e}setZ(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=_s(e,this.array)),e}setW(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),n=Ge(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),n=Ge(n,this.array),i=Ge(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),n=Ge(n,this.array),i=Ge(i,this.array),r=Ge(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==cc&&(t.usage=this.usage),t}};var zr=class extends jt{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var Br=class extends jt{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var se=class extends jt{constructor(t,e,n){super(new Float32Array(t),e,n)}};var id=0,$e=new le,to=new we,Fi=new C,qe=new Nn,Ms=new Nn,Se=new C,Te=class s extends ei{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:id++}),this.uuid=rs(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(yh(t)?Br:zr)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Yt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return $e.makeRotationFromQuaternion(t),this.applyMatrix4($e),this}rotateX(t){return $e.makeRotationX(t),this.applyMatrix4($e),this}rotateY(t){return $e.makeRotationY(t),this.applyMatrix4($e),this}rotateZ(t){return $e.makeRotationZ(t),this.applyMatrix4($e),this}translate(t,e,n){return $e.makeTranslation(t,e,n),this.applyMatrix4($e),this}scale(t,e,n){return $e.makeScale(t,e,n),this.applyMatrix4($e),this}lookAt(t){return to.lookAt(t),to.updateMatrix(),this.applyMatrix4(to.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Fi).negate(),this.translate(Fi.x,Fi.y,Fi.z),this}setFromPoints(t){let e=[];for(let n=0,i=t.length;n<i;n++){let r=t[n];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new se(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Nn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new C(-1/0,-1/0,-1/0),new C(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){let r=e[n];qe.setFromBufferAttribute(r),this.morphTargetsRelative?(Se.addVectors(this.boundingBox.min,qe.min),this.boundingBox.expandByPoint(Se),Se.addVectors(this.boundingBox.max,qe.max),this.boundingBox.expandByPoint(Se)):(this.boundingBox.expandByPoint(qe.min),this.boundingBox.expandByPoint(qe.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ni);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new C,1/0);return}if(t){let n=this.boundingSphere.center;if(qe.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];Ms.setFromBufferAttribute(o),this.morphTargetsRelative?(Se.addVectors(qe.min,Ms.min),qe.expandByPoint(Se),Se.addVectors(qe.max,Ms.max),qe.expandByPoint(Se)):(qe.expandByPoint(Ms.min),qe.expandByPoint(Ms.max))}qe.getCenter(n);let i=0;for(let r=0,a=t.count;r<a;r++)Se.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(Se));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Se.fromBufferAttribute(o,c),l&&(Fi.fromBufferAttribute(t,c),Se.add(Fi)),i=Math.max(i,n.distanceToSquared(Se))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.array,i=e.position.array,r=e.normal.array,a=e.uv.array,o=i.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new jt(new Float32Array(4*o),4));let l=this.getAttribute("tangent").array,c=[],h=[];for(let b=0;b<o;b++)c[b]=new C,h[b]=new C;let u=new C,d=new C,p=new C,g=new _t,y=new _t,m=new _t,f=new C,x=new C;function _(b,F,k){u.fromArray(i,b*3),d.fromArray(i,F*3),p.fromArray(i,k*3),g.fromArray(a,b*2),y.fromArray(a,F*2),m.fromArray(a,k*2),d.sub(u),p.sub(u),y.sub(g),m.sub(g);let nt=1/(y.x*m.y-m.x*y.y);isFinite(nt)&&(f.copy(d).multiplyScalar(m.y).addScaledVector(p,-y.y).multiplyScalar(nt),x.copy(p).multiplyScalar(y.x).addScaledVector(d,-m.x).multiplyScalar(nt),c[b].add(f),c[F].add(f),c[k].add(f),h[b].add(x),h[F].add(x),h[k].add(x))}let M=this.groups;M.length===0&&(M=[{start:0,count:n.length}]);for(let b=0,F=M.length;b<F;++b){let k=M[b],nt=k.start,L=k.count;for(let N=nt,V=nt+L;N<V;N+=3)_(n[N+0],n[N+1],n[N+2])}let E=new C,w=new C,A=new C,U=new C;function v(b){A.fromArray(r,b*3),U.copy(A);let F=c[b];E.copy(F),E.sub(A.multiplyScalar(A.dot(F))).normalize(),w.crossVectors(U,F);let nt=w.dot(h[b])<0?-1:1;l[b*4]=E.x,l[b*4+1]=E.y,l[b*4+2]=E.z,l[b*4+3]=nt}for(let b=0,F=M.length;b<F;++b){let k=M[b],nt=k.start,L=k.count;for(let N=nt,V=nt+L;N<V;N+=3)v(n[N+0]),v(n[N+1]),v(n[N+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new jt(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,p=n.count;d<p;d++)n.setXYZ(d,0,0,0);let i=new C,r=new C,a=new C,o=new C,l=new C,c=new C,h=new C,u=new C;if(t)for(let d=0,p=t.count;d<p;d+=3){let g=t.getX(d+0),y=t.getX(d+1),m=t.getX(d+2);i.fromBufferAttribute(e,g),r.fromBufferAttribute(e,y),a.fromBufferAttribute(e,m),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,y),c.fromBufferAttribute(n,m),o.add(h),l.add(h),c.add(h),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(y,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,p=e.count;d<p;d+=3)i.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),a.fromBufferAttribute(e,d+2),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Se.fromBufferAttribute(t,e),Se.normalize(),t.setXYZ(e,Se.x,Se.y,Se.z)}toNonIndexed(){function t(o,l){let c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h),p=0,g=0;for(let y=0,m=l.length;y<m;y++){o.isInterleavedBufferAttribute?p=l[y]*o.data.stride+o.offset:p=l[y]*h;for(let f=0;f<h;f++)d[g++]=c[p++]}return new jt(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new s,n=this.index.array,i=this.attributes;for(let o in i){let l=i[o],c=t(l,n);e.setAttribute(o,c)}let r=this.morphAttributes;for(let o in r){let l=[],c=r[o];for(let h=0,u=c.length;h<u;h++){let d=c[h],p=t(d,n);l.push(p)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let i={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let p=c[u];h.push(p.toJSON(t.data))}h.length>0&&(i[l]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let i=t.attributes;for(let c in i){let h=i[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,p=u.length;d<p;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let c=0,h=a.length;c<h;c++){let u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Sc=new le,di=new Nr,ar=new ni,Ec=new C,Oi=new C,zi=new C,Bi=new C,eo=new C,or=new C,lr=new _t,cr=new _t,hr=new _t,wc=new C,Tc=new C,Ac=new C,ur=new C,dr=new C,It=class extends we{constructor(t=new Te,e=new pe){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){let o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);let o=this.morphTargetInfluences;if(r&&o){or.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=o[l],u=r[l];h!==0&&(eo.fromBufferAttribute(u,t),a?or.addScaledVector(eo,h):or.addScaledVector(eo.sub(e),h))}e.add(or)}return e}raycast(t,e){let n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ar.copy(n.boundingSphere),ar.applyMatrix4(r),di.copy(t.ray).recast(t.near),!(ar.containsPoint(di.origin)===!1&&(di.intersectSphere(ar,Ec)===null||di.origin.distanceToSquared(Ec)>(t.far-t.near)**2))&&(Sc.copy(r).invert(),di.copy(t.ray).applyMatrix4(Sc),!(n.boundingBox!==null&&di.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,di)))}_computeIntersections(t,e,n){let i,r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,p=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,y=d.length;g<y;g++){let m=d[g],f=a[m.materialIndex],x=Math.max(m.start,p.start),_=Math.min(o.count,Math.min(m.start+m.count,p.start+p.count));for(let M=x,E=_;M<E;M+=3){let w=o.getX(M),A=o.getX(M+1),U=o.getX(M+2);i=fr(this,f,t,n,c,h,u,w,A,U),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{let g=Math.max(0,p.start),y=Math.min(o.count,p.start+p.count);for(let m=g,f=y;m<f;m+=3){let x=o.getX(m),_=o.getX(m+1),M=o.getX(m+2);i=fr(this,a,t,n,c,h,u,x,_,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,y=d.length;g<y;g++){let m=d[g],f=a[m.materialIndex],x=Math.max(m.start,p.start),_=Math.min(l.count,Math.min(m.start+m.count,p.start+p.count));for(let M=x,E=_;M<E;M+=3){let w=M,A=M+1,U=M+2;i=fr(this,f,t,n,c,h,u,w,A,U),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{let g=Math.max(0,p.start),y=Math.min(l.count,p.start+p.count);for(let m=g,f=y;m<f;m+=3){let x=m,_=m+1,M=m+2;i=fr(this,a,t,n,c,h,u,x,_,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}};function sd(s,t,e,n,i,r,a,o){let l;if(t.side===Ee?l=n.intersectTriangle(a,r,i,!0,o):l=n.intersectTriangle(i,r,a,t.side===ti,o),l===null)return null;dr.copy(o),dr.applyMatrix4(s.matrixWorld);let c=e.ray.origin.distanceTo(dr);return c<e.near||c>e.far?null:{distance:c,point:dr.clone(),object:s}}function fr(s,t,e,n,i,r,a,o,l,c){s.getVertexPosition(o,Oi),s.getVertexPosition(l,zi),s.getVertexPosition(c,Bi);let h=sd(s,t,e,n,Oi,zi,Bi,ur);if(h){i&&(lr.fromBufferAttribute(i,o),cr.fromBufferAttribute(i,l),hr.fromBufferAttribute(i,c),h.uv=Wi.getInterpolation(ur,Oi,zi,Bi,lr,cr,hr,new _t)),r&&(lr.fromBufferAttribute(r,o),cr.fromBufferAttribute(r,l),hr.fromBufferAttribute(r,c),h.uv1=Wi.getInterpolation(ur,Oi,zi,Bi,lr,cr,hr,new _t),h.uv2=h.uv1),a&&(wc.fromBufferAttribute(a,o),Tc.fromBufferAttribute(a,l),Ac.fromBufferAttribute(a,c),h.normal=Wi.getInterpolation(ur,Oi,zi,Bi,wc,Tc,Ac,new C),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:l,c,normal:new C,materialIndex:0};Wi.getNormal(Oi,zi,Bi,u.normal),h.face=u}return h}var xe=class s extends Te{constructor(t=1,e=1,n=1,i=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:a};let o=this;i=Math.floor(i),r=Math.floor(r),a=Math.floor(a);let l=[],c=[],h=[],u=[],d=0,p=0;g("z","y","x",-1,-1,n,e,t,a,r,0),g("z","y","x",1,-1,n,e,-t,a,r,1),g("x","z","y",1,1,t,n,e,i,a,2),g("x","z","y",1,-1,t,n,-e,i,a,3),g("x","y","z",1,-1,t,e,n,i,r,4),g("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(l),this.setAttribute("position",new se(c,3)),this.setAttribute("normal",new se(h,3)),this.setAttribute("uv",new se(u,2));function g(y,m,f,x,_,M,E,w,A,U,v){let b=M/A,F=E/U,k=M/2,nt=E/2,L=w/2,N=A+1,V=U+1,et=0,Y=0,J=new C;for(let D=0;D<V;D++){let j=D*F-nt;for(let rt=0;rt<N;rt++){let O=rt*b-k;J[y]=O*x,J[m]=j*_,J[f]=L,c.push(J.x,J.y,J.z),J[y]=0,J[m]=0,J[f]=w>0?1:-1,h.push(J.x,J.y,J.z),u.push(rt/A),u.push(1-D/U),et+=1}}for(let D=0;D<U;D++)for(let j=0;j<A;j++){let rt=d+j+N*D,O=d+j+N*(D+1),$=d+(j+1)+N*(D+1),ht=d+(j+1)+N*D;l.push(rt,O,ht),l.push(O,$,ht),Y+=6}o.addGroup(p,Y,v),p+=Y,d+=et}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function ji(s){let t={};for(let e in s){t[e]={};for(let n in s[e]){let i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function ke(s){let t={};for(let e=0;e<s.length;e++){let n=ji(s[e]);for(let i in n)t[i]=n[i]}return t}function rd(s){let t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function Mh(s){return s.getRenderTarget()===null?s.outputColorSpace:Qt.workingColorSpace}var ad={clone:ji,merge:ke},od=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,ld=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,en=class extends ii{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=od,this.fragmentShader=ld,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=ji(t.uniforms),this.uniformsGroups=rd(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let i in this.uniforms){let a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},kr=class extends we{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new le,this.projectionMatrix=new le,this.projectionMatrixInverse=new le,this.coordinateSystem=In}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Ne=class extends kr{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=vo*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(za*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return vo*2*Math.atan(Math.tan(za*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,i,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(za*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*i/l,e-=a.offsetY*n/c,i*=a.width/l,n*=a.height/c}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},ki=-90,Hi=1,Eo=class extends we{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let i=new Ne(ki,Hi,t,e);i.layers=this.layers,this.add(i);let r=new Ne(ki,Hi,t,e);r.layers=this.layers,this.add(r);let a=new Ne(ki,Hi,t,e);a.layers=this.layers,this.add(a);let o=new Ne(ki,Hi,t,e);o.layers=this.layers,this.add(o);let l=new Ne(ki,Hi,t,e);l.layers=this.layers,this.add(l);let c=new Ne(ki,Hi,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,i,r,a,o,l]=e;for(let c of e)this.remove(c);if(t===In)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Pr)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),p=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;let y=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,a),t.setRenderTarget(n,2,i),t.render(e,o),t.setRenderTarget(n,3,i),t.render(e,l),t.setRenderTarget(n,4,i),t.render(e,c),n.texture.generateMipmaps=y,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(u,d,p),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},Hr=class extends tn{constructor(t,e,n,i,r,a,o,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:$i,super(t,e,n,i,r,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},wo=class extends Un{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];e.encoding!==void 0&&(ws("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===yi?_e:Qe),this.texture=new Hr(i,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Ke}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new xe(5,5,5),r=new en({name:"CubemapFromEquirect",uniforms:ji(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ee,blending:$n});r.uniforms.tEquirect.value=e;let a=new It(i,r),o=e.minFilter;return e.minFilter===Ls&&(e.minFilter=Ke),new Eo(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,i){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(r)}},no=new C,cd=new C,hd=new Yt,Ln=class{constructor(t=new C(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let i=no.subVectors(n,e).cross(cd.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(no),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||hd.getNormalMatrix(t),i=this.coplanarPoint(no).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},fi=new ni,pr=new C,Ds=class{constructor(t=new Ln,e=new Ln,n=new Ln,i=new Ln,r=new Ln,a=new Ln){this.planes=[t,e,n,i,r,a]}set(t,e,n,i,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(i),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=In){let n=this.planes,i=t.elements,r=i[0],a=i[1],o=i[2],l=i[3],c=i[4],h=i[5],u=i[6],d=i[7],p=i[8],g=i[9],y=i[10],m=i[11],f=i[12],x=i[13],_=i[14],M=i[15];if(n[0].setComponents(l-r,d-c,m-p,M-f).normalize(),n[1].setComponents(l+r,d+c,m+p,M+f).normalize(),n[2].setComponents(l+a,d+h,m+g,M+x).normalize(),n[3].setComponents(l-a,d-h,m-g,M-x).normalize(),n[4].setComponents(l-o,d-u,m-y,M-_).normalize(),e===In)n[5].setComponents(l+o,d+u,m+y,M+_).normalize();else if(e===Pr)n[5].setComponents(o,u,y,_).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),fi.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),fi.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(fi)}intersectsSprite(t){return fi.center.set(0,0,0),fi.radius=.7071067811865476,fi.applyMatrix4(t.matrixWorld),this.intersectsSphere(fi)}intersectsSphere(t){let e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let i=e[n];if(pr.x=i.normal.x>0?t.max.x:t.min.x,pr.y=i.normal.y>0?t.max.y:t.min.y,pr.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(pr)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function bh(){let s=null,t=!1,e=null,n=null;function i(r,a){e(r,a),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function ud(s,t){let e=t.isWebGL2,n=new WeakMap;function i(c,h){let u=c.array,d=c.usage,p=u.byteLength,g=s.createBuffer();s.bindBuffer(h,g),s.bufferData(h,u,d),c.onUploadCallback();let y;if(u instanceof Float32Array)y=s.FLOAT;else if(u instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(e)y=s.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else y=s.UNSIGNED_SHORT;else if(u instanceof Int16Array)y=s.SHORT;else if(u instanceof Uint32Array)y=s.UNSIGNED_INT;else if(u instanceof Int32Array)y=s.INT;else if(u instanceof Int8Array)y=s.BYTE;else if(u instanceof Uint8Array)y=s.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)y=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:g,type:y,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:p}}function r(c,h,u){let d=h.array,p=h._updateRange,g=h.updateRanges;if(s.bindBuffer(u,c),p.count===-1&&g.length===0&&s.bufferSubData(u,0,d),g.length!==0){for(let y=0,m=g.length;y<m;y++){let f=g[y];e?s.bufferSubData(u,f.start*d.BYTES_PER_ELEMENT,d,f.start,f.count):s.bufferSubData(u,f.start*d.BYTES_PER_ELEMENT,d.subarray(f.start,f.start+f.count))}h.clearUpdateRanges()}p.count!==-1&&(e?s.bufferSubData(u,p.offset*d.BYTES_PER_ELEMENT,d,p.offset,p.count):s.bufferSubData(u,p.offset*d.BYTES_PER_ELEMENT,d.subarray(p.offset,p.offset+p.count)),p.count=-1),h.onUploadCallback()}function a(c){return c.isInterleavedBufferAttribute&&(c=c.data),n.get(c)}function o(c){c.isInterleavedBufferAttribute&&(c=c.data);let h=n.get(c);h&&(s.deleteBuffer(h.buffer),n.delete(c))}function l(c,h){if(c.isGLBufferAttribute){let d=n.get(c);(!d||d.version<c.version)&&n.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);let u=n.get(c);if(u===void 0)n.set(c,i(c,h));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,c,h),u.version=c.version}}return{get:a,remove:o,update:l}}var ts=class s extends Te{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};let r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(i),c=o+1,h=l+1,u=t/o,d=e/l,p=[],g=[],y=[],m=[];for(let f=0;f<h;f++){let x=f*d-a;for(let _=0;_<c;_++){let M=_*u-r;g.push(M,-x,0),y.push(0,0,1),m.push(_/o),m.push(1-f/l)}}for(let f=0;f<l;f++)for(let x=0;x<o;x++){let _=x+c*f,M=x+c*(f+1),E=x+1+c*(f+1),w=x+1+c*f;p.push(_,M,w),p.push(M,E,w)}this.setIndex(p),this.setAttribute("position",new se(g,3)),this.setAttribute("normal",new se(y,3)),this.setAttribute("uv",new se(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.widthSegments,t.heightSegments)}},dd=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,fd=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,pd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,md=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,gd=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,_d=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,xd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,yd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,vd=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Md=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,bd=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Sd=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Ed=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,wd=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Td=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Ad=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Rd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Cd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Pd=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ld=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Id=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Dd=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Ud=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Nd=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Fd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Od=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,zd=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Bd=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,kd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Hd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Vd="gl_FragColor = linearToOutputTexel( gl_FragColor );",Gd=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Wd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Xd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,qd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Yd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Zd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Jd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,$d=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Kd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Qd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,jd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,tf=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,ef=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,nf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,sf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,rf=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,af=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,of=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lf=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,cf=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,hf=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,uf=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,df=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ff=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,pf=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,mf=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,gf=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_f=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,xf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,yf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,vf=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Mf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,bf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Sf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ef=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,wf=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Tf=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Af=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Rf=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Cf=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Pf=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Lf=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,If=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Df=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Uf=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Nf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Ff=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Of=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,zf=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Bf=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,kf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Hf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Vf=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Gf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Wf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Xf=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,qf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Yf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Zf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Jf=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,$f=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Kf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Qf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,jf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,tp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,ep=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,np=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,ip=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,sp=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,rp=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,ap=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,op=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,lp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,cp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,hp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,up=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,dp=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,fp=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,mp=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,gp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,_p=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,yp=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,vp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Mp=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,bp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Sp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ep=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,wp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Tp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Ap=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rp=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Cp=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pp=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Lp=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ip=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Dp=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Up=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Np=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fp=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Op=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zp=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Bp=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Hp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Vp=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Gp=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Wp=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Xp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Gt={alphahash_fragment:dd,alphahash_pars_fragment:fd,alphamap_fragment:pd,alphamap_pars_fragment:md,alphatest_fragment:gd,alphatest_pars_fragment:_d,aomap_fragment:xd,aomap_pars_fragment:yd,batching_pars_vertex:vd,batching_vertex:Md,begin_vertex:bd,beginnormal_vertex:Sd,bsdfs:Ed,iridescence_fragment:wd,bumpmap_pars_fragment:Td,clipping_planes_fragment:Ad,clipping_planes_pars_fragment:Rd,clipping_planes_pars_vertex:Cd,clipping_planes_vertex:Pd,color_fragment:Ld,color_pars_fragment:Id,color_pars_vertex:Dd,color_vertex:Ud,common:Nd,cube_uv_reflection_fragment:Fd,defaultnormal_vertex:Od,displacementmap_pars_vertex:zd,displacementmap_vertex:Bd,emissivemap_fragment:kd,emissivemap_pars_fragment:Hd,colorspace_fragment:Vd,colorspace_pars_fragment:Gd,envmap_fragment:Wd,envmap_common_pars_fragment:Xd,envmap_pars_fragment:qd,envmap_pars_vertex:Yd,envmap_physical_pars_fragment:af,envmap_vertex:Zd,fog_vertex:Jd,fog_pars_vertex:$d,fog_fragment:Kd,fog_pars_fragment:Qd,gradientmap_pars_fragment:jd,lightmap_fragment:tf,lightmap_pars_fragment:ef,lights_lambert_fragment:nf,lights_lambert_pars_fragment:sf,lights_pars_begin:rf,lights_toon_fragment:of,lights_toon_pars_fragment:lf,lights_phong_fragment:cf,lights_phong_pars_fragment:hf,lights_physical_fragment:uf,lights_physical_pars_fragment:df,lights_fragment_begin:ff,lights_fragment_maps:pf,lights_fragment_end:mf,logdepthbuf_fragment:gf,logdepthbuf_pars_fragment:_f,logdepthbuf_pars_vertex:xf,logdepthbuf_vertex:yf,map_fragment:vf,map_pars_fragment:Mf,map_particle_fragment:bf,map_particle_pars_fragment:Sf,metalnessmap_fragment:Ef,metalnessmap_pars_fragment:wf,morphcolor_vertex:Tf,morphnormal_vertex:Af,morphtarget_pars_vertex:Rf,morphtarget_vertex:Cf,normal_fragment_begin:Pf,normal_fragment_maps:Lf,normal_pars_fragment:If,normal_pars_vertex:Df,normal_vertex:Uf,normalmap_pars_fragment:Nf,clearcoat_normal_fragment_begin:Ff,clearcoat_normal_fragment_maps:Of,clearcoat_pars_fragment:zf,iridescence_pars_fragment:Bf,opaque_fragment:kf,packing:Hf,premultiplied_alpha_fragment:Vf,project_vertex:Gf,dithering_fragment:Wf,dithering_pars_fragment:Xf,roughnessmap_fragment:qf,roughnessmap_pars_fragment:Yf,shadowmap_pars_fragment:Zf,shadowmap_pars_vertex:Jf,shadowmap_vertex:$f,shadowmask_pars_fragment:Kf,skinbase_vertex:Qf,skinning_pars_vertex:jf,skinning_vertex:tp,skinnormal_vertex:ep,specularmap_fragment:np,specularmap_pars_fragment:ip,tonemapping_fragment:sp,tonemapping_pars_fragment:rp,transmission_fragment:ap,transmission_pars_fragment:op,uv_pars_fragment:lp,uv_pars_vertex:cp,uv_vertex:hp,worldpos_vertex:up,background_vert:dp,background_frag:fp,backgroundCube_vert:pp,backgroundCube_frag:mp,cube_vert:gp,cube_frag:_p,depth_vert:xp,depth_frag:yp,distanceRGBA_vert:vp,distanceRGBA_frag:Mp,equirect_vert:bp,equirect_frag:Sp,linedashed_vert:Ep,linedashed_frag:wp,meshbasic_vert:Tp,meshbasic_frag:Ap,meshlambert_vert:Rp,meshlambert_frag:Cp,meshmatcap_vert:Pp,meshmatcap_frag:Lp,meshnormal_vert:Ip,meshnormal_frag:Dp,meshphong_vert:Up,meshphong_frag:Np,meshphysical_vert:Fp,meshphysical_frag:Op,meshtoon_vert:zp,meshtoon_frag:Bp,points_vert:kp,points_frag:Hp,shadow_vert:Vp,shadow_frag:Gp,sprite_vert:Wp,sprite_frag:Xp},mt={common:{diffuse:{value:new Ct(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Yt}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Yt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Yt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Yt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Yt},normalScale:{value:new _t(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Yt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Yt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Yt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Yt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ct(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ct(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0},uvTransform:{value:new Yt}},sprite:{diffuse:{value:new Ct(16777215)},opacity:{value:1},center:{value:new _t(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}}},vn={basic:{uniforms:ke([mt.common,mt.specularmap,mt.envmap,mt.aomap,mt.lightmap,mt.fog]),vertexShader:Gt.meshbasic_vert,fragmentShader:Gt.meshbasic_frag},lambert:{uniforms:ke([mt.common,mt.specularmap,mt.envmap,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.fog,mt.lights,{emissive:{value:new Ct(0)}}]),vertexShader:Gt.meshlambert_vert,fragmentShader:Gt.meshlambert_frag},phong:{uniforms:ke([mt.common,mt.specularmap,mt.envmap,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.fog,mt.lights,{emissive:{value:new Ct(0)},specular:{value:new Ct(1118481)},shininess:{value:30}}]),vertexShader:Gt.meshphong_vert,fragmentShader:Gt.meshphong_frag},standard:{uniforms:ke([mt.common,mt.envmap,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.roughnessmap,mt.metalnessmap,mt.fog,mt.lights,{emissive:{value:new Ct(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Gt.meshphysical_vert,fragmentShader:Gt.meshphysical_frag},toon:{uniforms:ke([mt.common,mt.aomap,mt.lightmap,mt.emissivemap,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.gradientmap,mt.fog,mt.lights,{emissive:{value:new Ct(0)}}]),vertexShader:Gt.meshtoon_vert,fragmentShader:Gt.meshtoon_frag},matcap:{uniforms:ke([mt.common,mt.bumpmap,mt.normalmap,mt.displacementmap,mt.fog,{matcap:{value:null}}]),vertexShader:Gt.meshmatcap_vert,fragmentShader:Gt.meshmatcap_frag},points:{uniforms:ke([mt.points,mt.fog]),vertexShader:Gt.points_vert,fragmentShader:Gt.points_frag},dashed:{uniforms:ke([mt.common,mt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Gt.linedashed_vert,fragmentShader:Gt.linedashed_frag},depth:{uniforms:ke([mt.common,mt.displacementmap]),vertexShader:Gt.depth_vert,fragmentShader:Gt.depth_frag},normal:{uniforms:ke([mt.common,mt.bumpmap,mt.normalmap,mt.displacementmap,{opacity:{value:1}}]),vertexShader:Gt.meshnormal_vert,fragmentShader:Gt.meshnormal_frag},sprite:{uniforms:ke([mt.sprite,mt.fog]),vertexShader:Gt.sprite_vert,fragmentShader:Gt.sprite_frag},background:{uniforms:{uvTransform:{value:new Yt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Gt.background_vert,fragmentShader:Gt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Gt.backgroundCube_vert,fragmentShader:Gt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Gt.cube_vert,fragmentShader:Gt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Gt.equirect_vert,fragmentShader:Gt.equirect_frag},distanceRGBA:{uniforms:ke([mt.common,mt.displacementmap,{referencePosition:{value:new C},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Gt.distanceRGBA_vert,fragmentShader:Gt.distanceRGBA_frag},shadow:{uniforms:ke([mt.lights,mt.fog,{color:{value:new Ct(0)},opacity:{value:1}}]),vertexShader:Gt.shadow_vert,fragmentShader:Gt.shadow_frag}};vn.physical={uniforms:ke([vn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Yt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Yt},clearcoatNormalScale:{value:new _t(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Yt},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Yt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Yt},sheen:{value:0},sheenColor:{value:new Ct(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Yt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Yt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Yt},transmissionSamplerSize:{value:new _t},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Yt},attenuationDistance:{value:0},attenuationColor:{value:new Ct(0)},specularColor:{value:new Ct(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Yt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Yt},anisotropyVector:{value:new _t},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Yt}}]),vertexShader:Gt.meshphysical_vert,fragmentShader:Gt.meshphysical_frag};var mr={r:0,b:0,g:0};function qp(s,t,e,n,i,r,a){let o=new Ct(0),l=r===!0?0:1,c,h,u=null,d=0,p=null;function g(m,f){let x=!1,_=f.isScene===!0?f.background:null;_&&_.isTexture&&(_=(f.backgroundBlurriness>0?e:t).get(_)),_===null?y(o,l):_&&_.isColor&&(y(_,1),x=!0);let M=s.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,a):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(s.autoClear||x)&&s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil),_&&(_.isCubeTexture||_.mapping===ra)?(h===void 0&&(h=new It(new xe(1,1,1),new en({name:"BackgroundCubeMaterial",uniforms:ji(vn.backgroundCube.uniforms),vertexShader:vn.backgroundCube.vertexShader,fragmentShader:vn.backgroundCube.fragmentShader,side:Ee,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(E,w,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),h.material.uniforms.envMap.value=_,h.material.uniforms.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,h.material.toneMapped=Qt.getTransfer(_.colorSpace)!==re,(u!==_||d!==_.version||p!==s.toneMapping)&&(h.material.needsUpdate=!0,u=_,d=_.version,p=s.toneMapping),h.layers.enableAll(),m.unshift(h,h.geometry,h.material,0,0,null)):_&&_.isTexture&&(c===void 0&&(c=new It(new ts(2,2),new en({name:"BackgroundMaterial",uniforms:ji(vn.background.uniforms),vertexShader:vn.background.vertexShader,fragmentShader:vn.background.fragmentShader,side:ti,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=_,c.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,c.material.toneMapped=Qt.getTransfer(_.colorSpace)!==re,_.matrixAutoUpdate===!0&&_.updateMatrix(),c.material.uniforms.uvTransform.value.copy(_.matrix),(u!==_||d!==_.version||p!==s.toneMapping)&&(c.material.needsUpdate=!0,u=_,d=_.version,p=s.toneMapping),c.layers.enableAll(),m.unshift(c,c.geometry,c.material,0,0,null))}function y(m,f){m.getRGB(mr,Mh(s)),n.buffers.color.setClear(mr.r,mr.g,mr.b,f,a)}return{getClearColor:function(){return o},setClearColor:function(m,f=1){o.set(m),l=f,y(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(m){l=m,y(o,l)},render:g}}function Yp(s,t,e,n){let i=s.getParameter(s.MAX_VERTEX_ATTRIBS),r=n.isWebGL2?null:t.get("OES_vertex_array_object"),a=n.isWebGL2||r!==null,o={},l=m(null),c=l,h=!1;function u(L,N,V,et,Y){let J=!1;if(a){let D=y(et,V,N);c!==D&&(c=D,p(c.object)),J=f(L,et,V,Y),J&&x(L,et,V,Y)}else{let D=N.wireframe===!0;(c.geometry!==et.id||c.program!==V.id||c.wireframe!==D)&&(c.geometry=et.id,c.program=V.id,c.wireframe=D,J=!0)}Y!==null&&e.update(Y,s.ELEMENT_ARRAY_BUFFER),(J||h)&&(h=!1,U(L,N,V,et),Y!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,e.get(Y).buffer))}function d(){return n.isWebGL2?s.createVertexArray():r.createVertexArrayOES()}function p(L){return n.isWebGL2?s.bindVertexArray(L):r.bindVertexArrayOES(L)}function g(L){return n.isWebGL2?s.deleteVertexArray(L):r.deleteVertexArrayOES(L)}function y(L,N,V){let et=V.wireframe===!0,Y=o[L.id];Y===void 0&&(Y={},o[L.id]=Y);let J=Y[N.id];J===void 0&&(J={},Y[N.id]=J);let D=J[et];return D===void 0&&(D=m(d()),J[et]=D),D}function m(L){let N=[],V=[],et=[];for(let Y=0;Y<i;Y++)N[Y]=0,V[Y]=0,et[Y]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:N,enabledAttributes:V,attributeDivisors:et,object:L,attributes:{},index:null}}function f(L,N,V,et){let Y=c.attributes,J=N.attributes,D=0,j=V.getAttributes();for(let rt in j)if(j[rt].location>=0){let $=Y[rt],ht=J[rt];if(ht===void 0&&(rt==="instanceMatrix"&&L.instanceMatrix&&(ht=L.instanceMatrix),rt==="instanceColor"&&L.instanceColor&&(ht=L.instanceColor)),$===void 0||$.attribute!==ht||ht&&$.data!==ht.data)return!0;D++}return c.attributesNum!==D||c.index!==et}function x(L,N,V,et){let Y={},J=N.attributes,D=0,j=V.getAttributes();for(let rt in j)if(j[rt].location>=0){let $=J[rt];$===void 0&&(rt==="instanceMatrix"&&L.instanceMatrix&&($=L.instanceMatrix),rt==="instanceColor"&&L.instanceColor&&($=L.instanceColor));let ht={};ht.attribute=$,$&&$.data&&(ht.data=$.data),Y[rt]=ht,D++}c.attributes=Y,c.attributesNum=D,c.index=et}function _(){let L=c.newAttributes;for(let N=0,V=L.length;N<V;N++)L[N]=0}function M(L){E(L,0)}function E(L,N){let V=c.newAttributes,et=c.enabledAttributes,Y=c.attributeDivisors;V[L]=1,et[L]===0&&(s.enableVertexAttribArray(L),et[L]=1),Y[L]!==N&&((n.isWebGL2?s:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](L,N),Y[L]=N)}function w(){let L=c.newAttributes,N=c.enabledAttributes;for(let V=0,et=N.length;V<et;V++)N[V]!==L[V]&&(s.disableVertexAttribArray(V),N[V]=0)}function A(L,N,V,et,Y,J,D){D===!0?s.vertexAttribIPointer(L,N,V,Y,J):s.vertexAttribPointer(L,N,V,et,Y,J)}function U(L,N,V,et){if(n.isWebGL2===!1&&(L.isInstancedMesh||et.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;_();let Y=et.attributes,J=V.getAttributes(),D=N.defaultAttributeValues;for(let j in J){let rt=J[j];if(rt.location>=0){let O=Y[j];if(O===void 0&&(j==="instanceMatrix"&&L.instanceMatrix&&(O=L.instanceMatrix),j==="instanceColor"&&L.instanceColor&&(O=L.instanceColor)),O!==void 0){let $=O.normalized,ht=O.itemSize,ft=e.get(O);if(ft===void 0)continue;let dt=ft.buffer,X=ft.type,Q=ft.bytesPerElement,tt=n.isWebGL2===!0&&(X===s.INT||X===s.UNSIGNED_INT||O.gpuType===ch);if(O.isInterleavedBufferAttribute){let xt=O.data,P=xt.stride,st=O.offset;if(xt.isInstancedInterleavedBuffer){for(let H=0;H<rt.locationSize;H++)E(rt.location+H,xt.meshPerAttribute);L.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=xt.meshPerAttribute*xt.count)}else for(let H=0;H<rt.locationSize;H++)M(rt.location+H);s.bindBuffer(s.ARRAY_BUFFER,dt);for(let H=0;H<rt.locationSize;H++)A(rt.location+H,ht/rt.locationSize,X,$,P*Q,(st+ht/rt.locationSize*H)*Q,tt)}else{if(O.isInstancedBufferAttribute){for(let xt=0;xt<rt.locationSize;xt++)E(rt.location+xt,O.meshPerAttribute);L.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=O.meshPerAttribute*O.count)}else for(let xt=0;xt<rt.locationSize;xt++)M(rt.location+xt);s.bindBuffer(s.ARRAY_BUFFER,dt);for(let xt=0;xt<rt.locationSize;xt++)A(rt.location+xt,ht/rt.locationSize,X,$,ht*Q,ht/rt.locationSize*xt*Q,tt)}}else if(D!==void 0){let $=D[j];if($!==void 0)switch($.length){case 2:s.vertexAttrib2fv(rt.location,$);break;case 3:s.vertexAttrib3fv(rt.location,$);break;case 4:s.vertexAttrib4fv(rt.location,$);break;default:s.vertexAttrib1fv(rt.location,$)}}}}w()}function v(){k();for(let L in o){let N=o[L];for(let V in N){let et=N[V];for(let Y in et)g(et[Y].object),delete et[Y];delete N[V]}delete o[L]}}function b(L){if(o[L.id]===void 0)return;let N=o[L.id];for(let V in N){let et=N[V];for(let Y in et)g(et[Y].object),delete et[Y];delete N[V]}delete o[L.id]}function F(L){for(let N in o){let V=o[N];if(V[L.id]===void 0)continue;let et=V[L.id];for(let Y in et)g(et[Y].object),delete et[Y];delete V[L.id]}}function k(){nt(),h=!0,c!==l&&(c=l,p(c.object))}function nt(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:u,reset:k,resetDefaultState:nt,dispose:v,releaseStatesOfGeometry:b,releaseStatesOfProgram:F,initAttributes:_,enableAttribute:M,disableUnusedAttributes:w}}function Zp(s,t,e,n){let i=n.isWebGL2,r;function a(h){r=h}function o(h,u){s.drawArrays(r,h,u),e.update(u,r,1)}function l(h,u,d){if(d===0)return;let p,g;if(i)p=s,g="drawArraysInstanced";else if(p=t.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",p===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[g](r,h,u,d),e.update(u,r,d)}function c(h,u,d){if(d===0)return;let p=t.get("WEBGL_multi_draw");if(p===null)for(let g=0;g<d;g++)this.render(h[g],u[g]);else{p.multiDrawArraysWEBGL(r,h,0,u,0,d);let g=0;for(let y=0;y<d;y++)g+=u[y];e.update(g,r,1)}}this.setMode=a,this.render=o,this.renderInstances=l,this.renderMultiDraw=c}function Jp(s,t,e){let n;function i(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){let A=t.get("EXT_texture_filter_anisotropic");n=s.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function r(A){if(A==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let a=typeof WebGL2RenderingContext<"u"&&s.constructor.name==="WebGL2RenderingContext",o=e.precision!==void 0?e.precision:"highp",l=r(o);l!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",l,"instead."),o=l);let c=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,u=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),d=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),p=s.getParameter(s.MAX_TEXTURE_SIZE),g=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),y=s.getParameter(s.MAX_VERTEX_ATTRIBS),m=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),f=s.getParameter(s.MAX_VARYING_VECTORS),x=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),_=d>0,M=a||t.has("OES_texture_float"),E=_&&M,w=a?s.getParameter(s.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:c,getMaxAnisotropy:i,getMaxPrecision:r,precision:o,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:d,maxTextureSize:p,maxCubemapSize:g,maxAttributes:y,maxVertexUniforms:m,maxVaryings:f,maxFragmentUniforms:x,vertexTextures:_,floatFragmentTextures:M,floatVertexTextures:E,maxSamples:w}}function $p(s){let t=this,e=null,n=0,i=!1,r=!1,a=new Ln,o=new Yt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let p=u.length!==0||d||n!==0||i;return i=d,n=u.length,p},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,p){let g=u.clippingPlanes,y=u.clipIntersection,m=u.clipShadows,f=s.get(u);if(!i||g===null||g.length===0||r&&!m)r?h(null):c();else{let x=r?0:n,_=x*4,M=f.clippingState||null;l.value=M,M=h(g,d,_,p);for(let E=0;E!==_;++E)M[E]=e[E];f.clippingState=M,this.numIntersection=y?this.numPlanes:0,this.numPlanes+=x}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,p,g){let y=u!==null?u.length:0,m=null;if(y!==0){if(m=l.value,g!==!0||m===null){let f=p+y*4,x=d.matrixWorldInverse;o.getNormalMatrix(x),(m===null||m.length<f)&&(m=new Float32Array(f));for(let _=0,M=p;_!==y;++_,M+=4)a.copy(u[_]).applyMatrix4(x,o),a.normal.toArray(m,M),m[M+3]=a.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=y,t.numIntersection=0,m}}function Kp(s){let t=new WeakMap;function e(a,o){return o===go?a.mapping=$i:o===_o&&(a.mapping=Ki),a}function n(a){if(a&&a.isTexture){let o=a.mapping;if(o===go||o===_o)if(t.has(a)){let l=t.get(a).texture;return e(l,a.mapping)}else{let l=a.image;if(l&&l.height>0){let c=new wo(l.height/2);return c.fromEquirectangularTexture(s,a),t.set(a,c),a.addEventListener("dispose",i),e(c.texture,a.mapping)}else return null}}return a}function i(a){let o=a.target;o.removeEventListener("dispose",i);let l=t.get(o);l!==void 0&&(t.delete(o),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var Vr=class extends kr{constructor(t=-1,e=1,n=1,i=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,r=n-t,a=n+t,o=i+e,l=i-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Xi=4,Rc=[.125,.215,.35,.446,.526,.582],gi=20,io=new Vr,Cc=new Ct,so=null,ro=0,ao=0,pi=(1+Math.sqrt(5))/2,Vi=1/pi,Pc=[new C(1,1,1),new C(-1,1,1),new C(1,1,-1),new C(-1,1,-1),new C(0,pi,Vi),new C(0,pi,-Vi),new C(Vi,0,pi),new C(-Vi,0,pi),new C(pi,Vi,0),new C(-pi,Vi,0)],es=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100){so=this._renderer.getRenderTarget(),ro=this._renderer.getActiveCubeFace(),ao=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,i,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Dc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Ic(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(so,ro,ao),t.scissorTest=!1,gr(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===$i||t.mapping===Ki?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),so=this._renderer.getRenderTarget(),ro=this._renderer.getActiveCubeFace(),ao=this._renderer.getActiveMipmapLevel();let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Ke,minFilter:Ke,generateMipmaps:!1,type:Is,format:pn,colorSpace:Dn,depthBuffer:!1},i=Lc(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Lc(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Qp(r)),this._blurMaterial=jp(r,t,e)}return i}_compileMaterial(t){let e=new It(this._lodPlanes[0],t);this._renderer.compile(e,io)}_sceneToCubeUV(t,e,n,i){let o=new Ne(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(Cc),h.toneMapping=Qn,h.autoClear=!1;let p=new pe({name:"PMREM.Background",side:Ee,depthWrite:!1,depthTest:!1}),g=new It(new xe,p),y=!1,m=t.background;m?m.isColor&&(p.color.copy(m),t.background=null,y=!0):(p.color.copy(Cc),y=!0);for(let f=0;f<6;f++){let x=f%3;x===0?(o.up.set(0,l[f],0),o.lookAt(c[f],0,0)):x===1?(o.up.set(0,0,l[f]),o.lookAt(0,c[f],0)):(o.up.set(0,l[f],0),o.lookAt(0,0,c[f]));let _=this._cubeSize;gr(i,x*_,f>2?_:0,_,_),h.setRenderTarget(i),y&&h.render(g,o),h.render(t,o)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,t.background=m}_textureToCubeUV(t,e){let n=this._renderer,i=t.mapping===$i||t.mapping===Ki;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=Dc()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Ic());let r=i?this._cubemapMaterial:this._equirectMaterial,a=new It(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let l=this._cubeSize;gr(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,io)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let i=1;i<this._lodPlanes.length;i++){let r=Math.sqrt(this._sigmas[i]*this._sigmas[i]-this._sigmas[i-1]*this._sigmas[i-1]),a=Pc[(i-1)%Pc.length];this._blur(t,i-1,i,r,a)}e.autoClear=n}_blur(t,e,n,i,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,i,"latitudinal",r),this._halfBlur(a,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,a,o){let l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new It(this._lodPlanes[i],c),d=c.uniforms,p=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*p):2*Math.PI/(2*gi-1),y=r/g,m=isFinite(r)?1+Math.floor(h*y):gi;m>gi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${gi}`);let f=[],x=0;for(let A=0;A<gi;++A){let U=A/y,v=Math.exp(-U*U/2);f.push(v),A===0?x+=v:A<m&&(x+=2*v)}for(let A=0;A<f.length;A++)f[A]=f[A]/x;d.envMap.value=t.texture,d.samples.value=m,d.weights.value=f,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);let{_lodMax:_}=this;d.dTheta.value=g,d.mipInt.value=_-n;let M=this._sizeLods[i],E=3*M*(i>_-Xi?i-_+Xi:0),w=4*(this._cubeSize-M);gr(e,E,w,3*M,2*M),l.setRenderTarget(e),l.render(u,io)}};function Qp(s){let t=[],e=[],n=[],i=s,r=s-Xi+1+Rc.length;for(let a=0;a<r;a++){let o=Math.pow(2,i);e.push(o);let l=1/o;a>s-Xi?l=Rc[a-s+Xi-1]:a===0&&(l=0),n.push(l);let c=1/(o-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],p=6,g=6,y=3,m=2,f=1,x=new Float32Array(y*g*p),_=new Float32Array(m*g*p),M=new Float32Array(f*g*p);for(let w=0;w<p;w++){let A=w%3*2/3-1,U=w>2?0:-1,v=[A,U,0,A+2/3,U,0,A+2/3,U+1,0,A,U,0,A+2/3,U+1,0,A,U+1,0];x.set(v,y*g*w),_.set(d,m*g*w);let b=[w,w,w,w,w,w];M.set(b,f*g*w)}let E=new Te;E.setAttribute("position",new jt(x,y)),E.setAttribute("uv",new jt(_,m)),E.setAttribute("faceIndex",new jt(M,f)),t.push(E),i>Xi&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function Lc(s,t,e){let n=new Un(s,t,e);return n.texture.mapping=ra,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function gr(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function jp(s,t,e){let n=new Float32Array(gi),i=new C(0,1,0);return new en({name:"SphericalGaussianBlur",defines:{n:gi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:hl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function Ic(){return new en({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:hl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function Dc(){return new en({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:hl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function hl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function tm(s){let t=new WeakMap,e=null;function n(o){if(o&&o.isTexture){let l=o.mapping,c=l===go||l===_o,h=l===$i||l===Ki;if(c||h)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=t.get(o);return e===null&&(e=new es(s)),u=c?e.fromEquirectangular(o,u):e.fromCubemap(o,u),t.set(o,u),u.texture}else{if(t.has(o))return t.get(o).texture;{let u=o.image;if(c&&u&&u.height>0||h&&u&&i(u)){e===null&&(e=new es(s));let d=c?e.fromEquirectangular(o):e.fromCubemap(o);return t.set(o,d),o.addEventListener("dispose",r),d.texture}else return null}}}return o}function i(o){let l=0,c=6;for(let h=0;h<c;h++)o[h]!==void 0&&l++;return l===c}function r(o){let l=o.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function em(s){let t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=s.getExtension("WEBGL_depth_texture")||s.getExtension("MOZ_WEBGL_depth_texture")||s.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=s.getExtension("EXT_texture_filter_anisotropic")||s.getExtension("MOZ_EXT_texture_filter_anisotropic")||s.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=s.getExtension("WEBGL_compressed_texture_s3tc")||s.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=s.getExtension("WEBGL_compressed_texture_pvrtc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=s.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){let i=e(n);return i===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function nm(s,t,e,n){let i={},r=new WeakMap;function a(u){let d=u.target;d.index!==null&&t.remove(d.index);for(let g in d.attributes)t.remove(d.attributes[g]);for(let g in d.morphAttributes){let y=d.morphAttributes[g];for(let m=0,f=y.length;m<f;m++)t.remove(y[m])}d.removeEventListener("dispose",a),delete i[d.id];let p=r.get(d);p&&(t.remove(p),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function o(u,d){return i[d.id]===!0||(d.addEventListener("dispose",a),i[d.id]=!0,e.memory.geometries++),d}function l(u){let d=u.attributes;for(let g in d)t.update(d[g],s.ARRAY_BUFFER);let p=u.morphAttributes;for(let g in p){let y=p[g];for(let m=0,f=y.length;m<f;m++)t.update(y[m],s.ARRAY_BUFFER)}}function c(u){let d=[],p=u.index,g=u.attributes.position,y=0;if(p!==null){let x=p.array;y=p.version;for(let _=0,M=x.length;_<M;_+=3){let E=x[_+0],w=x[_+1],A=x[_+2];d.push(E,w,w,A,A,E)}}else if(g!==void 0){let x=g.array;y=g.version;for(let _=0,M=x.length/3-1;_<M;_+=3){let E=_+0,w=_+1,A=_+2;d.push(E,w,w,A,A,E)}}else return;let m=new(yh(d)?Br:zr)(d,1);m.version=y;let f=r.get(u);f&&t.remove(f),r.set(u,m)}function h(u){let d=r.get(u);if(d){let p=u.index;p!==null&&d.version<p.version&&c(u)}else c(u);return r.get(u)}return{get:o,update:l,getWireframeAttribute:h}}function im(s,t,e,n){let i=n.isWebGL2,r;function a(p){r=p}let o,l;function c(p){o=p.type,l=p.bytesPerElement}function h(p,g){s.drawElements(r,g,o,p*l),e.update(g,r,1)}function u(p,g,y){if(y===0)return;let m,f;if(i)m=s,f="drawElementsInstanced";else if(m=t.get("ANGLE_instanced_arrays"),f="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[f](r,g,o,p*l,y),e.update(g,r,y)}function d(p,g,y){if(y===0)return;let m=t.get("WEBGL_multi_draw");if(m===null)for(let f=0;f<y;f++)this.render(p[f]/l,g[f]);else{m.multiDrawElementsWEBGL(r,g,0,o,p,0,y);let f=0;for(let x=0;x<y;x++)f+=g[x];e.update(f,r,1)}}this.setMode=a,this.setIndex=c,this.render=h,this.renderInstances=u,this.renderMultiDraw=d}function sm(s){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case s.TRIANGLES:e.triangles+=o*(r/3);break;case s.LINES:e.lines+=o*(r/2);break;case s.LINE_STRIP:e.lines+=o*(r-1);break;case s.LINE_LOOP:e.lines+=o*r;break;case s.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function rm(s,t){return s[0]-t[0]}function am(s,t){return Math.abs(t[1])-Math.abs(s[1])}function om(s,t,e){let n={},i=new Float32Array(8),r=new WeakMap,a=new oe,o=[];for(let c=0;c<8;c++)o[c]=[c,0];function l(c,h,u){let d=c.morphTargetInfluences;if(t.isWebGL2===!0){let p=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,g=p!==void 0?p.length:0,y=r.get(h);if(y===void 0||y.count!==g){let L=function(){k.dispose(),r.delete(h),h.removeEventListener("dispose",L)};y!==void 0&&y.texture.dispose();let x=h.morphAttributes.position!==void 0,_=h.morphAttributes.normal!==void 0,M=h.morphAttributes.color!==void 0,E=h.morphAttributes.position||[],w=h.morphAttributes.normal||[],A=h.morphAttributes.color||[],U=0;x===!0&&(U=1),_===!0&&(U=2),M===!0&&(U=3);let v=h.attributes.position.count*U,b=1;v>t.maxTextureSize&&(b=Math.ceil(v/t.maxTextureSize),v=t.maxTextureSize);let F=new Float32Array(v*b*4*g),k=new Ur(F,v,b,g);k.type=Jn,k.needsUpdate=!0;let nt=U*4;for(let N=0;N<g;N++){let V=E[N],et=w[N],Y=A[N],J=v*b*4*N;for(let D=0;D<V.count;D++){let j=D*nt;x===!0&&(a.fromBufferAttribute(V,D),F[J+j+0]=a.x,F[J+j+1]=a.y,F[J+j+2]=a.z,F[J+j+3]=0),_===!0&&(a.fromBufferAttribute(et,D),F[J+j+4]=a.x,F[J+j+5]=a.y,F[J+j+6]=a.z,F[J+j+7]=0),M===!0&&(a.fromBufferAttribute(Y,D),F[J+j+8]=a.x,F[J+j+9]=a.y,F[J+j+10]=a.z,F[J+j+11]=Y.itemSize===4?a.w:1)}}y={count:g,texture:k,size:new _t(v,b)},r.set(h,y),h.addEventListener("dispose",L)}let m=0;for(let x=0;x<d.length;x++)m+=d[x];let f=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(s,"morphTargetBaseInfluence",f),u.getUniforms().setValue(s,"morphTargetInfluences",d),u.getUniforms().setValue(s,"morphTargetsTexture",y.texture,e),u.getUniforms().setValue(s,"morphTargetsTextureSize",y.size)}else{let p=d===void 0?0:d.length,g=n[h.id];if(g===void 0||g.length!==p){g=[];for(let _=0;_<p;_++)g[_]=[_,0];n[h.id]=g}for(let _=0;_<p;_++){let M=g[_];M[0]=_,M[1]=d[_]}g.sort(am);for(let _=0;_<8;_++)_<p&&g[_][1]?(o[_][0]=g[_][0],o[_][1]=g[_][1]):(o[_][0]=Number.MAX_SAFE_INTEGER,o[_][1]=0);o.sort(rm);let y=h.morphAttributes.position,m=h.morphAttributes.normal,f=0;for(let _=0;_<8;_++){let M=o[_],E=M[0],w=M[1];E!==Number.MAX_SAFE_INTEGER&&w?(y&&h.getAttribute("morphTarget"+_)!==y[E]&&h.setAttribute("morphTarget"+_,y[E]),m&&h.getAttribute("morphNormal"+_)!==m[E]&&h.setAttribute("morphNormal"+_,m[E]),i[_]=w,f+=w):(y&&h.hasAttribute("morphTarget"+_)===!0&&h.deleteAttribute("morphTarget"+_),m&&h.hasAttribute("morphNormal"+_)===!0&&h.deleteAttribute("morphNormal"+_),i[_]=0)}let x=h.morphTargetsRelative?1:1-f;u.getUniforms().setValue(s,"morphTargetBaseInfluence",x),u.getUniforms().setValue(s,"morphTargetInfluences",i)}}return{update:l}}function lm(s,t,e,n){let i=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=t.get(l,h);if(i.get(u)!==c&&(t.update(u),i.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),i.get(l)!==c&&(e.update(l.instanceMatrix,s.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,s.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;i.get(d)!==c&&(d.update(),i.set(d,c))}return u}function a(){i=new WeakMap}function o(l){let c=l.target;c.removeEventListener("dispose",o),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:a}}var Gr=class extends tn{constructor(t,e,n,i,r,a,o,l,c,h){if(h=h!==void 0?h:xi,h!==xi&&h!==Qi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===xi&&(n=Zn),n===void 0&&h===Qi&&(n=_i),super(null,i,r,a,o,l,h,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:He,this.minFilter=l!==void 0?l:He,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},Sh=new tn,Eh=new Gr(1,1);Eh.compareFunction=xh;var wh=new Ur,Th=new So,Ah=new Hr,Uc=[],Nc=[],Fc=new Float32Array(16),Oc=new Float32Array(9),zc=new Float32Array(4);function as(s,t,e){let n=s[0];if(n<=0||n>0)return s;let i=t*e,r=Uc[i];if(r===void 0&&(r=new Float32Array(i),Uc[i]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,s[a].toArray(r,o)}return r}function ye(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function ve(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function oa(s,t){let e=Nc[t];e===void 0&&(e=new Int32Array(t),Nc[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function cm(s,t){let e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function hm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ye(e,t))return;s.uniform2fv(this.addr,t),ve(e,t)}}function um(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(ye(e,t))return;s.uniform3fv(this.addr,t),ve(e,t)}}function dm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ye(e,t))return;s.uniform4fv(this.addr,t),ve(e,t)}}function fm(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ye(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),ve(e,t)}else{if(ye(e,n))return;zc.set(n),s.uniformMatrix2fv(this.addr,!1,zc),ve(e,n)}}function pm(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ye(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),ve(e,t)}else{if(ye(e,n))return;Oc.set(n),s.uniformMatrix3fv(this.addr,!1,Oc),ve(e,n)}}function mm(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ye(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),ve(e,t)}else{if(ye(e,n))return;Fc.set(n),s.uniformMatrix4fv(this.addr,!1,Fc),ve(e,n)}}function gm(s,t){let e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function _m(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ye(e,t))return;s.uniform2iv(this.addr,t),ve(e,t)}}function xm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ye(e,t))return;s.uniform3iv(this.addr,t),ve(e,t)}}function ym(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ye(e,t))return;s.uniform4iv(this.addr,t),ve(e,t)}}function vm(s,t){let e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function Mm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ye(e,t))return;s.uniform2uiv(this.addr,t),ve(e,t)}}function bm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ye(e,t))return;s.uniform3uiv(this.addr,t),ve(e,t)}}function Sm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ye(e,t))return;s.uniform4uiv(this.addr,t),ve(e,t)}}function Em(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r=this.type===s.SAMPLER_2D_SHADOW?Eh:Sh;e.setTexture2D(t||r,i)}function wm(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Th,i)}function Tm(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||Ah,i)}function Am(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||wh,i)}function Rm(s){switch(s){case 5126:return cm;case 35664:return hm;case 35665:return um;case 35666:return dm;case 35674:return fm;case 35675:return pm;case 35676:return mm;case 5124:case 35670:return gm;case 35667:case 35671:return _m;case 35668:case 35672:return xm;case 35669:case 35673:return ym;case 5125:return vm;case 36294:return Mm;case 36295:return bm;case 36296:return Sm;case 35678:case 36198:case 36298:case 36306:case 35682:return Em;case 35679:case 36299:case 36307:return wm;case 35680:case 36300:case 36308:case 36293:return Tm;case 36289:case 36303:case 36311:case 36292:return Am}}function Cm(s,t){s.uniform1fv(this.addr,t)}function Pm(s,t){let e=as(t,this.size,2);s.uniform2fv(this.addr,e)}function Lm(s,t){let e=as(t,this.size,3);s.uniform3fv(this.addr,e)}function Im(s,t){let e=as(t,this.size,4);s.uniform4fv(this.addr,e)}function Dm(s,t){let e=as(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function Um(s,t){let e=as(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function Nm(s,t){let e=as(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function Fm(s,t){s.uniform1iv(this.addr,t)}function Om(s,t){s.uniform2iv(this.addr,t)}function zm(s,t){s.uniform3iv(this.addr,t)}function Bm(s,t){s.uniform4iv(this.addr,t)}function km(s,t){s.uniform1uiv(this.addr,t)}function Hm(s,t){s.uniform2uiv(this.addr,t)}function Vm(s,t){s.uniform3uiv(this.addr,t)}function Gm(s,t){s.uniform4uiv(this.addr,t)}function Wm(s,t,e){let n=this.cache,i=t.length,r=oa(e,i);ye(n,r)||(s.uniform1iv(this.addr,r),ve(n,r));for(let a=0;a!==i;++a)e.setTexture2D(t[a]||Sh,r[a])}function Xm(s,t,e){let n=this.cache,i=t.length,r=oa(e,i);ye(n,r)||(s.uniform1iv(this.addr,r),ve(n,r));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||Th,r[a])}function qm(s,t,e){let n=this.cache,i=t.length,r=oa(e,i);ye(n,r)||(s.uniform1iv(this.addr,r),ve(n,r));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||Ah,r[a])}function Ym(s,t,e){let n=this.cache,i=t.length,r=oa(e,i);ye(n,r)||(s.uniform1iv(this.addr,r),ve(n,r));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||wh,r[a])}function Zm(s){switch(s){case 5126:return Cm;case 35664:return Pm;case 35665:return Lm;case 35666:return Im;case 35674:return Dm;case 35675:return Um;case 35676:return Nm;case 5124:case 35670:return Fm;case 35667:case 35671:return Om;case 35668:case 35672:return zm;case 35669:case 35673:return Bm;case 5125:return km;case 36294:return Hm;case 36295:return Vm;case 36296:return Gm;case 35678:case 36198:case 36298:case 36306:case 35682:return Wm;case 35679:case 36299:case 36307:return Xm;case 35680:case 36300:case 36308:case 36293:return qm;case 36289:case 36303:case 36311:case 36292:return Ym}}var To=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Rm(e.type)}},Ao=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Zm(e.type)}},Ro=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let i=this.seq;for(let r=0,a=i.length;r!==a;++r){let o=i[r];o.setValue(t,e[o.id],n)}}},oo=/(\w+)(\])?(\[|\.)?/g;function Bc(s,t){s.seq.push(t),s.map[t.id]=t}function Jm(s,t,e){let n=s.name,i=n.length;for(oo.lastIndex=0;;){let r=oo.exec(n),a=oo.lastIndex,o=r[1],l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===i){Bc(e,c===void 0?new To(o,s,t):new Ao(o,s,t));break}else{let u=e.map[o];u===void 0&&(u=new Ro(o),Bc(e,u)),e=u}}}var Ji=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){let r=t.getActiveUniform(e,i),a=t.getUniformLocation(e,r.name);Jm(r,a,this)}}setValue(t,e,n,i){let r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){let i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,a=e.length;r!==a;++r){let o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,i)}}static seqWithValue(t,e){let n=[];for(let i=0,r=t.length;i!==r;++i){let a=t[i];a.id in e&&n.push(a)}return n}};function kc(s,t,e){let n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}var $m=37297,Km=0;function Qm(s,t){let e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=i;a<r;a++){let o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}function jm(s){let t=Qt.getPrimaries(Qt.workingColorSpace),e=Qt.getPrimaries(s),n;switch(t===e?n="":t===Cr&&e===Rr?n="LinearDisplayP3ToLinearSRGB":t===Rr&&e===Cr&&(n="LinearSRGBToLinearDisplayP3"),s){case Dn:case aa:return[n,"LinearTransferOETF"];case _e:case cl:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",s),[n,"LinearTransferOETF"]}}function Hc(s,t,e){let n=s.getShaderParameter(t,s.COMPILE_STATUS),i=s.getShaderInfoLog(t).trim();if(n&&i==="")return"";let r=/ERROR: 0:(\d+)/.exec(i);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+i+`

`+Qm(s.getShaderSource(t),a)}else return i}function tg(s,t){let e=jm(t);return`vec4 ${s}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function eg(s,t){let e;switch(t){case yu:e="Linear";break;case vu:e="Reinhard";break;case Mu:e="OptimizedCineon";break;case ol:e="ACESFilmic";break;case Su:e="AgX";break;case bu:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function ng(s){return[s.extensionDerivatives||s.envMapCubeUVHeight||s.bumpMap||s.normalMapTangentSpace||s.clearcoatNormalMap||s.flatShading||s.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(s.extensionFragDepth||s.logarithmicDepthBuffer)&&s.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",s.extensionDrawBuffers&&s.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(s.extensionShaderTextureLOD||s.envMap||s.transmission)&&s.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(qi).join(`
`)}function ig(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(qi).join(`
`)}function sg(s){let t=[];for(let e in s){let n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function rg(s,t){let e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){let r=s.getActiveAttrib(t,i),a=r.name,o=1;r.type===s.FLOAT_MAT2&&(o=2),r.type===s.FLOAT_MAT3&&(o=3),r.type===s.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:s.getAttribLocation(t,a),locationSize:o}}return e}function qi(s){return s!==""}function Vc(s,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Gc(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var ag=/^[ \t]*#include +<([\w\d./]+)>/gm;function Co(s){return s.replace(ag,lg)}var og=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function lg(s,t){let e=Gt[t];if(e===void 0){let n=og.get(t);if(n!==void 0)e=Gt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Co(e)}var cg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Wc(s){return s.replace(cg,hg)}function hg(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function Xc(s){let t="precision "+s.precision+` float;
precision `+s.precision+" int;";return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function ug(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===ah?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===Yh?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===Pn&&(t="SHADOWMAP_TYPE_VSM"),t}function dg(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case $i:case Ki:t="ENVMAP_TYPE_CUBE";break;case ra:t="ENVMAP_TYPE_CUBE_UV";break}return t}function fg(s){let t="ENVMAP_MODE_REFLECTION";return s.envMap&&s.envMapMode===Ki&&(t="ENVMAP_MODE_REFRACTION"),t}function pg(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case oh:t="ENVMAP_BLENDING_MULTIPLY";break;case _u:t="ENVMAP_BLENDING_MIX";break;case xu:t="ENVMAP_BLENDING_ADD";break}return t}function mg(s){let t=s.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function gg(s,t,e,n){let i=s.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,l=ug(e),c=dg(e),h=fg(e),u=pg(e),d=mg(e),p=e.isWebGL2?"":ng(e),g=ig(e),y=sg(r),m=i.createProgram(),f,x,_=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(f=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(qi).join(`
`),f.length>0&&(f+=`
`),x=[p,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(qi).join(`
`),x.length>0&&(x+=`
`)):(f=[Xc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(qi).join(`
`),x=[p,Xc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Qn?"#define TONE_MAPPING":"",e.toneMapping!==Qn?Gt.tonemapping_pars_fragment:"",e.toneMapping!==Qn?eg("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Gt.colorspace_pars_fragment,tg("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(qi).join(`
`)),a=Co(a),a=Vc(a,e),a=Gc(a,e),o=Co(o),o=Vc(o,e),o=Gc(o,e),a=Wc(a),o=Wc(o),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(_=`#version 300 es
`,f=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,x=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===hc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===hc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);let M=_+f+a,E=_+x+o,w=kc(i,i.VERTEX_SHADER,M),A=kc(i,i.FRAGMENT_SHADER,E);i.attachShader(m,w),i.attachShader(m,A),e.index0AttributeName!==void 0?i.bindAttribLocation(m,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(m,0,"position"),i.linkProgram(m);function U(k){if(s.debug.checkShaderErrors){let nt=i.getProgramInfoLog(m).trim(),L=i.getShaderInfoLog(w).trim(),N=i.getShaderInfoLog(A).trim(),V=!0,et=!0;if(i.getProgramParameter(m,i.LINK_STATUS)===!1)if(V=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,m,w,A);else{let Y=Hc(i,w,"vertex"),J=Hc(i,A,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(m,i.VALIDATE_STATUS)+`

Program Info Log: `+nt+`
`+Y+`
`+J)}else nt!==""?console.warn("THREE.WebGLProgram: Program Info Log:",nt):(L===""||N==="")&&(et=!1);et&&(k.diagnostics={runnable:V,programLog:nt,vertexShader:{log:L,prefix:f},fragmentShader:{log:N,prefix:x}})}i.deleteShader(w),i.deleteShader(A),v=new Ji(i,m),b=rg(i,m)}let v;this.getUniforms=function(){return v===void 0&&U(this),v};let b;this.getAttributes=function(){return b===void 0&&U(this),b};let F=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return F===!1&&(F=i.getProgramParameter(m,$m)),F},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(m),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Km++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=w,this.fragmentShader=A,this}var _g=0,Po=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new Lo(t),e.set(t,n)),n}},Lo=class{constructor(t){this.id=_g++,this.code=t,this.usedTimes=0}};function xg(s,t,e,n,i,r,a){let o=new Or,l=new Po,c=[],h=i.isWebGL2,u=i.logarithmicDepthBuffer,d=i.vertexTextures,p=i.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(v){return v===0?"uv":`uv${v}`}function m(v,b,F,k,nt){let L=k.fog,N=nt.geometry,V=v.isMeshStandardMaterial?k.environment:null,et=(v.isMeshStandardMaterial?e:t).get(v.envMap||V),Y=et&&et.mapping===ra?et.image.height:null,J=g[v.type];v.precision!==null&&(p=i.getMaxPrecision(v.precision),p!==v.precision&&console.warn("THREE.WebGLProgram.getParameters:",v.precision,"not supported, using",p,"instead."));let D=N.morphAttributes.position||N.morphAttributes.normal||N.morphAttributes.color,j=D!==void 0?D.length:0,rt=0;N.morphAttributes.position!==void 0&&(rt=1),N.morphAttributes.normal!==void 0&&(rt=2),N.morphAttributes.color!==void 0&&(rt=3);let O,$,ht,ft;if(J){let ze=vn[J];O=ze.vertexShader,$=ze.fragmentShader}else O=v.vertexShader,$=v.fragmentShader,l.update(v),ht=l.getVertexShaderID(v),ft=l.getFragmentShaderID(v);let dt=s.getRenderTarget(),X=nt.isInstancedMesh===!0,Q=nt.isBatchedMesh===!0,tt=!!v.map,xt=!!v.matcap,P=!!et,st=!!v.aoMap,H=!!v.lightMap,K=!!v.bumpMap,G=!!v.normalMap,yt=!!v.displacementMap,ut=!!v.emissiveMap,T=!!v.metalnessMap,S=!!v.roughnessMap,z=v.anisotropy>0,it=v.clearcoat>0,ot=v.iridescence>0,at=v.sheen>0,Tt=v.transmission>0,vt=z&&!!v.anisotropyMap,Et=it&&!!v.clearcoatMap,Pt=it&&!!v.clearcoatNormalMap,kt=it&&!!v.clearcoatRoughnessMap,lt=ot&&!!v.iridescenceMap,Jt=ot&&!!v.iridescenceThicknessMap,Zt=at&&!!v.sheenColorMap,Ft=at&&!!v.sheenRoughnessMap,Rt=!!v.specularMap,wt=!!v.specularColorMap,Vt=!!v.specularIntensityMap,Kt=Tt&&!!v.transmissionMap,ue=Tt&&!!v.thicknessMap,Xt=!!v.gradientMap,pt=!!v.alphaMap,I=v.alphaTest>0,Mt=!!v.alphaHash,bt=!!v.extensions,Ut=!!N.attributes.uv1,Lt=!!N.attributes.uv2,ee=!!N.attributes.uv3,ne=Qn;return v.toneMapped&&(dt===null||dt.isXRRenderTarget===!0)&&(ne=s.toneMapping),{isWebGL2:h,shaderID:J,shaderType:v.type,shaderName:v.name,vertexShader:O,fragmentShader:$,defines:v.defines,customVertexShaderID:ht,customFragmentShaderID:ft,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:p,batching:Q,instancing:X,instancingColor:X&&nt.instanceColor!==null,supportsVertexTextures:d,outputColorSpace:dt===null?s.outputColorSpace:dt.isXRRenderTarget===!0?dt.texture.colorSpace:Dn,map:tt,matcap:xt,envMap:P,envMapMode:P&&et.mapping,envMapCubeUVHeight:Y,aoMap:st,lightMap:H,bumpMap:K,normalMap:G,displacementMap:d&&yt,emissiveMap:ut,normalMapObjectSpace:G&&v.normalMapType===Nu,normalMapTangentSpace:G&&v.normalMapType===_h,metalnessMap:T,roughnessMap:S,anisotropy:z,anisotropyMap:vt,clearcoat:it,clearcoatMap:Et,clearcoatNormalMap:Pt,clearcoatRoughnessMap:kt,iridescence:ot,iridescenceMap:lt,iridescenceThicknessMap:Jt,sheen:at,sheenColorMap:Zt,sheenRoughnessMap:Ft,specularMap:Rt,specularColorMap:wt,specularIntensityMap:Vt,transmission:Tt,transmissionMap:Kt,thicknessMap:ue,gradientMap:Xt,opaque:v.transparent===!1&&v.blending===Kn,alphaMap:pt,alphaTest:I,alphaHash:Mt,combine:v.combine,mapUv:tt&&y(v.map.channel),aoMapUv:st&&y(v.aoMap.channel),lightMapUv:H&&y(v.lightMap.channel),bumpMapUv:K&&y(v.bumpMap.channel),normalMapUv:G&&y(v.normalMap.channel),displacementMapUv:yt&&y(v.displacementMap.channel),emissiveMapUv:ut&&y(v.emissiveMap.channel),metalnessMapUv:T&&y(v.metalnessMap.channel),roughnessMapUv:S&&y(v.roughnessMap.channel),anisotropyMapUv:vt&&y(v.anisotropyMap.channel),clearcoatMapUv:Et&&y(v.clearcoatMap.channel),clearcoatNormalMapUv:Pt&&y(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:kt&&y(v.clearcoatRoughnessMap.channel),iridescenceMapUv:lt&&y(v.iridescenceMap.channel),iridescenceThicknessMapUv:Jt&&y(v.iridescenceThicknessMap.channel),sheenColorMapUv:Zt&&y(v.sheenColorMap.channel),sheenRoughnessMapUv:Ft&&y(v.sheenRoughnessMap.channel),specularMapUv:Rt&&y(v.specularMap.channel),specularColorMapUv:wt&&y(v.specularColorMap.channel),specularIntensityMapUv:Vt&&y(v.specularIntensityMap.channel),transmissionMapUv:Kt&&y(v.transmissionMap.channel),thicknessMapUv:ue&&y(v.thicknessMap.channel),alphaMapUv:pt&&y(v.alphaMap.channel),vertexTangents:!!N.attributes.tangent&&(G||z),vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!N.attributes.color&&N.attributes.color.itemSize===4,vertexUv1s:Ut,vertexUv2s:Lt,vertexUv3s:ee,pointsUvs:nt.isPoints===!0&&!!N.attributes.uv&&(tt||pt),fog:!!L,useFog:v.fog===!0,fogExp2:L&&L.isFogExp2,flatShading:v.flatShading===!0,sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:nt.isSkinnedMesh===!0,morphTargets:N.morphAttributes.position!==void 0,morphNormals:N.morphAttributes.normal!==void 0,morphColors:N.morphAttributes.color!==void 0,morphTargetsCount:j,morphTextureStride:rt,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:v.dithering,shadowMapEnabled:s.shadowMap.enabled&&F.length>0,shadowMapType:s.shadowMap.type,toneMapping:ne,useLegacyLights:s._useLegacyLights,decodeVideoTexture:tt&&v.map.isVideoTexture===!0&&Qt.getTransfer(v.map.colorSpace)===re,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===Ve,flipSided:v.side===Ee,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionDerivatives:bt&&v.extensions.derivatives===!0,extensionFragDepth:bt&&v.extensions.fragDepth===!0,extensionDrawBuffers:bt&&v.extensions.drawBuffers===!0,extensionShaderTextureLOD:bt&&v.extensions.shaderTextureLOD===!0,extensionClipCullDistance:bt&&v.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()}}function f(v){let b=[];if(v.shaderID?b.push(v.shaderID):(b.push(v.customVertexShaderID),b.push(v.customFragmentShaderID)),v.defines!==void 0)for(let F in v.defines)b.push(F),b.push(v.defines[F]);return v.isRawShaderMaterial===!1&&(x(b,v),_(b,v),b.push(s.outputColorSpace)),b.push(v.customProgramCacheKey),b.join()}function x(v,b){v.push(b.precision),v.push(b.outputColorSpace),v.push(b.envMapMode),v.push(b.envMapCubeUVHeight),v.push(b.mapUv),v.push(b.alphaMapUv),v.push(b.lightMapUv),v.push(b.aoMapUv),v.push(b.bumpMapUv),v.push(b.normalMapUv),v.push(b.displacementMapUv),v.push(b.emissiveMapUv),v.push(b.metalnessMapUv),v.push(b.roughnessMapUv),v.push(b.anisotropyMapUv),v.push(b.clearcoatMapUv),v.push(b.clearcoatNormalMapUv),v.push(b.clearcoatRoughnessMapUv),v.push(b.iridescenceMapUv),v.push(b.iridescenceThicknessMapUv),v.push(b.sheenColorMapUv),v.push(b.sheenRoughnessMapUv),v.push(b.specularMapUv),v.push(b.specularColorMapUv),v.push(b.specularIntensityMapUv),v.push(b.transmissionMapUv),v.push(b.thicknessMapUv),v.push(b.combine),v.push(b.fogExp2),v.push(b.sizeAttenuation),v.push(b.morphTargetsCount),v.push(b.morphAttributeCount),v.push(b.numDirLights),v.push(b.numPointLights),v.push(b.numSpotLights),v.push(b.numSpotLightMaps),v.push(b.numHemiLights),v.push(b.numRectAreaLights),v.push(b.numDirLightShadows),v.push(b.numPointLightShadows),v.push(b.numSpotLightShadows),v.push(b.numSpotLightShadowsWithMaps),v.push(b.numLightProbes),v.push(b.shadowMapType),v.push(b.toneMapping),v.push(b.numClippingPlanes),v.push(b.numClipIntersection),v.push(b.depthPacking)}function _(v,b){o.disableAll(),b.isWebGL2&&o.enable(0),b.supportsVertexTextures&&o.enable(1),b.instancing&&o.enable(2),b.instancingColor&&o.enable(3),b.matcap&&o.enable(4),b.envMap&&o.enable(5),b.normalMapObjectSpace&&o.enable(6),b.normalMapTangentSpace&&o.enable(7),b.clearcoat&&o.enable(8),b.iridescence&&o.enable(9),b.alphaTest&&o.enable(10),b.vertexColors&&o.enable(11),b.vertexAlphas&&o.enable(12),b.vertexUv1s&&o.enable(13),b.vertexUv2s&&o.enable(14),b.vertexUv3s&&o.enable(15),b.vertexTangents&&o.enable(16),b.anisotropy&&o.enable(17),b.alphaHash&&o.enable(18),b.batching&&o.enable(19),v.push(o.mask),o.disableAll(),b.fog&&o.enable(0),b.useFog&&o.enable(1),b.flatShading&&o.enable(2),b.logarithmicDepthBuffer&&o.enable(3),b.skinning&&o.enable(4),b.morphTargets&&o.enable(5),b.morphNormals&&o.enable(6),b.morphColors&&o.enable(7),b.premultipliedAlpha&&o.enable(8),b.shadowMapEnabled&&o.enable(9),b.useLegacyLights&&o.enable(10),b.doubleSided&&o.enable(11),b.flipSided&&o.enable(12),b.useDepthPacking&&o.enable(13),b.dithering&&o.enable(14),b.transmission&&o.enable(15),b.sheen&&o.enable(16),b.opaque&&o.enable(17),b.pointsUvs&&o.enable(18),b.decodeVideoTexture&&o.enable(19),v.push(o.mask)}function M(v){let b=g[v.type],F;if(b){let k=vn[b];F=ad.clone(k.uniforms)}else F=v.uniforms;return F}function E(v,b){let F;for(let k=0,nt=c.length;k<nt;k++){let L=c[k];if(L.cacheKey===b){F=L,++F.usedTimes;break}}return F===void 0&&(F=new gg(s,b,v,r),c.push(F)),F}function w(v){if(--v.usedTimes===0){let b=c.indexOf(v);c[b]=c[c.length-1],c.pop(),v.destroy()}}function A(v){l.remove(v)}function U(){l.dispose()}return{getParameters:m,getProgramCacheKey:f,getUniforms:M,acquireProgram:E,releaseProgram:w,releaseShaderCache:A,programs:c,dispose:U}}function yg(){let s=new WeakMap;function t(r){let a=s.get(r);return a===void 0&&(a={},s.set(r,a)),a}function e(r){s.delete(r)}function n(r,a,o){s.get(r)[a]=o}function i(){s=new WeakMap}return{get:t,remove:e,update:n,dispose:i}}function vg(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function qc(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function Yc(){let s=[],t=0,e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function a(u,d,p,g,y,m){let f=s[t];return f===void 0?(f={id:u.id,object:u,geometry:d,material:p,groupOrder:g,renderOrder:u.renderOrder,z:y,group:m},s[t]=f):(f.id=u.id,f.object=u,f.geometry=d,f.material=p,f.groupOrder=g,f.renderOrder=u.renderOrder,f.z=y,f.group=m),t++,f}function o(u,d,p,g,y,m){let f=a(u,d,p,g,y,m);p.transmission>0?n.push(f):p.transparent===!0?i.push(f):e.push(f)}function l(u,d,p,g,y,m){let f=a(u,d,p,g,y,m);p.transmission>0?n.unshift(f):p.transparent===!0?i.unshift(f):e.unshift(f)}function c(u,d){e.length>1&&e.sort(u||vg),n.length>1&&n.sort(d||qc),i.length>1&&i.sort(d||qc)}function h(){for(let u=t,d=s.length;u<d;u++){let p=s[u];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:o,unshift:l,finish:h,sort:c}}function Mg(){let s=new WeakMap;function t(n,i){let r=s.get(n),a;return r===void 0?(a=new Yc,s.set(n,[a])):i>=r.length?(a=new Yc,r.push(a)):a=r[i],a}function e(){s=new WeakMap}return{get:t,dispose:e}}function bg(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new C,color:new Ct};break;case"SpotLight":e={position:new C,direction:new C,color:new Ct,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new C,color:new Ct,distance:0,decay:0};break;case"HemisphereLight":e={direction:new C,skyColor:new Ct,groundColor:new Ct};break;case"RectAreaLight":e={color:new Ct,position:new C,halfWidth:new C,halfHeight:new C};break}return s[t.id]=e,e}}}function Sg(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _t};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _t};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new _t,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}var Eg=0;function wg(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function Tg(s,t){let e=new bg,n=Sg(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)i.probe.push(new C);let r=new C,a=new le,o=new le;function l(h,u){let d=0,p=0,g=0;for(let k=0;k<9;k++)i.probe[k].set(0,0,0);let y=0,m=0,f=0,x=0,_=0,M=0,E=0,w=0,A=0,U=0,v=0;h.sort(wg);let b=u===!0?Math.PI:1;for(let k=0,nt=h.length;k<nt;k++){let L=h[k],N=L.color,V=L.intensity,et=L.distance,Y=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)d+=N.r*V*b,p+=N.g*V*b,g+=N.b*V*b;else if(L.isLightProbe){for(let J=0;J<9;J++)i.probe[J].addScaledVector(L.sh.coefficients[J],V);v++}else if(L.isDirectionalLight){let J=e.get(L);if(J.color.copy(L.color).multiplyScalar(L.intensity*b),L.castShadow){let D=L.shadow,j=n.get(L);j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,i.directionalShadow[y]=j,i.directionalShadowMap[y]=Y,i.directionalShadowMatrix[y]=L.shadow.matrix,M++}i.directional[y]=J,y++}else if(L.isSpotLight){let J=e.get(L);J.position.setFromMatrixPosition(L.matrixWorld),J.color.copy(N).multiplyScalar(V*b),J.distance=et,J.coneCos=Math.cos(L.angle),J.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),J.decay=L.decay,i.spot[f]=J;let D=L.shadow;if(L.map&&(i.spotLightMap[A]=L.map,A++,D.updateMatrices(L),L.castShadow&&U++),i.spotLightMatrix[f]=D.matrix,L.castShadow){let j=n.get(L);j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,i.spotShadow[f]=j,i.spotShadowMap[f]=Y,w++}f++}else if(L.isRectAreaLight){let J=e.get(L);J.color.copy(N).multiplyScalar(V),J.halfWidth.set(L.width*.5,0,0),J.halfHeight.set(0,L.height*.5,0),i.rectArea[x]=J,x++}else if(L.isPointLight){let J=e.get(L);if(J.color.copy(L.color).multiplyScalar(L.intensity*b),J.distance=L.distance,J.decay=L.decay,L.castShadow){let D=L.shadow,j=n.get(L);j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,j.shadowCameraNear=D.camera.near,j.shadowCameraFar=D.camera.far,i.pointShadow[m]=j,i.pointShadowMap[m]=Y,i.pointShadowMatrix[m]=L.shadow.matrix,E++}i.point[m]=J,m++}else if(L.isHemisphereLight){let J=e.get(L);J.skyColor.copy(L.color).multiplyScalar(V*b),J.groundColor.copy(L.groundColor).multiplyScalar(V*b),i.hemi[_]=J,_++}}x>0&&(t.isWebGL2?s.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=mt.LTC_FLOAT_1,i.rectAreaLTC2=mt.LTC_FLOAT_2):(i.rectAreaLTC1=mt.LTC_HALF_1,i.rectAreaLTC2=mt.LTC_HALF_2):s.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=mt.LTC_FLOAT_1,i.rectAreaLTC2=mt.LTC_FLOAT_2):s.has("OES_texture_half_float_linear")===!0?(i.rectAreaLTC1=mt.LTC_HALF_1,i.rectAreaLTC2=mt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),i.ambient[0]=d,i.ambient[1]=p,i.ambient[2]=g;let F=i.hash;(F.directionalLength!==y||F.pointLength!==m||F.spotLength!==f||F.rectAreaLength!==x||F.hemiLength!==_||F.numDirectionalShadows!==M||F.numPointShadows!==E||F.numSpotShadows!==w||F.numSpotMaps!==A||F.numLightProbes!==v)&&(i.directional.length=y,i.spot.length=f,i.rectArea.length=x,i.point.length=m,i.hemi.length=_,i.directionalShadow.length=M,i.directionalShadowMap.length=M,i.pointShadow.length=E,i.pointShadowMap.length=E,i.spotShadow.length=w,i.spotShadowMap.length=w,i.directionalShadowMatrix.length=M,i.pointShadowMatrix.length=E,i.spotLightMatrix.length=w+A-U,i.spotLightMap.length=A,i.numSpotLightShadowsWithMaps=U,i.numLightProbes=v,F.directionalLength=y,F.pointLength=m,F.spotLength=f,F.rectAreaLength=x,F.hemiLength=_,F.numDirectionalShadows=M,F.numPointShadows=E,F.numSpotShadows=w,F.numSpotMaps=A,F.numLightProbes=v,i.version=Eg++)}function c(h,u){let d=0,p=0,g=0,y=0,m=0,f=u.matrixWorldInverse;for(let x=0,_=h.length;x<_;x++){let M=h[x];if(M.isDirectionalLight){let E=i.directional[d];E.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),E.direction.sub(r),E.direction.transformDirection(f),d++}else if(M.isSpotLight){let E=i.spot[g];E.position.setFromMatrixPosition(M.matrixWorld),E.position.applyMatrix4(f),E.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),E.direction.sub(r),E.direction.transformDirection(f),g++}else if(M.isRectAreaLight){let E=i.rectArea[y];E.position.setFromMatrixPosition(M.matrixWorld),E.position.applyMatrix4(f),o.identity(),a.copy(M.matrixWorld),a.premultiply(f),o.extractRotation(a),E.halfWidth.set(M.width*.5,0,0),E.halfHeight.set(0,M.height*.5,0),E.halfWidth.applyMatrix4(o),E.halfHeight.applyMatrix4(o),y++}else if(M.isPointLight){let E=i.point[p];E.position.setFromMatrixPosition(M.matrixWorld),E.position.applyMatrix4(f),p++}else if(M.isHemisphereLight){let E=i.hemi[m];E.direction.setFromMatrixPosition(M.matrixWorld),E.direction.transformDirection(f),m++}}}return{setup:l,setupView:c,state:i}}function Zc(s,t){let e=new Tg(s,t),n=[],i=[];function r(){n.length=0,i.length=0}function a(u){n.push(u)}function o(u){i.push(u)}function l(u){e.setup(n,u)}function c(u){e.setupView(n,u)}return{init:r,state:{lightsArray:n,shadowsArray:i,lights:e},setupLights:l,setupLightsView:c,pushLight:a,pushShadow:o}}function Ag(s,t){let e=new WeakMap;function n(r,a=0){let o=e.get(r),l;return o===void 0?(l=new Zc(s,t),e.set(r,[l])):a>=o.length?(l=new Zc(s,t),o.push(l)):l=o[a],l}function i(){e=new WeakMap}return{get:n,dispose:i}}var Io=class extends ii{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Du,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},Do=class extends ii{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},Rg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Cg=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Pg(s,t,e){let n=new Ds,i=new _t,r=new _t,a=new oe,o=new Io({depthPacking:Uu}),l=new Do,c={},h=e.maxTextureSize,u={[ti]:Ee,[Ee]:ti,[Ve]:Ve},d=new en({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new _t},radius:{value:4}},vertexShader:Rg,fragmentShader:Cg}),p=d.clone();p.defines.HORIZONTAL_PASS=1;let g=new Te;g.setAttribute("position",new jt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let y=new It(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ah;let f=this.type;this.render=function(w,A,U){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||w.length===0)return;let v=s.getRenderTarget(),b=s.getActiveCubeFace(),F=s.getActiveMipmapLevel(),k=s.state;k.setBlending($n),k.buffers.color.setClear(1,1,1,1),k.buffers.depth.setTest(!0),k.setScissorTest(!1);let nt=f!==Pn&&this.type===Pn,L=f===Pn&&this.type!==Pn;for(let N=0,V=w.length;N<V;N++){let et=w[N],Y=et.shadow;if(Y===void 0){console.warn("THREE.WebGLShadowMap:",et,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;i.copy(Y.mapSize);let J=Y.getFrameExtents();if(i.multiply(J),r.copy(Y.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/J.x),i.x=r.x*J.x,Y.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/J.y),i.y=r.y*J.y,Y.mapSize.y=r.y)),Y.map===null||nt===!0||L===!0){let j=this.type!==Pn?{minFilter:He,magFilter:He}:{};Y.map!==null&&Y.map.dispose(),Y.map=new Un(i.x,i.y,j),Y.map.texture.name=et.name+".shadowMap",Y.camera.updateProjectionMatrix()}s.setRenderTarget(Y.map),s.clear();let D=Y.getViewportCount();for(let j=0;j<D;j++){let rt=Y.getViewport(j);a.set(r.x*rt.x,r.y*rt.y,r.x*rt.z,r.y*rt.w),k.viewport(a),Y.updateMatrices(et,j),n=Y.getFrustum(),M(A,U,Y.camera,et,this.type)}Y.isPointLightShadow!==!0&&this.type===Pn&&x(Y,U),Y.needsUpdate=!1}f=this.type,m.needsUpdate=!1,s.setRenderTarget(v,b,F)};function x(w,A){let U=t.update(y);d.defines.VSM_SAMPLES!==w.blurSamples&&(d.defines.VSM_SAMPLES=w.blurSamples,p.defines.VSM_SAMPLES=w.blurSamples,d.needsUpdate=!0,p.needsUpdate=!0),w.mapPass===null&&(w.mapPass=new Un(i.x,i.y)),d.uniforms.shadow_pass.value=w.map.texture,d.uniforms.resolution.value=w.mapSize,d.uniforms.radius.value=w.radius,s.setRenderTarget(w.mapPass),s.clear(),s.renderBufferDirect(A,null,U,d,y,null),p.uniforms.shadow_pass.value=w.mapPass.texture,p.uniforms.resolution.value=w.mapSize,p.uniforms.radius.value=w.radius,s.setRenderTarget(w.map),s.clear(),s.renderBufferDirect(A,null,U,p,y,null)}function _(w,A,U,v){let b=null,F=U.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(F!==void 0)b=F;else if(b=U.isPointLight===!0?l:o,s.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){let k=b.uuid,nt=A.uuid,L=c[k];L===void 0&&(L={},c[k]=L);let N=L[nt];N===void 0&&(N=b.clone(),L[nt]=N,A.addEventListener("dispose",E)),b=N}if(b.visible=A.visible,b.wireframe=A.wireframe,v===Pn?b.side=A.shadowSide!==null?A.shadowSide:A.side:b.side=A.shadowSide!==null?A.shadowSide:u[A.side],b.alphaMap=A.alphaMap,b.alphaTest=A.alphaTest,b.map=A.map,b.clipShadows=A.clipShadows,b.clippingPlanes=A.clippingPlanes,b.clipIntersection=A.clipIntersection,b.displacementMap=A.displacementMap,b.displacementScale=A.displacementScale,b.displacementBias=A.displacementBias,b.wireframeLinewidth=A.wireframeLinewidth,b.linewidth=A.linewidth,U.isPointLight===!0&&b.isMeshDistanceMaterial===!0){let k=s.properties.get(b);k.light=U}return b}function M(w,A,U,v,b){if(w.visible===!1)return;if(w.layers.test(A.layers)&&(w.isMesh||w.isLine||w.isPoints)&&(w.castShadow||w.receiveShadow&&b===Pn)&&(!w.frustumCulled||n.intersectsObject(w))){w.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,w.matrixWorld);let nt=t.update(w),L=w.material;if(Array.isArray(L)){let N=nt.groups;for(let V=0,et=N.length;V<et;V++){let Y=N[V],J=L[Y.materialIndex];if(J&&J.visible){let D=_(w,J,v,b);w.onBeforeShadow(s,w,A,U,nt,D,Y),s.renderBufferDirect(U,null,nt,D,w,Y),w.onAfterShadow(s,w,A,U,nt,D,Y)}}}else if(L.visible){let N=_(w,L,v,b);w.onBeforeShadow(s,w,A,U,nt,N,null),s.renderBufferDirect(U,null,nt,N,w,null),w.onAfterShadow(s,w,A,U,nt,N,null)}}let k=w.children;for(let nt=0,L=k.length;nt<L;nt++)M(k[nt],A,U,v,b)}function E(w){w.target.removeEventListener("dispose",E);for(let U in c){let v=c[U],b=w.target.uuid;b in v&&(v[b].dispose(),delete v[b])}}}function Lg(s,t,e){let n=e.isWebGL2;function i(){let I=!1,Mt=new oe,bt=null,Ut=new oe(0,0,0,0);return{setMask:function(Lt){bt!==Lt&&!I&&(s.colorMask(Lt,Lt,Lt,Lt),bt=Lt)},setLocked:function(Lt){I=Lt},setClear:function(Lt,ee,ne,Me,ze){ze===!0&&(Lt*=Me,ee*=Me,ne*=Me),Mt.set(Lt,ee,ne,Me),Ut.equals(Mt)===!1&&(s.clearColor(Lt,ee,ne,Me),Ut.copy(Mt))},reset:function(){I=!1,bt=null,Ut.set(-1,0,0,0)}}}function r(){let I=!1,Mt=null,bt=null,Ut=null;return{setTest:function(Lt){Lt?Q(s.DEPTH_TEST):tt(s.DEPTH_TEST)},setMask:function(Lt){Mt!==Lt&&!I&&(s.depthMask(Lt),Mt=Lt)},setFunc:function(Lt){if(bt!==Lt){switch(Lt){case hu:s.depthFunc(s.NEVER);break;case uu:s.depthFunc(s.ALWAYS);break;case du:s.depthFunc(s.LESS);break;case Er:s.depthFunc(s.LEQUAL);break;case fu:s.depthFunc(s.EQUAL);break;case pu:s.depthFunc(s.GEQUAL);break;case mu:s.depthFunc(s.GREATER);break;case gu:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}bt=Lt}},setLocked:function(Lt){I=Lt},setClear:function(Lt){Ut!==Lt&&(s.clearDepth(Lt),Ut=Lt)},reset:function(){I=!1,Mt=null,bt=null,Ut=null}}}function a(){let I=!1,Mt=null,bt=null,Ut=null,Lt=null,ee=null,ne=null,Me=null,ze=null;return{setTest:function(ie){I||(ie?Q(s.STENCIL_TEST):tt(s.STENCIL_TEST))},setMask:function(ie){Mt!==ie&&!I&&(s.stencilMask(ie),Mt=ie)},setFunc:function(ie,Be,yn){(bt!==ie||Ut!==Be||Lt!==yn)&&(s.stencilFunc(ie,Be,yn),bt=ie,Ut=Be,Lt=yn)},setOp:function(ie,Be,yn){(ee!==ie||ne!==Be||Me!==yn)&&(s.stencilOp(ie,Be,yn),ee=ie,ne=Be,Me=yn)},setLocked:function(ie){I=ie},setClear:function(ie){ze!==ie&&(s.clearStencil(ie),ze=ie)},reset:function(){I=!1,Mt=null,bt=null,Ut=null,Lt=null,ee=null,ne=null,Me=null,ze=null}}}let o=new i,l=new r,c=new a,h=new WeakMap,u=new WeakMap,d={},p={},g=new WeakMap,y=[],m=null,f=!1,x=null,_=null,M=null,E=null,w=null,A=null,U=null,v=new Ct(0,0,0),b=0,F=!1,k=null,nt=null,L=null,N=null,V=null,et=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS),Y=!1,J=0,D=s.getParameter(s.VERSION);D.indexOf("WebGL")!==-1?(J=parseFloat(/^WebGL (\d)/.exec(D)[1]),Y=J>=1):D.indexOf("OpenGL ES")!==-1&&(J=parseFloat(/^OpenGL ES (\d)/.exec(D)[1]),Y=J>=2);let j=null,rt={},O=s.getParameter(s.SCISSOR_BOX),$=s.getParameter(s.VIEWPORT),ht=new oe().fromArray(O),ft=new oe().fromArray($);function dt(I,Mt,bt,Ut){let Lt=new Uint8Array(4),ee=s.createTexture();s.bindTexture(I,ee),s.texParameteri(I,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(I,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let ne=0;ne<bt;ne++)n&&(I===s.TEXTURE_3D||I===s.TEXTURE_2D_ARRAY)?s.texImage3D(Mt,0,s.RGBA,1,1,Ut,0,s.RGBA,s.UNSIGNED_BYTE,Lt):s.texImage2D(Mt+ne,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,Lt);return ee}let X={};X[s.TEXTURE_2D]=dt(s.TEXTURE_2D,s.TEXTURE_2D,1),X[s.TEXTURE_CUBE_MAP]=dt(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(X[s.TEXTURE_2D_ARRAY]=dt(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),X[s.TEXTURE_3D]=dt(s.TEXTURE_3D,s.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),l.setClear(1),c.setClear(0),Q(s.DEPTH_TEST),l.setFunc(Er),ut(!1),T(Rl),Q(s.CULL_FACE),G($n);function Q(I){d[I]!==!0&&(s.enable(I),d[I]=!0)}function tt(I){d[I]!==!1&&(s.disable(I),d[I]=!1)}function xt(I,Mt){return p[I]!==Mt?(s.bindFramebuffer(I,Mt),p[I]=Mt,n&&(I===s.DRAW_FRAMEBUFFER&&(p[s.FRAMEBUFFER]=Mt),I===s.FRAMEBUFFER&&(p[s.DRAW_FRAMEBUFFER]=Mt)),!0):!1}function P(I,Mt){let bt=y,Ut=!1;if(I)if(bt=g.get(Mt),bt===void 0&&(bt=[],g.set(Mt,bt)),I.isWebGLMultipleRenderTargets){let Lt=I.texture;if(bt.length!==Lt.length||bt[0]!==s.COLOR_ATTACHMENT0){for(let ee=0,ne=Lt.length;ee<ne;ee++)bt[ee]=s.COLOR_ATTACHMENT0+ee;bt.length=Lt.length,Ut=!0}}else bt[0]!==s.COLOR_ATTACHMENT0&&(bt[0]=s.COLOR_ATTACHMENT0,Ut=!0);else bt[0]!==s.BACK&&(bt[0]=s.BACK,Ut=!0);Ut&&(e.isWebGL2?s.drawBuffers(bt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(bt))}function st(I){return m!==I?(s.useProgram(I),m=I,!0):!1}let H={[mi]:s.FUNC_ADD,[Jh]:s.FUNC_SUBTRACT,[$h]:s.FUNC_REVERSE_SUBTRACT};if(n)H[Ll]=s.MIN,H[Il]=s.MAX;else{let I=t.get("EXT_blend_minmax");I!==null&&(H[Ll]=I.MIN_EXT,H[Il]=I.MAX_EXT)}let K={[Kh]:s.ZERO,[Qh]:s.ONE,[jh]:s.SRC_COLOR,[po]:s.SRC_ALPHA,[ru]:s.SRC_ALPHA_SATURATE,[iu]:s.DST_COLOR,[eu]:s.DST_ALPHA,[tu]:s.ONE_MINUS_SRC_COLOR,[mo]:s.ONE_MINUS_SRC_ALPHA,[su]:s.ONE_MINUS_DST_COLOR,[nu]:s.ONE_MINUS_DST_ALPHA,[au]:s.CONSTANT_COLOR,[ou]:s.ONE_MINUS_CONSTANT_COLOR,[lu]:s.CONSTANT_ALPHA,[cu]:s.ONE_MINUS_CONSTANT_ALPHA};function G(I,Mt,bt,Ut,Lt,ee,ne,Me,ze,ie){if(I===$n){f===!0&&(tt(s.BLEND),f=!1);return}if(f===!1&&(Q(s.BLEND),f=!0),I!==Zh){if(I!==x||ie!==F){if((_!==mi||w!==mi)&&(s.blendEquation(s.FUNC_ADD),_=mi,w=mi),ie)switch(I){case Kn:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case mn:s.blendFunc(s.ONE,s.ONE);break;case Cl:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case Pl:s.blendFuncSeparate(s.ZERO,s.SRC_COLOR,s.ZERO,s.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}else switch(I){case Kn:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case mn:s.blendFunc(s.SRC_ALPHA,s.ONE);break;case Cl:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case Pl:s.blendFunc(s.ZERO,s.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}M=null,E=null,A=null,U=null,v.set(0,0,0),b=0,x=I,F=ie}return}Lt=Lt||Mt,ee=ee||bt,ne=ne||Ut,(Mt!==_||Lt!==w)&&(s.blendEquationSeparate(H[Mt],H[Lt]),_=Mt,w=Lt),(bt!==M||Ut!==E||ee!==A||ne!==U)&&(s.blendFuncSeparate(K[bt],K[Ut],K[ee],K[ne]),M=bt,E=Ut,A=ee,U=ne),(Me.equals(v)===!1||ze!==b)&&(s.blendColor(Me.r,Me.g,Me.b,ze),v.copy(Me),b=ze),x=I,F=!1}function yt(I,Mt){I.side===Ve?tt(s.CULL_FACE):Q(s.CULL_FACE);let bt=I.side===Ee;Mt&&(bt=!bt),ut(bt),I.blending===Kn&&I.transparent===!1?G($n):G(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),l.setFunc(I.depthFunc),l.setTest(I.depthTest),l.setMask(I.depthWrite),o.setMask(I.colorWrite);let Ut=I.stencilWrite;c.setTest(Ut),Ut&&(c.setMask(I.stencilWriteMask),c.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),c.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),z(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?Q(s.SAMPLE_ALPHA_TO_COVERAGE):tt(s.SAMPLE_ALPHA_TO_COVERAGE)}function ut(I){k!==I&&(I?s.frontFace(s.CW):s.frontFace(s.CCW),k=I)}function T(I){I!==Xh?(Q(s.CULL_FACE),I!==nt&&(I===Rl?s.cullFace(s.BACK):I===qh?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):tt(s.CULL_FACE),nt=I}function S(I){I!==L&&(Y&&s.lineWidth(I),L=I)}function z(I,Mt,bt){I?(Q(s.POLYGON_OFFSET_FILL),(N!==Mt||V!==bt)&&(s.polygonOffset(Mt,bt),N=Mt,V=bt)):tt(s.POLYGON_OFFSET_FILL)}function it(I){I?Q(s.SCISSOR_TEST):tt(s.SCISSOR_TEST)}function ot(I){I===void 0&&(I=s.TEXTURE0+et-1),j!==I&&(s.activeTexture(I),j=I)}function at(I,Mt,bt){bt===void 0&&(j===null?bt=s.TEXTURE0+et-1:bt=j);let Ut=rt[bt];Ut===void 0&&(Ut={type:void 0,texture:void 0},rt[bt]=Ut),(Ut.type!==I||Ut.texture!==Mt)&&(j!==bt&&(s.activeTexture(bt),j=bt),s.bindTexture(I,Mt||X[I]),Ut.type=I,Ut.texture=Mt)}function Tt(){let I=rt[j];I!==void 0&&I.type!==void 0&&(s.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function vt(){try{s.compressedTexImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Et(){try{s.compressedTexImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Pt(){try{s.texSubImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function kt(){try{s.texSubImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function lt(){try{s.compressedTexSubImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Jt(){try{s.compressedTexSubImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Zt(){try{s.texStorage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Ft(){try{s.texStorage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Rt(){try{s.texImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function wt(){try{s.texImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Vt(I){ht.equals(I)===!1&&(s.scissor(I.x,I.y,I.z,I.w),ht.copy(I))}function Kt(I){ft.equals(I)===!1&&(s.viewport(I.x,I.y,I.z,I.w),ft.copy(I))}function ue(I,Mt){let bt=u.get(Mt);bt===void 0&&(bt=new WeakMap,u.set(Mt,bt));let Ut=bt.get(I);Ut===void 0&&(Ut=s.getUniformBlockIndex(Mt,I.name),bt.set(I,Ut))}function Xt(I,Mt){let Ut=u.get(Mt).get(I);h.get(Mt)!==Ut&&(s.uniformBlockBinding(Mt,Ut,I.__bindingPointIndex),h.set(Mt,Ut))}function pt(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),n===!0&&(s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null)),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),d={},j=null,rt={},p={},g=new WeakMap,y=[],m=null,f=!1,x=null,_=null,M=null,E=null,w=null,A=null,U=null,v=new Ct(0,0,0),b=0,F=!1,k=null,nt=null,L=null,N=null,V=null,ht.set(0,0,s.canvas.width,s.canvas.height),ft.set(0,0,s.canvas.width,s.canvas.height),o.reset(),l.reset(),c.reset()}return{buffers:{color:o,depth:l,stencil:c},enable:Q,disable:tt,bindFramebuffer:xt,drawBuffers:P,useProgram:st,setBlending:G,setMaterial:yt,setFlipSided:ut,setCullFace:T,setLineWidth:S,setPolygonOffset:z,setScissorTest:it,activeTexture:ot,bindTexture:at,unbindTexture:Tt,compressedTexImage2D:vt,compressedTexImage3D:Et,texImage2D:Rt,texImage3D:wt,updateUBOMapping:ue,uniformBlockBinding:Xt,texStorage2D:Zt,texStorage3D:Ft,texSubImage2D:Pt,texSubImage3D:kt,compressedTexSubImage2D:lt,compressedTexSubImage3D:Jt,scissor:Vt,viewport:Kt,reset:pt}}function Ig(s,t,e,n,i,r,a){let o=i.isWebGL2,l=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,d=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(T,S){return p?new OffscreenCanvas(T,S):Lr("canvas")}function y(T,S,z,it){let ot=1;if((T.width>it||T.height>it)&&(ot=it/Math.max(T.width,T.height)),ot<1||S===!0)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap){let at=S?Mo:Math.floor,Tt=at(ot*T.width),vt=at(ot*T.height);u===void 0&&(u=g(Tt,vt));let Et=z?g(Tt,vt):u;return Et.width=Tt,Et.height=vt,Et.getContext("2d").drawImage(T,0,0,Tt,vt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+T.width+"x"+T.height+") to ("+Tt+"x"+vt+")."),Et}else return"data"in T&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+T.width+"x"+T.height+")."),T;return T}function m(T){return uc(T.width)&&uc(T.height)}function f(T){return o?!1:T.wrapS!==fn||T.wrapT!==fn||T.minFilter!==He&&T.minFilter!==Ke}function x(T,S){return T.generateMipmaps&&S&&T.minFilter!==He&&T.minFilter!==Ke}function _(T){s.generateMipmap(T)}function M(T,S,z,it,ot=!1){if(o===!1)return S;if(T!==null){if(s[T]!==void 0)return s[T];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let at=S;if(S===s.RED&&(z===s.FLOAT&&(at=s.R32F),z===s.HALF_FLOAT&&(at=s.R16F),z===s.UNSIGNED_BYTE&&(at=s.R8)),S===s.RED_INTEGER&&(z===s.UNSIGNED_BYTE&&(at=s.R8UI),z===s.UNSIGNED_SHORT&&(at=s.R16UI),z===s.UNSIGNED_INT&&(at=s.R32UI),z===s.BYTE&&(at=s.R8I),z===s.SHORT&&(at=s.R16I),z===s.INT&&(at=s.R32I)),S===s.RG&&(z===s.FLOAT&&(at=s.RG32F),z===s.HALF_FLOAT&&(at=s.RG16F),z===s.UNSIGNED_BYTE&&(at=s.RG8)),S===s.RGBA){let Tt=ot?Ar:Qt.getTransfer(it);z===s.FLOAT&&(at=s.RGBA32F),z===s.HALF_FLOAT&&(at=s.RGBA16F),z===s.UNSIGNED_BYTE&&(at=Tt===re?s.SRGB8_ALPHA8:s.RGBA8),z===s.UNSIGNED_SHORT_4_4_4_4&&(at=s.RGBA4),z===s.UNSIGNED_SHORT_5_5_5_1&&(at=s.RGB5_A1)}return(at===s.R16F||at===s.R32F||at===s.RG16F||at===s.RG32F||at===s.RGBA16F||at===s.RGBA32F)&&t.get("EXT_color_buffer_float"),at}function E(T,S,z){return x(T,z)===!0||T.isFramebufferTexture&&T.minFilter!==He&&T.minFilter!==Ke?Math.log2(Math.max(S.width,S.height))+1:T.mipmaps!==void 0&&T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?S.mipmaps.length:1}function w(T){return T===He||T===Dl||T===La?s.NEAREST:s.LINEAR}function A(T){let S=T.target;S.removeEventListener("dispose",A),v(S),S.isVideoTexture&&h.delete(S)}function U(T){let S=T.target;S.removeEventListener("dispose",U),F(S)}function v(T){let S=n.get(T);if(S.__webglInit===void 0)return;let z=T.source,it=d.get(z);if(it){let ot=it[S.__cacheKey];ot.usedTimes--,ot.usedTimes===0&&b(T),Object.keys(it).length===0&&d.delete(z)}n.remove(T)}function b(T){let S=n.get(T);s.deleteTexture(S.__webglTexture);let z=T.source,it=d.get(z);delete it[S.__cacheKey],a.memory.textures--}function F(T){let S=T.texture,z=n.get(T),it=n.get(S);if(it.__webglTexture!==void 0&&(s.deleteTexture(it.__webglTexture),a.memory.textures--),T.depthTexture&&T.depthTexture.dispose(),T.isWebGLCubeRenderTarget)for(let ot=0;ot<6;ot++){if(Array.isArray(z.__webglFramebuffer[ot]))for(let at=0;at<z.__webglFramebuffer[ot].length;at++)s.deleteFramebuffer(z.__webglFramebuffer[ot][at]);else s.deleteFramebuffer(z.__webglFramebuffer[ot]);z.__webglDepthbuffer&&s.deleteRenderbuffer(z.__webglDepthbuffer[ot])}else{if(Array.isArray(z.__webglFramebuffer))for(let ot=0;ot<z.__webglFramebuffer.length;ot++)s.deleteFramebuffer(z.__webglFramebuffer[ot]);else s.deleteFramebuffer(z.__webglFramebuffer);if(z.__webglDepthbuffer&&s.deleteRenderbuffer(z.__webglDepthbuffer),z.__webglMultisampledFramebuffer&&s.deleteFramebuffer(z.__webglMultisampledFramebuffer),z.__webglColorRenderbuffer)for(let ot=0;ot<z.__webglColorRenderbuffer.length;ot++)z.__webglColorRenderbuffer[ot]&&s.deleteRenderbuffer(z.__webglColorRenderbuffer[ot]);z.__webglDepthRenderbuffer&&s.deleteRenderbuffer(z.__webglDepthRenderbuffer)}if(T.isWebGLMultipleRenderTargets)for(let ot=0,at=S.length;ot<at;ot++){let Tt=n.get(S[ot]);Tt.__webglTexture&&(s.deleteTexture(Tt.__webglTexture),a.memory.textures--),n.remove(S[ot])}n.remove(S),n.remove(T)}let k=0;function nt(){k=0}function L(){let T=k;return T>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+T+" texture units while this GPU supports only "+i.maxTextures),k+=1,T}function N(T){let S=[];return S.push(T.wrapS),S.push(T.wrapT),S.push(T.wrapR||0),S.push(T.magFilter),S.push(T.minFilter),S.push(T.anisotropy),S.push(T.internalFormat),S.push(T.format),S.push(T.type),S.push(T.generateMipmaps),S.push(T.premultiplyAlpha),S.push(T.flipY),S.push(T.unpackAlignment),S.push(T.colorSpace),S.join()}function V(T,S){let z=n.get(T);if(T.isVideoTexture&&yt(T),T.isRenderTargetTexture===!1&&T.version>0&&z.__version!==T.version){let it=T.image;if(it===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(it.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ht(z,T,S);return}}e.bindTexture(s.TEXTURE_2D,z.__webglTexture,s.TEXTURE0+S)}function et(T,S){let z=n.get(T);if(T.version>0&&z.__version!==T.version){ht(z,T,S);return}e.bindTexture(s.TEXTURE_2D_ARRAY,z.__webglTexture,s.TEXTURE0+S)}function Y(T,S){let z=n.get(T);if(T.version>0&&z.__version!==T.version){ht(z,T,S);return}e.bindTexture(s.TEXTURE_3D,z.__webglTexture,s.TEXTURE0+S)}function J(T,S){let z=n.get(T);if(T.version>0&&z.__version!==T.version){ft(z,T,S);return}e.bindTexture(s.TEXTURE_CUBE_MAP,z.__webglTexture,s.TEXTURE0+S)}let D={[Ps]:s.REPEAT,[fn]:s.CLAMP_TO_EDGE,[xo]:s.MIRRORED_REPEAT},j={[He]:s.NEAREST,[Dl]:s.NEAREST_MIPMAP_NEAREST,[La]:s.NEAREST_MIPMAP_LINEAR,[Ke]:s.LINEAR,[Eu]:s.LINEAR_MIPMAP_NEAREST,[Ls]:s.LINEAR_MIPMAP_LINEAR},rt={[Fu]:s.NEVER,[Vu]:s.ALWAYS,[Ou]:s.LESS,[xh]:s.LEQUAL,[zu]:s.EQUAL,[Hu]:s.GEQUAL,[Bu]:s.GREATER,[ku]:s.NOTEQUAL};function O(T,S,z){if(z?(s.texParameteri(T,s.TEXTURE_WRAP_S,D[S.wrapS]),s.texParameteri(T,s.TEXTURE_WRAP_T,D[S.wrapT]),(T===s.TEXTURE_3D||T===s.TEXTURE_2D_ARRAY)&&s.texParameteri(T,s.TEXTURE_WRAP_R,D[S.wrapR]),s.texParameteri(T,s.TEXTURE_MAG_FILTER,j[S.magFilter]),s.texParameteri(T,s.TEXTURE_MIN_FILTER,j[S.minFilter])):(s.texParameteri(T,s.TEXTURE_WRAP_S,s.CLAMP_TO_EDGE),s.texParameteri(T,s.TEXTURE_WRAP_T,s.CLAMP_TO_EDGE),(T===s.TEXTURE_3D||T===s.TEXTURE_2D_ARRAY)&&s.texParameteri(T,s.TEXTURE_WRAP_R,s.CLAMP_TO_EDGE),(S.wrapS!==fn||S.wrapT!==fn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),s.texParameteri(T,s.TEXTURE_MAG_FILTER,w(S.magFilter)),s.texParameteri(T,s.TEXTURE_MIN_FILTER,w(S.minFilter)),S.minFilter!==He&&S.minFilter!==Ke&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),S.compareFunction&&(s.texParameteri(T,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(T,s.TEXTURE_COMPARE_FUNC,rt[S.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let it=t.get("EXT_texture_filter_anisotropic");if(S.magFilter===He||S.minFilter!==La&&S.minFilter!==Ls||S.type===Jn&&t.has("OES_texture_float_linear")===!1||o===!1&&S.type===Is&&t.has("OES_texture_half_float_linear")===!1)return;(S.anisotropy>1||n.get(S).__currentAnisotropy)&&(s.texParameterf(T,it.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(S.anisotropy,i.getMaxAnisotropy())),n.get(S).__currentAnisotropy=S.anisotropy)}}function $(T,S){let z=!1;T.__webglInit===void 0&&(T.__webglInit=!0,S.addEventListener("dispose",A));let it=S.source,ot=d.get(it);ot===void 0&&(ot={},d.set(it,ot));let at=N(S);if(at!==T.__cacheKey){ot[at]===void 0&&(ot[at]={texture:s.createTexture(),usedTimes:0},a.memory.textures++,z=!0),ot[at].usedTimes++;let Tt=ot[T.__cacheKey];Tt!==void 0&&(ot[T.__cacheKey].usedTimes--,Tt.usedTimes===0&&b(S)),T.__cacheKey=at,T.__webglTexture=ot[at].texture}return z}function ht(T,S,z){let it=s.TEXTURE_2D;(S.isDataArrayTexture||S.isCompressedArrayTexture)&&(it=s.TEXTURE_2D_ARRAY),S.isData3DTexture&&(it=s.TEXTURE_3D);let ot=$(T,S),at=S.source;e.bindTexture(it,T.__webglTexture,s.TEXTURE0+z);let Tt=n.get(at);if(at.version!==Tt.__version||ot===!0){e.activeTexture(s.TEXTURE0+z);let vt=Qt.getPrimaries(Qt.workingColorSpace),Et=S.colorSpace===Qe?null:Qt.getPrimaries(S.colorSpace),Pt=S.colorSpace===Qe||vt===Et?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,S.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,S.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Pt);let kt=f(S)&&m(S.image)===!1,lt=y(S.image,kt,!1,i.maxTextureSize);lt=ut(S,lt);let Jt=m(lt)||o,Zt=r.convert(S.format,S.colorSpace),Ft=r.convert(S.type),Rt=M(S.internalFormat,Zt,Ft,S.colorSpace,S.isVideoTexture);O(it,S,Jt);let wt,Vt=S.mipmaps,Kt=o&&S.isVideoTexture!==!0&&Rt!==mh,ue=Tt.__version===void 0||ot===!0,Xt=E(S,lt,Jt);if(S.isDepthTexture)Rt=s.DEPTH_COMPONENT,o?S.type===Jn?Rt=s.DEPTH_COMPONENT32F:S.type===Zn?Rt=s.DEPTH_COMPONENT24:S.type===_i?Rt=s.DEPTH24_STENCIL8:Rt=s.DEPTH_COMPONENT16:S.type===Jn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),S.format===xi&&Rt===s.DEPTH_COMPONENT&&S.type!==ll&&S.type!==Zn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),S.type=Zn,Ft=r.convert(S.type)),S.format===Qi&&Rt===s.DEPTH_COMPONENT&&(Rt=s.DEPTH_STENCIL,S.type!==_i&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),S.type=_i,Ft=r.convert(S.type))),ue&&(Kt?e.texStorage2D(s.TEXTURE_2D,1,Rt,lt.width,lt.height):e.texImage2D(s.TEXTURE_2D,0,Rt,lt.width,lt.height,0,Zt,Ft,null));else if(S.isDataTexture)if(Vt.length>0&&Jt){Kt&&ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,Vt[0].width,Vt[0].height);for(let pt=0,I=Vt.length;pt<I;pt++)wt=Vt[pt],Kt?e.texSubImage2D(s.TEXTURE_2D,pt,0,0,wt.width,wt.height,Zt,Ft,wt.data):e.texImage2D(s.TEXTURE_2D,pt,Rt,wt.width,wt.height,0,Zt,Ft,wt.data);S.generateMipmaps=!1}else Kt?(ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,lt.width,lt.height),e.texSubImage2D(s.TEXTURE_2D,0,0,0,lt.width,lt.height,Zt,Ft,lt.data)):e.texImage2D(s.TEXTURE_2D,0,Rt,lt.width,lt.height,0,Zt,Ft,lt.data);else if(S.isCompressedTexture)if(S.isCompressedArrayTexture){Kt&&ue&&e.texStorage3D(s.TEXTURE_2D_ARRAY,Xt,Rt,Vt[0].width,Vt[0].height,lt.depth);for(let pt=0,I=Vt.length;pt<I;pt++)wt=Vt[pt],S.format!==pn?Zt!==null?Kt?e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,pt,0,0,0,wt.width,wt.height,lt.depth,Zt,wt.data,0,0):e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,pt,Rt,wt.width,wt.height,lt.depth,0,wt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Kt?e.texSubImage3D(s.TEXTURE_2D_ARRAY,pt,0,0,0,wt.width,wt.height,lt.depth,Zt,Ft,wt.data):e.texImage3D(s.TEXTURE_2D_ARRAY,pt,Rt,wt.width,wt.height,lt.depth,0,Zt,Ft,wt.data)}else{Kt&&ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,Vt[0].width,Vt[0].height);for(let pt=0,I=Vt.length;pt<I;pt++)wt=Vt[pt],S.format!==pn?Zt!==null?Kt?e.compressedTexSubImage2D(s.TEXTURE_2D,pt,0,0,wt.width,wt.height,Zt,wt.data):e.compressedTexImage2D(s.TEXTURE_2D,pt,Rt,wt.width,wt.height,0,wt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Kt?e.texSubImage2D(s.TEXTURE_2D,pt,0,0,wt.width,wt.height,Zt,Ft,wt.data):e.texImage2D(s.TEXTURE_2D,pt,Rt,wt.width,wt.height,0,Zt,Ft,wt.data)}else if(S.isDataArrayTexture)Kt?(ue&&e.texStorage3D(s.TEXTURE_2D_ARRAY,Xt,Rt,lt.width,lt.height,lt.depth),e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,lt.width,lt.height,lt.depth,Zt,Ft,lt.data)):e.texImage3D(s.TEXTURE_2D_ARRAY,0,Rt,lt.width,lt.height,lt.depth,0,Zt,Ft,lt.data);else if(S.isData3DTexture)Kt?(ue&&e.texStorage3D(s.TEXTURE_3D,Xt,Rt,lt.width,lt.height,lt.depth),e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,lt.width,lt.height,lt.depth,Zt,Ft,lt.data)):e.texImage3D(s.TEXTURE_3D,0,Rt,lt.width,lt.height,lt.depth,0,Zt,Ft,lt.data);else if(S.isFramebufferTexture){if(ue)if(Kt)e.texStorage2D(s.TEXTURE_2D,Xt,Rt,lt.width,lt.height);else{let pt=lt.width,I=lt.height;for(let Mt=0;Mt<Xt;Mt++)e.texImage2D(s.TEXTURE_2D,Mt,Rt,pt,I,0,Zt,Ft,null),pt>>=1,I>>=1}}else if(Vt.length>0&&Jt){Kt&&ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,Vt[0].width,Vt[0].height);for(let pt=0,I=Vt.length;pt<I;pt++)wt=Vt[pt],Kt?e.texSubImage2D(s.TEXTURE_2D,pt,0,0,Zt,Ft,wt):e.texImage2D(s.TEXTURE_2D,pt,Rt,Zt,Ft,wt);S.generateMipmaps=!1}else Kt?(ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,lt.width,lt.height),e.texSubImage2D(s.TEXTURE_2D,0,0,0,Zt,Ft,lt)):e.texImage2D(s.TEXTURE_2D,0,Rt,Zt,Ft,lt);x(S,Jt)&&_(it),Tt.__version=at.version,S.onUpdate&&S.onUpdate(S)}T.__version=S.version}function ft(T,S,z){if(S.image.length!==6)return;let it=$(T,S),ot=S.source;e.bindTexture(s.TEXTURE_CUBE_MAP,T.__webglTexture,s.TEXTURE0+z);let at=n.get(ot);if(ot.version!==at.__version||it===!0){e.activeTexture(s.TEXTURE0+z);let Tt=Qt.getPrimaries(Qt.workingColorSpace),vt=S.colorSpace===Qe?null:Qt.getPrimaries(S.colorSpace),Et=S.colorSpace===Qe||Tt===vt?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,S.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,S.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Et);let Pt=S.isCompressedTexture||S.image[0].isCompressedTexture,kt=S.image[0]&&S.image[0].isDataTexture,lt=[];for(let pt=0;pt<6;pt++)!Pt&&!kt?lt[pt]=y(S.image[pt],!1,!0,i.maxCubemapSize):lt[pt]=kt?S.image[pt].image:S.image[pt],lt[pt]=ut(S,lt[pt]);let Jt=lt[0],Zt=m(Jt)||o,Ft=r.convert(S.format,S.colorSpace),Rt=r.convert(S.type),wt=M(S.internalFormat,Ft,Rt,S.colorSpace),Vt=o&&S.isVideoTexture!==!0,Kt=at.__version===void 0||it===!0,ue=E(S,Jt,Zt);O(s.TEXTURE_CUBE_MAP,S,Zt);let Xt;if(Pt){Vt&&Kt&&e.texStorage2D(s.TEXTURE_CUBE_MAP,ue,wt,Jt.width,Jt.height);for(let pt=0;pt<6;pt++){Xt=lt[pt].mipmaps;for(let I=0;I<Xt.length;I++){let Mt=Xt[I];S.format!==pn?Ft!==null?Vt?e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I,0,0,Mt.width,Mt.height,Ft,Mt.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I,wt,Mt.width,Mt.height,0,Mt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I,0,0,Mt.width,Mt.height,Ft,Rt,Mt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I,wt,Mt.width,Mt.height,0,Ft,Rt,Mt.data)}}}else{Xt=S.mipmaps,Vt&&Kt&&(Xt.length>0&&ue++,e.texStorage2D(s.TEXTURE_CUBE_MAP,ue,wt,lt[0].width,lt[0].height));for(let pt=0;pt<6;pt++)if(kt){Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,0,0,lt[pt].width,lt[pt].height,Ft,Rt,lt[pt].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,wt,lt[pt].width,lt[pt].height,0,Ft,Rt,lt[pt].data);for(let I=0;I<Xt.length;I++){let bt=Xt[I].image[pt].image;Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I+1,0,0,bt.width,bt.height,Ft,Rt,bt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I+1,wt,bt.width,bt.height,0,Ft,Rt,bt.data)}}else{Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,0,0,Ft,Rt,lt[pt]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,0,wt,Ft,Rt,lt[pt]);for(let I=0;I<Xt.length;I++){let Mt=Xt[I];Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I+1,0,0,Ft,Rt,Mt.image[pt]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+pt,I+1,wt,Ft,Rt,Mt.image[pt])}}}x(S,Zt)&&_(s.TEXTURE_CUBE_MAP),at.__version=ot.version,S.onUpdate&&S.onUpdate(S)}T.__version=S.version}function dt(T,S,z,it,ot,at){let Tt=r.convert(z.format,z.colorSpace),vt=r.convert(z.type),Et=M(z.internalFormat,Tt,vt,z.colorSpace);if(!n.get(S).__hasExternalTextures){let kt=Math.max(1,S.width>>at),lt=Math.max(1,S.height>>at);ot===s.TEXTURE_3D||ot===s.TEXTURE_2D_ARRAY?e.texImage3D(ot,at,Et,kt,lt,S.depth,0,Tt,vt,null):e.texImage2D(ot,at,Et,kt,lt,0,Tt,vt,null)}e.bindFramebuffer(s.FRAMEBUFFER,T),G(S)?l.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,it,ot,n.get(z).__webglTexture,0,K(S)):(ot===s.TEXTURE_2D||ot>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&ot<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,it,ot,n.get(z).__webglTexture,at),e.bindFramebuffer(s.FRAMEBUFFER,null)}function X(T,S,z){if(s.bindRenderbuffer(s.RENDERBUFFER,T),S.depthBuffer&&!S.stencilBuffer){let it=o===!0?s.DEPTH_COMPONENT24:s.DEPTH_COMPONENT16;if(z||G(S)){let ot=S.depthTexture;ot&&ot.isDepthTexture&&(ot.type===Jn?it=s.DEPTH_COMPONENT32F:ot.type===Zn&&(it=s.DEPTH_COMPONENT24));let at=K(S);G(S)?l.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,at,it,S.width,S.height):s.renderbufferStorageMultisample(s.RENDERBUFFER,at,it,S.width,S.height)}else s.renderbufferStorage(s.RENDERBUFFER,it,S.width,S.height);s.framebufferRenderbuffer(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.RENDERBUFFER,T)}else if(S.depthBuffer&&S.stencilBuffer){let it=K(S);z&&G(S)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,it,s.DEPTH24_STENCIL8,S.width,S.height):G(S)?l.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,it,s.DEPTH24_STENCIL8,S.width,S.height):s.renderbufferStorage(s.RENDERBUFFER,s.DEPTH_STENCIL,S.width,S.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.RENDERBUFFER,T)}else{let it=S.isWebGLMultipleRenderTargets===!0?S.texture:[S.texture];for(let ot=0;ot<it.length;ot++){let at=it[ot],Tt=r.convert(at.format,at.colorSpace),vt=r.convert(at.type),Et=M(at.internalFormat,Tt,vt,at.colorSpace),Pt=K(S);z&&G(S)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,Pt,Et,S.width,S.height):G(S)?l.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,Pt,Et,S.width,S.height):s.renderbufferStorage(s.RENDERBUFFER,Et,S.width,S.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function Q(T,S){if(S&&S.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,T),!(S.depthTexture&&S.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(S.depthTexture).__webglTexture||S.depthTexture.image.width!==S.width||S.depthTexture.image.height!==S.height)&&(S.depthTexture.image.width=S.width,S.depthTexture.image.height=S.height,S.depthTexture.needsUpdate=!0),V(S.depthTexture,0);let it=n.get(S.depthTexture).__webglTexture,ot=K(S);if(S.depthTexture.format===xi)G(S)?l.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,it,0,ot):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,it,0);else if(S.depthTexture.format===Qi)G(S)?l.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,it,0,ot):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,it,0);else throw new Error("Unknown depthTexture format")}function tt(T){let S=n.get(T),z=T.isWebGLCubeRenderTarget===!0;if(T.depthTexture&&!S.__autoAllocateDepthBuffer){if(z)throw new Error("target.depthTexture not supported in Cube render targets");Q(S.__webglFramebuffer,T)}else if(z){S.__webglDepthbuffer=[];for(let it=0;it<6;it++)e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer[it]),S.__webglDepthbuffer[it]=s.createRenderbuffer(),X(S.__webglDepthbuffer[it],T,!1)}else e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer),S.__webglDepthbuffer=s.createRenderbuffer(),X(S.__webglDepthbuffer,T,!1);e.bindFramebuffer(s.FRAMEBUFFER,null)}function xt(T,S,z){let it=n.get(T);S!==void 0&&dt(it.__webglFramebuffer,T,T.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),z!==void 0&&tt(T)}function P(T){let S=T.texture,z=n.get(T),it=n.get(S);T.addEventListener("dispose",U),T.isWebGLMultipleRenderTargets!==!0&&(it.__webglTexture===void 0&&(it.__webglTexture=s.createTexture()),it.__version=S.version,a.memory.textures++);let ot=T.isWebGLCubeRenderTarget===!0,at=T.isWebGLMultipleRenderTargets===!0,Tt=m(T)||o;if(ot){z.__webglFramebuffer=[];for(let vt=0;vt<6;vt++)if(o&&S.mipmaps&&S.mipmaps.length>0){z.__webglFramebuffer[vt]=[];for(let Et=0;Et<S.mipmaps.length;Et++)z.__webglFramebuffer[vt][Et]=s.createFramebuffer()}else z.__webglFramebuffer[vt]=s.createFramebuffer()}else{if(o&&S.mipmaps&&S.mipmaps.length>0){z.__webglFramebuffer=[];for(let vt=0;vt<S.mipmaps.length;vt++)z.__webglFramebuffer[vt]=s.createFramebuffer()}else z.__webglFramebuffer=s.createFramebuffer();if(at)if(i.drawBuffers){let vt=T.texture;for(let Et=0,Pt=vt.length;Et<Pt;Et++){let kt=n.get(vt[Et]);kt.__webglTexture===void 0&&(kt.__webglTexture=s.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&T.samples>0&&G(T)===!1){let vt=at?S:[S];z.__webglMultisampledFramebuffer=s.createFramebuffer(),z.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let Et=0;Et<vt.length;Et++){let Pt=vt[Et];z.__webglColorRenderbuffer[Et]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,z.__webglColorRenderbuffer[Et]);let kt=r.convert(Pt.format,Pt.colorSpace),lt=r.convert(Pt.type),Jt=M(Pt.internalFormat,kt,lt,Pt.colorSpace,T.isXRRenderTarget===!0),Zt=K(T);s.renderbufferStorageMultisample(s.RENDERBUFFER,Zt,Jt,T.width,T.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Et,s.RENDERBUFFER,z.__webglColorRenderbuffer[Et])}s.bindRenderbuffer(s.RENDERBUFFER,null),T.depthBuffer&&(z.__webglDepthRenderbuffer=s.createRenderbuffer(),X(z.__webglDepthRenderbuffer,T,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(ot){e.bindTexture(s.TEXTURE_CUBE_MAP,it.__webglTexture),O(s.TEXTURE_CUBE_MAP,S,Tt);for(let vt=0;vt<6;vt++)if(o&&S.mipmaps&&S.mipmaps.length>0)for(let Et=0;Et<S.mipmaps.length;Et++)dt(z.__webglFramebuffer[vt][Et],T,S,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+vt,Et);else dt(z.__webglFramebuffer[vt],T,S,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+vt,0);x(S,Tt)&&_(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(at){let vt=T.texture;for(let Et=0,Pt=vt.length;Et<Pt;Et++){let kt=vt[Et],lt=n.get(kt);e.bindTexture(s.TEXTURE_2D,lt.__webglTexture),O(s.TEXTURE_2D,kt,Tt),dt(z.__webglFramebuffer,T,kt,s.COLOR_ATTACHMENT0+Et,s.TEXTURE_2D,0),x(kt,Tt)&&_(s.TEXTURE_2D)}e.unbindTexture()}else{let vt=s.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(o?vt=T.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(vt,it.__webglTexture),O(vt,S,Tt),o&&S.mipmaps&&S.mipmaps.length>0)for(let Et=0;Et<S.mipmaps.length;Et++)dt(z.__webglFramebuffer[Et],T,S,s.COLOR_ATTACHMENT0,vt,Et);else dt(z.__webglFramebuffer,T,S,s.COLOR_ATTACHMENT0,vt,0);x(S,Tt)&&_(vt),e.unbindTexture()}T.depthBuffer&&tt(T)}function st(T){let S=m(T)||o,z=T.isWebGLMultipleRenderTargets===!0?T.texture:[T.texture];for(let it=0,ot=z.length;it<ot;it++){let at=z[it];if(x(at,S)){let Tt=T.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:s.TEXTURE_2D,vt=n.get(at).__webglTexture;e.bindTexture(Tt,vt),_(Tt),e.unbindTexture()}}}function H(T){if(o&&T.samples>0&&G(T)===!1){let S=T.isWebGLMultipleRenderTargets?T.texture:[T.texture],z=T.width,it=T.height,ot=s.COLOR_BUFFER_BIT,at=[],Tt=T.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,vt=n.get(T),Et=T.isWebGLMultipleRenderTargets===!0;if(Et)for(let Pt=0;Pt<S.length;Pt++)e.bindFramebuffer(s.FRAMEBUFFER,vt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,vt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,vt.__webglMultisampledFramebuffer),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,vt.__webglFramebuffer);for(let Pt=0;Pt<S.length;Pt++){at.push(s.COLOR_ATTACHMENT0+Pt),T.depthBuffer&&at.push(Tt);let kt=vt.__ignoreDepthValues!==void 0?vt.__ignoreDepthValues:!1;if(kt===!1&&(T.depthBuffer&&(ot|=s.DEPTH_BUFFER_BIT),T.stencilBuffer&&(ot|=s.STENCIL_BUFFER_BIT)),Et&&s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,vt.__webglColorRenderbuffer[Pt]),kt===!0&&(s.invalidateFramebuffer(s.READ_FRAMEBUFFER,[Tt]),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[Tt])),Et){let lt=n.get(S[Pt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,lt,0)}s.blitFramebuffer(0,0,z,it,0,0,z,it,ot,s.NEAREST),c&&s.invalidateFramebuffer(s.READ_FRAMEBUFFER,at)}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),Et)for(let Pt=0;Pt<S.length;Pt++){e.bindFramebuffer(s.FRAMEBUFFER,vt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.RENDERBUFFER,vt.__webglColorRenderbuffer[Pt]);let kt=n.get(S[Pt]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,vt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.TEXTURE_2D,kt,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,vt.__webglMultisampledFramebuffer)}}function K(T){return Math.min(i.maxSamples,T.samples)}function G(T){let S=n.get(T);return o&&T.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&S.__useRenderToTexture!==!1}function yt(T){let S=a.render.frame;h.get(T)!==S&&(h.set(T,S),T.update())}function ut(T,S){let z=T.colorSpace,it=T.format,ot=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||T.format===yo||z!==Dn&&z!==Qe&&(Qt.getTransfer(z)===re?o===!1?t.has("EXT_sRGB")===!0&&it===pn?(T.format=yo,T.minFilter=Ke,T.generateMipmaps=!1):S=Ir.sRGBToLinear(S):(it!==pn||ot!==jn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",z)),S}this.allocateTextureUnit=L,this.resetTextureUnits=nt,this.setTexture2D=V,this.setTexture2DArray=et,this.setTexture3D=Y,this.setTextureCube=J,this.rebindTextures=xt,this.setupRenderTarget=P,this.updateRenderTargetMipmap=st,this.updateMultisampleRenderTarget=H,this.setupDepthRenderbuffer=tt,this.setupFrameBufferTexture=dt,this.useMultisampledRTT=G}function Dg(s,t,e){let n=e.isWebGL2;function i(r,a=Qe){let o,l=Qt.getTransfer(a);if(r===jn)return s.UNSIGNED_BYTE;if(r===hh)return s.UNSIGNED_SHORT_4_4_4_4;if(r===uh)return s.UNSIGNED_SHORT_5_5_5_1;if(r===wu)return s.BYTE;if(r===Tu)return s.SHORT;if(r===ll)return s.UNSIGNED_SHORT;if(r===ch)return s.INT;if(r===Zn)return s.UNSIGNED_INT;if(r===Jn)return s.FLOAT;if(r===Is)return n?s.HALF_FLOAT:(o=t.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(r===Au)return s.ALPHA;if(r===pn)return s.RGBA;if(r===Ru)return s.LUMINANCE;if(r===Cu)return s.LUMINANCE_ALPHA;if(r===xi)return s.DEPTH_COMPONENT;if(r===Qi)return s.DEPTH_STENCIL;if(r===yo)return o=t.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(r===Pu)return s.RED;if(r===dh)return s.RED_INTEGER;if(r===Lu)return s.RG;if(r===fh)return s.RG_INTEGER;if(r===ph)return s.RGBA_INTEGER;if(r===Ia||r===Da||r===Ua||r===Na)if(l===re)if(o=t.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(r===Ia)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===Da)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Ua)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===Na)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=t.get("WEBGL_compressed_texture_s3tc"),o!==null){if(r===Ia)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===Da)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Ua)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===Na)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Ul||r===Nl||r===Fl||r===Ol)if(o=t.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(r===Ul)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===Nl)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Fl)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Ol)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===mh)return o=t.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===zl||r===Bl)if(o=t.get("WEBGL_compressed_texture_etc"),o!==null){if(r===zl)return l===re?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(r===Bl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===kl||r===Hl||r===Vl||r===Gl||r===Wl||r===Xl||r===ql||r===Yl||r===Zl||r===Jl||r===$l||r===Kl||r===Ql||r===jl)if(o=t.get("WEBGL_compressed_texture_astc"),o!==null){if(r===kl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Hl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Vl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Gl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Wl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Xl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===ql)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Yl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Zl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Jl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===$l)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Kl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Ql)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===jl)return l===re?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Fa||r===tc||r===ec)if(o=t.get("EXT_texture_compression_bptc"),o!==null){if(r===Fa)return l===re?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===tc)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===ec)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===Iu||r===nc||r===ic||r===sc)if(o=t.get("EXT_texture_compression_rgtc"),o!==null){if(r===Fa)return o.COMPRESSED_RED_RGTC1_EXT;if(r===nc)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===ic)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===sc)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===_i?n?s.UNSIGNED_INT_24_8:(o=t.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):s[r]!==void 0?s[r]:null}return{convert:i}}var Uo=class extends Ne{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},je=class extends we{constructor(){super(),this.isGroup=!0,this.type="Group"}},Ug={type:"move"},Ts=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new je,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new je,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new C,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new C),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new je,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new C,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new C),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(let y of t.hand.values()){let m=e.getJointPose(y,n),f=this._getHandJoint(c,y);m!==null&&(f.matrix.fromArray(m.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=m.radius),f.visible=m!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),p=.02,g=.005;c.inputState.pinching&&d>p+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=p-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(o.matrix.fromArray(i.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,i.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(i.linearVelocity)):o.hasLinearVelocity=!1,i.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(i.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Ug)))}return o!==null&&(o.visible=i!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new je;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},No=class extends ei{constructor(t,e){super();let n=this,i=null,r=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,p=null,g=null,y=e.getContextAttributes(),m=null,f=null,x=[],_=[],M=new _t,E=null,w=new Ne;w.layers.enable(1),w.viewport=new oe;let A=new Ne;A.layers.enable(2),A.viewport=new oe;let U=[w,A],v=new Uo;v.layers.enable(1),v.layers.enable(2);let b=null,F=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(O){let $=x[O];return $===void 0&&($=new Ts,x[O]=$),$.getTargetRaySpace()},this.getControllerGrip=function(O){let $=x[O];return $===void 0&&($=new Ts,x[O]=$),$.getGripSpace()},this.getHand=function(O){let $=x[O];return $===void 0&&($=new Ts,x[O]=$),$.getHandSpace()};function k(O){let $=_.indexOf(O.inputSource);if($===-1)return;let ht=x[$];ht!==void 0&&(ht.update(O.inputSource,O.frame,c||a),ht.dispatchEvent({type:O.type,data:O.inputSource}))}function nt(){i.removeEventListener("select",k),i.removeEventListener("selectstart",k),i.removeEventListener("selectend",k),i.removeEventListener("squeeze",k),i.removeEventListener("squeezestart",k),i.removeEventListener("squeezeend",k),i.removeEventListener("end",nt),i.removeEventListener("inputsourceschange",L);for(let O=0;O<x.length;O++){let $=_[O];$!==null&&(_[O]=null,x[O].disconnect($))}b=null,F=null,t.setRenderTarget(m),p=null,d=null,u=null,i=null,f=null,rt.stop(),n.isPresenting=!1,t.setPixelRatio(E),t.setSize(M.width,M.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(O){r=O,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(O){o=O,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(O){c=O},this.getBaseLayer=function(){return d!==null?d:p},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(O){if(i=O,i!==null){if(m=t.getRenderTarget(),i.addEventListener("select",k),i.addEventListener("selectstart",k),i.addEventListener("selectend",k),i.addEventListener("squeeze",k),i.addEventListener("squeezestart",k),i.addEventListener("squeezeend",k),i.addEventListener("end",nt),i.addEventListener("inputsourceschange",L),y.xrCompatible!==!0&&await e.makeXRCompatible(),E=t.getPixelRatio(),t.getSize(M),i.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let $={antialias:i.renderState.layers===void 0?y.antialias:!0,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(i,e,$),i.updateRenderState({baseLayer:p}),t.setPixelRatio(1),t.setSize(p.framebufferWidth,p.framebufferHeight,!1),f=new Un(p.framebufferWidth,p.framebufferHeight,{format:pn,type:jn,colorSpace:t.outputColorSpace,stencilBuffer:y.stencil})}else{let $=null,ht=null,ft=null;y.depth&&(ft=y.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,$=y.stencil?Qi:xi,ht=y.stencil?_i:Zn);let dt={colorFormat:e.RGBA8,depthFormat:ft,scaleFactor:r};u=new XRWebGLBinding(i,e),d=u.createProjectionLayer(dt),i.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),f=new Un(d.textureWidth,d.textureHeight,{format:pn,type:jn,depthTexture:new Gr(d.textureWidth,d.textureHeight,ht,void 0,void 0,void 0,void 0,void 0,void 0,$),stencilBuffer:y.stencil,colorSpace:t.outputColorSpace,samples:y.antialias?4:0});let X=t.properties.get(f);X.__ignoreDepthValues=d.ignoreDepthValues}f.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await i.requestReferenceSpace(o),rt.setContext(i),rt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode};function L(O){for(let $=0;$<O.removed.length;$++){let ht=O.removed[$],ft=_.indexOf(ht);ft>=0&&(_[ft]=null,x[ft].disconnect(ht))}for(let $=0;$<O.added.length;$++){let ht=O.added[$],ft=_.indexOf(ht);if(ft===-1){for(let X=0;X<x.length;X++)if(X>=_.length){_.push(ht),ft=X;break}else if(_[X]===null){_[X]=ht,ft=X;break}if(ft===-1)break}let dt=x[ft];dt&&dt.connect(ht)}}let N=new C,V=new C;function et(O,$,ht){N.setFromMatrixPosition($.matrixWorld),V.setFromMatrixPosition(ht.matrixWorld);let ft=N.distanceTo(V),dt=$.projectionMatrix.elements,X=ht.projectionMatrix.elements,Q=dt[14]/(dt[10]-1),tt=dt[14]/(dt[10]+1),xt=(dt[9]+1)/dt[5],P=(dt[9]-1)/dt[5],st=(dt[8]-1)/dt[0],H=(X[8]+1)/X[0],K=Q*st,G=Q*H,yt=ft/(-st+H),ut=yt*-st;$.matrixWorld.decompose(O.position,O.quaternion,O.scale),O.translateX(ut),O.translateZ(yt),O.matrixWorld.compose(O.position,O.quaternion,O.scale),O.matrixWorldInverse.copy(O.matrixWorld).invert();let T=Q+yt,S=tt+yt,z=K-ut,it=G+(ft-ut),ot=xt*tt/S*T,at=P*tt/S*T;O.projectionMatrix.makePerspective(z,it,ot,at,T,S),O.projectionMatrixInverse.copy(O.projectionMatrix).invert()}function Y(O,$){$===null?O.matrixWorld.copy(O.matrix):O.matrixWorld.multiplyMatrices($.matrixWorld,O.matrix),O.matrixWorldInverse.copy(O.matrixWorld).invert()}this.updateCamera=function(O){if(i===null)return;v.near=A.near=w.near=O.near,v.far=A.far=w.far=O.far,(b!==v.near||F!==v.far)&&(i.updateRenderState({depthNear:v.near,depthFar:v.far}),b=v.near,F=v.far);let $=O.parent,ht=v.cameras;Y(v,$);for(let ft=0;ft<ht.length;ft++)Y(ht[ft],$);ht.length===2?et(v,w,A):v.projectionMatrix.copy(w.projectionMatrix),J(O,v,$)};function J(O,$,ht){ht===null?O.matrix.copy($.matrixWorld):(O.matrix.copy(ht.matrixWorld),O.matrix.invert(),O.matrix.multiply($.matrixWorld)),O.matrix.decompose(O.position,O.quaternion,O.scale),O.updateMatrixWorld(!0),O.projectionMatrix.copy($.projectionMatrix),O.projectionMatrixInverse.copy($.projectionMatrixInverse),O.isPerspectiveCamera&&(O.fov=vo*2*Math.atan(1/O.projectionMatrix.elements[5]),O.zoom=1)}this.getCamera=function(){return v},this.getFoveation=function(){if(!(d===null&&p===null))return l},this.setFoveation=function(O){l=O,d!==null&&(d.fixedFoveation=O),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=O)};let D=null;function j(O,$){if(h=$.getViewerPose(c||a),g=$,h!==null){let ht=h.views;p!==null&&(t.setRenderTargetFramebuffer(f,p.framebuffer),t.setRenderTarget(f));let ft=!1;ht.length!==v.cameras.length&&(v.cameras.length=0,ft=!0);for(let dt=0;dt<ht.length;dt++){let X=ht[dt],Q=null;if(p!==null)Q=p.getViewport(X);else{let xt=u.getViewSubImage(d,X);Q=xt.viewport,dt===0&&(t.setRenderTargetTextures(f,xt.colorTexture,d.ignoreDepthValues?void 0:xt.depthStencilTexture),t.setRenderTarget(f))}let tt=U[dt];tt===void 0&&(tt=new Ne,tt.layers.enable(dt),tt.viewport=new oe,U[dt]=tt),tt.matrix.fromArray(X.transform.matrix),tt.matrix.decompose(tt.position,tt.quaternion,tt.scale),tt.projectionMatrix.fromArray(X.projectionMatrix),tt.projectionMatrixInverse.copy(tt.projectionMatrix).invert(),tt.viewport.set(Q.x,Q.y,Q.width,Q.height),dt===0&&(v.matrix.copy(tt.matrix),v.matrix.decompose(v.position,v.quaternion,v.scale)),ft===!0&&v.cameras.push(tt)}}for(let ht=0;ht<x.length;ht++){let ft=_[ht],dt=x[ht];ft!==null&&dt!==void 0&&dt.update(ft,$,c||a)}D&&D(O,$),$.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:$}),g=null}let rt=new bh;rt.setAnimationLoop(j),this.setAnimationLoop=function(O){D=O},this.dispose=function(){}}};function Ng(s,t){function e(m,f){m.matrixAutoUpdate===!0&&m.updateMatrix(),f.value.copy(m.matrix)}function n(m,f){f.color.getRGB(m.fogColor.value,Mh(s)),f.isFog?(m.fogNear.value=f.near,m.fogFar.value=f.far):f.isFogExp2&&(m.fogDensity.value=f.density)}function i(m,f,x,_,M){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(m,f):f.isMeshToonMaterial?(r(m,f),u(m,f)):f.isMeshPhongMaterial?(r(m,f),h(m,f)):f.isMeshStandardMaterial?(r(m,f),d(m,f),f.isMeshPhysicalMaterial&&p(m,f,M)):f.isMeshMatcapMaterial?(r(m,f),g(m,f)):f.isMeshDepthMaterial?r(m,f):f.isMeshDistanceMaterial?(r(m,f),y(m,f)):f.isMeshNormalMaterial?r(m,f):f.isLineBasicMaterial?(a(m,f),f.isLineDashedMaterial&&o(m,f)):f.isPointsMaterial?l(m,f,x,_):f.isSpriteMaterial?c(m,f):f.isShadowMaterial?(m.color.value.copy(f.color),m.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(m,f){m.opacity.value=f.opacity,f.color&&m.diffuse.value.copy(f.color),f.emissive&&m.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(m.map.value=f.map,e(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.bumpMap&&(m.bumpMap.value=f.bumpMap,e(f.bumpMap,m.bumpMapTransform),m.bumpScale.value=f.bumpScale,f.side===Ee&&(m.bumpScale.value*=-1)),f.normalMap&&(m.normalMap.value=f.normalMap,e(f.normalMap,m.normalMapTransform),m.normalScale.value.copy(f.normalScale),f.side===Ee&&m.normalScale.value.negate()),f.displacementMap&&(m.displacementMap.value=f.displacementMap,e(f.displacementMap,m.displacementMapTransform),m.displacementScale.value=f.displacementScale,m.displacementBias.value=f.displacementBias),f.emissiveMap&&(m.emissiveMap.value=f.emissiveMap,e(f.emissiveMap,m.emissiveMapTransform)),f.specularMap&&(m.specularMap.value=f.specularMap,e(f.specularMap,m.specularMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest);let x=t.get(f).envMap;if(x&&(m.envMap.value=x,m.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=f.reflectivity,m.ior.value=f.ior,m.refractionRatio.value=f.refractionRatio),f.lightMap){m.lightMap.value=f.lightMap;let _=s._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=f.lightMapIntensity*_,e(f.lightMap,m.lightMapTransform)}f.aoMap&&(m.aoMap.value=f.aoMap,m.aoMapIntensity.value=f.aoMapIntensity,e(f.aoMap,m.aoMapTransform))}function a(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,f.map&&(m.map.value=f.map,e(f.map,m.mapTransform))}function o(m,f){m.dashSize.value=f.dashSize,m.totalSize.value=f.dashSize+f.gapSize,m.scale.value=f.scale}function l(m,f,x,_){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.size.value=f.size*x,m.scale.value=_*.5,f.map&&(m.map.value=f.map,e(f.map,m.uvTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function c(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.rotation.value=f.rotation,f.map&&(m.map.value=f.map,e(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function h(m,f){m.specular.value.copy(f.specular),m.shininess.value=Math.max(f.shininess,1e-4)}function u(m,f){f.gradientMap&&(m.gradientMap.value=f.gradientMap)}function d(m,f){m.metalness.value=f.metalness,f.metalnessMap&&(m.metalnessMap.value=f.metalnessMap,e(f.metalnessMap,m.metalnessMapTransform)),m.roughness.value=f.roughness,f.roughnessMap&&(m.roughnessMap.value=f.roughnessMap,e(f.roughnessMap,m.roughnessMapTransform)),t.get(f).envMap&&(m.envMapIntensity.value=f.envMapIntensity)}function p(m,f,x){m.ior.value=f.ior,f.sheen>0&&(m.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),m.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(m.sheenColorMap.value=f.sheenColorMap,e(f.sheenColorMap,m.sheenColorMapTransform)),f.sheenRoughnessMap&&(m.sheenRoughnessMap.value=f.sheenRoughnessMap,e(f.sheenRoughnessMap,m.sheenRoughnessMapTransform))),f.clearcoat>0&&(m.clearcoat.value=f.clearcoat,m.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(m.clearcoatMap.value=f.clearcoatMap,e(f.clearcoatMap,m.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,e(f.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(m.clearcoatNormalMap.value=f.clearcoatNormalMap,e(f.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===Ee&&m.clearcoatNormalScale.value.negate())),f.iridescence>0&&(m.iridescence.value=f.iridescence,m.iridescenceIOR.value=f.iridescenceIOR,m.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(m.iridescenceMap.value=f.iridescenceMap,e(f.iridescenceMap,m.iridescenceMapTransform)),f.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=f.iridescenceThicknessMap,e(f.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),f.transmission>0&&(m.transmission.value=f.transmission,m.transmissionSamplerMap.value=x.texture,m.transmissionSamplerSize.value.set(x.width,x.height),f.transmissionMap&&(m.transmissionMap.value=f.transmissionMap,e(f.transmissionMap,m.transmissionMapTransform)),m.thickness.value=f.thickness,f.thicknessMap&&(m.thicknessMap.value=f.thicknessMap,e(f.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=f.attenuationDistance,m.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(m.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(m.anisotropyMap.value=f.anisotropyMap,e(f.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=f.specularIntensity,m.specularColor.value.copy(f.specularColor),f.specularColorMap&&(m.specularColorMap.value=f.specularColorMap,e(f.specularColorMap,m.specularColorMapTransform)),f.specularIntensityMap&&(m.specularIntensityMap.value=f.specularIntensityMap,e(f.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,f){f.matcap&&(m.matcap.value=f.matcap)}function y(m,f){let x=t.get(f).light;m.referencePosition.value.setFromMatrixPosition(x.matrixWorld),m.nearDistance.value=x.shadow.camera.near,m.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function Fg(s,t,e,n){let i={},r={},a=[],o=e.isWebGL2?s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(x,_){let M=_.program;n.uniformBlockBinding(x,M)}function c(x,_){let M=i[x.id];M===void 0&&(g(x),M=h(x),i[x.id]=M,x.addEventListener("dispose",m));let E=_.program;n.updateUBOMapping(x,E);let w=t.render.frame;r[x.id]!==w&&(d(x),r[x.id]=w)}function h(x){let _=u();x.__bindingPointIndex=_;let M=s.createBuffer(),E=x.__size,w=x.usage;return s.bindBuffer(s.UNIFORM_BUFFER,M),s.bufferData(s.UNIFORM_BUFFER,E,w),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,_,M),M}function u(){for(let x=0;x<o;x++)if(a.indexOf(x)===-1)return a.push(x),x;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(x){let _=i[x.id],M=x.uniforms,E=x.__cache;s.bindBuffer(s.UNIFORM_BUFFER,_);for(let w=0,A=M.length;w<A;w++){let U=Array.isArray(M[w])?M[w]:[M[w]];for(let v=0,b=U.length;v<b;v++){let F=U[v];if(p(F,w,v,E)===!0){let k=F.__offset,nt=Array.isArray(F.value)?F.value:[F.value],L=0;for(let N=0;N<nt.length;N++){let V=nt[N],et=y(V);typeof V=="number"||typeof V=="boolean"?(F.__data[0]=V,s.bufferSubData(s.UNIFORM_BUFFER,k+L,F.__data)):V.isMatrix3?(F.__data[0]=V.elements[0],F.__data[1]=V.elements[1],F.__data[2]=V.elements[2],F.__data[3]=0,F.__data[4]=V.elements[3],F.__data[5]=V.elements[4],F.__data[6]=V.elements[5],F.__data[7]=0,F.__data[8]=V.elements[6],F.__data[9]=V.elements[7],F.__data[10]=V.elements[8],F.__data[11]=0):(V.toArray(F.__data,L),L+=et.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,k,F.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function p(x,_,M,E){let w=x.value,A=_+"_"+M;if(E[A]===void 0)return typeof w=="number"||typeof w=="boolean"?E[A]=w:E[A]=w.clone(),!0;{let U=E[A];if(typeof w=="number"||typeof w=="boolean"){if(U!==w)return E[A]=w,!0}else if(U.equals(w)===!1)return U.copy(w),!0}return!1}function g(x){let _=x.uniforms,M=0,E=16;for(let A=0,U=_.length;A<U;A++){let v=Array.isArray(_[A])?_[A]:[_[A]];for(let b=0,F=v.length;b<F;b++){let k=v[b],nt=Array.isArray(k.value)?k.value:[k.value];for(let L=0,N=nt.length;L<N;L++){let V=nt[L],et=y(V),Y=M%E;Y!==0&&E-Y<et.boundary&&(M+=E-Y),k.__data=new Float32Array(et.storage/Float32Array.BYTES_PER_ELEMENT),k.__offset=M,M+=et.storage}}}let w=M%E;return w>0&&(M+=E-w),x.__size=M,x.__cache={},this}function y(x){let _={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(_.boundary=4,_.storage=4):x.isVector2?(_.boundary=8,_.storage=8):x.isVector3||x.isColor?(_.boundary=16,_.storage=12):x.isVector4?(_.boundary=16,_.storage=16):x.isMatrix3?(_.boundary=48,_.storage=48):x.isMatrix4?(_.boundary=64,_.storage=64):x.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",x),_}function m(x){let _=x.target;_.removeEventListener("dispose",m);let M=a.indexOf(_.__bindingPointIndex);a.splice(M,1),s.deleteBuffer(i[_.id]),delete i[_.id],delete r[_.id]}function f(){for(let x in i)s.deleteBuffer(i[x]);a=[],i={},r={}}return{bind:l,update:c,dispose:f}}var Us=class{constructor(t={}){let{canvas:e=Wu(),context:n=null,depth:i=!0,stencil:r=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=t;this.isWebGLRenderer=!0;let d;n!==null?d=n.getContextAttributes().alpha:d=a;let p=new Uint32Array(4),g=new Int32Array(4),y=null,m=null,f=[],x=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=_e,this._useLegacyLights=!1,this.toneMapping=Qn,this.toneMappingExposure=1;let _=this,M=!1,E=0,w=0,A=null,U=-1,v=null,b=new oe,F=new oe,k=null,nt=new Ct(0),L=0,N=e.width,V=e.height,et=1,Y=null,J=null,D=new oe(0,0,N,V),j=new oe(0,0,N,V),rt=!1,O=new Ds,$=!1,ht=!1,ft=null,dt=new le,X=new _t,Q=new C,tt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function xt(){return A===null?et:1}let P=n;function st(R,B){for(let q=0;q<R.length;q++){let Z=R[q],W=e.getContext(Z,B);if(W!==null)return W}return null}try{let R={alpha:!0,depth:i,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine","three.js r160"),e.addEventListener("webglcontextlost",pt,!1),e.addEventListener("webglcontextrestored",I,!1),e.addEventListener("webglcontextcreationerror",Mt,!1),P===null){let B=["webgl2","webgl","experimental-webgl"];if(_.isWebGL1Renderer===!0&&B.shift(),P=st(B,R),P===null)throw st(B)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&P instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),P.getShaderPrecisionFormat===void 0&&(P.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(R){throw console.error("THREE.WebGLRenderer: "+R.message),R}let H,K,G,yt,ut,T,S,z,it,ot,at,Tt,vt,Et,Pt,kt,lt,Jt,Zt,Ft,Rt,wt,Vt,Kt;function ue(){H=new em(P),K=new Jp(P,H,t),H.init(K),wt=new Dg(P,H,K),G=new Lg(P,H,K),yt=new sm(P),ut=new yg,T=new Ig(P,H,G,ut,K,wt,yt),S=new Kp(_),z=new tm(_),it=new ud(P,K),Vt=new Yp(P,H,it,K),ot=new nm(P,it,yt,Vt),at=new lm(P,ot,it,yt),Zt=new om(P,K,T),kt=new $p(ut),Tt=new xg(_,S,z,H,K,Vt,kt),vt=new Ng(_,ut),Et=new Mg,Pt=new Ag(H,K),Jt=new qp(_,S,z,G,at,d,l),lt=new Pg(_,at,K),Kt=new Fg(P,yt,K,G),Ft=new Zp(P,H,yt,K),Rt=new im(P,H,yt,K),yt.programs=Tt.programs,_.capabilities=K,_.extensions=H,_.properties=ut,_.renderLists=Et,_.shadowMap=lt,_.state=G,_.info=yt}ue();let Xt=new No(_,P);this.xr=Xt,this.getContext=function(){return P},this.getContextAttributes=function(){return P.getContextAttributes()},this.forceContextLoss=function(){let R=H.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){let R=H.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return et},this.setPixelRatio=function(R){R!==void 0&&(et=R,this.setSize(N,V,!1))},this.getSize=function(R){return R.set(N,V)},this.setSize=function(R,B,q=!0){if(Xt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}N=R,V=B,e.width=Math.floor(R*et),e.height=Math.floor(B*et),q===!0&&(e.style.width=R+"px",e.style.height=B+"px"),this.setViewport(0,0,R,B)},this.getDrawingBufferSize=function(R){return R.set(N*et,V*et).floor()},this.setDrawingBufferSize=function(R,B,q){N=R,V=B,et=q,e.width=Math.floor(R*q),e.height=Math.floor(B*q),this.setViewport(0,0,R,B)},this.getCurrentViewport=function(R){return R.copy(b)},this.getViewport=function(R){return R.copy(D)},this.setViewport=function(R,B,q,Z){R.isVector4?D.set(R.x,R.y,R.z,R.w):D.set(R,B,q,Z),G.viewport(b.copy(D).multiplyScalar(et).floor())},this.getScissor=function(R){return R.copy(j)},this.setScissor=function(R,B,q,Z){R.isVector4?j.set(R.x,R.y,R.z,R.w):j.set(R,B,q,Z),G.scissor(F.copy(j).multiplyScalar(et).floor())},this.getScissorTest=function(){return rt},this.setScissorTest=function(R){G.setScissorTest(rt=R)},this.setOpaqueSort=function(R){Y=R},this.setTransparentSort=function(R){J=R},this.getClearColor=function(R){return R.copy(Jt.getClearColor())},this.setClearColor=function(){Jt.setClearColor.apply(Jt,arguments)},this.getClearAlpha=function(){return Jt.getClearAlpha()},this.setClearAlpha=function(){Jt.setClearAlpha.apply(Jt,arguments)},this.clear=function(R=!0,B=!0,q=!0){let Z=0;if(R){let W=!1;if(A!==null){let St=A.texture.format;W=St===ph||St===fh||St===dh}if(W){let St=A.texture.type,At=St===jn||St===Zn||St===ll||St===_i||St===hh||St===uh,Dt=Jt.getClearColor(),Nt=Jt.getClearAlpha(),Wt=Dt.r,Ot=Dt.g,Ht=Dt.b;At?(p[0]=Wt,p[1]=Ot,p[2]=Ht,p[3]=Nt,P.clearBufferuiv(P.COLOR,0,p)):(g[0]=Wt,g[1]=Ot,g[2]=Ht,g[3]=Nt,P.clearBufferiv(P.COLOR,0,g))}else Z|=P.COLOR_BUFFER_BIT}B&&(Z|=P.DEPTH_BUFFER_BIT),q&&(Z|=P.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),P.clear(Z)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",pt,!1),e.removeEventListener("webglcontextrestored",I,!1),e.removeEventListener("webglcontextcreationerror",Mt,!1),Et.dispose(),Pt.dispose(),ut.dispose(),S.dispose(),z.dispose(),at.dispose(),Vt.dispose(),Kt.dispose(),Tt.dispose(),Xt.dispose(),Xt.removeEventListener("sessionstart",ze),Xt.removeEventListener("sessionend",ie),ft&&(ft.dispose(),ft=null),Be.stop()};function pt(R){R.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),M=!0}function I(){console.log("THREE.WebGLRenderer: Context Restored."),M=!1;let R=yt.autoReset,B=lt.enabled,q=lt.autoUpdate,Z=lt.needsUpdate,W=lt.type;ue(),yt.autoReset=R,lt.enabled=B,lt.autoUpdate=q,lt.needsUpdate=Z,lt.type=W}function Mt(R){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function bt(R){let B=R.target;B.removeEventListener("dispose",bt),Ut(B)}function Ut(R){Lt(R),ut.remove(R)}function Lt(R){let B=ut.get(R).programs;B!==void 0&&(B.forEach(function(q){Tt.releaseProgram(q)}),R.isShaderMaterial&&Tt.releaseShaderCache(R))}this.renderBufferDirect=function(R,B,q,Z,W,St){B===null&&(B=tt);let At=W.isMesh&&W.matrixWorld.determinant()<0,Dt=Hh(R,B,q,Z,W);G.setMaterial(Z,At);let Nt=q.index,Wt=1;if(Z.wireframe===!0){if(Nt=ot.getWireframeAttribute(q),Nt===void 0)return;Wt=2}let Ot=q.drawRange,Ht=q.attributes.position,fe=Ot.start*Wt,We=(Ot.start+Ot.count)*Wt;St!==null&&(fe=Math.max(fe,St.start*Wt),We=Math.min(We,(St.start+St.count)*Wt)),Nt!==null?(fe=Math.max(fe,0),We=Math.min(We,Nt.count)):Ht!=null&&(fe=Math.max(fe,0),We=Math.min(We,Ht.count));let be=We-fe;if(be<0||be===1/0)return;Vt.setup(W,Z,Dt,q,Nt);let En,ce=Ft;if(Nt!==null&&(En=it.get(Nt),ce=Rt,ce.setIndex(En)),W.isMesh)Z.wireframe===!0?(G.setLineWidth(Z.wireframeLinewidth*xt()),ce.setMode(P.LINES)):ce.setMode(P.TRIANGLES);else if(W.isLine){let qt=Z.linewidth;qt===void 0&&(qt=1),G.setLineWidth(qt*xt()),W.isLineSegments?ce.setMode(P.LINES):W.isLineLoop?ce.setMode(P.LINE_LOOP):ce.setMode(P.LINE_STRIP)}else W.isPoints?ce.setMode(P.POINTS):W.isSprite&&ce.setMode(P.TRIANGLES);if(W.isBatchedMesh)ce.renderMultiDraw(W._multiDrawStarts,W._multiDrawCounts,W._multiDrawCount);else if(W.isInstancedMesh)ce.renderInstances(fe,be,W.count);else if(q.isInstancedBufferGeometry){let qt=q._maxInstanceCount!==void 0?q._maxInstanceCount:1/0,Aa=Math.min(q.instanceCount,qt);ce.renderInstances(fe,be,Aa)}else ce.render(fe,be)};function ee(R,B,q){R.transparent===!0&&R.side===Ve&&R.forceSinglePass===!1?(R.side=Ee,R.needsUpdate=!0,Zs(R,B,q),R.side=ti,R.needsUpdate=!0,Zs(R,B,q),R.side=Ve):Zs(R,B,q)}this.compile=function(R,B,q=null){q===null&&(q=R),m=Pt.get(q),m.init(),x.push(m),q.traverseVisible(function(W){W.isLight&&W.layers.test(B.layers)&&(m.pushLight(W),W.castShadow&&m.pushShadow(W))}),R!==q&&R.traverseVisible(function(W){W.isLight&&W.layers.test(B.layers)&&(m.pushLight(W),W.castShadow&&m.pushShadow(W))}),m.setupLights(_._useLegacyLights);let Z=new Set;return R.traverse(function(W){let St=W.material;if(St)if(Array.isArray(St))for(let At=0;At<St.length;At++){let Dt=St[At];ee(Dt,q,W),Z.add(Dt)}else ee(St,q,W),Z.add(St)}),x.pop(),m=null,Z},this.compileAsync=function(R,B,q=null){let Z=this.compile(R,B,q);return new Promise(W=>{function St(){if(Z.forEach(function(At){ut.get(At).currentProgram.isReady()&&Z.delete(At)}),Z.size===0){W(R);return}setTimeout(St,10)}H.get("KHR_parallel_shader_compile")!==null?St():setTimeout(St,10)})};let ne=null;function Me(R){ne&&ne(R)}function ze(){Be.stop()}function ie(){Be.start()}let Be=new bh;Be.setAnimationLoop(Me),typeof self<"u"&&Be.setContext(self),this.setAnimationLoop=function(R){ne=R,Xt.setAnimationLoop(R),R===null?Be.stop():Be.start()},Xt.addEventListener("sessionstart",ze),Xt.addEventListener("sessionend",ie),this.render=function(R,B){if(B!==void 0&&B.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(M===!0)return;R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),B.parent===null&&B.matrixWorldAutoUpdate===!0&&B.updateMatrixWorld(),Xt.enabled===!0&&Xt.isPresenting===!0&&(Xt.cameraAutoUpdate===!0&&Xt.updateCamera(B),B=Xt.getCamera()),R.isScene===!0&&R.onBeforeRender(_,R,B,A),m=Pt.get(R,x.length),m.init(),x.push(m),dt.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),O.setFromProjectionMatrix(dt),ht=this.localClippingEnabled,$=kt.init(this.clippingPlanes,ht),y=Et.get(R,f.length),y.init(),f.push(y),yn(R,B,0,_.sortObjects),y.finish(),_.sortObjects===!0&&y.sort(Y,J),this.info.render.frame++,$===!0&&kt.beginShadows();let q=m.state.shadowsArray;if(lt.render(q,R,B),$===!0&&kt.endShadows(),this.info.autoReset===!0&&this.info.reset(),Jt.render(y,R),m.setupLights(_._useLegacyLights),B.isArrayCamera){let Z=B.cameras;for(let W=0,St=Z.length;W<St;W++){let At=Z[W];bl(y,R,At,At.viewport)}}else bl(y,R,B);A!==null&&(T.updateMultisampleRenderTarget(A),T.updateRenderTargetMipmap(A)),R.isScene===!0&&R.onAfterRender(_,R,B),Vt.resetDefaultState(),U=-1,v=null,x.pop(),x.length>0?m=x[x.length-1]:m=null,f.pop(),f.length>0?y=f[f.length-1]:y=null};function yn(R,B,q,Z){if(R.visible===!1)return;if(R.layers.test(B.layers)){if(R.isGroup)q=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(B);else if(R.isLight)m.pushLight(R),R.castShadow&&m.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||O.intersectsSprite(R)){Z&&Q.setFromMatrixPosition(R.matrixWorld).applyMatrix4(dt);let At=at.update(R),Dt=R.material;Dt.visible&&y.push(R,At,Dt,q,Q.z,null)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||O.intersectsObject(R))){let At=at.update(R),Dt=R.material;if(Z&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),Q.copy(R.boundingSphere.center)):(At.boundingSphere===null&&At.computeBoundingSphere(),Q.copy(At.boundingSphere.center)),Q.applyMatrix4(R.matrixWorld).applyMatrix4(dt)),Array.isArray(Dt)){let Nt=At.groups;for(let Wt=0,Ot=Nt.length;Wt<Ot;Wt++){let Ht=Nt[Wt],fe=Dt[Ht.materialIndex];fe&&fe.visible&&y.push(R,At,fe,q,Q.z,Ht)}}else Dt.visible&&y.push(R,At,Dt,q,Q.z,null)}}let St=R.children;for(let At=0,Dt=St.length;At<Dt;At++)yn(St[At],B,q,Z)}function bl(R,B,q,Z){let W=R.opaque,St=R.transmissive,At=R.transparent;m.setupLightsView(q),$===!0&&kt.setGlobalState(_.clippingPlanes,q),St.length>0&&kh(W,St,B,q),Z&&G.viewport(b.copy(Z)),W.length>0&&Ys(W,B,q),St.length>0&&Ys(St,B,q),At.length>0&&Ys(At,B,q),G.buffers.depth.setTest(!0),G.buffers.depth.setMask(!0),G.buffers.color.setMask(!0),G.setPolygonOffset(!1)}function kh(R,B,q,Z){if((q.isScene===!0?q.overrideMaterial:null)!==null)return;let St=K.isWebGL2;ft===null&&(ft=new Un(1,1,{generateMipmaps:!0,type:H.has("EXT_color_buffer_half_float")?Is:jn,minFilter:Ls,samples:St?4:0})),_.getDrawingBufferSize(X),St?ft.setSize(X.x,X.y):ft.setSize(Mo(X.x),Mo(X.y));let At=_.getRenderTarget();_.setRenderTarget(ft),_.getClearColor(nt),L=_.getClearAlpha(),L<1&&_.setClearColor(16777215,.5),_.clear();let Dt=_.toneMapping;_.toneMapping=Qn,Ys(R,q,Z),T.updateMultisampleRenderTarget(ft),T.updateRenderTargetMipmap(ft);let Nt=!1;for(let Wt=0,Ot=B.length;Wt<Ot;Wt++){let Ht=B[Wt],fe=Ht.object,We=Ht.geometry,be=Ht.material,En=Ht.group;if(be.side===Ve&&fe.layers.test(Z.layers)){let ce=be.side;be.side=Ee,be.needsUpdate=!0,Sl(fe,q,Z,We,be,En),be.side=ce,be.needsUpdate=!0,Nt=!0}}Nt===!0&&(T.updateMultisampleRenderTarget(ft),T.updateRenderTargetMipmap(ft)),_.setRenderTarget(At),_.setClearColor(nt,L),_.toneMapping=Dt}function Ys(R,B,q){let Z=B.isScene===!0?B.overrideMaterial:null;for(let W=0,St=R.length;W<St;W++){let At=R[W],Dt=At.object,Nt=At.geometry,Wt=Z===null?At.material:Z,Ot=At.group;Dt.layers.test(q.layers)&&Sl(Dt,B,q,Nt,Wt,Ot)}}function Sl(R,B,q,Z,W,St){R.onBeforeRender(_,B,q,Z,W,St),R.modelViewMatrix.multiplyMatrices(q.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),W.onBeforeRender(_,B,q,Z,R,St),W.transparent===!0&&W.side===Ve&&W.forceSinglePass===!1?(W.side=Ee,W.needsUpdate=!0,_.renderBufferDirect(q,B,Z,W,R,St),W.side=ti,W.needsUpdate=!0,_.renderBufferDirect(q,B,Z,W,R,St),W.side=Ve):_.renderBufferDirect(q,B,Z,W,R,St),R.onAfterRender(_,B,q,Z,W,St)}function Zs(R,B,q){B.isScene!==!0&&(B=tt);let Z=ut.get(R),W=m.state.lights,St=m.state.shadowsArray,At=W.state.version,Dt=Tt.getParameters(R,W.state,St,B,q),Nt=Tt.getProgramCacheKey(Dt),Wt=Z.programs;Z.environment=R.isMeshStandardMaterial?B.environment:null,Z.fog=B.fog,Z.envMap=(R.isMeshStandardMaterial?z:S).get(R.envMap||Z.environment),Wt===void 0&&(R.addEventListener("dispose",bt),Wt=new Map,Z.programs=Wt);let Ot=Wt.get(Nt);if(Ot!==void 0){if(Z.currentProgram===Ot&&Z.lightsStateVersion===At)return wl(R,Dt),Ot}else Dt.uniforms=Tt.getUniforms(R),R.onBuild(q,Dt,_),R.onBeforeCompile(Dt,_),Ot=Tt.acquireProgram(Dt,Nt),Wt.set(Nt,Ot),Z.uniforms=Dt.uniforms;let Ht=Z.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&(Ht.clippingPlanes=kt.uniform),wl(R,Dt),Z.needsLights=Gh(R),Z.lightsStateVersion=At,Z.needsLights&&(Ht.ambientLightColor.value=W.state.ambient,Ht.lightProbe.value=W.state.probe,Ht.directionalLights.value=W.state.directional,Ht.directionalLightShadows.value=W.state.directionalShadow,Ht.spotLights.value=W.state.spot,Ht.spotLightShadows.value=W.state.spotShadow,Ht.rectAreaLights.value=W.state.rectArea,Ht.ltc_1.value=W.state.rectAreaLTC1,Ht.ltc_2.value=W.state.rectAreaLTC2,Ht.pointLights.value=W.state.point,Ht.pointLightShadows.value=W.state.pointShadow,Ht.hemisphereLights.value=W.state.hemi,Ht.directionalShadowMap.value=W.state.directionalShadowMap,Ht.directionalShadowMatrix.value=W.state.directionalShadowMatrix,Ht.spotShadowMap.value=W.state.spotShadowMap,Ht.spotLightMatrix.value=W.state.spotLightMatrix,Ht.spotLightMap.value=W.state.spotLightMap,Ht.pointShadowMap.value=W.state.pointShadowMap,Ht.pointShadowMatrix.value=W.state.pointShadowMatrix),Z.currentProgram=Ot,Z.uniformsList=null,Ot}function El(R){if(R.uniformsList===null){let B=R.currentProgram.getUniforms();R.uniformsList=Ji.seqWithValue(B.seq,R.uniforms)}return R.uniformsList}function wl(R,B){let q=ut.get(R);q.outputColorSpace=B.outputColorSpace,q.batching=B.batching,q.instancing=B.instancing,q.instancingColor=B.instancingColor,q.skinning=B.skinning,q.morphTargets=B.morphTargets,q.morphNormals=B.morphNormals,q.morphColors=B.morphColors,q.morphTargetsCount=B.morphTargetsCount,q.numClippingPlanes=B.numClippingPlanes,q.numIntersection=B.numClipIntersection,q.vertexAlphas=B.vertexAlphas,q.vertexTangents=B.vertexTangents,q.toneMapping=B.toneMapping}function Hh(R,B,q,Z,W){B.isScene!==!0&&(B=tt),T.resetTextureUnits();let St=B.fog,At=Z.isMeshStandardMaterial?B.environment:null,Dt=A===null?_.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:Dn,Nt=(Z.isMeshStandardMaterial?z:S).get(Z.envMap||At),Wt=Z.vertexColors===!0&&!!q.attributes.color&&q.attributes.color.itemSize===4,Ot=!!q.attributes.tangent&&(!!Z.normalMap||Z.anisotropy>0),Ht=!!q.morphAttributes.position,fe=!!q.morphAttributes.normal,We=!!q.morphAttributes.color,be=Qn;Z.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(be=_.toneMapping);let En=q.morphAttributes.position||q.morphAttributes.normal||q.morphAttributes.color,ce=En!==void 0?En.length:0,qt=ut.get(Z),Aa=m.state.lights;if($===!0&&(ht===!0||R!==v)){let Je=R===v&&Z.id===U;kt.setState(Z,R,Je)}let de=!1;Z.version===qt.__version?(qt.needsLights&&qt.lightsStateVersion!==Aa.state.version||qt.outputColorSpace!==Dt||W.isBatchedMesh&&qt.batching===!1||!W.isBatchedMesh&&qt.batching===!0||W.isInstancedMesh&&qt.instancing===!1||!W.isInstancedMesh&&qt.instancing===!0||W.isSkinnedMesh&&qt.skinning===!1||!W.isSkinnedMesh&&qt.skinning===!0||W.isInstancedMesh&&qt.instancingColor===!0&&W.instanceColor===null||W.isInstancedMesh&&qt.instancingColor===!1&&W.instanceColor!==null||qt.envMap!==Nt||Z.fog===!0&&qt.fog!==St||qt.numClippingPlanes!==void 0&&(qt.numClippingPlanes!==kt.numPlanes||qt.numIntersection!==kt.numIntersection)||qt.vertexAlphas!==Wt||qt.vertexTangents!==Ot||qt.morphTargets!==Ht||qt.morphNormals!==fe||qt.morphColors!==We||qt.toneMapping!==be||K.isWebGL2===!0&&qt.morphTargetsCount!==ce)&&(de=!0):(de=!0,qt.__version=Z.version);let li=qt.currentProgram;de===!0&&(li=Zs(Z,B,W));let Tl=!1,gs=!1,Ra=!1,Le=li.getUniforms(),ci=qt.uniforms;if(G.useProgram(li.program)&&(Tl=!0,gs=!0,Ra=!0),Z.id!==U&&(U=Z.id,gs=!0),Tl||v!==R){Le.setValue(P,"projectionMatrix",R.projectionMatrix),Le.setValue(P,"viewMatrix",R.matrixWorldInverse);let Je=Le.map.cameraPosition;Je!==void 0&&Je.setValue(P,Q.setFromMatrixPosition(R.matrixWorld)),K.logarithmicDepthBuffer&&Le.setValue(P,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(Z.isMeshPhongMaterial||Z.isMeshToonMaterial||Z.isMeshLambertMaterial||Z.isMeshBasicMaterial||Z.isMeshStandardMaterial||Z.isShaderMaterial)&&Le.setValue(P,"isOrthographic",R.isOrthographicCamera===!0),v!==R&&(v=R,gs=!0,Ra=!0)}if(W.isSkinnedMesh){Le.setOptional(P,W,"bindMatrix"),Le.setOptional(P,W,"bindMatrixInverse");let Je=W.skeleton;Je&&(K.floatVertexTextures?(Je.boneTexture===null&&Je.computeBoneTexture(),Le.setValue(P,"boneTexture",Je.boneTexture,T)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}W.isBatchedMesh&&(Le.setOptional(P,W,"batchingTexture"),Le.setValue(P,"batchingTexture",W._matricesTexture,T));let Ca=q.morphAttributes;if((Ca.position!==void 0||Ca.normal!==void 0||Ca.color!==void 0&&K.isWebGL2===!0)&&Zt.update(W,q,li),(gs||qt.receiveShadow!==W.receiveShadow)&&(qt.receiveShadow=W.receiveShadow,Le.setValue(P,"receiveShadow",W.receiveShadow)),Z.isMeshGouraudMaterial&&Z.envMap!==null&&(ci.envMap.value=Nt,ci.flipEnvMap.value=Nt.isCubeTexture&&Nt.isRenderTargetTexture===!1?-1:1),gs&&(Le.setValue(P,"toneMappingExposure",_.toneMappingExposure),qt.needsLights&&Vh(ci,Ra),St&&Z.fog===!0&&vt.refreshFogUniforms(ci,St),vt.refreshMaterialUniforms(ci,Z,et,V,ft),Ji.upload(P,El(qt),ci,T)),Z.isShaderMaterial&&Z.uniformsNeedUpdate===!0&&(Ji.upload(P,El(qt),ci,T),Z.uniformsNeedUpdate=!1),Z.isSpriteMaterial&&Le.setValue(P,"center",W.center),Le.setValue(P,"modelViewMatrix",W.modelViewMatrix),Le.setValue(P,"normalMatrix",W.normalMatrix),Le.setValue(P,"modelMatrix",W.matrixWorld),Z.isShaderMaterial||Z.isRawShaderMaterial){let Je=Z.uniformsGroups;for(let Pa=0,Wh=Je.length;Pa<Wh;Pa++)if(K.isWebGL2){let Al=Je[Pa];Kt.update(Al,li),Kt.bind(Al,li)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return li}function Vh(R,B){R.ambientLightColor.needsUpdate=B,R.lightProbe.needsUpdate=B,R.directionalLights.needsUpdate=B,R.directionalLightShadows.needsUpdate=B,R.pointLights.needsUpdate=B,R.pointLightShadows.needsUpdate=B,R.spotLights.needsUpdate=B,R.spotLightShadows.needsUpdate=B,R.rectAreaLights.needsUpdate=B,R.hemisphereLights.needsUpdate=B}function Gh(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return w},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(R,B,q){ut.get(R.texture).__webglTexture=B,ut.get(R.depthTexture).__webglTexture=q;let Z=ut.get(R);Z.__hasExternalTextures=!0,Z.__hasExternalTextures&&(Z.__autoAllocateDepthBuffer=q===void 0,Z.__autoAllocateDepthBuffer||H.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),Z.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(R,B){let q=ut.get(R);q.__webglFramebuffer=B,q.__useDefaultFramebuffer=B===void 0},this.setRenderTarget=function(R,B=0,q=0){A=R,E=B,w=q;let Z=!0,W=null,St=!1,At=!1;if(R){let Nt=ut.get(R);Nt.__useDefaultFramebuffer!==void 0?(G.bindFramebuffer(P.FRAMEBUFFER,null),Z=!1):Nt.__webglFramebuffer===void 0?T.setupRenderTarget(R):Nt.__hasExternalTextures&&T.rebindTextures(R,ut.get(R.texture).__webglTexture,ut.get(R.depthTexture).__webglTexture);let Wt=R.texture;(Wt.isData3DTexture||Wt.isDataArrayTexture||Wt.isCompressedArrayTexture)&&(At=!0);let Ot=ut.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(Ot[B])?W=Ot[B][q]:W=Ot[B],St=!0):K.isWebGL2&&R.samples>0&&T.useMultisampledRTT(R)===!1?W=ut.get(R).__webglMultisampledFramebuffer:Array.isArray(Ot)?W=Ot[q]:W=Ot,b.copy(R.viewport),F.copy(R.scissor),k=R.scissorTest}else b.copy(D).multiplyScalar(et).floor(),F.copy(j).multiplyScalar(et).floor(),k=rt;if(G.bindFramebuffer(P.FRAMEBUFFER,W)&&K.drawBuffers&&Z&&G.drawBuffers(R,W),G.viewport(b),G.scissor(F),G.setScissorTest(k),St){let Nt=ut.get(R.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_CUBE_MAP_POSITIVE_X+B,Nt.__webglTexture,q)}else if(At){let Nt=ut.get(R.texture),Wt=B||0;P.framebufferTextureLayer(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,Nt.__webglTexture,q||0,Wt)}U=-1},this.readRenderTargetPixels=function(R,B,q,Z,W,St,At){if(!(R&&R.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Dt=ut.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&At!==void 0&&(Dt=Dt[At]),Dt){G.bindFramebuffer(P.FRAMEBUFFER,Dt);try{let Nt=R.texture,Wt=Nt.format,Ot=Nt.type;if(Wt!==pn&&wt.convert(Wt)!==P.getParameter(P.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Ht=Ot===Is&&(H.has("EXT_color_buffer_half_float")||K.isWebGL2&&H.has("EXT_color_buffer_float"));if(Ot!==jn&&wt.convert(Ot)!==P.getParameter(P.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Ot===Jn&&(K.isWebGL2||H.has("OES_texture_float")||H.has("WEBGL_color_buffer_float")))&&!Ht){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}B>=0&&B<=R.width-Z&&q>=0&&q<=R.height-W&&P.readPixels(B,q,Z,W,wt.convert(Wt),wt.convert(Ot),St)}finally{let Nt=A!==null?ut.get(A).__webglFramebuffer:null;G.bindFramebuffer(P.FRAMEBUFFER,Nt)}}},this.copyFramebufferToTexture=function(R,B,q=0){let Z=Math.pow(2,-q),W=Math.floor(B.image.width*Z),St=Math.floor(B.image.height*Z);T.setTexture2D(B,0),P.copyTexSubImage2D(P.TEXTURE_2D,q,0,0,R.x,R.y,W,St),G.unbindTexture()},this.copyTextureToTexture=function(R,B,q,Z=0){let W=B.image.width,St=B.image.height,At=wt.convert(q.format),Dt=wt.convert(q.type);T.setTexture2D(q,0),P.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,q.flipY),P.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,q.premultiplyAlpha),P.pixelStorei(P.UNPACK_ALIGNMENT,q.unpackAlignment),B.isDataTexture?P.texSubImage2D(P.TEXTURE_2D,Z,R.x,R.y,W,St,At,Dt,B.image.data):B.isCompressedTexture?P.compressedTexSubImage2D(P.TEXTURE_2D,Z,R.x,R.y,B.mipmaps[0].width,B.mipmaps[0].height,At,B.mipmaps[0].data):P.texSubImage2D(P.TEXTURE_2D,Z,R.x,R.y,At,Dt,B.image),Z===0&&q.generateMipmaps&&P.generateMipmap(P.TEXTURE_2D),G.unbindTexture()},this.copyTextureToTexture3D=function(R,B,q,Z,W=0){if(_.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let St=R.max.x-R.min.x+1,At=R.max.y-R.min.y+1,Dt=R.max.z-R.min.z+1,Nt=wt.convert(Z.format),Wt=wt.convert(Z.type),Ot;if(Z.isData3DTexture)T.setTexture3D(Z,0),Ot=P.TEXTURE_3D;else if(Z.isDataArrayTexture||Z.isCompressedArrayTexture)T.setTexture2DArray(Z,0),Ot=P.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}P.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,Z.flipY),P.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Z.premultiplyAlpha),P.pixelStorei(P.UNPACK_ALIGNMENT,Z.unpackAlignment);let Ht=P.getParameter(P.UNPACK_ROW_LENGTH),fe=P.getParameter(P.UNPACK_IMAGE_HEIGHT),We=P.getParameter(P.UNPACK_SKIP_PIXELS),be=P.getParameter(P.UNPACK_SKIP_ROWS),En=P.getParameter(P.UNPACK_SKIP_IMAGES),ce=q.isCompressedTexture?q.mipmaps[W]:q.image;P.pixelStorei(P.UNPACK_ROW_LENGTH,ce.width),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,ce.height),P.pixelStorei(P.UNPACK_SKIP_PIXELS,R.min.x),P.pixelStorei(P.UNPACK_SKIP_ROWS,R.min.y),P.pixelStorei(P.UNPACK_SKIP_IMAGES,R.min.z),q.isDataTexture||q.isData3DTexture?P.texSubImage3D(Ot,W,B.x,B.y,B.z,St,At,Dt,Nt,Wt,ce.data):q.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),P.compressedTexSubImage3D(Ot,W,B.x,B.y,B.z,St,At,Dt,Nt,ce.data)):P.texSubImage3D(Ot,W,B.x,B.y,B.z,St,At,Dt,Nt,Wt,ce),P.pixelStorei(P.UNPACK_ROW_LENGTH,Ht),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,fe),P.pixelStorei(P.UNPACK_SKIP_PIXELS,We),P.pixelStorei(P.UNPACK_SKIP_ROWS,be),P.pixelStorei(P.UNPACK_SKIP_IMAGES,En),W===0&&Z.generateMipmaps&&P.generateMipmap(Ot),G.unbindTexture()},this.initTexture=function(R){R.isCubeTexture?T.setTextureCube(R,0):R.isData3DTexture?T.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?T.setTexture2DArray(R,0):T.setTexture2D(R,0),G.unbindTexture()},this.resetState=function(){E=0,w=0,A=null,G.reset(),Vt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return In}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===cl?"display-p3":"srgb",e.unpackColorSpace=Qt.workingColorSpace===aa?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===_e?yi:gh}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===yi?_e:Dn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},Fo=class extends Us{};Fo.prototype.isWebGL1Renderer=!0;var Wr=class s{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new Ct(t),this.density=e}clone(){return new s(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var Ns=class extends we{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}};var Xr=class extends jt{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},Gi=new le,Jc=new le,_r=[],$c=new Nn,Og=new le,bs=new It,Ss=new ni,qr=class extends It{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Xr(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,Og)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Nn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Gi),$c.copy(t.boundingBox).applyMatrix4(Gi),this.boundingBox.union($c)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new ni),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Gi),Ss.copy(t.boundingSphere).applyMatrix4(Gi),this.boundingSphere.union(Ss)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let n=this.matrixWorld,i=this.count;if(bs.geometry=this.geometry,bs.material=this.material,bs.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ss.copy(this.boundingSphere),Ss.applyMatrix4(n),t.ray.intersectsSphere(Ss)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,Gi),Jc.multiplyMatrices(n,Gi),bs.matrixWorld=Jc,bs.raycast(t,_r);for(let a=0,o=_r.length;a<o;a++){let l=_r[a];l.instanceId=r,l.object=this,e.push(l)}_r.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Xr(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var Oo=class extends ii{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ct(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Kc=new le,zo=new Nr,xr=new ni,yr=new C,Fs=class extends we{constructor(t=new Te,e=new Oo){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let n=this.geometry,i=this.matrixWorld,r=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),xr.copy(n.boundingSphere),xr.applyMatrix4(i),xr.radius+=r,t.ray.intersectsSphere(xr)===!1)return;Kc.copy(i).invert(),zo.copy(t.ray).applyMatrix4(Kc);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,a.start),p=Math.min(c.count,a.start+a.count);for(let g=d,y=p;g<y;g++){let m=c.getX(g);yr.fromBufferAttribute(u,m),Qc(yr,m,l,i,t,e,this)}}else{let d=Math.max(0,a.start),p=Math.min(u.count,a.start+a.count);for(let g=d,y=p;g<y;g++)yr.fromBufferAttribute(u,g),Qc(yr,g,l,i,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){let o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Qc(s,t,e,n,i,r,a){let o=zo.distanceSqToPoint(s);if(o<e){let l=new C;zo.closestPointToPoint(s,l),l.applyMatrix4(n);let c=i.ray.origin.distanceTo(l);if(c<i.near||c>i.far)return;r.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,object:a})}}var Yr=class extends tn{constructor(t,e,n,i,r,a,o,l,c){super(t,e,n,i,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},nn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],n,i=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),r+=n.distanceTo(i),e.push(r),i=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let n=this.getLengths(),i=0,r=n.length,a;e?a=e:a=t*n[r-1];let o=0,l=r-1,c;for(;o<=l;)if(i=Math.floor(o+(l-o)/2),c=n[i]-a,c<0)o=i+1;else if(c>0)l=i-1;else{l=i;break}if(i=l,n[i]===a)return i/(r-1);let h=n[i],d=n[i+1]-h,p=(a-h)/d;return(i+p)/(r-1)}getTangent(t,e){let i=t-1e-4,r=t+1e-4;i<0&&(i=0),r>1&&(r=1);let a=this.getPoint(i),o=this.getPoint(r),l=e||(a.isVector2?new _t:new C);return l.copy(o).sub(a).normalize(),l}getTangentAt(t,e){let n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){let n=new C,i=[],r=[],a=[],o=new C,l=new le;for(let p=0;p<=t;p++){let g=p/t;i[p]=this.getTangentAt(g,new C)}r[0]=new C,a[0]=new C;let c=Number.MAX_VALUE,h=Math.abs(i[0].x),u=Math.abs(i[0].y),d=Math.abs(i[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(i[0],n).normalize(),r[0].crossVectors(i[0],o),a[0].crossVectors(i[0],r[0]);for(let p=1;p<=t;p++){if(r[p]=r[p-1].clone(),a[p]=a[p-1].clone(),o.crossVectors(i[p-1],i[p]),o.length()>Number.EPSILON){o.normalize();let g=Math.acos(Ue(i[p-1].dot(i[p]),-1,1));r[p].applyMatrix4(l.makeRotationAxis(o,g))}a[p].crossVectors(i[p],r[p])}if(e===!0){let p=Math.acos(Ue(r[0].dot(r[t]),-1,1));p/=t,i[0].dot(o.crossVectors(r[0],r[t]))>0&&(p=-p);for(let g=1;g<=t;g++)r[g].applyMatrix4(l.makeRotationAxis(i[g],p*g)),a[g].crossVectors(i[g],r[g])}return{tangents:i,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},Os=class extends nn{constructor(t=0,e=0,n=1,i=1,r=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=i,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(t,e){let n=e||new _t,i=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=i;for(;r>i;)r-=i;r<Number.EPSILON&&(a?r=0:r=i),this.aClockwise===!0&&!a&&(r===i?r=-i:r=r-i);let o=this.aStartAngle+t*r,l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,p=c-this.aY;l=d*h-p*u+this.aX,c=d*u+p*h+this.aY}return n.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},Bo=class extends Os{constructor(t,e,n,i,r,a){super(t,e,n,n,i,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function ul(){let s=0,t=0,e=0,n=0;function i(r,a,o,l){s=r,t=o,e=-3*r+3*a-2*o-l,n=2*r-2*a+o+l}return{initCatmullRom:function(r,a,o,l,c){i(a,o,c*(o-r),c*(l-a))},initNonuniformCatmullRom:function(r,a,o,l,c,h,u){let d=(a-r)/c-(o-r)/(c+h)+(o-a)/h,p=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,p*=h,i(a,o,d,p)},calc:function(r){let a=r*r,o=a*r;return s+t*r+e*a+n*o}}}var vr=new C,lo=new ul,co=new ul,ho=new ul,ko=class extends nn{constructor(t=[],e=!1,n="centripetal",i=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=i}getPoint(t,e=new C){let n=e,i=this.points,r=i.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:l===0&&o===r-1&&(o=r-2,l=1);let c,h;this.closed||o>0?c=i[(o-1)%r]:(vr.subVectors(i[0],i[1]).add(i[0]),c=vr);let u=i[o%r],d=i[(o+1)%r];if(this.closed||o+2<r?h=i[(o+2)%r]:(vr.subVectors(i[r-1],i[r-2]).add(i[r-1]),h=vr),this.curveType==="centripetal"||this.curveType==="chordal"){let p=this.curveType==="chordal"?.5:.25,g=Math.pow(c.distanceToSquared(u),p),y=Math.pow(u.distanceToSquared(d),p),m=Math.pow(d.distanceToSquared(h),p);y<1e-4&&(y=1),g<1e-4&&(g=y),m<1e-4&&(m=y),lo.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,y,m),co.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,y,m),ho.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,y,m)}else this.curveType==="catmullrom"&&(lo.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),co.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),ho.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(lo.calc(l),co.calc(l),ho.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(i.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let i=this.points[e];t.points.push(i.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(new C().fromArray(i))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function jc(s,t,e,n,i){let r=(n-t)*.5,a=(i-e)*.5,o=s*s,l=s*o;return(2*e-2*n+r+a)*l+(-3*e+3*n-2*r-a)*o+r*s+e}function zg(s,t){let e=1-s;return e*e*t}function Bg(s,t){return 2*(1-s)*s*t}function kg(s,t){return s*s*t}function As(s,t,e,n){return zg(s,t)+Bg(s,e)+kg(s,n)}function Hg(s,t){let e=1-s;return e*e*e*t}function Vg(s,t){let e=1-s;return 3*e*e*s*t}function Gg(s,t){return 3*(1-s)*s*s*t}function Wg(s,t){return s*s*s*t}function Rs(s,t,e,n,i){return Hg(s,t)+Vg(s,e)+Gg(s,n)+Wg(s,i)}var Zr=class extends nn{constructor(t=new _t,e=new _t,n=new _t,i=new _t){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new _t){let n=e,i=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Rs(t,i.x,r.x,a.x,o.x),Rs(t,i.y,r.y,a.y,o.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Ho=class extends nn{constructor(t=new C,e=new C,n=new C,i=new C){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new C){let n=e,i=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Rs(t,i.x,r.x,a.x,o.x),Rs(t,i.y,r.y,a.y,o.y),Rs(t,i.z,r.z,a.z,o.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Jr=class extends nn{constructor(t=new _t,e=new _t){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new _t){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new _t){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Vo=class extends nn{constructor(t=new C,e=new C){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new C){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new C){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},$r=class extends nn{constructor(t=new _t,e=new _t,n=new _t){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new _t){let n=e,i=this.v0,r=this.v1,a=this.v2;return n.set(As(t,i.x,r.x,a.x),As(t,i.y,r.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Go=class extends nn{constructor(t=new C,e=new C,n=new C){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new C){let n=e,i=this.v0,r=this.v1,a=this.v2;return n.set(As(t,i.x,r.x,a.x),As(t,i.y,r.y,a.y),As(t,i.z,r.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Kr=class extends nn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new _t){let n=e,i=this.points,r=(i.length-1)*t,a=Math.floor(r),o=r-a,l=i[a===0?a:a-1],c=i[a],h=i[a>i.length-2?i.length-1:a+1],u=i[a>i.length-3?i.length-1:a+2];return n.set(jc(o,l.x,c.x,h.x,u.x),jc(o,l.y,c.y,h.y,u.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(i.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let i=this.points[e];t.points.push(i.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(new _t().fromArray(i))}return this}},Wo=Object.freeze({__proto__:null,ArcCurve:Bo,CatmullRomCurve3:ko,CubicBezierCurve:Zr,CubicBezierCurve3:Ho,EllipseCurve:Os,LineCurve:Jr,LineCurve3:Vo,QuadraticBezierCurve:$r,QuadraticBezierCurve3:Go,SplineCurve:Kr}),Xo=class extends nn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Wo[n](e,t))}return this}getPoint(t,e){let n=t*this.getLength(),i=this.getCurveLengths(),r=0;for(;r<i.length;){if(i[r]>=n){let a=i[r]-n,o=this.curves[r],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let n=0,i=this.curves.length;n<i;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],n;for(let i=0,r=this.curves;i<r.length;i++){let a=r[i],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,l=a.getPoints(o);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let i=t.curves[e];this.curves.push(i.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){let i=this.curves[e];t.curves.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let i=t.curves[e];this.curves.push(new Wo[i.type]().fromJSON(i))}return this}},Qr=class extends Xo{constructor(t){super(),this.type="Path",this.currentPoint=new _t,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let n=new Jr(this.currentPoint.clone(),new _t(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,i){let r=new $r(this.currentPoint.clone(),new _t(t,e),new _t(n,i));return this.curves.push(r),this.currentPoint.set(n,i),this}bezierCurveTo(t,e,n,i,r,a){let o=new Zr(this.currentPoint.clone(),new _t(t,e),new _t(n,i),new _t(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),n=new Kr(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,i,r,a){let o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+o,e+l,n,i,r,a),this}absarc(t,e,n,i,r,a){return this.absellipse(t,e,n,n,i,r,a),this}ellipse(t,e,n,i,r,a,o,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,n,i,r,a,o,l),this}absellipse(t,e,n,i,r,a,o,l){let c=new Os(t,e,n,i,r,a,o,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}};var sn=class s extends Te{constructor(t=1,e=1,n=1,i=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};let c=this;i=Math.floor(i),r=Math.floor(r);let h=[],u=[],d=[],p=[],g=0,y=[],m=n/2,f=0;x(),a===!1&&(t>0&&_(!0),e>0&&_(!1)),this.setIndex(h),this.setAttribute("position",new se(u,3)),this.setAttribute("normal",new se(d,3)),this.setAttribute("uv",new se(p,2));function x(){let M=new C,E=new C,w=0,A=(e-t)/n;for(let U=0;U<=r;U++){let v=[],b=U/r,F=b*(e-t)+t;for(let k=0;k<=i;k++){let nt=k/i,L=nt*l+o,N=Math.sin(L),V=Math.cos(L);E.x=F*N,E.y=-b*n+m,E.z=F*V,u.push(E.x,E.y,E.z),M.set(N,A,V).normalize(),d.push(M.x,M.y,M.z),p.push(nt,1-b),v.push(g++)}y.push(v)}for(let U=0;U<i;U++)for(let v=0;v<r;v++){let b=y[v][U],F=y[v+1][U],k=y[v+1][U+1],nt=y[v][U+1];h.push(b,F,nt),h.push(F,k,nt),w+=6}c.addGroup(f,w,0),f+=w}function _(M){let E=g,w=new _t,A=new C,U=0,v=M===!0?t:e,b=M===!0?1:-1;for(let k=1;k<=i;k++)u.push(0,m*b,0),d.push(0,b,0),p.push(.5,.5),g++;let F=g;for(let k=0;k<=i;k++){let L=k/i*l+o,N=Math.cos(L),V=Math.sin(L);A.x=v*V,A.y=m*b,A.z=v*N,u.push(A.x,A.y,A.z),d.push(0,b,0),w.x=N*.5+.5,w.y=V*.5*b+.5,p.push(w.x,w.y),g++}for(let k=0;k<i;k++){let nt=E+k,L=F+k;M===!0?h.push(L,L+1,nt):h.push(L+1,L,nt),U+=3}c.addGroup(f,U,M===!0?1:2),f+=U}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},ns=class s extends sn{constructor(t=1,e=1,n=32,i=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,n,i,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new s(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},qo=class s extends Te{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};let r=[],a=[];o(i),c(n),h(),this.setAttribute("position",new se(r,3)),this.setAttribute("normal",new se(r.slice(),3)),this.setAttribute("uv",new se(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function o(x){let _=new C,M=new C,E=new C;for(let w=0;w<e.length;w+=3)p(e[w+0],_),p(e[w+1],M),p(e[w+2],E),l(_,M,E,x)}function l(x,_,M,E){let w=E+1,A=[];for(let U=0;U<=w;U++){A[U]=[];let v=x.clone().lerp(M,U/w),b=_.clone().lerp(M,U/w),F=w-U;for(let k=0;k<=F;k++)k===0&&U===w?A[U][k]=v:A[U][k]=v.clone().lerp(b,k/F)}for(let U=0;U<w;U++)for(let v=0;v<2*(w-U)-1;v++){let b=Math.floor(v/2);v%2===0?(d(A[U][b+1]),d(A[U+1][b]),d(A[U][b])):(d(A[U][b+1]),d(A[U+1][b+1]),d(A[U+1][b]))}}function c(x){let _=new C;for(let M=0;M<r.length;M+=3)_.x=r[M+0],_.y=r[M+1],_.z=r[M+2],_.normalize().multiplyScalar(x),r[M+0]=_.x,r[M+1]=_.y,r[M+2]=_.z}function h(){let x=new C;for(let _=0;_<r.length;_+=3){x.x=r[_+0],x.y=r[_+1],x.z=r[_+2];let M=m(x)/2/Math.PI+.5,E=f(x)/Math.PI+.5;a.push(M,1-E)}g(),u()}function u(){for(let x=0;x<a.length;x+=6){let _=a[x+0],M=a[x+2],E=a[x+4],w=Math.max(_,M,E),A=Math.min(_,M,E);w>.9&&A<.1&&(_<.2&&(a[x+0]+=1),M<.2&&(a[x+2]+=1),E<.2&&(a[x+4]+=1))}}function d(x){r.push(x.x,x.y,x.z)}function p(x,_){let M=x*3;_.x=t[M+0],_.y=t[M+1],_.z=t[M+2]}function g(){let x=new C,_=new C,M=new C,E=new C,w=new _t,A=new _t,U=new _t;for(let v=0,b=0;v<r.length;v+=9,b+=6){x.set(r[v+0],r[v+1],r[v+2]),_.set(r[v+3],r[v+4],r[v+5]),M.set(r[v+6],r[v+7],r[v+8]),w.set(a[b+0],a[b+1]),A.set(a[b+2],a[b+3]),U.set(a[b+4],a[b+5]),E.copy(x).add(_).add(M).divideScalar(3);let F=m(E);y(w,b+0,x,F),y(A,b+2,_,F),y(U,b+4,M,F)}}function y(x,_,M,E){E<0&&x.x===1&&(a[_]=x.x-1),M.x===0&&M.z===0&&(a[_]=E/2/Math.PI+.5)}function m(x){return Math.atan2(x.z,-x.x)}function f(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.vertices,t.indices,t.radius,t.details)}};var zs=class extends Qr{constructor(t){super(t),this.uuid=rs(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let n=0,i=this.holes.length;n<i;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let i=t.holes[e];this.holes.push(i.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){let i=this.holes[e];t.holes.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let i=t.holes[e];this.holes.push(new Qr().fromJSON(i))}return this}},Xg={triangulate:function(s,t,e=2){let n=t&&t.length,i=n?t[0]*e:s.length,r=Rh(s,0,i,e,!0),a=[];if(!r||r.next===r.prev)return a;let o,l,c,h,u,d,p;if(n&&(r=$g(s,t,r,e)),s.length>80*e){o=c=s[0],l=h=s[1];for(let g=e;g<i;g+=e)u=s[g],d=s[g+1],u<o&&(o=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);p=Math.max(c-o,h-l),p=p!==0?32767/p:0}return Bs(r,a,e,o,l,p,0),a}};function Rh(s,t,e,n,i){let r,a;if(i===o0(s,t,e,n)>0)for(r=t;r<e;r+=n)a=th(r,s[r],s[r+1],a);else for(r=e-n;r>=t;r-=n)a=th(r,s[r],s[r+1],a);return a&&la(a,a.next)&&(Hs(a),a=a.next),a}function vi(s,t){if(!s)return s;t||(t=s);let e=s,n;do if(n=!1,!e.steiner&&(la(e,e.next)||he(e.prev,e,e.next)===0)){if(Hs(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function Bs(s,t,e,n,i,r,a){if(!s)return;!a&&r&&e0(s,n,i,r);let o=s,l,c;for(;s.prev!==s.next;){if(l=s.prev,c=s.next,r?Yg(s,n,i,r):qg(s)){t.push(l.i/e|0),t.push(s.i/e|0),t.push(c.i/e|0),Hs(s),s=c.next,o=c.next;continue}if(s=c,s===o){a?a===1?(s=Zg(vi(s),t,e),Bs(s,t,e,n,i,r,2)):a===2&&Jg(s,t,e,n,i,r):Bs(vi(s),t,e,n,i,r,1);break}}}function qg(s){let t=s.prev,e=s,n=s.next;if(he(t,e,n)>=0)return!1;let i=t.x,r=e.x,a=n.x,o=t.y,l=e.y,c=n.y,h=i<r?i<a?i:a:r<a?r:a,u=o<l?o<c?o:c:l<c?l:c,d=i>r?i>a?i:a:r>a?r:a,p=o>l?o>c?o:c:l>c?l:c,g=n.next;for(;g!==t;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=p&&Yi(i,o,r,l,a,c,g.x,g.y)&&he(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function Yg(s,t,e,n){let i=s.prev,r=s,a=s.next;if(he(i,r,a)>=0)return!1;let o=i.x,l=r.x,c=a.x,h=i.y,u=r.y,d=a.y,p=o<l?o<c?o:c:l<c?l:c,g=h<u?h<d?h:d:u<d?u:d,y=o>l?o>c?o:c:l>c?l:c,m=h>u?h>d?h:d:u>d?u:d,f=Yo(p,g,t,e,n),x=Yo(y,m,t,e,n),_=s.prevZ,M=s.nextZ;for(;_&&_.z>=f&&M&&M.z<=x;){if(_.x>=p&&_.x<=y&&_.y>=g&&_.y<=m&&_!==i&&_!==a&&Yi(o,h,l,u,c,d,_.x,_.y)&&he(_.prev,_,_.next)>=0||(_=_.prevZ,M.x>=p&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&Yi(o,h,l,u,c,d,M.x,M.y)&&he(M.prev,M,M.next)>=0))return!1;M=M.nextZ}for(;_&&_.z>=f;){if(_.x>=p&&_.x<=y&&_.y>=g&&_.y<=m&&_!==i&&_!==a&&Yi(o,h,l,u,c,d,_.x,_.y)&&he(_.prev,_,_.next)>=0)return!1;_=_.prevZ}for(;M&&M.z<=x;){if(M.x>=p&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&Yi(o,h,l,u,c,d,M.x,M.y)&&he(M.prev,M,M.next)>=0)return!1;M=M.nextZ}return!0}function Zg(s,t,e){let n=s;do{let i=n.prev,r=n.next.next;!la(i,r)&&Ch(i,n,n.next,r)&&ks(i,r)&&ks(r,i)&&(t.push(i.i/e|0),t.push(n.i/e|0),t.push(r.i/e|0),Hs(n),Hs(n.next),n=s=r),n=n.next}while(n!==s);return vi(n)}function Jg(s,t,e,n,i,r){let a=s;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&s0(a,o)){let l=Ph(a,o);a=vi(a,a.next),l=vi(l,l.next),Bs(a,t,e,n,i,r,0),Bs(l,t,e,n,i,r,0);return}o=o.next}a=a.next}while(a!==s)}function $g(s,t,e,n){let i=[],r,a,o,l,c;for(r=0,a=t.length;r<a;r++)o=t[r]*n,l=r<a-1?t[r+1]*n:s.length,c=Rh(s,o,l,n,!1),c===c.next&&(c.steiner=!0),i.push(i0(c));for(i.sort(Kg),r=0;r<i.length;r++)e=Qg(i[r],e);return e}function Kg(s,t){return s.x-t.x}function Qg(s,t){let e=jg(s,t);if(!e)return t;let n=Ph(e,s);return vi(n,n.next),vi(e,e.next)}function jg(s,t){let e=t,n=-1/0,i,r=s.x,a=s.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){let d=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(d<=r&&d>n&&(n=d,i=e.x<e.next.x?e:e.next,d===r))return i}e=e.next}while(e!==t);if(!i)return null;let o=i,l=i.x,c=i.y,h=1/0,u;e=i;do r>=e.x&&e.x>=l&&r!==e.x&&Yi(a<c?r:n,a,l,c,a<c?n:r,a,e.x,e.y)&&(u=Math.abs(a-e.y)/(r-e.x),ks(e,s)&&(u<h||u===h&&(e.x>i.x||e.x===i.x&&t0(i,e)))&&(i=e,h=u)),e=e.next;while(e!==o);return i}function t0(s,t){return he(s.prev,s,t.prev)<0&&he(t.next,s,s.next)<0}function e0(s,t,e,n){let i=s;do i.z===0&&(i.z=Yo(i.x,i.y,t,e,n)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==s);i.prevZ.nextZ=null,i.prevZ=null,n0(i)}function n0(s){let t,e,n,i,r,a,o,l,c=1;do{for(e=s,s=null,r=null,a=0;e;){for(a++,n=e,o=0,t=0;t<c&&(o++,n=n.nextZ,!!n);t++);for(l=c;o>0||l>0&&n;)o!==0&&(l===0||!n||e.z<=n.z)?(i=e,e=e.nextZ,o--):(i=n,n=n.nextZ,l--),r?r.nextZ=i:s=i,i.prevZ=r,r=i;e=n}r.nextZ=null,c*=2}while(a>1);return s}function Yo(s,t,e,n,i){return s=(s-e)*i|0,t=(t-n)*i|0,s=(s|s<<8)&16711935,s=(s|s<<4)&252645135,s=(s|s<<2)&858993459,s=(s|s<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,s|t<<1}function i0(s){let t=s,e=s;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==s);return e}function Yi(s,t,e,n,i,r,a,o){return(i-a)*(t-o)>=(s-a)*(r-o)&&(s-a)*(n-o)>=(e-a)*(t-o)&&(e-a)*(r-o)>=(i-a)*(n-o)}function s0(s,t){return s.next.i!==t.i&&s.prev.i!==t.i&&!r0(s,t)&&(ks(s,t)&&ks(t,s)&&a0(s,t)&&(he(s.prev,s,t.prev)||he(s,t.prev,t))||la(s,t)&&he(s.prev,s,s.next)>0&&he(t.prev,t,t.next)>0)}function he(s,t,e){return(t.y-s.y)*(e.x-t.x)-(t.x-s.x)*(e.y-t.y)}function la(s,t){return s.x===t.x&&s.y===t.y}function Ch(s,t,e,n){let i=br(he(s,t,e)),r=br(he(s,t,n)),a=br(he(e,n,s)),o=br(he(e,n,t));return!!(i!==r&&a!==o||i===0&&Mr(s,e,t)||r===0&&Mr(s,n,t)||a===0&&Mr(e,s,n)||o===0&&Mr(e,t,n))}function Mr(s,t,e){return t.x<=Math.max(s.x,e.x)&&t.x>=Math.min(s.x,e.x)&&t.y<=Math.max(s.y,e.y)&&t.y>=Math.min(s.y,e.y)}function br(s){return s>0?1:s<0?-1:0}function r0(s,t){let e=s;do{if(e.i!==s.i&&e.next.i!==s.i&&e.i!==t.i&&e.next.i!==t.i&&Ch(e,e.next,s,t))return!0;e=e.next}while(e!==s);return!1}function ks(s,t){return he(s.prev,s,s.next)<0?he(s,t,s.next)>=0&&he(s,s.prev,t)>=0:he(s,t,s.prev)<0||he(s,s.next,t)<0}function a0(s,t){let e=s,n=!1,i=(s.x+t.x)/2,r=(s.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&i<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==s);return n}function Ph(s,t){let e=new Zo(s.i,s.x,s.y),n=new Zo(t.i,t.x,t.y),i=s.next,r=t.prev;return s.next=t,t.prev=s,e.next=i,i.prev=e,n.next=e,e.prev=n,r.next=n,n.prev=r,n}function th(s,t,e,n){let i=new Zo(s,t,e);return n?(i.next=n.next,i.prev=n,n.next.prev=i,n.next=i):(i.prev=i,i.next=i),i}function Hs(s){s.next.prev=s.prev,s.prev.next=s.next,s.prevZ&&(s.prevZ.nextZ=s.nextZ),s.nextZ&&(s.nextZ.prevZ=s.prevZ)}function Zo(s,t,e){this.i=s,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function o0(s,t,e,n){let i=0;for(let r=t,a=e-n;r<e;r+=n)i+=(s[a]-s[r])*(s[r+1]+s[a+1]),a=r;return i}var Cs=class s{static area(t){let e=t.length,n=0;for(let i=e-1,r=0;r<e;i=r++)n+=t[i].x*t[r].y-t[r].x*t[i].y;return n*.5}static isClockWise(t){return s.area(t)<0}static triangulateShape(t,e){let n=[],i=[],r=[];eh(t),nh(n,t);let a=t.length;e.forEach(eh);for(let l=0;l<e.length;l++)i.push(a),a+=e[l].length,nh(n,e[l]);let o=Xg.triangulate(n,i);for(let l=0;l<o.length;l+=3)r.push(o.slice(l,l+3));return r}};function eh(s){let t=s.length;t>2&&s[t-1].equals(s[0])&&s.pop()}function nh(s,t){for(let e=0;e<t.length;e++)s.push(t[e].x),s.push(t[e].y)}var jr=class s extends Te{constructor(t=new zs([new _t(.5,.5),new _t(-.5,.5),new _t(-.5,-.5),new _t(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let n=this,i=[],r=[];for(let o=0,l=t.length;o<l;o++){let c=t[o];a(c)}this.setAttribute("position",new se(i,3)),this.setAttribute("uv",new se(r,2)),this.computeVertexNormals();function a(o){let l=[],c=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,u=e.depth!==void 0?e.depth:1,d=e.bevelEnabled!==void 0?e.bevelEnabled:!0,p=e.bevelThickness!==void 0?e.bevelThickness:.2,g=e.bevelSize!==void 0?e.bevelSize:p-.1,y=e.bevelOffset!==void 0?e.bevelOffset:0,m=e.bevelSegments!==void 0?e.bevelSegments:3,f=e.extrudePath,x=e.UVGenerator!==void 0?e.UVGenerator:l0,_,M=!1,E,w,A,U;f&&(_=f.getSpacedPoints(h),M=!0,d=!1,E=f.computeFrenetFrames(h,!1),w=new C,A=new C,U=new C),d||(m=0,p=0,g=0,y=0);let v=o.extractPoints(c),b=v.shape,F=v.holes;if(!Cs.isClockWise(b)){b=b.reverse();for(let P=0,st=F.length;P<st;P++){let H=F[P];Cs.isClockWise(H)&&(F[P]=H.reverse())}}let nt=Cs.triangulateShape(b,F),L=b;for(let P=0,st=F.length;P<st;P++){let H=F[P];b=b.concat(H)}function N(P,st,H){return st||console.error("THREE.ExtrudeGeometry: vec does not exist"),P.clone().addScaledVector(st,H)}let V=b.length,et=nt.length;function Y(P,st,H){let K,G,yt,ut=P.x-st.x,T=P.y-st.y,S=H.x-P.x,z=H.y-P.y,it=ut*ut+T*T,ot=ut*z-T*S;if(Math.abs(ot)>Number.EPSILON){let at=Math.sqrt(it),Tt=Math.sqrt(S*S+z*z),vt=st.x-T/at,Et=st.y+ut/at,Pt=H.x-z/Tt,kt=H.y+S/Tt,lt=((Pt-vt)*z-(kt-Et)*S)/(ut*z-T*S);K=vt+ut*lt-P.x,G=Et+T*lt-P.y;let Jt=K*K+G*G;if(Jt<=2)return new _t(K,G);yt=Math.sqrt(Jt/2)}else{let at=!1;ut>Number.EPSILON?S>Number.EPSILON&&(at=!0):ut<-Number.EPSILON?S<-Number.EPSILON&&(at=!0):Math.sign(T)===Math.sign(z)&&(at=!0),at?(K=-T,G=ut,yt=Math.sqrt(it)):(K=ut,G=T,yt=Math.sqrt(it/2))}return new _t(K/yt,G/yt)}let J=[];for(let P=0,st=L.length,H=st-1,K=P+1;P<st;P++,H++,K++)H===st&&(H=0),K===st&&(K=0),J[P]=Y(L[P],L[H],L[K]);let D=[],j,rt=J.concat();for(let P=0,st=F.length;P<st;P++){let H=F[P];j=[];for(let K=0,G=H.length,yt=G-1,ut=K+1;K<G;K++,yt++,ut++)yt===G&&(yt=0),ut===G&&(ut=0),j[K]=Y(H[K],H[yt],H[ut]);D.push(j),rt=rt.concat(j)}for(let P=0;P<m;P++){let st=P/m,H=p*Math.cos(st*Math.PI/2),K=g*Math.sin(st*Math.PI/2)+y;for(let G=0,yt=L.length;G<yt;G++){let ut=N(L[G],J[G],K);dt(ut.x,ut.y,-H)}for(let G=0,yt=F.length;G<yt;G++){let ut=F[G];j=D[G];for(let T=0,S=ut.length;T<S;T++){let z=N(ut[T],j[T],K);dt(z.x,z.y,-H)}}}let O=g+y;for(let P=0;P<V;P++){let st=d?N(b[P],rt[P],O):b[P];M?(A.copy(E.normals[0]).multiplyScalar(st.x),w.copy(E.binormals[0]).multiplyScalar(st.y),U.copy(_[0]).add(A).add(w),dt(U.x,U.y,U.z)):dt(st.x,st.y,0)}for(let P=1;P<=h;P++)for(let st=0;st<V;st++){let H=d?N(b[st],rt[st],O):b[st];M?(A.copy(E.normals[P]).multiplyScalar(H.x),w.copy(E.binormals[P]).multiplyScalar(H.y),U.copy(_[P]).add(A).add(w),dt(U.x,U.y,U.z)):dt(H.x,H.y,u/h*P)}for(let P=m-1;P>=0;P--){let st=P/m,H=p*Math.cos(st*Math.PI/2),K=g*Math.sin(st*Math.PI/2)+y;for(let G=0,yt=L.length;G<yt;G++){let ut=N(L[G],J[G],K);dt(ut.x,ut.y,u+H)}for(let G=0,yt=F.length;G<yt;G++){let ut=F[G];j=D[G];for(let T=0,S=ut.length;T<S;T++){let z=N(ut[T],j[T],K);M?dt(z.x,z.y+_[h-1].y,_[h-1].x+H):dt(z.x,z.y,u+H)}}}$(),ht();function $(){let P=i.length/3;if(d){let st=0,H=V*st;for(let K=0;K<et;K++){let G=nt[K];X(G[2]+H,G[1]+H,G[0]+H)}st=h+m*2,H=V*st;for(let K=0;K<et;K++){let G=nt[K];X(G[0]+H,G[1]+H,G[2]+H)}}else{for(let st=0;st<et;st++){let H=nt[st];X(H[2],H[1],H[0])}for(let st=0;st<et;st++){let H=nt[st];X(H[0]+V*h,H[1]+V*h,H[2]+V*h)}}n.addGroup(P,i.length/3-P,0)}function ht(){let P=i.length/3,st=0;ft(L,st),st+=L.length;for(let H=0,K=F.length;H<K;H++){let G=F[H];ft(G,st),st+=G.length}n.addGroup(P,i.length/3-P,1)}function ft(P,st){let H=P.length;for(;--H>=0;){let K=H,G=H-1;G<0&&(G=P.length-1);for(let yt=0,ut=h+m*2;yt<ut;yt++){let T=V*yt,S=V*(yt+1),z=st+K+T,it=st+G+T,ot=st+G+S,at=st+K+S;Q(z,it,ot,at)}}}function dt(P,st,H){l.push(P),l.push(st),l.push(H)}function X(P,st,H){tt(P),tt(st),tt(H);let K=i.length/3,G=x.generateTopUV(n,i,K-3,K-2,K-1);xt(G[0]),xt(G[1]),xt(G[2])}function Q(P,st,H,K){tt(P),tt(st),tt(K),tt(st),tt(H),tt(K);let G=i.length/3,yt=x.generateSideWallUV(n,i,G-6,G-3,G-2,G-1);xt(yt[0]),xt(yt[1]),xt(yt[3]),xt(yt[1]),xt(yt[2]),xt(yt[3])}function tt(P){i.push(l[P*3+0]),i.push(l[P*3+1]),i.push(l[P*3+2])}function xt(P){r.push(P.x),r.push(P.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,n=this.parameters.options;return c0(e,n,t)}static fromJSON(t,e){let n=[];for(let r=0,a=t.shapes.length;r<a;r++){let o=e[t.shapes[r]];n.push(o)}let i=t.options.extrudePath;return i!==void 0&&(t.options.extrudePath=new Wo[i.type]().fromJSON(i)),new s(n,t.options)}},l0={generateTopUV:function(s,t,e,n,i){let r=t[e*3],a=t[e*3+1],o=t[n*3],l=t[n*3+1],c=t[i*3],h=t[i*3+1];return[new _t(r,a),new _t(o,l),new _t(c,h)]},generateSideWallUV:function(s,t,e,n,i,r){let a=t[e*3],o=t[e*3+1],l=t[e*3+2],c=t[n*3],h=t[n*3+1],u=t[n*3+2],d=t[i*3],p=t[i*3+1],g=t[i*3+2],y=t[r*3],m=t[r*3+1],f=t[r*3+2];return Math.abs(o-h)<Math.abs(a-c)?[new _t(a,1-l),new _t(c,1-u),new _t(d,1-g),new _t(y,1-f)]:[new _t(o,1-l),new _t(h,1-u),new _t(p,1-g),new _t(m,1-f)]}};function c0(s,t,e){if(e.shapes=[],Array.isArray(s))for(let n=0,i=s.length;n<i;n++){let r=s[n];e.shapes.push(r.uuid)}else e.shapes.push(s.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var ta=class s extends qo{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,i=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(i,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new s(t.radius,t.detail)}};var ea=class s extends Te{constructor(t=.5,e=1,n=32,i=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:i,thetaStart:r,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);let o=[],l=[],c=[],h=[],u=t,d=(e-t)/i,p=new C,g=new _t;for(let y=0;y<=i;y++){for(let m=0;m<=n;m++){let f=r+m/n*a;p.x=u*Math.cos(f),p.y=u*Math.sin(f),l.push(p.x,p.y,p.z),c.push(0,0,1),g.x=(p.x/e+1)/2,g.y=(p.y/e+1)/2,h.push(g.x,g.y)}u+=d}for(let y=0;y<i;y++){let m=y*(n+1);for(let f=0;f<n;f++){let x=f+m,_=x,M=x+n+1,E=x+n+2,w=x+1;o.push(_,M,w),o.push(M,E,w)}}this.setIndex(o),this.setAttribute("position",new se(l,3)),this.setAttribute("normal",new se(c,3)),this.setAttribute("uv",new se(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var Mi=class s extends Te{constructor(t=1,e=32,n=16,i=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(a+o,Math.PI),c=0,h=[],u=new C,d=new C,p=[],g=[],y=[],m=[];for(let f=0;f<=n;f++){let x=[],_=f/n,M=0;f===0&&a===0?M=.5/e:f===n&&l===Math.PI&&(M=-.5/e);for(let E=0;E<=e;E++){let w=E/e;u.x=-t*Math.cos(i+w*r)*Math.sin(a+_*o),u.y=t*Math.cos(a+_*o),u.z=t*Math.sin(i+w*r)*Math.sin(a+_*o),g.push(u.x,u.y,u.z),d.copy(u).normalize(),y.push(d.x,d.y,d.z),m.push(w+M,1-_),x.push(c++)}h.push(x)}for(let f=0;f<n;f++)for(let x=0;x<e;x++){let _=h[f][x+1],M=h[f][x],E=h[f+1][x],w=h[f+1][x+1];(f!==0||a>0)&&p.push(_,M,w),(f!==n-1||l<Math.PI)&&p.push(M,E,w)}this.setIndex(p),this.setAttribute("position",new se(g,3)),this.setAttribute("normal",new se(y,3)),this.setAttribute("uv",new se(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var Ce=class extends ii{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Ct(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ct(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=_h,this.normalScale=new _t(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function Sr(s,t,e){return!s||!e&&s.constructor===t?s:typeof t.BYTES_PER_ELEMENT=="number"?new t(s):Array.prototype.slice.call(s)}function h0(s){return ArrayBuffer.isView(s)&&!(s instanceof DataView)}var is=class{constructor(t,e,n,i){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,i=e[n],r=e[n-1];n:{t:{let a;e:{i:if(!(t<i)){for(let o=n+2;;){if(i===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(r=i,i=e[++n],t<i)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(n=2,r=o);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(i=r,r=e[--n-1],t>=r)break t}a=n,n=0;break e}break n}for(;n<a;){let o=n+a>>>1;t<e[o]?a=o:n=o+1}if(i=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,i)}return this.interpolate_(n,r,t,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,i=this.valueSize,r=t*i;for(let a=0;a!==i;++a)e[a]=n[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Jo=class extends is{constructor(t,e,n,i){super(t,e,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:rc,endingEnd:rc}}intervalChanged_(t,e,n){let i=this.parameterPositions,r=t-2,a=t+1,o=i[r],l=i[a];if(o===void 0)switch(this.getSettings_().endingStart){case ac:r=t,o=2*e-n;break;case oc:r=i.length-2,o=e+i[r]-i[r+1];break;default:r=t,o=n}if(l===void 0)switch(this.getSettings_().endingEnd){case ac:a=t,l=2*n-e;break;case oc:a=1,l=n+i[1]-i[0];break;default:a=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-o),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,p=this._weightNext,g=(n-e)/(i-e),y=g*g,m=y*g,f=-d*m+2*d*y-d*g,x=(1+d)*m+(-1.5-2*d)*y+(-.5+d)*g+1,_=(-1-p)*m+(1.5+p)*y+.5*g,M=p*m-p*y;for(let E=0;E!==o;++E)r[E]=f*a[h+E]+x*a[c+E]+_*a[l+E]+M*a[u+E];return r}},$o=class extends is{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=(n-e)/(i-e),u=1-h;for(let d=0;d!==o;++d)r[d]=a[c+d]*u+a[l+d]*h;return r}},Ko=class extends is{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t){return this.copySampleValue_(t-1)}},gn=class{constructor(t,e,n,i){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=Sr(e,this.TimeBufferType),this.values=Sr(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:Sr(t.times,Array),values:Sr(t.values,Array)};let i=t.getInterpolation();i!==t.DefaultInterpolation&&(n.interpolation=i)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new Ko(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new $o(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Jo(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case wr:e=this.InterpolantFactoryMethodDiscrete;break;case Tr:e=this.InterpolantFactoryMethodLinear;break;case Oa:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return wr;case this.InterpolantFactoryMethodLinear:return Tr;case this.InterpolantFactoryMethodSmooth:return Oa}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]*=t}return this}trim(t,e){let n=this.times,i=n.length,r=0,a=i-1;for(;r!==i&&n[r]<t;)++r;for(;a!==-1&&n[a]>e;)--a;if(++a,r!==0||a!==i){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=n.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,i=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let l=n[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),t=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),t=!1;break}a=l}if(i!==void 0&&h0(i))for(let o=0,l=i.length;o!==l;++o){let c=i[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===Oa,r=t.length-1,a=1;for(let o=1;o<r;++o){let l=!1,c=t[o],h=t[o+1];if(c!==h&&(o!==1||c!==t[0]))if(i)l=!0;else{let u=o*n,d=u-n,p=u+n;for(let g=0;g!==n;++g){let y=e[u+g];if(y!==e[d+g]||y!==e[p+g]){l=!0;break}}}if(l){if(o!==a){t[a]=t[o];let u=o*n,d=a*n;for(let p=0;p!==n;++p)e[d+p]=e[u+p]}++a}}if(r>0){t[a]=t[r];for(let o=r*n,l=a*n,c=0;c!==n;++c)e[l+c]=e[o+c];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,i=new n(this.name,t,e);return i.createInterpolant=this.createInterpolant,i}};gn.prototype.TimeBufferType=Float32Array;gn.prototype.ValueBufferType=Float32Array;gn.prototype.DefaultInterpolation=Tr;var bi=class extends gn{};bi.prototype.ValueTypeName="bool";bi.prototype.ValueBufferType=Array;bi.prototype.DefaultInterpolation=wr;bi.prototype.InterpolantFactoryMethodLinear=void 0;bi.prototype.InterpolantFactoryMethodSmooth=void 0;var Qo=class extends gn{};Qo.prototype.ValueTypeName="color";var jo=class extends gn{};jo.prototype.ValueTypeName="number";var tl=class extends is{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(n-e)/(i-e),c=t*o;for(let h=c+o;c!==h;c+=4)$t.slerpFlat(r,0,a,c-o,a,c,l);return r}},Vs=class extends gn{InterpolantFactoryMethodLinear(t){return new tl(this.times,this.values,this.getValueSize(),t)}};Vs.prototype.ValueTypeName="quaternion";Vs.prototype.DefaultInterpolation=Tr;Vs.prototype.InterpolantFactoryMethodSmooth=void 0;var Si=class extends gn{};Si.prototype.ValueTypeName="string";Si.prototype.ValueBufferType=Array;Si.prototype.DefaultInterpolation=wr;Si.prototype.InterpolantFactoryMethodLinear=void 0;Si.prototype.InterpolantFactoryMethodSmooth=void 0;var el=class extends gn{};el.prototype.ValueTypeName="vector";var nl=class{constructor(t,e,n){let i=this,r=!1,a=0,o=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(h){o++,r===!1&&i.onStart!==void 0&&i.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,i.onProgress!==void 0&&i.onProgress(h,a,o),a===o&&(r=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(h){i.onError!==void 0&&i.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let p=c[u],g=c[u+1];if(p.global&&(p.lastIndex=0),p.test(h))return g}return null}}},u0=new nl,il=class{constructor(t){this.manager=t!==void 0?t:u0,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(i,r){n.load(t,i,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};il.DEFAULT_MATERIAL_NAME="__DEFAULT";var Gs=class extends we{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Ct(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},na=class extends Gs{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(we.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ct(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},uo=new le,ih=new C,sh=new C,ia=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new _t(512,512),this.map=null,this.mapPass=null,this.matrix=new le,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ds,this._frameExtents=new _t(1,1),this._viewportCount=1,this._viewports=[new oe(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;ih.setFromMatrixPosition(t.matrixWorld),e.position.copy(ih),sh.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(sh),e.updateMatrixWorld(),uo.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(uo),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(uo)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var rh=new le,Es=new C,fo=new C,sl=class extends ia{constructor(){super(new Ne(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new _t(4,2),this._viewportCount=6,this._viewports=[new oe(2,1,1,1),new oe(0,1,1,1),new oe(3,1,1,1),new oe(1,1,1,1),new oe(3,0,1,1),new oe(1,0,1,1)],this._cubeDirections=[new C(1,0,0),new C(-1,0,0),new C(0,0,1),new C(0,0,-1),new C(0,1,0),new C(0,-1,0)],this._cubeUps=[new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,0,1),new C(0,0,-1)]}updateMatrices(t,e=0){let n=this.camera,i=this.matrix,r=t.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),Es.setFromMatrixPosition(t.matrixWorld),n.position.copy(Es),fo.copy(n.position),fo.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(fo),n.updateMatrixWorld(),i.makeTranslation(-Es.x,-Es.y,-Es.z),rh.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(rh)}},ss=class extends Gs{constructor(t,e,n=0,i=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new sl}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}},rl=class extends ia{constructor(){super(new Vr(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},sa=class extends Gs{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(we.DEFAULT_UP),this.updateMatrix(),this.target=new we,this.shadow=new rl}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var dl="\\[\\]\\.:\\/",d0=new RegExp("["+dl+"]","g"),fl="[^"+dl+"]",f0="[^"+dl.replace("\\.","")+"]",p0=/((?:WC+[\/:])*)/.source.replace("WC",fl),m0=/(WCOD+)?/.source.replace("WCOD",f0),g0=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",fl),_0=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",fl),x0=new RegExp("^"+p0+m0+g0+_0+"$"),y0=["material","materials","bones","map"],al=class{constructor(t,e,n){let i=n||ae.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,i)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,r=n.length;i!==r;++i)n[i].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},ae=class s{constructor(t,e,n){this.path=e,this.parsedPath=n||s.parseTrackName(e),this.node=s.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new s.Composite(t,e,n):new s(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(d0,"")}static parseTrackName(t){let e=x0.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let r=n.nodeName.substring(i+1);y0.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let l=n(o.children);if(l)return l}return null},i=n(t.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)t[e++]=n[i]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,i=e.propertyName,r=e.propertyIndex;if(t||(t=s.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let a=t[i];if(a===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+i+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(i==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=i;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};ae.Composite=al;ae.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};ae.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};ae.prototype.GetterByBindingType=[ae.prototype._getValue_direct,ae.prototype._getValue_array,ae.prototype._getValue_arrayElement,ae.prototype._getValue_toArray];ae.prototype.SetterByBindingTypeAndVersioning=[[ae.prototype._setValue_direct,ae.prototype._setValue_direct_setNeedsUpdate,ae.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[ae.prototype._setValue_array,ae.prototype._setValue_array_setNeedsUpdate,ae.prototype._setValue_array_setMatrixWorldNeedsUpdate],[ae.prototype._setValue_arrayElement,ae.prototype._setValue_arrayElement_setNeedsUpdate,ae.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[ae.prototype._setValue_fromArray,ae.prototype._setValue_fromArray_setNeedsUpdate,ae.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var L0=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"160"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="160");var zt=s=>s*.01,me=s=>s/.01,gt={version:"1.0.0",sim:{hz:120,maxCatchupSteps:8,gravity:zt(650),solverIterations:10},arena:{halfWidth:zt(4096),halfLength:zt(5120),height:zt(2044),floorRampRadius:zt(260),ceilingRampRadius:zt(260),cornerRadius:zt(1152),goalHalfWidth:zt(892.75),goalHeight:zt(642.775),goalDepth:zt(880),postRadius:zt(30),arcSegments:14,friction:.5,restitution:.75},car:{halfLength:zt(120.5)/2,halfWidth:zt(86.7)/2,halfHeight:zt(38.7)/2,mass:180,comOffsetY:-.04,restHeight:.205,wheelRadius:.14,wheelbase:zt(101.5),wheelX:.4,wheelZFront:-.43,wheelZRear:.38,wheelAttachY:-.02,suspensionDroop:.05,springEquilibrium:.07,springDampingRatio:.55,bumpStopStart:.1,bumpStopStiffness:9,rollInfluence:.06,lateralGrip:1,frictionCoeff:4,powerslideGrip:.1,powerslideYawRate:4.2,powerslideYawAccel:22,gripRecoveryTime:.18,stickyAccel:zt(325),throttleAccel0:zt(1600),maxDriveSpeed:zt(1410),brakeAccel:zt(3500),coastAccel:zt(525),reverseMaxSpeed:zt(1410),boostAccelGround:zt(992),boostAccelAir:zt(1058),maxSpeed:zt(2300),supersonic:zt(2200),airThrottleAccel:zt(66.7),steerAngles:[[0,35],[500,20],[1e3,11],[1500,6.25],[1750,5],[3e3,2]],jumpImpulse:zt(292),jumpHoldAccel:zt(1458),jumpHoldTime:.2,dodgeWindow:1.25,fallOffJumpWindow:1.45,dodgeImpulse:zt(500),dodgeSpeedBonus:.9,dodgeDeadzone:.5,flipTime:.65,flipRampIn:.12,flipRampOut:.3,flipAngleGain:10,flipOffAxisDamp:12,flipMaxAngularSpeed:14,flipVerticalDamp:.35,flipVerticalDampTime:.15,flipCancelThreshold:.5,airPitchAccel:12.46,airYawAccel:9.11,airRollAccel:38.34,airPitchDamp:2.798,airYawDamp:1.886,airRollDamp:4,maxAngularSpeed:5.5,demoRespawn:3,demoMinRelSpeed:zt(300),boostStart:33.33,boostMax:100,boostPerSecond:33.3,colliderFriction:.4,colliderRestitution:.15},ball:{radius:zt(91.25),mass:30,maxSpeed:zt(6e3),maxAngularSpeed:6,linearDamping:.03,angularDamping:.05,restitution:.8,friction:.7,carRestitution:.35,hitVerticalScale:.35,hitCurve:[[0,.65],[500,.65],[2300,.55],[4600,.3]],hitCooldown:.05},boost:{smallAmount:12,smallRespawn:4,smallRadius:zt(144),largeAmount:100,largeRespawn:10,largeRadius:zt(208),pickupHeight:zt(165)},camera:{hFov:110,distance:270,height:100,angle:-4,stiffness:.4,swivelSpeed:4,transitionSpeed:6,ballCamPitchMax:45,freeLookMax:1.9},match:{duration:300,countdown:3,goalCelebration:2.2,replayDuration:5,replaySpeed:.5,resultsDelay:1,kickoffHalfWidth:0},input:{stickDeadzone:.12,triggerDeadzone:.05,steerSensitivity:1,dodgeDeadzone:.5,mouseSensitivity:.0022,bindings:{throttle:["KeyW"],brake:["KeyS"],left:["KeyA"],right:["KeyD"],jump:["Space"],boost:["ShiftLeft","ShiftRight"],powerslide:["ControlLeft","ControlRight"],rollLeft:["KeyQ"],rollRight:["KeyE"],ballCam:["KeyC"],reset:["KeyR"],lookLeft:["ArrowLeft"],lookRight:["ArrowRight"],lookUp:["ArrowUp"],lookDown:["ArrowDown"],pause:["Escape"]}},ai:{difficulties:{rookie:{reaction:.28,steerNoise:.18,boostUse:.5,aerial:!1,dodge:!1,predictTime:2,speedLimit:.8,powerslide:!1},pro:{reaction:.14,steerNoise:.07,boostUse:.8,aerial:!1,dodge:!0,predictTime:3,speedLimit:1,powerslide:!0},allstar:{reaction:.05,steerNoise:.02,boostUse:1,aerial:!0,dodge:!0,predictTime:4,speedLimit:1,powerslide:!0}}},audio:{master:.6,mute:!1},ui:{showFps:!1}};function ca(s,t){if(t<=s[0][0])return s[0][1];for(let e=1;e<s.length;e++)if(t<=s[e][0]){let[n,i]=s[e-1],[r,a]=s[e];return i+(t-n)/(r-n)*(a-i)}return s[s.length-1][1]}var os=class{constructor(){this.pos=[],this.nor=[],this.uv=[],this.idx=[]}vert(t,e,n){return this.pos.push(t[0],t[1],t[2]),this.nor.push(e[0],e[1],e[2]),this.uv.push(n[0],n[1]),this.pos.length/3-1}tri(t,e,n){let i=this.pos,r=this.nor,a=i[t*3],o=i[t*3+1],l=i[t*3+2],c=[i[e*3]-a,i[e*3+1]-o,i[e*3+2]-l],h=[i[n*3]-a,i[n*3+1]-o,i[n*3+2]-l],u=c[1]*h[2]-c[2]*h[1],d=c[2]*h[0]-c[0]*h[2],p=c[0]*h[1]-c[1]*h[0];if(u*u+d*d+p*p<1e-14)return;u*(r[t*3]+r[e*3]+r[n*3])+d*(r[t*3+1]+r[e*3+1]+r[n*3+1])+p*(r[t*3+2]+r[e*3+2]+r[n*3+2])>=0?this.idx.push(t,e,n):this.idx.push(t,n,e)}quad(t,e,n,i){this.tri(t,e,n),this.tri(t,n,i)}finish(){return{positions:new Float32Array(this.pos),normals:new Float32Array(this.nor),uvs:new Float32Array(this.uv),indices:new Uint32Array(this.idx)}}},v0=[[0,-4240],[-1792,-4184],[1792,-4184],[-940,-3308],[940,-3308],[0,-2816],[-3584,-2484],[3584,-2484],[-1788,-2300],[1788,-2300],[-2048,-1036],[0,-1024],[2048,-1036],[-1024,0],[1024,0],[-2048,1036],[0,1024],[2048,1036],[-1788,2300],[1788,2300],[-3584,2484],[3584,2484],[0,2816],[-940,3308],[940,3308],[-1792,4184],[1792,4184],[0,4240]],M0=[[-3584,0],[3584,0],[-3072,4096],[3072,4096],[-3072,-4096],[3072,-4096]];function b0(){let s=[];for(let[t,e]of v0)s.push({x:zt(t),z:zt(e),large:!1});for(let[t,e]of M0)s.push({x:zt(t),z:zt(e),large:!0});return s}function S0(){return[{x:0,z:-4608,yaw:0},{x:-2048,z:-2560,yaw:0},{x:2048,z:-2560,yaw:0},{x:-256,z:-3840,yaw:0},{x:256,z:-3840,yaw:0}].map(s=>({x:zt(s.x),z:zt(s.z),yaw:s.yaw}))}function Lh(s=gt.arena){let t=s.halfWidth,e=s.halfLength,n=s.height,i=s.floorRampRadius,r=s.ceilingRampRadius,a=s.cornerRadius,o=s.goalHalfWidth,l=s.goalHeight,c=s.goalDepth,h=1e-4,u=s.arcSegments,d=[],p=(X,Q,tt,xt,P)=>d.push({x:X,z:Q,nx:tt,nz:xt,end:P}),g=(X,Q,tt,xt,P,st,H,K=[])=>{let G=Math.hypot(tt-X,xt-Q),yt=new Set([0]),ut=Math.max(1,Math.ceil(G/10));for(let T=1;T<ut;T++)yt.add(T/ut);for(let T of K)yt.add(T);[...yt].sort((T,S)=>T-S).forEach(T=>p(X+(tt-X)*T,Q+(xt-Q)*T,P,st,H))},y=(X,Q,tt,xt)=>{for(let P=0;P<=u;P++){let st=tt+(xt-tt)*P/u,H=Math.cos(st),K=Math.sin(st);p(X+H*a,Q+K*a,-H,-K,0)}},m=t-a,f=e-a,x=(o- -m)/(2*m),_=X=>(m-X)/(2*m);g(m,e,-m,e,0,-1,1,[_(o),_(-o)]),y(-m,f,Math.PI/2,Math.PI),g(-t,f,-t,-f,1,0,0),y(-m,-f,Math.PI,Math.PI*1.5),g(-m,-e,m,-e,0,1,-1,[_(-o),_(o)].map(X=>1-X)),y(m,-f,Math.PI*1.5,Math.PI*2),g(t,-f,t,f,-1,0,0),y(m,f,0,Math.PI/2);let M=[];for(let X of d){let Q=M[M.length-1];if(Q&&Math.abs(Q.x-X.x)<h&&Math.abs(Q.z-X.z)<h){X.end&&(Q.end=X.end,Q.nx=X.nx,Q.nz=X.nz);continue}M.push(X)}let E=M[0],w=M[M.length-1];Math.abs(E.x-w.x)<h&&Math.abs(E.z-w.z)<h&&M.pop();let A=0;M.forEach((X,Q)=>{Q>0&&(A+=Math.hypot(X.x-M[Q-1].x,X.z-M[Q-1].z)),X.s=A});let U=A+Math.hypot(M[0].x-M[M.length-1].x,M[0].z-M[M.length-1].z),v=[],b=(X,Q,tt,xt)=>v.push({d:X,y:Q,nd:tt,ny:xt});for(let X=0;X<=u;X++){let Q=Math.PI/2*(X/u);b(i*(1-Math.sin(Q)),i*(1-Math.cos(Q)),Math.sin(Q),Math.cos(Q))}b(0,l,1,0),b(0,n-r,1,0);for(let X=1;X<=u;X++){let Q=Math.PI/2*(X/u);b(r*(1-Math.cos(Q)),n-r+r*Math.sin(Q),Math.cos(Q),-Math.sin(Q))}let F=0;v.forEach((X,Q)=>{Q>0&&(F+=Math.hypot(X.d-v[Q-1].d,X.y-v[Q-1].y)),X.v=F});let k=new os,nt=new os,L=[new os,new os],N=M.map(X=>v.map(Q=>k.vert([X.x+X.nx*Q.d,Q.y,X.z+X.nz*Q.d],[X.nx*Q.nd,Q.ny,X.nz*Q.nd],[X.s/8,Q.v/8]))),V=M.length;for(let X=0;X<V;X++){let Q=(X+1)%V,tt=M[X],xt=M[Q],P=tt.end!==0&&tt.end===xt.end&&Math.abs(tt.x)<=o+h&&Math.abs(xt.x)<=o+h,st=Q===0;for(let H=0;H<v.length-1;H++){if(P&&Math.max(v[H].y,v[H+1].y)<=l+h)continue;let K=N[X][H],G=N[X][H+1],yt=N[Q][H],ut=N[Q][H+1];if(st){let T=(S,z,it)=>k.vert([S.x+S.nx*z.d,z.y,S.z+S.nz*z.d],[S.nx*z.nd,z.ny,S.nz*z.nd],[it,z.v/8]);yt=T(xt,v[H],U/8),ut=T(xt,v[H+1],U/8)}k.quad(K,yt,ut,G)}}let et=(X,Q,tt,xt,P)=>{let st=X.vert([0,Q,0],[0,tt,0],P(0,0)),H=M.map(K=>{let G=K.x+K.nx*xt,yt=K.z+K.nz*xt;return X.vert([G,Q,yt],[0,tt,0],P(G,yt))});for(let K=0;K<H.length;K++)X.tri(st,H[K],H[(K+1)%H.length])};et(nt,0,1,i,(X,Q)=>[(X+t)/(2*t),(Q+e)/(2*e)]),et(k,n,-1,r,(X,Q)=>[X/8+40,Q/8+40]);let Y=(X,Q,tt,xt)=>X.vert(Q,tt,xt),J=[...new Set(M.filter(X=>X.end!==0&&Math.abs(X.x)<=o+h).map(X=>+X.x.toFixed(4)))].sort((X,Q)=>X-Q);for(let X=0;X<2;X++){let Q=X===0?-1:1,tt=L[X],xt=Q*e,P=Q*(e+c),st=Q*(e-i);for(let K=0;K<J.length-1;K++){let G=J[K],yt=J[K+1],ut=[Y(tt,[G,0,st],[0,1,0],[0,0]),Y(tt,[yt,0,st],[0,1,0],[1,0]),Y(tt,[yt,0,P],[0,1,0],[1,1]),Y(tt,[G,0,P],[0,1,0],[0,1])];tt.quad(ut[0],ut[1],ut[2],ut[3]),ut=[Y(tt,[G,l,xt],[0,-1,0],[0,0]),Y(tt,[yt,l,xt],[0,-1,0],[1,0]),Y(tt,[yt,l,P],[0,-1,0],[1,1]),Y(tt,[G,l,P],[0,-1,0],[0,1])],tt.quad(ut[0],ut[1],ut[2],ut[3])}let H;H=[Y(tt,[-o,0,P],[0,0,-Q],[0,0]),Y(tt,[o,0,P],[0,0,-Q],[1,0]),Y(tt,[o,l,P],[0,0,-Q],[1,1]),Y(tt,[-o,l,P],[0,0,-Q],[0,1])],tt.quad(H[0],H[1],H[2],H[3]);for(let K of[-1,1]){let G=K*o;H=[Y(tt,[G,0,xt],[-K,0,0],[0,0]),Y(tt,[G,0,P],[-K,0,0],[1,0]),Y(tt,[G,l,P],[-K,0,0],[1,1]),Y(tt,[G,l,xt],[-K,0,0],[0,1])],tt.quad(H[0],H[1],H[2],H[3]);for(let yt=0;yt<u;yt++){let ut=v[yt],T=v[yt+1],S=Q*(e-ut.d),z=Q*(e-T.d),it=[Y(tt,[G,0,S],[-K,0,0],[0,0]),Y(tt,[G,ut.y,S],[-K,0,0],[0,1]),Y(tt,[G,T.y,z],[-K,0,0],[1,1]),Y(tt,[G,0,z],[-K,0,0],[1,0])];tt.quad(it[0],it[1],it[2],it[3])}}}let D={floor:nt.finish(),shell:k.finish(),goalBlue:L[0].finish(),goalOrange:L[1].finish()},j=(X,Q,tt)=>`${Math.round(X*1e4)},${Math.round(Q*1e4)},${Math.round(tt*1e4)}`,rt=new Map,O=[],$=[];for(let X of Object.values(D)){let Q=new Uint32Array(X.positions.length/3);for(let tt=0;tt<Q.length;tt++){let xt=X.positions[tt*3],P=X.positions[tt*3+1],st=X.positions[tt*3+2],H=j(xt,P,st),K=rt.get(H);K===void 0&&(K=O.length/3,O.push(xt,P,st),rt.set(H,K)),Q[tt]=K}for(let tt=0;tt<X.indices.length;tt+=3){let xt=Q[X.indices[tt]],P=Q[X.indices[tt+1]],st=Q[X.indices[tt+2]];xt!==P&&P!==st&&xt!==st&&$.push(xt,P,st)}}let ht={positions:new Float32Array(O),indices:new Uint32Array($)},ft=s.postRadius,dt=[];for(let X of[-1,1]){for(let Q of[-1,1])dt.push({kind:"post",x:Q*(o+ft),y:l/2,z:X*e,halfHeight:l/2+ft,radius:ft});dt.push({kind:"bar",x:0,y:l+ft,z:X*e,halfLength:o+2*ft,radius:ft})}return{groups:D,collider:ht,frame:dt,dims:{W:t,L:e,H:n,GW:o,Hg:l,Dg:c,Rf:i,Rc:r,Rk:a},boostPads:b0(),kickoff:S0()}}import ri from"./rapier.js";var Pe={ARENA:1,CAR:2,BALL:4},Ws=(s,t)=>(s<<16|t)>>>0,ha=class s{static async create(t){return await ri.init(),new s(t)}constructor(t){this.R=ri,this.world=new ri.World({x:0,y:-gt.sim.gravity,z:0}),this.world.timestep=1/gt.sim.hz,this.world.numSolverIterations=gt.sim.solverIterations,this.events=new ri.EventQueue(!0),this.rayArena=Ws(Pe.ARENA|Pe.CAR|Pe.BALL,Pe.ARENA),this.buildArena(t)}buildArena(t){let e=ri,n=gt.arena,i=this.world.createRigidBody(e.RigidBodyDesc.fixed()),r=e.ColliderDesc.trimesh(t.collider.positions,t.collider.indices).setFriction(n.friction).setRestitution(n.restitution).setFrictionCombineRule(e.CoefficientCombineRule.Multiply).setRestitutionCombineRule(e.CoefficientCombineRule.Multiply).setCollisionGroups(Ws(Pe.ARENA,Pe.CAR|Pe.BALL));this.arenaCollider=this.world.createCollider(r,i);for(let a of t.frame){let o;a.kind==="post"?o=e.ColliderDesc.cylinder(a.halfHeight,a.radius).setTranslation(a.x,a.y,a.z):o=e.ColliderDesc.cylinder(a.halfLength,a.radius).setTranslation(a.x,a.y,a.z).setRotation({x:0,y:0,z:Math.SQRT1_2,w:Math.SQRT1_2}),o.setFriction(n.friction).setRestitution(n.restitution).setFrictionCombineRule(e.CoefficientCombineRule.Multiply).setRestitutionCombineRule(e.CoefficientCombineRule.Multiply).setCollisionGroups(Ws(Pe.ARENA,Pe.CAR|Pe.BALL)),this.world.createCollider(o,i)}}createBall(t,e,n){let i=ri,r=gt.ball,a=this.world.createRigidBody(i.RigidBodyDesc.dynamic().setTranslation(t,e,n).setLinearDamping(r.linearDamping).setAngularDamping(r.angularDamping).setCcdEnabled(!0)),o=this.world.createCollider(i.ColliderDesc.ball(r.radius).setMass(r.mass).setRestitution(r.restitution).setFriction(r.friction).setFrictionCombineRule(i.CoefficientCombineRule.Multiply).setRestitutionCombineRule(i.CoefficientCombineRule.Multiply).setCollisionGroups(Ws(Pe.BALL,Pe.ARENA|Pe.CAR)),a);return{body:a,collider:o}}createChassis(t,e,n,i){let r=ri,a=gt.car,o={x:0,y:Math.sin(i/2),z:0,w:Math.cos(i/2)},l=this.world.createRigidBody(r.RigidBodyDesc.dynamic().setTranslation(t,e,n).setRotation(o).setLinearDamping(0).setAngularDamping(0).setCcdEnabled(!0).setAdditionalMassProperties(a.mass,{x:0,y:a.comOffsetY,z:0},this.carInertia(),{x:0,y:0,z:0,w:1})),c=this.world.createCollider(r.ColliderDesc.cuboid(a.halfWidth,a.halfHeight,a.halfLength).setDensity(0).setFriction(a.colliderFriction).setRestitution(a.colliderRestitution).setFrictionCombineRule(r.CoefficientCombineRule.Multiply).setRestitutionCombineRule(r.CoefficientCombineRule.Min).setCollisionGroups(Ws(Pe.CAR,Pe.ARENA|Pe.BALL|Pe.CAR)).setActiveEvents(r.ActiveEvents.COLLISION_EVENTS),l);return l.recomputeMassPropertiesFromColliders(),{body:l,collider:c}}carInertia(){let t=gt.car,e=t.mass,n=t.halfWidth*2,i=t.halfHeight*2*1.6,r=t.halfLength*2;return{x:e/12*(i*i+r*r),y:e/12*(n*n+r*r),z:e/12*(n*n+i*i)}}step(){this.world.step(this.events)}rayArenaCast(t,e,n,i,r,a,o){let l=new ri.Ray({x:t,y:e,z:n},{x:i,y:r,z:a}),c=this.world.castRayAndGetNormal(l,o,!0,void 0,this.rayArena);return c?{toi:c.toi,nx:c.normal.x,ny:c.normal.y,nz:c.normal.z}:null}touchesArena(t){let e=!1;return this.world.contactPair(t,this.arenaCollider,n=>{n.numSolverContacts()>0&&(e=!0)}),e}};var ct=gt.car,Ih=gt.sim.gravity,E0=new C(0,1,0),Ye=(s,t,e)=>Math.max(t,Math.min(e,s)),ls=s=>s>0?1:s<0?-1:0,Dh=new $t,cs=new $t,Fn=new C,pl=new C,rn=new C,hs=new C,On=new C;function _n(){return{throttle:0,steer:0,pitch:0,roll:0,jump:!1,boost:!1,handbrake:!1,airRoll:!1}}var us=class{constructor(t,e){this.P=t,this.team=e.team,this.index=e.index||0,this.isHuman=!!e.isHuman,this.name=e.name||(this.isHuman?"You":"Bot");let n=t.createChassis(0,5,0,0);this.body=n.body,this.collider=n.collider,this.inertia=t.carInertia();let i=Ih+ct.stickyAccel;this.spring=ct.mass*i/4/ct.springEquilibrium,this.damper=2*ct.springDampingRatio*Math.sqrt(this.spring*ct.mass/4),this.restLen=ct.restHeight+ct.wheelAttachY+ct.springEquilibrium,this.rayLen=this.restLen+ct.suspensionDroop,this.wheels=[{x:-ct.wheelX,z:ct.wheelZFront,front:!0},{x:ct.wheelX,z:ct.wheelZFront,front:!0},{x:-ct.wheelX,z:ct.wheelZRear,front:!1},{x:ct.wheelX,z:ct.wheelZRear,front:!1}].map(r=>({...r,contact:!1,compression:0,spin:0,slip:0,steer:0,px:0,py:0,pz:0,nx:0,ny:1,nz:0,load:0})),this.ctrl=_n(),this.prevJump=!1,this.boost=ct.boostStart,this.unlimitedBoost=!1,this.demolished=!1,this.respawnTimer=0,this.spawn={x:0,y:ct.restHeight,z:0,yaw:0},this.resetState(),this.prevT=new C,this.currT=new C,this.prevQ=new $t,this.currQ=new $t,this.vel=new C,this.angVel=new C,this.prevVel=new C,this.speed=0,this.prevSpeed=0,this.forwardSpeed=0,this.up=new C(0,1,0),this.fwd=new C(0,0,-1),this.right=new C(1,0,0),this.surfaceNormal=new C(0,1,0),this.readState(),this.prevT.copy(this.currT),this.prevQ.copy(this.currQ)}resetState(){this.contacts=0,this.onGround=!1,this.bodyTouch=!1,this.airTime=0,this.hasJumped=!1,this.jumpTime=99,this.jumpHolding=!1,this.holdTime=0,this.hasDodged=!1,this.dodgeTime=99,this.flipActive=!1,this.dodgeAxis=new C,this.flipAngle=0,this.flipTarget=0,this.flipTotal=Math.PI*2,this.dodgeF=0,this.dodgeS=0,this.grip=1,this.boosting=!1,this.supersonic=!1,this.slipAmount=0,this.landedEvent=0,this.lastJumpEvent=0,this.dodgeEvent=0,this.boostSpent=0,this.prevJump=!1,this.handbrakeAmount=0}place(t){this.spawn=t;let e=this.body;e.setEnabled(!0),e.setTranslation({x:t.x,y:t.y??ct.restHeight,z:t.z},!0),e.setRotation({x:0,y:Math.sin(t.yaw/2),z:0,w:Math.cos(t.yaw/2)},!0),e.setLinvel({x:0,y:0,z:0},!0),e.setAngvel({x:0,y:0,z:0},!0),e.resetForces(!0),e.resetTorques(!0),this.resetState(),this.demolished=!1,this.readState(),this.prevT.copy(this.currT),this.prevQ.copy(this.currQ)}setControls(t){this.ctrl=t}readState(){let t=this.body,e=t.translation(),n=t.rotation(),i=t.linvel(),r=t.angvel();this.currT.set(e.x,e.y,e.z),this.currQ.set(n.x,n.y,n.z,n.w),this.vel.set(i.x,i.y,i.z),this.angVel.set(r.x,r.y,r.z),this.up.set(0,1,0).applyQuaternion(this.currQ),this.fwd.set(0,0,-1).applyQuaternion(this.currQ),this.right.set(1,0,0).applyQuaternion(this.currQ),this.speed=this.vel.length(),this.forwardSpeed=this.vel.dot(this.fwd),this.supersonic=me(this.speed)>=me(ct.supersonic)}snapshot(){this.prevT.copy(this.currT),this.prevQ.copy(this.currQ)}addBoost(t){this.boost=Math.min(ct.boostMax,this.boost+t)}preStep(t){if(this.demolished)return;this.readState();let e=this.body,n=ct.mass,i=this.ctrl;this.prevSpeed=this.speed,this.prevVel.copy(this.vel);let r=this.currQ;cs.copy(r).invert();let a=e.worldCom(),o=a.x,l=a.y,c=a.z,h=this.up,u=this.fwd,d=0;this.surfaceNormal.set(0,0,0);for(let D of this.wheels){rn.set(D.x,ct.wheelAttachY,D.z).applyQuaternion(r);let j=this.currT.x+rn.x,rt=this.currT.y+rn.y,O=this.currT.z+rn.z;D.ax=j,D.ay=rt,D.az=O;let $=this.P.rayArenaCast(j,rt,O,-h.x,-h.y,-h.z,this.rayLen);if($){D.contact=!0,D.dist=$.toi,D.px=j-h.x*$.toi,D.py=rt-h.y*$.toi,D.pz=O-h.z*$.toi;let ht=$.nx,ft=$.ny,dt=$.nz;ht*h.x+ft*h.y+dt*h.z<0&&(ht=-ht,ft=-ft,dt=-dt),D.nx=ht,D.ny=ft,D.nz=dt,this.surfaceNormal.x+=ht,this.surfaceNormal.y+=ft,this.surfaceNormal.z+=dt,d++}else D.contact=!1,D.dist=this.rayLen;D.compression=Ye(1-(D.dist-0)/this.rayLen,0,1)}this.contacts=d;let p=this.jumpTime<.12;d>0?this.surfaceNormal.normalize():this.surfaceNormal.copy(h);let g=this.surfaceNormal;this.bodyTouch=d===0&&this.P.touchesArena(this.collider),this.landedEvent=0,(d>0||this.bodyTouch)&&!p&&!(this.hasDodged&&this.dodgeTime<.25)?((this.airTime>.15||this.hasJumped||this.hasDodged)&&(this.landedEvent=Math.min(1,this.airTime/.6)),this.airTime=0,this.hasJumped=!1,this.hasDodged=!1,d>0&&(this.flipActive=!1)):d===0&&!this.bodyTouch&&(this.airTime+=t),this.onGround=d>0,this.jumpTime+=t,this.hasDodged&&(this.dodgeTime+=t);let y=i.jump&&!this.prevJump;this.prevJump=i.jump,this.lastJumpEvent=0,this.dodgeEvent=0;let m=Ye(i.pitch,-1,1),f=Ye(i.steer,-1,1);if(y)if(d>0&&!this.hasJumped&&!this.demolished){let D=h;this.applyLinear(D.x*ct.jumpImpulse,D.y*ct.jumpImpulse,D.z*ct.jumpImpulse),this.hasJumped=!0,this.jumpTime=0,this.jumpHolding=!0,this.holdTime=0,this.lastJumpEvent=1,this.airTime=0}else!this.hasDodged&&d===0&&(this.hasJumped&&this.jumpTime<=ct.dodgeWindow||!this.hasJumped&&this.airTime<=ct.fallOffJumpWindow||this.bodyTouch&&!this.hasJumped)&&this.doDodge(m,f);this.jumpHolding&&(this.holdTime+=t,!i.jump||this.holdTime>ct.jumpHoldTime||this.hasDodged?this.jumpHolding=!1:this.applyLinear(h.x*ct.jumpHoldAccel*t,h.y*ct.jumpHoldAccel*t,h.z*ct.jumpHoldAccel*t));let x=this.spring,_=this.damper,M=!p||this.jumpTime>.04;for(let D of this.wheels){if(D.load=0,!D.contact||!M)continue;let j=this.restLen-D.dist;if(j<=0)continue;rn.set(D.ax-o,D.ay-l,D.az-c),hs.copy(this.angVel).cross(rn).add(this.vel);let rt=hs.x*D.nx+hs.y*D.ny+hs.z*D.nz,O=x*j-_*rt;j>ct.bumpStopStart&&(O+=x*ct.bumpStopStiffness*(j-ct.bumpStopStart)),O<0&&(O=0),D.load=O,e.applyImpulseAtPoint({x:D.nx*O*t,y:D.ny*O*t,z:D.nz*O*t},{x:D.ax,y:D.ay,z:D.az},!0)}let E=d>0&&this.jumpTime>.2?ct.stickyAccel*n*(d/4)*t:0;E&&this.applyLinear(-g.x*E/n,-g.y*E/n,-g.z*E/n);let w=On.copy(u).addScaledVector(g,-u.dot(g));w.lengthSq()<1e-6?w.copy(u):w.normalize();let A=this.vel.dot(w),U=me(Math.abs(A)),v=d>=3?1:d/3,b=Ye(i.throttle,-1,1);if(d>0&&!p){let D=0;if(Math.abs(b)<.02)Math.abs(A)>.001&&(D=-ls(A)*Math.min(ct.coastAccel,Math.abs(A)/t));else if(ls(b)===ls(A)||Math.abs(A)<.05){let j=Math.max(0,1-U/me(ct.maxDriveSpeed));D=b*ct.throttleAccel0*j}else D=b*Math.min(ct.brakeAccel,Math.abs(A)/t/Math.max(Math.abs(b),.01)*1),D=ls(b)*Math.min(ct.brakeAccel*Math.abs(b),Math.abs(A)/t+ct.throttleAccel0*0);D*=v,D!==0&&this.applyLinear(w.x*D*t,w.y*D*t,w.z*D*t)}let F=i.handbrake&&d>0,k=F?ct.powerslideGrip:1,nt=F?1/.04:1/ct.gripRecoveryTime;this.grip+=Ye(k-this.grip,-nt*t,nt*t);let N=ca(ct.steerAngles,U)*Math.PI/180*Ye(i.steer,-1,1),V=0,et=0;if(d>0&&!p)for(let D of this.wheels){if(!D.contact)continue;let j=rn.set(D.nx,D.ny,D.nz),rt=hs.copy(u).addScaledVector(j,-u.dot(j));if(rt.lengthSq()<1e-6)continue;rt.normalize(),D.front&&(Dh.setFromAxisAngle(j,-N),rt.applyQuaternion(Dh)),D.steer=D.front?N:0;let O=pl.copy(rt).cross(j).normalize(),$=D.px-o,ht=D.py-l,ft=D.pz-c;Fn.copy(this.angVel).cross(On.set($,ht,ft)).add(this.vel);let dt=Fn.dot(O),X=Fn.dot(rt);D.spin+=X/ct.wheelRadius*t,D.slip=dt,V+=Math.abs(dt),et++;let tt=((o-D.px)*D.nx+(l-D.py)*D.ny+(c-D.pz)*D.nz)*(1-ct.rollInfluence),xt=D.px+D.nx*tt,P=D.py+D.ny*tt,st=D.pz+D.nz*tt;On.set(xt-o,P-l,st-c).cross(O).applyQuaternion(cs);let H=On.x*On.x/this.inertia.x+On.y*On.y/this.inertia.y+On.z*On.z/this.inertia.z,K=1/(1/n+H),G=-dt*K*ct.lateralGrip*.32*this.grip,yt=D.load+E/t/4||n*Ih/4,ut=ct.frictionCoeff*yt*t*Math.max(this.grip,.02);G=Ye(G,-ut,ut),e.applyImpulseAtPoint({x:O.x*G,y:O.y*G,z:O.z*G},{x:xt,y:P,z:st},!0)}else for(let D of this.wheels)D.spin+=this.forwardSpeed/ct.wheelRadius*t*.98,D.steer=0,D.slip=0;if(this.slipAmount=et?V/et:0,F&&Math.abs(i.steer)>.05&&!p){let D=Ye(Math.abs(A)/4,0,1),j=-Ye(i.steer,-1,1)*ct.powerslideYawRate*D*(A>=0?1:-1),rt=this.angVel.dot(g),O=Ye(j-rt,-ct.powerslideYawAccel*t,ct.powerslideYawAccel*t),$=this.inertia.y;e.applyTorqueImpulse({x:g.x*$*O,y:g.y*$*O,z:g.z*$*O},!0)}if(this.boosting=!1,i.boost&&(this.boost>0||this.unlimitedBoost)&&!this.demolished){this.boosting=!0;let D=d>0?ct.boostAccelGround:ct.boostAccelAir;Fn.copy(this.vel).addScaledVector(u,D*t);let j=ct.maxSpeed,rt=Fn.length();rt>j&&rt>this.speed&&Fn.multiplyScalar(Math.max(j,this.speed)/rt),this.applyLinear(Fn.x-this.vel.x,Fn.y-this.vel.y,Fn.z-this.vel.z),this.unlimitedBoost||(this.boost=Math.max(0,this.boost-ct.boostPerSecond*t),this.boostSpent+=ct.boostPerSecond*t)}if(d<=2&&!(d>0&&!this.hasJumped&&d>=2&&!1)){if(Math.abs(b)>.02&&d===0){let D=ct.airThrottleAccel*b*t;this.applyLinear(u.x*D,u.y*D,u.z*D)}this.airControl(t,m,f)}else this.clampAngular(t);this.vel.copy(e.linvel());let J=this.vel.length();if(J>ct.maxSpeed){let D=ct.maxSpeed/J-1;this.applyLinear(this.vel.x*D,this.vel.y*D,this.vel.z*D)}}applyLinear(t,e,n){let i=ct.mass;this.body.applyImpulse({x:t*i,y:e*i,z:n*i},!0)}applyAngularDeltaLocal(t,e,n){rn.set(this.inertia.x*t,this.inertia.y*e,this.inertia.z*n).applyQuaternion(this.currQ),this.body.applyTorqueImpulse({x:rn.x,y:rn.y,z:rn.z},!0)}clampAngular(t){cs.copy(this.currQ).invert();let e=pl.copy(this.body.angvel()).applyQuaternion(cs),n=e.length();if(n>ct.maxAngularSpeed){let i=ct.maxAngularSpeed/n-1;this.applyAngularDeltaLocal(e.x*i,e.y*i,e.z*i)}}airControl(t,e,n){let i=this.ctrl;cs.copy(this.currQ).invert();let r=pl.copy(this.body.angvel()).applyQuaternion(cs),a=e,o=n,l=Ye(i.roll,-1,1);i.airRoll&&(l=Ye(l+n,-1,1),o=0);let c=0,h=0,u=0,d=ct.maxAngularSpeed;if(this.flipActive&&this.dodgeF!==0&&e*this.dodgeF<-ct.flipCancelThreshold&&this.dodgeTime>.05){let f=this.dodgeAxis,x=r.x*f.x+r.z*f.z;c-=f.x*x*.85,u-=f.z*x*.85,this.flipActive=!1}if(this.flipActive){let f=ct.flipTime,x=this.dodgeAxis,_=this.dodgeTime/f,M=r.x*x.x+r.z*x.z;if(this.flipAngle+=M*t,_>=1||this.flipAngle>=this.flipTotal-.02){c-=x.x*M,u-=x.z*M;let E=r.x-x.x*M,w=r.z-x.z*M;c-=E*.6,u-=w*.6,this.flipActive=!1}else{let E=this.flipTotal/(f*(1-ct.flipRampIn/2-ct.flipRampOut/2)),w=Math.min(1,_/ct.flipRampIn)*Math.min(1,(1-_)/ct.flipRampOut);this.flipTarget+=E*w*t;let A=Math.max(0,E*w+ct.flipAngleGain*(this.flipTarget-this.flipAngle));c+=x.x*(A-M),u+=x.z*(A-M);let U=r.x-x.x*M,v=r.z-x.z*M,b=1-Math.exp(-ct.flipOffAxisDamp*t);if(c-=U*b,u-=v*b,this.dodgeTime<ct.flipVerticalDampTime){let N=this.body.linvel().y;this.applyLinear(0,-N*ct.flipVerticalDamp*(t/ct.flipVerticalDampTime),0)}a=0,l=0,d=ct.flipMaxAngularSpeed,h+=(-o*ct.airYawAccel-ct.airYawDamp*r.y*(1-Math.abs(o)))*t;let F=r.x+c,k=r.y+h,nt=r.z+u,L=Math.hypot(F,k,nt);if(L>d){let N=d/L;c=F*N-r.x,h=k*N-r.y,u=nt*N-r.z}this.applyAngularDeltaLocal(c,h,u);return}}c+=(-a*ct.airPitchAccel-ct.airPitchDamp*r.x*(1-Math.abs(a)))*t,h+=(-o*ct.airYawAccel-ct.airYawDamp*r.y*(1-Math.abs(o)))*t,u+=(-l*ct.airRollAccel-ct.airRollDamp*r.z*(1-Math.abs(l)))*t;let p=r.x+c,g=r.y+h,y=r.z+u,m=Math.hypot(p,g,y);if(m>d){let f=d/m;c=p*f-r.x,h=g*f-r.y,u=y*f-r.z}this.applyAngularDeltaLocal(c,h,u)}doDodge(t,e){let n=Math.hypot(t,e);this.hasDodged=!0,this.dodgeTime=0,this.jumpHolding=!1,this.dodgeEvent=1;let i=this.up;if(n<(this.dodgeDeadzone??ct.dodgeDeadzone)){i.y<-.2&&this.bodyTouch?(this.applyLinear(0,ct.jumpImpulse,0),this.startFlip(0,0,-1,Math.PI),this.dodgeF=0,this.dodgeS=1):this.applyLinear(i.x*ct.jumpImpulse,i.y*ct.jumpImpulse,i.z*ct.jumpImpulse);return}let r=t/n,a=e/n;i.y<-.2&&this.bodyTouch&&this.applyLinear(0,ct.jumpImpulse,0),this.dodgeF=r,this.dodgeS=a;let o=rn.copy(this.fwd).setY(0);o.lengthSq()<.04&&o.copy(this.up).multiplyScalar(-1).setY(0),o.lengthSq()<1e-6&&o.set(0,0,-1),o.normalize();let l=hs.copy(o).cross(E0).normalize(),c=this.vel.dot(this.fwd),h=Ye(this.speed/ct.maxSpeed,0,1),u=r!==0&&ls(r)===ls(c)&&Math.abs(c)>1?1+ct.dodgeSpeedBonus*h:1,d=r*ct.dodgeImpulse*u,p=a*ct.dodgeImpulse;this.applyLinear(o.x*d+l.x*p,o.y*d+l.y*p,o.z*d+l.z*p);let g=i.y<-.2&&this.bodyTouch;this.startFlip(-r,0,-a,g?Math.PI:Math.PI*2)}startFlip(t,e,n,i){this.dodgeAxis.set(t,e,n).normalize(),this.flipActive=!0,this.flipAngle=0,this.flipTarget=0,this.flipTotal=i}demolish(){this.demolished=!0,this.respawnTimer=ct.demoRespawn,this.body.setLinvel({x:0,y:0,z:0},!0),this.body.setAngvel({x:0,y:0,z:0},!0),this.body.setEnabled(!1)}postStep(){this.readState()}};var ml="rl3d.settings.v1",zn=(s,t,e)=>Math.max(t,Math.min(e,s)),ua=class{constructor(t){this.keys=new Set,this.bindings=JSON.parse(JSON.stringify(gt.input.bindings)),this.settings={stickDeadzone:gt.input.stickDeadzone,triggerDeadzone:gt.input.triggerDeadzone,steerSensitivity:gt.input.steerSensitivity,dodgeDeadzone:gt.input.dodgeDeadzone,mouseSensitivity:gt.input.mouseSensitivity,ballCamDefault:!0},this.ballCam=!0,this.look={x:0,y:0},this.mouseLook={x:0,y:0},this.pointerLocked=!1,this.edges={ballCam:!1,pause:!1,reset:!1,any:!1},this.prevEdge={ballCam:!1,pause:!1,reset:!1,padPause:!1,padBall:!1},this.capturing=null,this.enabled=!0,this.pad=null,this.padActive=!1,this.target=t,this.load(),this.bind()}load(){try{let t=JSON.parse(localStorage.getItem(ml)||"null");if(t){if(t.bindings)for(let e of Object.keys(this.bindings))Array.isArray(t.bindings[e])&&(this.bindings[e]=t.bindings[e]);t.input&&Object.assign(this.settings,t.input)}}catch{}this.ballCam=this.settings.ballCamDefault!==!1}bind(){let t=e=>e.target&&/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName);window.addEventListener("keydown",e=>{if(this.capturing){if(e.preventDefault(),e.code!=="Escape"){let n=this.capturing;this.capturing=null,n(e.code)}else{let n=this.capturing;this.capturing=null,n(null)}return}t(e)||(this.isBound(e.code)&&e.preventDefault(),!e.repeat&&(this.keys.add(e.code),this.edges.any=!0,this.bindings.jump.includes(e.code)&&(this.jumpLatch=!0)))}),window.addEventListener("keyup",e=>{this.keys.delete(e.code)}),window.addEventListener("blur",()=>{this.keys.clear(),this.mouseLook.x=this.mouseLook.y=0}),document.addEventListener("visibilitychange",()=>{document.hidden&&this.keys.clear()}),window.addEventListener("contextmenu",e=>{this.enabled&&e.preventDefault()}),document.addEventListener("pointerlockchange",()=>{this.pointerLocked=document.pointerLockElement===this.target}),window.addEventListener("mousemove",e=>{if(!this.pointerLocked)return;let n=this.settings.mouseSensitivity;this.mouseLook.x=zn(this.mouseLook.x+e.movementX*n,-1.2,1.2),this.mouseLook.y=zn(this.mouseLook.y+e.movementY*n,-1.2,1.2)})}isBound(t){return Object.values(this.bindings).some(e=>e.includes(t))}down(t){return this.bindings[t].some(e=>this.keys.has(e))}save(){try{localStorage.setItem(ml,JSON.stringify({bindings:this.bindings,input:this.settings,ui:this.uiSettings||{}}))}catch{}}loadUi(){try{return(JSON.parse(localStorage.getItem(ml)||"null")||{}).ui||{}}catch{return{}}}rebind(t,e){this.bindings[t]=[e],this.save()}resetBindings(){this.bindings=JSON.parse(JSON.stringify(gt.input.bindings)),this.save()}captureNext(t){this.capturing=t,this.keys.clear()}requestPointerLock(){if(this.enabled&&this.target.requestPointerLock&&!this.pointerLocked)try{let t=this.target.requestPointerLock();t&&t.catch&&t.catch(()=>{})}catch{}}releasePointerLock(){document.pointerLockElement&&document.exitPointerLock()}radial(t,e,n){let i=Math.hypot(t,e);if(i<n)return[0,0];let r=(i-n)/(1-n)/i;return[zn(t*r,-1,1),zn(e*r,-1,1)]}pollPad(){let t=navigator.getGamepads?navigator.getGamepads():[];this.pad=null;for(let e of t)if(e&&e.connected){this.pad=e;break}}get(t){let e=_n(),n=this.settings;this.pollPad();let i=(this.down("throttle")?1:0)-(this.down("brake")?1:0),r=(this.down("right")?1:0)-(this.down("left")?1:0);e.throttle=i,e.pitch=i,e.steer=r,e.roll=(this.down("rollRight")?1:0)-(this.down("rollLeft")?1:0),e.jump=this.down("jump")||this.jumpLatch,this.jumpLatch=!1,e.boost=this.down("boost");let a=this.down("powerslide");e.handbrake=a,e.airRoll=a;let o=(this.down("lookRight")?1:0)-(this.down("lookLeft")?1:0),l=(this.down("lookDown")?1:0)-(this.down("lookUp")?1:0),c=!1,h=!1;if(this.pad){let g=this.pad,y=v=>g.buttons[v]?g.buttons[v].value:0,m=v=>!!(g.buttons[v]&&g.buttons[v].pressed),[f,x]=this.radial(g.axes[0]||0,g.axes[1]||0,n.stickDeadzone),[_,M]=this.radial(g.axes[2]||0,g.axes[3]||0,n.stickDeadzone),E=n.triggerDeadzone,w=y(7)>E?y(7):0,A=y(6)>E?y(6):0;(Math.abs(f)+Math.abs(x)+w+A+Math.abs(_)+Math.abs(M)>0||m(0)||m(1)||m(2)||m(4)||m(5))&&(this.padActive=!0,(w||A)&&(e.throttle=w-A),(x!==0||i===0)&&(e.pitch=i!==0?e.pitch:-x),f!==0&&(e.steer=zn(f*n.steerSensitivity,-1,1)),m(0)&&(e.jump=!0),m(1)&&(e.boost=!0),m(2)&&(e.handbrake=!0,e.airRoll=!0),m(4)&&(e.roll-=1),m(5)&&(e.roll+=1),Math.abs(_)>0&&(o=_),Math.abs(M)>0&&(l=M)),c=m(3),h=m(9)}e.steer=zn(e.steer*(e.steer===r&&r!==0,1),-1,1),e.roll=zn(e.roll,-1,1),this.mouseLook.x*=Math.exp(-t*3.2),this.mouseLook.y*=Math.exp(-t*3.2),this.look.x=zn(o+this.mouseLook.x,-1,1),this.look.y=zn(l+this.mouseLook.y,-1,1);let u=this.down("ballCam")||c,d=this.down("pause")||h,p=this.down("reset");return this.edges.ballCam=u&&!this.prevEdge.ballCam,this.edges.pause=d&&!this.prevEdge.pause,this.edges.reset=p&&!this.prevEdge.reset,this.prevEdge.ballCam=u,this.prevEdge.pause=d,this.prevEdge.reset=p,this.edges.ballCam&&(this.ballCam=!this.ballCam),e}neutral(){return _n()}};function Uh(s){return s?s.replace(/^Key/,"").replace(/^Digit/,"").replace("Arrow","").replace("Left",s.startsWith("Arrow")?"\u2190":" L").replace("Right",s.startsWith("Arrow")?"\u2192":" R").replace("Up","\u2191").replace("Down","\u2193").replace("Control","Ctrl").replace("Space","Space"):"\u2014"}var an=gt.ball,Bn=gt.car,W0=new $t,da=new $t,X0=new C,xn=new C,Ei=new C,Nh=new C,ds=new C,fa=new C,ai=new C,pa=new C,gl=(s,t,e)=>Math.max(t,Math.min(e,s)),ma=class s{constructor(t){this.P=t;let e=t.createBall(0,an.radius+.01,0);this.body=e.body,this.collider=e.collider,this.radius=an.radius,this.pos=new C,this.vel=new C,this.angVel=new C,this.quat=new $t,this.prevPos=new C,this.prevQuat=new $t,this.pending=[],this.hitEvents=[],this.lastHitCar=null,this.lastTouchTeam=-1,this.cool=new Map,this.readState(),this.prevPos.copy(this.pos),this.prevQuat.copy(this.quat)}reset(t,e,n,i=0,r=0,a=0){let o=this.body;o.setTranslation({x:t,y:e,z:n},!0),o.setRotation({x:0,y:0,z:0,w:1},!0),o.setLinvel({x:i,y:r,z:a},!0),o.setAngvel({x:0,y:0,z:0},!0),o.resetForces(!0),o.resetTorques(!0),this.lastHitCar=null,this.lastTouchTeam=-1,this.pending.length=0,this.cool.clear(),this.readState(),this.prevPos.copy(this.pos),this.prevQuat.copy(this.quat)}readState(){let t=this.body.translation(),e=this.body.rotation(),n=this.body.linvel(),i=this.body.angvel();this.pos.set(t.x,t.y,t.z),this.quat.set(e.x,e.y,e.z,e.w),this.vel.set(n.x,n.y,n.z),this.angVel.set(i.x,i.y,i.z)}snapshot(){this.prevPos.copy(this.pos),this.prevQuat.copy(this.quat)}static closest(t,e,n,i){da.copy(t.currQ).invert(),i.copy(e).sub(t.currT).applyQuaternion(da),n.set(gl(i.x,-Bn.halfWidth,Bn.halfWidth),gl(i.y,-Bn.halfHeight,Bn.halfHeight),gl(i.z,-Bn.halfLength,Bn.halfLength));let r=Math.abs(i.x)<Bn.halfWidth&&Math.abs(i.y)<Bn.halfHeight&&Math.abs(i.z)<Bn.halfLength;Nh.copy(i).sub(n);let a=Nh.length();return r&&(a=0),n.applyQuaternion(t.currQ).add(t.currT),a}beginStep(t,e){this.readState();for(let n of t){if(n.demolished)continue;let i=s.closest(n,this.pos,Ei,xn);pa.copy(Ei).sub(n.currT),fa.copy(n.angVel).cross(pa).add(n.vel),ds.copy(this.vel).sub(fa),ai.copy(this.pos).sub(Ei);let r=ai.length();if(r<1e-6)continue;ai.multiplyScalar(1/r);let a=-ds.dot(ai),o=i-this.radius;if(a>.3&&o<a*e*2.5+.03){let l=this.pending.find(c=>c.car===n);l?a>l.closing&&(l.closing=a,l.relSpeed=ds.length()):this.pending.push({car:n,relSpeed:ds.length(),closing:a,age:0})}}}endStep(t,e,n){this.readState(),this.hitEvents.length=0;for(let l=this.pending.length-1;l>=0;l--){let c=this.pending[l],h=c.car;if(c.age++,h.demolished||c.age>4){this.pending.splice(l,1);continue}h.readState();let u=s.closest(h,this.pos,Ei,xn);pa.copy(Ei).sub(h.currT),fa.copy(h.angVel).cross(pa).add(h.vel),ds.copy(this.vel).sub(fa),ai.copy(this.pos).sub(Ei);let d=ai.length();if(d<1e-6)continue;ai.multiplyScalar(1/d);let p=-ds.dot(ai);if(!(u-this.radius<.08&&p<Math.max(.35*c.closing,.5)))continue;this.pending.splice(l,1);let y=this.cool.get(h)??-1;if(n-y<an.hitCooldown||(xn.copy(this.pos).sub(h.currT),da.copy(h.currQ).invert(),xn.applyQuaternion(da),xn.y*=an.hitVerticalScale,xn.lengthSq()<1e-8))continue;xn.normalize().applyQuaternion(h.currQ);let m=c.relSpeed,f=m*ca(an.hitCurve,me(m));this.body.applyImpulse({x:xn.x*f*an.mass,y:xn.y*f*an.mass,z:xn.z*f*an.mass},!0),this.cool.set(h,n),this.lastHitCar=h,this.lastTouchTeam=h.team,this.hitEvents.push({car:h,power:m,point:Ei.clone(),normal:xn.clone()})}let i=this.body.linvel(),r=Math.hypot(i.x,i.y,i.z);if(r>an.maxSpeed){let l=an.maxSpeed/r;this.body.setLinvel({x:i.x*l,y:i.y*l,z:i.z*l},!0)}let a=this.body.angvel(),o=Math.hypot(a.x,a.y,a.z);if(o>an.maxAngularSpeed){let l=an.maxAngularSpeed/o;this.body.setAngvel({x:a.x*l,y:a.y*l,z:a.z*l},!0)}this.readState()}};var ga=class{constructor(t){let e=gt.boost;this.pads=t.map((n,i)=>({id:i,x:n.x,z:n.z,large:n.large,radius:n.large?e.largeRadius:e.smallRadius,amount:n.large?e.largeAmount:e.smallAmount,respawn:n.large?e.largeRespawn:e.smallRespawn,active:!0,timer:0,pickedAt:-99})),this.events=[]}reset(){for(let t of this.pads)t.active=!0,t.timer=0;this.events.length=0}update(t,e,n){this.events.length=0;for(let i of this.pads){if(!i.active){i.timer-=t,i.timer<=0&&(i.active=!0,this.events.push({pad:i,car:null,respawned:!0}));continue}for(let r of e){if(r.demolished||r.boost>=gt.car.boostMax)continue;let a=r.currT;if(a.y>gt.boost.pickupHeight)continue;let o=a.x-i.x,l=a.z-i.z;if(o*o+l*l<i.radius*i.radius){i.large?r.boost=gt.car.boostMax:r.addBoost(i.amount),i.active=!1,i.timer=i.respawn,i.pickedAt=n,this.events.push({pad:i,car:r,respawned:!1});break}}}}};var _l=gt.car,Ze=gt.arena,wi=gt.ball.radius,Mn=(s,t,e)=>Math.max(t,Math.min(e,s)),w0=s=>{for(;s>Math.PI;)s-=2*Math.PI;for(;s<-Math.PI;)s+=2*Math.PI;return s},K0=new $t,bn=new $t,Ae=new C,on=new C;function T0(s,t,e=1/30){let n=[],i=s.pos.x,r=s.pos.y,a=s.pos.z,o=s.vel.x,l=s.vel.y,c=s.vel.z,h=gt.sim.gravity,u=.6,d=Ze.halfWidth-wi,p=Ze.halfLength-wi,g=Ze.height-wi;for(let y=0;y<t;y+=e){l-=h*e,i+=o*e,r+=l*e,a+=c*e,r<wi&&(r=wi,l<0&&(l=-l*u,Math.abs(l)<1.5&&(l=0)),o*=.995,c*=.995),r>g&&(r=g,l>0&&(l=-l*u)),i>d?(i=d,o>0&&(o=-o*u)):i<-d&&(i=-d,o<0&&(o=-o*u));let f=Math.abs(i)<Ze.goalHalfWidth-wi*.3&&r<Ze.goalHeight-wi*.5?p+Ze.goalDepth:p;a>f?(a=f,c>0&&(c=-c*u)):a<-f&&(a=-f,c<0&&(c=-c*u)),n.push({t:y+e,x:i,y:r,z:a,vx:o,vy:l,vz:c})}return n}var _a=class{constructor(t,e="pro"){this.car=t,this.setDifficulty(e),this.ctrl=_n(),this.timer=0,this.plan=null,this.pred=[],this.predTimer=0,this.seq=null,this.noise=0,this.noiseT=0,this.mode="kickoff",this.target=new C,this.wantBoost=!1,this.stuckT=0,this.reactT=0,this.padTarget=null}setDifficulty(t){this.diff=gt.ai.difficulties[t]||gt.ai.difficulties.pro,this.diffName=t}update(t,e){let n=this.car,i=e.ball,r=this.ctrl;r.throttle=0,r.steer=0,r.pitch=0,r.roll=0,r.boost=!1,r.handbrake=!1,r.airRoll=!1;let a=r.jump;if(r.jump=!1,n.demolished||!e.active)return this.seq=null,r;this.timer+=t,this.predTimer-=t,this.noiseT-=t,this.noiseT<=0&&(this.noise=(Math.random()*2-1)*this.diff.steerNoise,this.noiseT=.3+Math.random()*.5),this.predTimer<=0&&(this.pred=T0(i,this.diff.predictTime),this.predTimer=this.diff.reaction*.7+.05);let o=n.team===0?-1:1,l=o*Ze.halfLength,c=-l,h=n.currT,u=i.pos,d=n.contacts>=2,p=Ae.copy(u).sub(h).length();if(this.seq&&(this.runSeq(t,r),this.seq))return r;if(!d&&n.contacts===0)return this.airLogic(t,r,e,l,c),r;let g=e.kickoff&&Math.hypot(i.vel.x,i.vel.z)<.3&&Math.abs(u.x)<.5&&Math.abs(u.z)<.5,y=e.cars.find(v=>v.team!==n.team&&!v.demolished),m=y?Ae.copy(u).sub(y.currT).length():99,f=u.z*o>0,x=null,_=this.diff.speedLimit*(n.boost>10?18:14);for(let v of this.pred){if(v.y>4.5)continue;if(Math.hypot(v.x-h.x,v.z-h.z)/_<v.t+.1){x=v;break}}let M=this.pred.some(v=>Math.abs(v.z)>Ze.halfLength-.5&&Math.sign(v.z)===o&&Math.abs(v.x)<Ze.goalHalfWidth),E=this.target,w=1,A=!1,U=!1;if(g)this.mode="kickoff",E.set(u.x,0,u.z),A=this.diff.boostUse>.3,U=!0;else if(M||f&&m<p*.8&&x){this.mode="save";let v=x||this.pred.find(F=>F.y<5)||{x:u.x,z:u.z,y:1},b=on.set(v.x,0,v.z-c).normalize();E.set(v.x+(l-v.z)*0,0,v.z).addScaledVector(on.set(0,0,o*1),.2),A=!0,U=!0}else if(x&&(!f||p<m)){this.mode="attack";let v=x,b=on.set(0-v.x,0,c-v.z).normalize(),F=2.1,k=new C(v.x-b.x*F,0,v.z-b.z*F),nt=Ae.set(v.x-h.x,0,v.z-h.z),L=nt.lengthSq()>1e-4?nt.normalize().dot(b)>.55:!0,N=Math.hypot(v.x-h.x,v.z-h.z);L||N<5?E.set(v.x,0,v.z):E.copy(k),E.x=Mn(E.x,-Ze.halfWidth+1.5,Ze.halfWidth-1.5),E.z=Mn(E.z,-Ze.halfLength+1.5,Ze.halfLength-1.5),A=!0,U=!0}else{let b=n.boost<60?this.nearestPad(e,h):null;if(b&&(!f||n.boost<25))this.mode="boost",E.set(b.x,0,b.z),A=!1;else{this.mode="defend";let F=l*.62+u.z*.38;E.set(Mn(u.x*.5,-6,6),0,F),w=.9}}return this.drive(t,r,E,w,A,U,e),this.tryTouch(t,r,e,U),Math.abs(n.forwardSpeed)<1&&r.throttle>.5&&n.contacts>0?this.stuckT+=t:Math.abs(n.forwardSpeed)>3&&(this.stuckT=0),this.stuckT>1&&(this.stuckT=0,this.seq={type:"reverse",t:0,s:Math.random()<.5?-1:1}),n.up.y<-.4&&n.contacts===0&&!n.hasDodged&&this.startDodge(0,1,!1,!0),r}nearestPad(t,e){let n=null,i=1e9,r=this.car.team===0?-1:1;for(let a of t.pads.pads){if(!a.active)continue;let o=Math.hypot(a.x-e.x,a.z-e.z)-(a.large?14:0)+(a.z*r<0?12:0);o<i&&(i=o,n=a)}return n}drive(t,e,n,i,r,a,o){let l=this.car;bn.copy(l.currQ).invert(),Ae.set(n.x-l.currT.x,n.y-l.currT.y,n.z-l.currT.z).applyQuaternion(bn);let c=Math.hypot(Ae.x,Ae.z),h=Math.atan2(Ae.x,-Ae.z),u=l.forwardSpeed;if(Math.abs(h)>2.2&&c<14&&u<7){e.throttle=-1,e.steer=Mn(-w0(h-Math.PI*Math.sign(h))*2+this.noise,-1,1)*-1;return}e.steer=Mn(h*2.4+this.noise,-1,1),e.throttle=i*(c<2.2&&Math.abs(u)>12?.3:1),Math.abs(h)>1.3&&u>14&&c>4&&(e.throttle=.2),this.diff.powerslide&&Math.abs(h)>.9&&u>9&&c>6&&(e.handbrake=!0);let p=r&&l.boost>3&&Math.abs(h)<.18&&c>14&&me(u)<2150&&Math.random()<this.diff.boostUse+.1;e.boost=p,a&&this.diff.dodge&&l.onGround&&Math.abs(h)<.12&&c>26&&me(u)>1e3&&me(u)<2e3&&l.boost>5&&Math.random()<.01&&this.startDodge(1,0,!0)}tryTouch(t,e,n,i){let r=this.car,a=n.ball;if(!r.onGround)return;Ae.copy(a.pos).sub(r.currT);let o=Ae.length();bn.copy(r.currQ).invert(),on.copy(Ae).applyQuaternion(bn);let l=Math.abs(r.forwardSpeed);if(!this.diff.dodge){o<3.4&&a.pos.y>1.6&&a.pos.y<3.3&&on.z<0&&this.startJump();return}o<4.2&&o>1.8&&on.z<-1&&Math.abs(on.x)<1.2&&a.pos.y<2.6&&l>6&&i?this.startDodge(1,Mn(on.x*.2,-.4,.4),!1):this.diff.aerial&&a.pos.y>3.2&&a.pos.y<12&&o<24&&r.boost>25&&on.z<-2?this.seq={type:"aerial",t:0,target:a.pos.clone()}:o<3.6&&a.pos.y>1.9&&a.pos.y<4.5&&on.z<0&&this.startJump()}startJump(){this.seq||(this.seq={type:"jump",t:0})}startDodge(t,e,n,i){this.seq||(this.seq={type:"dodge",t:0,f:t,s:e,speedflip:!!n,righting:!!i})}runSeq(t,e){let n=this.seq,i=this.car;if(n.t+=t,n.type==="reverse"){e.throttle=-1,e.steer=n.s,n.t>1.1&&(this.seq=null);return}if(n.type==="jump"){e.jump=n.t<.18,e.throttle=1,n.t>.4&&(this.seq=null);return}if(n.type==="dodge"){if(e.throttle=1,n.righting){e.jump=n.t>.05&&n.t<.2,e.pitch=0,e.steer=n.s||1,n.t>.7&&(this.seq=null);return}n.t<.06?e.jump=!0:n.t<.12?e.jump=!1:n.t<.2?(e.jump=!0,e.pitch=n.f,e.steer=n.s):(e.pitch=0,n.speedflip&&n.t<.5&&(e.boost=!0),n.t>.9&&(this.seq=null)),n.speedflip&&n.t<.2&&(e.boost=!0);return}if(n.type==="aerial"){let r=n.target;if(n.t<.15){e.jump=!0;return}if(n.t<.22){e.jump=!1;return}if(n.t<.3){e.jump=!0,e.pitch=0;return}this.aim(e,Ae.copy(r).sub(i.currT).normalize(),null);let a=Ae.copy(r).sub(i.currT);e.boost=bn.copy(i.currQ)&&i.fwd.dot(a.clone().normalize())>.9&&i.boost>1,(n.t>2.4||i.contacts>0&&n.t>.5)&&(this.seq=null);return}}aim(t,e,n){let i=this.car;bn.copy(i.currQ).invert();let r=Ae.copy(e).applyQuaternion(bn),a=on.copy(i.body.angvel()).applyQuaternion(bn),o=Math.atan2(r.y,-r.z),l=Math.atan2(-r.x,-r.z),c=0,h=(n?Ae.copy(n):Ae.set(0,1,0)).applyQuaternion(bn);c=Math.atan2(-h.x,h.y);let u=9*o-3.2*a.x,d=9*l-3.2*a.y,p=9*c-3.2*a.z;t.pitch=Mn(-u/_l.airPitchAccel,-1,1),t.steer=Mn(-d/_l.airYawAccel,-1,1),t.roll=Mn(-p/_l.airRollAccel,-1,1),t.airRoll=!1}airLogic(t,e,n,i,r){let a=this.car,o=n.ball;if(a.bodyTouch&&a.up.y<.5&&a.speed<12){this.startDodge(0,Math.random()<.5?1:-1,!1,!0);return}let l=Ae.copy(a.vel),c=on.set(l.x,Math.max(l.y*.2,-3),l.z);c.lengthSq()<1&&c.copy(a.fwd).setY(0),c.normalize();let h=o.pos.distanceTo(a.currT);if(this.diff.aerial&&h<8&&o.pos.y>2.5&&c.copy(o.pos).sub(a.currT).normalize(),this.aim(e,c.clone(),null),e.throttle=0,c.dot(a.fwd)>.92&&h<14&&a.boost>5&&this.diff.aerial&&o.pos.y>3&&(e.boost=!0),this.diff.dodge&&!a.hasDodged&&h<4.2&&o.pos.y>2&&a.airTime<1.1&&a.airTime>.2){let u=Ae.copy(o.pos).sub(a.currT).applyQuaternion(bn.copy(a.currQ).invert());u.z<-.5&&(this.seq={type:"dodge",t:.1,f:1,s:Mn(u.x*.3,-.6,.6),speedflip:!1})}}};var xl=gt.arena,kn=gt.match,fs=gt.ball.radius,xa=1/gt.sim.hz,ya=new C,Fh=new C,va=class{constructor(){this.h={}}on(t,e){var n;((n=this.h)[t]||(n[t]=[])).push(e)}emit(t,e){let n=this.h[t];if(n)for(let i of n)i(e)}},Ma=class{constructor(t,e,n,i){this.P=t,this.geo=e,this.input=n,this.bus=i,this.ball=new ma(t),this.pads=new ga(e.boostPads),this.cars=[],this.bots=[],this.mode="menu",this.state="idle",this.paused=!1,this.scores=[0,0],this.timeLeft=kn.duration,this.overtime=!1,this.overtimeTime=0,this.countdown=0,this.stateTime=0,this.simTime=0,this.acc=0,this.lastScorer=-1,this.lastGoalInfo=null,this.humanCtrl=_n(),this.unlimitedBoost=!1,this.preset="kickoff",this.record=[],this.maxRecord=Math.ceil(gt.sim.hz*(kn.replayDuration+3)),this.replay=null,this.difficulty="pro",this.stats={shots:[0,0],saves:[0,0],demos:[0,0],touches:[0,0]},this.human=null,this.fps=60,this.ballPrevVel=new C,this.rBall={pos:new C,quat:new $t}}clearCars(){for(let t of this.cars)this.P.world.removeRigidBody(t.body);this.cars=[],this.bots=[],this.human=null}startFreePlay(){this.clearCars(),this.mode="freeplay";let t=new us(this.P,{team:0,isHuman:!0,name:"You"});this.cars.push(t),this.human=t,this.scores=[0,0],this.timeLeft=kn.duration,this.overtime=!1,this.pads.reset(),this.setPreset("kickoff"),this.state="playing",this.stateTime=0,this.paused=!1,this.replay=null,this.record.length=0,this.bus.emit("matchStart",{mode:"freeplay"})}startVersus(t="pro"){this.clearCars(),this.mode="versus",this.difficulty=t;let e=new us(this.P,{team:0,isHuman:!0,name:"You",index:0}),n=new us(this.P,{team:1,isHuman:!1,name:"Bot",index:1});this.cars.push(e,n),this.human=e,this.bots=[new _a(n,t)],this.scores=[0,0],this.timeLeft=kn.duration,this.overtime=!1,this.overtimeTime=0,this.stats={shots:[0,0],saves:[0,0],demos:[0,0],touches:[0,0]},this.pads.reset(),this.replay=null,this.record.length=0,this.paused=!1,this.kickoff(),this.bus.emit("matchStart",{mode:"versus"})}spawnFor(t,e=0){let n=this.geo.kickoff[e%this.geo.kickoff.length],i=t===0?1:-1;return{x:n.x*i,y:gt.car.restHeight,z:n.z*i,yaw:t===0?Math.PI:0}}kickoff(){this.cars.forEach(t=>{t.place(this.spawnFor(t.team,0)),t.boost=gt.car.boostStart,t.setControls(_n())});for(let t of this.bots)t.seq=null,t.stuckT=0;this.ball.reset(0,fs+.02,0),this.state="countdown",this.countdown=kn.countdown,this.stateTime=0,this.lastGoalInfo=null,this.pads.reset(),this.bus.emit("kickoff",{}),this.lastCountInt=Math.ceil(this.countdown),this.bus.emit("count",{n:this.lastCountInt})}setPreset(t){this.preset=t;let e=this.human,n=this.ball,i=fs,r=(a,o,l,c=100)=>{e.place({x:a,y:gt.car.restHeight,z:o,yaw:l}),e.boost=c};switch(t){case"shot":r(-12,-30,Math.PI),n.reset(6,i+.02,-8);break;case"dribble":r(0,-38,Math.PI,60),n.reset(0,gt.car.restHeight+gt.car.halfHeight+i+.06,-38);break;case"aerial":r(0,-30,Math.PI),n.reset(2,11,6,0,8,6);break;case"wall":r(-8,-10,-Math.PI/2*0+Math.PI/2*0-Math.PI/2),n.reset(30,5,-6,4,9,10);break;case"defend":r(0,-44,Math.PI,100),n.reset(-6,6,18,2,4,-34);break;default:r(0,-46.08,Math.PI,gt.car.boostStart),n.reset(0,i+.02,0);break}e.unlimitedBoost=this.unlimitedBoost,this.pads.reset(),this.bus.emit("reset",{preset:t})}resetAll(){this.setPreset(this.preset)}resetBall(){this.ball.reset(0,fs+.02,0),this.bus.emit("reset",{})}launchBall(){if(!this.human)return;let e=this.human.currT.z<0?-1:1;this.ball.reset((Math.random()-.5)*20,6+Math.random()*4,-e*10,(Math.random()-.5)*16,6+Math.random()*6,e*(20+Math.random()*25))}toggleUnlimitedBoost(){return this.unlimitedBoost=!this.unlimitedBoost,this.human&&(this.human.unlimitedBoost=this.unlimitedBoost,this.human.boost=100),this.unlimitedBoost}frame(t){if(t=Math.min(t,.25),this.mode==="menu"||this.paused)return this.acc=0,this.updateRender(1);if(this.state==="replay")return this.stepReplay(t),1;this.acc+=t;let e=0;for(;this.acc>=xa&&e<gt.sim.maxCatchupSteps;)this.step(xa),this.acc-=xa,e++;return e===gt.sim.maxCatchupSteps&&(this.acc=0),this.updateRender(this.acc/xa)}updateRender(t){for(let e of this.cars)e.rPos||(e.rPos=new C),e.rQuat||(e.rQuat=new $t),e.rPos.copy(e.prevT).lerp(e.currT,t),e.rQuat.copy(e.prevQ).slerp(e.currQ,t);return this.rBall.pos.copy(this.ball.prevPos).lerp(this.ball.pos,t),this.rBall.quat.copy(this.ball.prevQuat).slerp(this.ball.quat,t),t}step(t){let e=this.cars,n=this.ball;for(let r of e)r.snapshot();n.snapshot(),this.ballPrevVel.copy(n.vel);let i=this.state==="playing"||this.mode==="freeplay";for(let r of e)r.isHuman&&r.setControls(i?this.humanCtrl:_n());for(let r of this.bots){let a=r.update(t,{ball:n,cars:e,pads:this.pads,active:this.state==="playing",kickoff:this.stateTime<4&&this.lastTouchless()});r.car.setControls(this.state==="playing"?a:_n())}for(let r of e)r.demolished&&(r.respawnTimer-=t,r.respawnTimer<=0&&(r.place(this.spawnFor(r.team,0)),r.boost=gt.car.boostStart,this.bus.emit("respawn",{car:r})));for(let r of e)r.preStep(t);for(let r of e)r.lastJumpEvent&&this.bus.emit("jump",{car:r}),r.dodgeEvent&&this.bus.emit("dodge",{car:r});n.beginStep(e,t),this.P.step(),this.simTime+=t;for(let r of e)r.postStep();n.endStep(e,t,this.simTime);for(let r of e)r.landedEvent>.05&&this.bus.emit("land",{car:r,power:r.landedEvent});for(let r of n.hitEvents)this.stats.touches[r.car.team]++,this.bus.emit("ballHit",r);if(!n.hitEvents.length){let r=ya.copy(n.vel).sub(this.ballPrevVel).length();r>3.5&&this.bus.emit("ballImpact",{power:r,pos:n.pos})}this.P.events.drainCollisionEvents((r,a,o)=>{o&&this.carCollision(r,a)}),this.pads.update(t,e,this.simTime);for(let r of this.pads.events)this.bus.emit(r.respawned?"padRespawn":"padPickup",r);switch(this.stateTime+=t,this.state){case"countdown":{this.countdown-=t;let r=Math.ceil(this.countdown);r!==this.lastCountInt&&r>0&&(this.lastCountInt=r,this.bus.emit("count",{n:r})),this.countdown<=0&&(this.state="playing",this.stateTime=0,this.bus.emit("go",{}));break}case"playing":this.playing(t);break;case"goal":this.stateTime>=kn.goalCelebration&&this.beginReplay();break;default:break}this.mode==="freeplay"&&this.freeplayGoalCheck(),this.recordFrame()}lastTouchless(){return this.ball.lastHitCar===null}playing(t){if(this.mode!=="versus")return;if(this.overtime)this.overtimeTime+=t;else if(this.timeLeft-=t,this.timeLeft<=0){if(this.timeLeft=0,this.scores[0]!==this.scores[1])return this.finish();this.overtime=!0,this.overtimeTime=0,this.bus.emit("overtime",{})}let e=this.goalCheck();e>=0&&this.scoreGoal(e)}goalCheck(){let t=this.ball.pos;return Math.abs(t.z)>xl.halfLength+fs&&Math.abs(t.x)<xl.goalHalfWidth&&t.y<xl.goalHeight+fs?t.z>0?0:1:-1}freeplayGoalCheck(){if(this.state!=="playing")return;let t=this.goalCheck();t>=0&&(this.scores[t]++,this.lastScorer=t,this.state="goal",this.stateTime=0,this.bus.emit("goal",{team:t,freeplay:!0,ball:this.ball.pos.clone(),by:this.ball.lastHitCar}))}scoreGoal(t){this.scores[t]++,this.lastScorer=t;let e=this.ball.lastHitCar;this.lastGoalInfo={team:t,by:e,speed:me(this.ball.vel.length()),overtime:this.overtime},this.stats.shots[t]++,this.state="goal",this.stateTime=0,this.goalFrame=this.record.length,this.bus.emit("goal",{team:t,ball:this.ball.pos.clone(),by:e,speed:this.lastGoalInfo.speed})}finish(){this.state="ended",this.stateTime=0;let t=this.scores[0]===this.scores[1]?-1:this.scores[0]>this.scores[1]?0:1;this.bus.emit("ended",{scores:this.scores.slice(),winner:t,stats:this.stats})}carCollision(t,e){let n=this.cars.find(u=>u.collider.handle===t),i=this.cars.find(u=>u.collider.handle===e);if(!n||!i||n===i||n.demolished||i.demolished||n.team===i.team)return;let r=gt.car.supersonic,a=(u,d)=>u.prevSpeed<r?!1:(Fh.copy(d.currT).sub(u.currT).normalize(),u.prevVel.dot(Fh)>.4*u.prevSpeed),o=a(n,i),l=a(i,n),c=null,h=null;if(o&&(!l||n.prevSpeed>=i.prevSpeed)?(c=n,h=i):l&&(c=i,h=n),!c){this.bus.emit("carBump",{a:n,b:i,power:ya.copy(n.vel).sub(i.vel).length()});return}this.stats.demos[c.team]++,this.bus.emit("demolish",{victim:h,attacker:c,pos:h.currT.clone()}),h.demolish()}recordFrame(){let t={b:[this.ball.pos.x,this.ball.pos.y,this.ball.pos.z,this.ball.quat.x,this.ball.quat.y,this.ball.quat.z,this.ball.quat.w],c:[]};for(let e of this.cars)t.c.push([e.currT.x,e.currT.y,e.currT.z,e.currQ.x,e.currQ.y,e.currQ.z,e.currQ.w,e.boosting?1:0,e.demolished?1:0]);this.record.push(t),this.record.length>this.maxRecord&&this.record.shift()}beginReplay(){let t=Math.min(this.record.length,Math.ceil((kn.replayDuration-.5)*gt.sim.hz)),e=this.record.length-Math.ceil((kn.goalCelebration-.8)*gt.sim.hz),n=Math.max(0,e-t);this.replay={frames:this.record.slice(n,Math.max(n+2,e)),t:0},this.state="replay",this.stateTime=0,this.bus.emit("replayStart",{})}stepReplay(t){let e=this.replay;if(!e)return this.endReplay();e.t+=t*kn.replaySpeed*gt.sim.hz,this.stateTime+=t;let n=Math.floor(e.t),i=e.t-n;if(n>=e.frames.length-1)return this.endReplay();let r=e.frames[n],a=e.frames[n+1];this.rBall.pos.set(r.b[0],r.b[1],r.b[2]).lerp(ya.set(a.b[0],a.b[1],a.b[2]),i),this.rBall.quat.set(r.b[3],r.b[4],r.b[5],r.b[6]).slerp(new $t(a.b[3],a.b[4],a.b[5],a.b[6]),i),this.cars.forEach((o,l)=>{let c=r.c[l],h=a.c[l];!c||!h||(o.rPos||(o.rPos=new C),o.rQuat||(o.rQuat=new $t),o.rPos.set(c[0],c[1],c[2]).lerp(ya.set(h[0],h[1],h[2]),i),o.rQuat.set(c[3],c[4],c[5],c[6]).slerp(new $t(h[3],h[4],h[5],h[6]),i),o.replayBoost=!!c[7],o.replayHidden=!!c[8])})}skipReplay(){this.state==="replay"&&this.endReplay()}endReplay(){this.replay=null;for(let t of this.cars)t.replayBoost=!1,t.replayHidden=!1;if(this.bus.emit("replayEnd",{}),this.mode==="freeplay"){this.state="playing",this.setPreset(this.preset);return}if(this.overtime)return this.finish();this.kickoff()}dispose(){this.clearCars(),this.P.world.removeRigidBody(this.ball.body)}restart(){this.mode==="freeplay"?this.startFreePlay():this.mode==="versus"&&this.startVersus(this.difficulty)}quitToMenu(){this.mode="menu",this.state="idle",this.paused=!1,this.clearCars(),this.replay=null,this.ball.reset(0,fs+.02,0)}};var Re=gt.arena,ln=gt.car,Fe=[{body:2063615,accent:8376575,glow:new Ct(.25,.65,1),css:"#3b9bff"},{body:16742938,accent:16765066,glow:new Ct(1,.5,.12),css:"#ff8a2b"}],ps=(s,t,e)=>Math.max(t,Math.min(e,s)),te=new C,oi=new C,a_=new $t,A0=new C(0,1,0),R0=new $t().setFromAxisAngle(new C(1,0,0),-Math.PI/2);function Xs(s,t,e,n={}){let i=document.createElement("canvas");i.width=s,i.height=t,e(i.getContext("2d"),s,t);let r=new Yr(i);return r.colorSpace=_e,r.anisotropy=8,n.repeat&&(r.wrapS=r.wrapT=Ps),n.noFlip&&(r.flipY=!1),r}var ba=class{constructor(t,e,n){this.max=t,this.n=0,this.cursor=0,this.pos=new Float32Array(t*3),this.col=new Float32Array(t*4),this.size=new Float32Array(t),this.vel=new Float32Array(t*3),this.life=new Float32Array(t),this.maxLife=new Float32Array(t),this.s0=new Float32Array(t),this.s1=new Float32Array(t),this.a0=new Float32Array(t),this.drag=new Float32Array(t),this.grav=new Float32Array(t),this.base=new Float32Array(t*3);let i=new Te;i.setAttribute("position",new jt(this.pos,3)),i.setAttribute("color",new jt(this.col,4)),i.setAttribute("size",new jt(this.size,1)),this.uniforms={uScale:{value:600}},this.mat=new en({uniforms:this.uniforms,transparent:!0,depthWrite:!1,blending:e?mn:Kn,vertexShader:"attribute float size; attribute vec4 color; varying vec4 vC; uniform float uScale; void main(){ vC=color; vec4 mv=modelViewMatrix*vec4(position,1.0); gl_PointSize=max(size*uScale/-mv.z,0.0); gl_Position=projectionMatrix*mv; }",fragmentShader:"varying vec4 vC; void main(){ float d=length(gl_PointCoord-0.5); float a=smoothstep(0.5,0.05,d); gl_FragColor=vec4(vC.rgb,vC.a*a); }"}),this.points=new Fs(i,this.mat),this.points.frustumCulled=!1,n.add(this.points);for(let r=0;r<t;r++)this.life[r]=0,this.size[r]=0,this.pos[r*3+1]=-999}emit(t,e,n,i,r,a,o,l,c,h,u,d,p,g=0,y=0){let m=this.cursor;this.cursor=(this.cursor+1)%this.max,this.pos[m*3]=t,this.pos[m*3+1]=e,this.pos[m*3+2]=n,this.vel[m*3]=i,this.vel[m*3+1]=r,this.vel[m*3+2]=a,this.col[m*4]=o,this.col[m*4+1]=l,this.col[m*4+2]=c,this.col[m*4+3]=h,this.a0[m]=h,this.s0[m]=u,this.s1[m]=d,this.life[m]=p,this.maxLife[m]=p,this.drag[m]=g,this.grav[m]=y,this.size[m]=u}update(t){for(let n=0;n<this.max;n++){if(this.life[n]<=0){this.size[n]!==0&&(this.size[n]=0);continue}if(this.life[n]-=t,this.life[n]<=0){this.size[n]=0,this.pos[n*3+1]=-999;continue}let i=1-this.life[n]/this.maxLife[n],r=Math.exp(-this.drag[n]*t);this.vel[n*3]*=r,this.vel[n*3+1]=this.vel[n*3+1]*r-this.grav[n]*t,this.vel[n*3+2]*=r,this.pos[n*3]+=this.vel[n*3]*t,this.pos[n*3+1]+=this.vel[n*3+1]*t,this.pos[n*3+2]+=this.vel[n*3+2]*t,this.pos[n*3+1]<.02&&this.grav[n]>0&&(this.pos[n*3+1]=.02,this.vel[n*3+1]*=-.4),this.size[n]=this.s0[n]+(this.s1[n]-this.s0[n])*i,this.col[n*4+3]=this.a0[n]*(1-i)*(1-i*.3)}let e=this.points.geometry;e.attributes.position.needsUpdate=!0,e.attributes.color.needsUpdate=!0,e.attributes.size.needsUpdate=!0}};function yl(s){let t=Fe[s],e=new je,n=new Ce({color:t.body,metalness:.35,roughness:.38,envMapIntensity:.7}),i=new Ce({color:1382431,metalness:.5,roughness:.45}),r=new Ce({color:659228,metalness:.95,roughness:.06}),a=new Ce({color:t.accent,metalness:.3,roughness:.4,emissive:t.accent,emissiveIntensity:.35}),o=(E,w,A,U)=>{let v=new zs;v.moveTo(E[0][0],E[0][1]);for(let k=1;k<E.length;k++)v.lineTo(E[k][0],E[k][1]);let b=new jr(v,{depth:w,bevelEnabled:!!U,bevelSize:U||0,bevelThickness:U||0,bevelSegments:2,steps:1});return b.translate(0,0,-w/2),b.rotateY(Math.PI/2),new It(b,A)};e.add(o([[-.6,-.12],[-.62,-.02],[-.58,.05],[-.3,.07],[-.14,.185],[.1,.19],[.3,.06],[.5,.03],[.62,-.02],[.63,-.1],[.5,-.14],[-.5,-.14]],.74,n,.03)),e.add(o([[-.2,.07],[-.11,.165],[.09,.17],[.25,.065]],.8,r,.005));let l=new It(new xe(.1,.012,.9),a);l.position.set(0,.075,.32),e.add(l);let c=new It(new xe(.78,.025,.2),n);c.position.set(0,.2,.55),e.add(c);for(let E of[-1,1]){let w=new It(new xe(.03,.12,.07),i);w.position.set(E*.2,.14,.55),e.add(w);let A=new It(new xe(.02,.07,.22),a);A.position.set(E*.39,.2,.55),e.add(A)}let h=new pe({color:16774872}),u=new pe({color:16722474});for(let E of[-1,1]){let w=new It(new xe(.15,.04,.02),h);w.position.set(E*.24,-.015,-.628),e.add(w);let A=new It(new xe(.16,.035,.02),u);A.position.set(E*.25,0,.62),e.add(A)}let d=new It(new xe(.8,.02,.1),i);d.position.set(0,-.145,-.6),e.add(d);let p=new It(new xe(.7,.03,1.2),i);p.position.set(0,-.145,0),e.add(p);let g=[],y=new pe({color:t.glow,transparent:!0,opacity:.6,blending:mn,depthWrite:!1}),m=new pe({color:13625599,transparent:!0,opacity:.55,blending:mn,depthWrite:!1});for(let E of[-1,1]){let w=new It(new sn(.045,.06,.1,12),i);w.rotation.x=Math.PI/2,w.position.set(E*.17,-.07,.64),e.add(w);let A=new ns(.06,.6,12,1,!0);A.translate(0,.3,0),A.rotateX(Math.PI/2);let U=new It(A,y);U.position.set(E*.17,-.07,.69),U.visible=!1,e.add(U);let v=new ns(.03,.3,10,1,!0);v.translate(0,.15,0),v.rotateX(Math.PI/2);let b=new It(v,m);b.position.copy(U.position),b.visible=!1,e.add(b),g.push(U,b)}let f=[],x=new Ce({color:855312,roughness:.85,metalness:.05}),_=new Ce({color:14212584,metalness:.9,roughness:.25}),M=[[-ln.wheelX,ln.wheelZFront,!0],[ln.wheelX,ln.wheelZFront,!0],[-ln.wheelX,ln.wheelZRear,!1],[ln.wheelX,ln.wheelZRear,!1]];for(let[E,w,A]of M){let U=new je;U.position.set(E,-.065,w);let v=new je;U.add(v);let b=A?ln.wheelRadius*.95:ln.wheelRadius*1.05,F=new It(new sn(b,b,.17,24),x);F.rotation.z=Math.PI/2,v.add(F);let k=new It(new sn(b*.66,b*.66,.178,18),_);k.rotation.z=Math.PI/2,v.add(k);for(let nt=0;nt<5;nt++){let L=new It(new xe(.182,b*.12,b*1.2),i);L.rotation.x=nt/5*Math.PI,v.add(L)}e.add(U),f.push({pivot:U,spin:v,front:A,baseY:-.065,radius:b,x:E,z:w})}return e.traverse(E=>{E.isMesh&&(E.frustumCulled=!0)}),{group:e,wheels:f,flames:g,bodyMat:n}}var Sa=class{constructor(t,e,n){this.canvas=t,this.geo=e,this.bus=n,this.gl=new Us({canvas:t,antialias:!0,powerPreference:"high-performance"}),this.gl.setPixelRatio(Math.min(window.devicePixelRatio||1,1.75)),this.gl.outputColorSpace=_e,this.gl.toneMapping=ol,this.gl.toneMappingExposure=.95,this.scene=new Ns,this.camera=new Ne(70,16/9,.1,600),this.time=0,this.carViews=new Map,this.padViews=[],this.flash=0,this.rings=[],this.buildEnvironmentMap(),this.buildLights(),this.buildArena(),this.buildStands(),this.buildSky(),this.buildPads(),this.buildBall(),this.buildEffects(),this.buildShowcase(),this.resize(),this.subscribe()}adaptQuality(t,e){this._q=this._q||{scale:Math.min(window.devicePixelRatio||1,1.75),max:Math.min(window.devicePixelRatio||1,1.75),low:0,high:0};let n=this._q;t<45?(n.low+=e,n.high=0):t>57?(n.high+=e,n.low=0):n.low=n.high=0;let i=!1;n.low>1.5&&n.scale>.6&&(n.scale=Math.max(.6,n.scale-.15),n.low=0,i=!0),n.high>6&&n.scale<n.max&&(n.scale=Math.min(n.max,n.scale+.1),n.high=0,i=!0),i&&(this.gl.setPixelRatio(n.scale),this.resize())}resize(){let t=this.canvas.clientWidth||window.innerWidth,e=this.canvas.clientHeight||window.innerHeight;return this.gl.setSize(t,e,!1),this.width=t,this.height=e,this.camera.aspect=t/e,this.camera.updateProjectionMatrix(),t/e}buildEnvironmentMap(){let t=new Ns,e=new It(new Mi(50,24,12),new pe({side:Ee,vertexColors:!0})),n=e.geometry.attributes.position,i=[];for(let a=0;a<n.count;a++){let o=(n.getY(a)/50+1)/2;i.push(.06+o*.25,.08+o*.3,.16+o*.55)}e.geometry.setAttribute("color",new se(i,3)),t.add(e);for(let a=0;a<6;a++){let o=new It(new xe(18,.5,6),new pe({color:new Ct(6,6,6.5)}));o.position.set((a-2.5)*14,40,a%2*18-9),t.add(o)}let r=new es(this.gl);this.scene.environment=r.fromScene(t,.03).texture,this.scene.environmentIntensity=.45,r.dispose()}buildLights(){this.scene.add(new na(10204415,3156026,.55));let t=new sa(16777215,.85);t.position.set(18,60,10),this.scene.add(t),this.blueLight=new ss(3837183,260,70,1.6),this.blueLight.position.set(0,18,-28),this.scene.add(this.blueLight),this.orangeLight=new ss(16747050,260,70,1.6),this.orangeLight.position.set(0,18,28),this.scene.add(this.orangeLight),this.flashLight=new ss(16777215,0,120,1.2),this.flashLight.position.set(0,14,0),this.scene.add(this.flashLight)}buildSky(){let t=new It(new Mi(300,24,12),new pe({side:Ee,vertexColors:!0,fog:!1})),e=t.geometry.attributes.position,n=[];for(let i=0;i<e.count;i++){let r=ps(e.getY(i)/300,-.3,1);n.push(.02+r*.05,.03+r*.06,.07+r*.14)}t.geometry.setAttribute("color",new se(n,3)),this.scene.add(t),this.scene.fog=new Wr(461334,.0035)}buildArena(){let{floor:t,shell:e,goalBlue:n,goalOrange:i}=this.geo.groups,r=Re.halfWidth,a=Re.halfLength,o=x=>{let _=new Te;return _.setAttribute("position",new jt(x.positions,3)),_.setAttribute("normal",new jt(x.normals,3)),_.setAttribute("uv",new jt(x.uvs,2)),_.setIndex(new jt(x.indices,1)),_},l=Xs(1024,1280,(x,_,M)=>{let E=x.createLinearGradient(0,0,0,M);E.addColorStop(0,"#102a52"),E.addColorStop(.47,"#17345f"),E.addColorStop(.5,"#1a2a44"),E.addColorStop(.53,"#4a2f2c"),E.addColorStop(1,"#5a2e1a"),x.fillStyle=E,x.fillRect(0,0,_,M),x.strokeStyle="rgba(255,255,255,0.05)",x.lineWidth=1;for(let v=0;v<=_;v+=_/16)x.beginPath(),x.moveTo(v,0),x.lineTo(v,M),x.stroke();for(let v=0;v<=M;v+=M/20)x.beginPath(),x.moveTo(0,v),x.lineTo(_,v),x.stroke();x.strokeStyle="rgba(255,255,255,0.75)",x.lineWidth=5;let w=_/(2*r),A=M/(2*a),U=(v,b)=>[(v+r)*w,(b+a)*A];x.beginPath(),x.moveTo(...U(-r,0)),x.lineTo(...U(r,0)),x.stroke(),x.beginPath(),x.ellipse(...U(0,0),9.2*w,9.2*A,0,0,Math.PI*2),x.stroke(),x.beginPath(),x.arc(...U(0,0),.5*w,0,Math.PI*2),x.fillStyle="#fff",x.fill(),x.lineWidth=4;for(let v of[-1,1]){let b=v<0?"rgba(90,170,255,0.9)":"rgba(255,150,70,0.9)";x.strokeStyle=b,x.strokeRect(...U(-18,v<0?-a:a-12.5),36*w,12.5*A),x.beginPath(),x.ellipse(...U(0,v*(a-12.5)),12*w,5*A,0,v<0?0:Math.PI,v<0?Math.PI:Math.PI*2),x.stroke()}x.strokeStyle="rgba(255,255,255,0.6)",x.lineWidth=6,x.strokeRect(2,2,_-4,M-4)},{noFlip:!0}),c=new Ce({map:l,roughness:.55,metalness:.12,envMapIntensity:.6});this.floorMesh=new It(o(t),c),this.scene.add(this.floorMesh);let h=o(e),u=e.positions,d=new Float32Array(u.length/3*4);for(let x=0;x<u.length/3;x++){let _=u[x*3+1],M=u[x*3+2],E=ps(M/a,-1,1),w=Math.abs(E)>.15?Math.min(1,(Math.abs(E)-.15)/.6):0,A=.35+(E>0?w*.65:-w*.15),U=.45+(E>0,w*.1),v=.8+(E<0?w*.2:-w*.5),b;_>Re.height-Re.ceilingRampRadius*.5?b=.92:_<Re.floorRampRadius+.01?b=.8:b=.3+.35*Math.pow(Math.min(1,Math.abs(_-Re.height/2)/(Re.height/2)),2),d[x*4]=A,d[x*4+1]=U,d[x*4+2]=v,d[x*4+3]=b}h.setAttribute("color",new jt(d,4));let p=Xs(256,256,(x,_,M)=>{x.fillStyle="#28365a",x.fillRect(0,0,_,M),x.strokeStyle="rgba(150,190,255,0.55)",x.lineWidth=3;let E=64;for(let w=0;w<=M;w+=E)for(let A=0;A<=_;A+=E)x.strokeRect(A+3,w+3,E-6,E-6);x.fillStyle="rgba(255,255,255,0.05)";for(let w=0;w<40;w++)x.fillRect(Math.random()*_,Math.random()*M,3,3)},{repeat:!0}),g=new Ce({map:p,vertexColors:!0,transparent:!0,side:Ve,roughness:.75,metalness:.2,emissive:1450570,emissiveIntensity:.9,depthWrite:!1});this.shellMesh=new It(h,g),this.shellMesh.renderOrder=2,this.scene.add(this.shellMesh);let y=x=>Xs(256,256,(_,M,E)=>{_.fillStyle="rgba(8,12,24,0.0)",_.clearRect(0,0,M,E),_.strokeStyle=x,_.lineWidth=2,_.globalAlpha=.85;for(let w=0;w<=8;w++)_.beginPath(),_.moveTo(w*M/8,0),_.lineTo(w*M/8,E),_.stroke(),_.beginPath(),_.moveTo(0,w*E/8),_.lineTo(M,w*E/8),_.stroke()},{repeat:!0}),m=(x,_)=>{let M=new It(o(x),new Ce({map:y(_?"#ffb070":"#7cc4ff"),transparent:!0,opacity:.8,side:Ve,emissive:_?8008976:1063546,emissiveIntensity:.9,roughness:.6,depthWrite:!1}));return M.geometry.attributes.uv.array.forEach((E,w,A)=>{A[w]=E*6}),this.scene.add(M),M};m(n,0),m(i,1);for(let x of this.geo.frame){let _=x.z<0?0:1,M=new Ce({color:Fe[_].body,emissive:Fe[_].body,emissiveIntensity:.6,metalness:.5,roughness:.3}),E;x.kind==="post"?(E=new It(new sn(x.radius,x.radius,x.halfHeight*2,14),M),E.position.set(x.x,x.y,x.z)):(E=new It(new sn(x.radius,x.radius,x.halfLength*2,14),M),E.rotation.z=Math.PI/2,E.position.set(x.x,x.y,x.z)),this.scene.add(E)}for(let x of[-1,1]){let _=new It(new ts(Re.goalHalfWidth*2,Re.goalHeight),new pe({color:Fe[x<0?0:1].body,transparent:!0,opacity:.06,side:Ve,depthWrite:!1,blending:mn}));_.position.set(0,Re.goalHeight/2,x*(Re.halfLength+Re.goalDepth*.5)),this.scene.add(_)}let f=new pe({color:new Ct(2.2,2.2,2.4)});for(let x=-4;x<=4;x++){let _=new It(new xe(Re.halfWidth*1.4,.12,.5),f);_.position.set(0,Re.height-.08,x*10),this.scene.add(_)}}buildStands(){let e=new qr(new xe(.7,1.1,.7),new Ce({roughness:.9}),2600),n=new we,i=new Ct,r=0,a=Re.halfWidth,o=Re.halfLength,l=[2833003,7023403,2845514,5982763,4210795,9079450,1976900,8010598],c=(f,x,_)=>{r>=2600||(n.position.set(f,x,_),n.scale.setScalar(.85+Math.random()*.3),n.updateMatrix(),e.setMatrixAt(r,n.matrix),i.setHex(l[Math.random()*l.length|0]).multiplyScalar(.7+Math.random()*.6),e.setColorAt(r,i),r++)};for(let f=0;f<9;f++){let x=4.5+f*1.5,_=1+f*1.25;for(let M=-o+14;M<=o-14;M+=1.5)c(-a-x,_,M+(Math.random()-.5)*.3),c(a+x,_,M+(Math.random()-.5)*.3);for(let M=-a+14;M<=a-14;M+=1.5)f>1&&(c(M,_,-o-x-Re.goalDepth*.6),c(M,_,o+x+Re.goalDepth*.6))}e.count=r,e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0),this.scene.add(e);let h=new Ce({color:856608,roughness:1});for(let f of[-1,1]){let x=new It(new xe(30,1,o*2+40),h);x.position.set(f*(a+20),-.6,0),this.scene.add(x);let _=new It(new xe(a*2+60,1,40),h);_.position.set(0,-.6,f*(o+28)),this.scene.add(_)}let u=220,d=new Float32Array(u*3),p=new Float32Array(u);for(let f=0;f<u;f++){let x=Math.random()<.5?-1:1;d[f*3]=x*(a+6+Math.random()*14),d[f*3+1]=3+Math.random()*11,d[f*3+2]=(Math.random()*2-1)*(o-5),p[f]=Math.random()*100}let g=new Te;g.setAttribute("position",new jt(d,3)),g.setAttribute("seed",new jt(p,1)),this.twinkle={value:0};let y=new en({transparent:!0,depthWrite:!1,blending:mn,uniforms:{uT:this.twinkle,uScale:{value:600}},vertexShader:"attribute float seed; uniform float uT; uniform float uScale; varying float vA; void main(){ float ph=fract(uT*0.35+seed*0.137); vA=smoothstep(0.0,0.04,ph)*smoothstep(0.12,0.04,ph); vec4 mv=modelViewMatrix*vec4(position,1.0); gl_PointSize=vA*1.6*uScale/-mv.z; gl_Position=projectionMatrix*mv; }",fragmentShader:"varying float vA; void main(){ float d=length(gl_PointCoord-0.5); gl_FragColor=vec4(vec3(1.0),vA*smoothstep(0.5,0.0,d)); }"});this.twinkleUniforms=y.uniforms;let m=new Fs(g,y);m.frustumCulled=!1,this.scene.add(m)}buildPads(){let t=new sn(.95,1.05,.06,6),e=new sn(1.45,1.55,.08,8),n=new ta(.62,1),i=new sn(.9,1.2,7,16,1,!0);i.translate(0,3.5,0);for(let r of this.geo.boostPads){let a=new je;a.position.set(r.x,.04,r.z);let o=new Ce({color:16756782,emissive:16747008,emissiveIntensity:.9,metalness:.3,roughness:.4}),l=new It(r.large?e:t,o);a.add(l);let c=new It(new ns(.4,.8,3),new pe({color:16773296}));c.rotation.x=-Math.PI/2,c.position.y=.06,c.scale.set(1,1,.2),a.add(c);let h=null,u=null;r.large&&(h=new It(n,new pe({color:16765034,transparent:!0,opacity:.95})),h.position.y=1.4,a.add(h),u=new It(i,new pe({color:16752672,transparent:!0,opacity:.16,blending:mn,depthWrite:!1,side:Ve})),a.add(u)),this.scene.add(a),this.padViews.push({grp:a,mat:o,orb:h,beam:u,base:l,arrow:c,pad:r,glow:1,spawnAnim:1})}}buildBall(){let t=gt.ball.radius,e=Xs(512,256,(n,i,r)=>{n.fillStyle="#e8edf8",n.fillRect(0,0,i,r),n.strokeStyle="#263055",n.lineWidth=4;for(let a=0;a<r;a+=64)for(let o=0;o<i;o+=64){let l=a/64%2?32:0;n.beginPath();for(let c=0;c<6;c++){let h=c/6*Math.PI*2,u=o+l+32+Math.cos(h)*30,d=a+32+Math.sin(h)*30;c?n.lineTo(u,d):n.moveTo(u,d)}n.closePath(),n.stroke(),(o/64+a/64)%3===0&&(n.fillStyle="#34406e",n.fill())}});this.ballMat=new Ce({map:e,roughness:.28,metalness:.25,emissive:2241365,emissiveIntensity:.35}),this.ballMesh=new It(new Mi(t,40,28),this.ballMat),this.scene.add(this.ballMesh),this.ballGlow=new It(new Mi(t*1.12,24,16),new pe({color:6728447,transparent:!0,opacity:0,blending:mn,depthWrite:!1,side:Ee})),this.scene.add(this.ballGlow),this.ballShadow=this.makeShadow(t*1.3),this.ballTrail=0}makeShadow(t){let e=Xs(64,64,(i,r,a)=>{let o=i.createRadialGradient(32,32,2,32,32,32);o.addColorStop(0,"rgba(0,0,0,0.85)"),o.addColorStop(1,"rgba(0,0,0,0)"),i.fillStyle=o,i.fillRect(0,0,r,a)}),n=new It(new ts(t*2,t*2),new pe({map:e,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2}));return n.rotation.x=-Math.PI/2,n.renderOrder=1,this.scene.add(n),n.userData.r=t,n}buildEffects(){this.addP=new ba(2600,!0,this.scene),this.smokeP=new ba(1400,!1,this.scene),this.markMax=1800,this.markN=0,this.markPtr=0;let t=new Te;this.markPos=new Float32Array(this.markMax*4*3),this.markCol=new Float32Array(this.markMax*4*4);let e=new Uint32Array(this.markMax*6);for(let n=0;n<this.markMax;n++){let i=n*4;e.set([i,i+1,i+2,i+2,i+1,i+3],n*6)}t.setAttribute("position",new jt(this.markPos,3)),t.setAttribute("color",new jt(this.markCol,4)),t.setIndex(new jt(e,1)),this.markMesh=new It(t,new pe({vertexColors:!0,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-3})),this.markMesh.frustumCulled=!1,this.markMesh.renderOrder=1,this.scene.add(this.markMesh),this.ringGeo=new ea(.85,1,48)}addRing(t,e,n,i,r=!1){let a=new It(this.ringGeo,new pe({color:e,transparent:!0,opacity:.9,blending:mn,depthWrite:!1,side:Ve}));a.position.copy(t),r||(a.rotation.x=-Math.PI/2),this.scene.add(a),this.rings.push({m:a,t:0,life:i,maxR:n})}burst(t,e,n,i,r=.3,a=.8,o=!0,l=6){let c=o?this.addP:this.smokeP;for(let h=0;h<e;h++){let u=Math.random()*Math.PI*2,d=Math.acos(2*Math.random()-1),p=n*(.3+Math.random()*.7);c.emit(t.x,t.y,t.z,Math.sin(d)*Math.cos(u)*p,Math.cos(d)*p,Math.sin(d)*Math.sin(u)*p,i.r,i.g,i.b,1,r,r*.3,a*(.5+Math.random()*.8),1.2,l)}}subscribe(){let t=this.bus;t.on("ballHit",e=>{let n=ps(me(e.power)/2300,.1,1.6),i=Fe[e.car.team].glow;this.burst(e.point,Math.round(10+n*26),6+n*12,new Ct(1,.9,.6).lerp(i,.4),.16,.5),n>.45&&this.addRing(e.point,Fe[e.car.team].body,1.2+n*2,.35,!0),this.ballGlowT=1,this.glowTeam=e.car.team,this.camShake=Math.max(this.camShake||0,n*.5)}),t.on("ballImpact",e=>{e.power>5&&this.burst(e.pos,8,5,new Ct(.8,.9,1),.14,.4)}),t.on("land",e=>{let n=e.car;if(e.power>.2)for(let i of n.wheels)i.contact&&this.dust(te.set(i.px,.05,i.pz),2,3*e.power)}),t.on("padPickup",e=>{let n=this.padViews[e.pad.id];n&&(n.spawnAnim=0);let i=te.set(e.pad.x,.2,e.pad.z);this.burst(i,e.pad.large?36:12,e.pad.large?9:5,new Ct(1,.75,.2),.2,.7),e.pad.large&&this.addRing(i,16760896,4,.5)}),t.on("goal",e=>{let n=Fe[e.team].glow,i=e.ball.clone();i.y=Math.max(i.y,1.5),this.burst(i,320,26,n,.55,1.8,!0,4),this.burst(i,160,38,new Ct(1,1,1),.3,1.4,!0,3),this.addRing(i,Fe[e.team].body,16,1,!0),this.addRing(new C(i.x,.1,i.z),Fe[e.team].body,22,1.2),this.flash=1,this.flashColor=Fe[e.team].body,this.camShake=1.2}),t.on("demolish",e=>{let n=e.pos;this.burst(n,140,18,new Ct(1,.55,.2),.45,1.1),this.burst(n,80,12,new Ct(.4,.45,.5),.6,1.4,!1,2),this.addRing(n,16744496,6,.6),this.camShake=.8}),t.on("carBump",e=>{e.power>4&&(te.copy(e.a.currT).add(e.b.currT).multiplyScalar(.5),this.burst(te,14,6,new Ct(1,.9,.6),.14,.4))}),t.on("jump",e=>{for(let n of e.car.wheels)this.dust(te.set(n.px,.05,n.pz),1,2)}),t.on("dodge",e=>{te.copy(e.car.currT),this.burst(te,12,4,Fe[e.car.team].glow,.12,.4,!0,0)})}dust(t,e,n){for(let i=0;i<e;i++)this.smokeP.emit(t.x+(Math.random()-.5)*.3,t.y,t.z+(Math.random()-.5)*.3,(Math.random()-.5)*n,Math.random()*n*.6,(Math.random()-.5)*n,.7,.74,.82,.16,.2,.9,.8,1.8,-.3)}getCarView(t){let e=this.carViews.get(t);if(!e){let n=yl(t.team);this.scene.add(n.group);let i=this.makeShadow(1);i.scale.set(1.15,1,1.8),e={car:t,model:n,shadow:i,wheelY:[0,0,0,0],lastMark:[null,null,null,null],flame:0},this.carViews.set(t,e)}return e}dropCars(t){for(let[e,n]of this.carViews)t.includes(e)||(this.scene.remove(n.model.group),this.scene.remove(n.shadow),this.carViews.delete(e))}buildShowcase(){this.showcase=new je;let t=yl(0),e=yl(1);t.group.position.set(-3,.205,-42),t.group.rotation.y=Math.PI*.85,e.group.position.set(3,.205,42),e.group.rotation.y=-Math.PI*.15,this.showcase.add(t.group,e.group),this.showcase.visible=!1,this.scene.add(this.showcase)}updateCar(t,e,n){let i=t.car,r=t.model.group,a=i.demolished||i.replayHidden;if(r.visible=!a,t.shadow.visible=!a,a)return;r.position.copy(i.rPos),r.quaternion.copy(i.rQuat);let o=n?i.replayBoost:i.boosting;t.model.wheels.forEach((p,g)=>{let y=i.wheels[g],m=n?p.baseY:-ln.wheelAttachY*0+ln.wheelAttachY-Math.min(y.dist??i.rayLen,i.rayLen)+p.radius;t.wheelY[g]+=(m-t.wheelY[g])*(1-Math.exp(-e*30)),isFinite(t.wheelY[g])||(t.wheelY[g]=p.baseY),p.pivot.position.y=t.wheelY[g],p.pivot.rotation.y=p.front?-(y.steer||0):0,p.spin.rotation.x=-(y.spin||0)}),t.flame+=((o?1:0)-t.flame)*(1-Math.exp(-e*(o?30:12)));let l=t.flame,c=.75+Math.random()*.5;t.model.flames.forEach((p,g)=>{p.visible=l>.05,p.scale.set(1,1,l*c*(g%2?.6:1))});let h=i.rPos.y,u=oi.set(0,1,0).applyQuaternion(i.rQuat);if(t.shadow.visible=u.y>.3||h<3,t.shadow.position.set(i.rPos.x,.025,i.rPos.z),t.shadow.material.opacity=ps(.8-h/7,0,.8),te.set(0,0,-1).applyQuaternion(i.rQuat),t.shadow.quaternion.setFromAxisAngle(A0,Math.atan2(-te.x,-te.z)).multiply(R0),n)return;let d=i.speed;if(o){let p=Fe[i.team].glow;for(let g of[-1,1]){te.set(g*.17,-.07,.7).applyQuaternion(i.rQuat).add(i.rPos),oi.copy(i.fwd).multiplyScalar(-9).addScaledVector(i.vel,.45);for(let y=0;y<2;y++)this.addP.emit(te.x,te.y,te.z,oi.x+(Math.random()-.5)*2,oi.y+(Math.random()-.5)*2,oi.z+(Math.random()-.5)*2,p.r*1.2,p.g*1.1,p.b*1.1+.2,.9,.34,.06,.35,2.5,0);this.addP.emit(te.x,te.y,te.z,oi.x*.5,oi.y*.5,oi.z*.5,1,.95,.85,1,.22,.04,.22,3,0)}}if(i.supersonic){te.set(0,0,.5).applyQuaternion(i.rQuat).add(i.rPos);let p=Fe[i.team].glow;this.addP.emit(te.x,te.y,te.z,0,0,0,p.r*.6+.4,p.g*.6+.4,p.b*.6+.4,.55,.28,.02,.5,0,0);for(let g of[-1,1])te.set(g*.42,0,.3).applyQuaternion(i.rQuat).add(i.rPos),this.addP.emit(te.x,te.y,te.z,0,0,0,.7,.85,1,.5,.12,.01,.4,0,0)}i.wheels.forEach((p,g)=>{if(p.contact&&Math.abs(p.slip)>3.2&&p.ny>.9){let m=p.px,f=p.pz,x=t.lastMark[g];x&&(x.x-m)**2+(x.z-f)**2>.04&&(x.x-m)**2+(x.z-f)**2<25&&this.addMark(x,{x:m,z:f},ps(Math.abs(p.slip)/12,.2,.7)),(!x||(x.x-m)**2+(x.z-f)**2>.04)&&(t.lastMark[g]={x:m,z:f}),Math.random()<.5&&this.dust(te.set(m,.05,f),1,2.2)}else t.lastMark[g]=null;p.contact&&d>18&&Math.random()<.12&&p.ny>.9&&this.dust(te.set(p.px,.05,p.pz),1,1.2)})}addMark(t,e,n){let i=e.x-t.x,r=e.z-t.z,a=Math.hypot(i,r)||1,o=-r/a*.07,l=i/a*.07,c=this.markPtr,h=c*12,u=c*16,d=.012,p=this.markPos;p[h]=t.x+o,p[h+1]=d,p[h+2]=t.z+l,p[h+3]=t.x-o,p[h+4]=d,p[h+5]=t.z-l,p[h+6]=e.x+o,p[h+7]=d,p[h+8]=e.z+l,p[h+9]=e.x-o,p[h+10]=d,p[h+11]=e.z-l;for(let g=0;g<4;g++)this.markCol[u+g*4]=.02,this.markCol[u+g*4+1]=.02,this.markCol[u+g*4+2]=.03,this.markCol[u+g*4+3]=n;this.markPtr=(this.markPtr+1)%this.markMax,this.markN=Math.min(this.markMax,this.markN+1),this.markDirty=!0}render(t,e,n){this.time+=e;let i=t.state==="replay",r=t.mode!=="menu";this.showcase.visible=!r,this.dropCars(t.cars);let a=t.rBall.quat,o=t.rBall.pos;this.ballMesh.position.copy(o),this.ballMesh.quaternion.copy(a),this.ballGlow.position.copy(o),this.ballGlowT=Math.max(0,(this.ballGlowT||0)-e*1.6);let l=this.ballGlow.material;l.opacity=this.ballGlowT*.55,this.glowTeam!==void 0&&l.color.copy(Fe[this.glowTeam].glow),this.ballMat.emissiveIntensity=.35+this.ballGlowT*.8,this.glowTeam!==void 0&&this.ballMat.emissive.copy(Fe[this.glowTeam].glow).multiplyScalar(.25+0),this.ballShadow.position.set(o.x,.026,o.z),this.ballShadow.material.opacity=ps(.85-o.y/14,0,.85);let c=1+o.y*.02;if(this.ballShadow.scale.set(c,c,c),r&&!i&&me(t.ball.vel.length())>2500&&Math.random()<.8){let p=this.glowTeam!==void 0?Fe[this.glowTeam].glow:new Ct(.6,.8,1);this.addP.emit(o.x,o.y,o.z,0,0,0,p.r,p.g,p.b,.7,.9,.1,.45,0,0)}for(let d of t.cars)d.rPos&&this.updateCar(this.getCarView(d),e,i);this.padViews.forEach((d,p)=>{let g=d.pad,y=t.pads.pads[p].active;d.spawnAnim=Math.min(1,d.spawnAnim+e*2.2);let m=y?1:0;d.glow+=(m-d.glow)*(1-Math.exp(-e*10)),d.mat.emissiveIntensity=.05+d.glow*.8,d.mat.color.setRGB(.25+d.glow*.75,.18+d.glow*.42,.05+d.glow*.03),d.arrow.visible=y,d.arrow.rotation.z=0,d.orb?(d.orb.visible=y,d.orb.position.y=1.4+Math.sin(this.time*2.2+p)*.18,d.orb.rotation.y=this.time*1.5,d.orb.rotation.x=this.time*.9,d.orb.scale.setScalar(.2+.8*d.spawnAnim),d.beam.visible=y,d.beam.material.opacity=.1+.07*Math.sin(this.time*3+p)):d.base.scale.setScalar(y?.85+.15*d.spawnAnim:.8)}),this.addP.update(e),this.smokeP.update(e);let h=this.camera.fov*Math.PI/180,u=this.height*.5/Math.tan(h/2);if(this.addP.uniforms.uScale.value=u,this.smokeP.uniforms.uScale.value=u,this.twinkleUniforms.uScale.value=u,this.twinkle.value=this.time,this.markDirty){let d=this.markMesh.geometry;d.attributes.position.needsUpdate=!0,d.attributes.color.needsUpdate=!0,d.setDrawRange(0,this.markMax*6),this.markDirty=!1}for(let d=this.rings.length-1;d>=0;d--){let p=this.rings[d];p.t+=e;let g=p.t/p.life;if(g>=1){this.scene.remove(p.m),p.m.material.dispose(),this.rings.splice(d,1);continue}p.m.scale.setScalar(.3+p.maxR*Math.sqrt(g)),p.m.material.opacity=.9*(1-g),p.m.rotation.x===0&&p.m.lookAt(this.camera.position)}this.flash=Math.max(0,this.flash-e*1.4),this.flashLight.intensity=this.flash*2500,this.flashColor!==void 0&&this.flashLight.color.setHex(this.flashColor),this.gl.toneMappingExposure=.95+this.flash*.5,this.gl.render(this.scene,this.camera)}};var Oe=(s,t,e)=>Math.max(t,Math.min(e,s)),Oh=s=>{for(;s>Math.PI;)s-=2*Math.PI;for(;s<-Math.PI;)s+=2*Math.PI;return s},Sn=Math.PI/180,cn=gt.arena,Ti=new C,Hn=new C;function ms(s,t,e,n,i=1/0,r=!1){let a=r?Oh(s.x-t):s.x-t,o=Math.exp(-e*n),l=(s.v+e*a)*n,c=(s.v-e*l)*o,h=-a+(a+l)*o,u=i*n;Math.abs(h)>u&&(h=Math.sign(h)*u,c=Oe(c,-i,i)),s.x=r?Oh(s.x+h):s.x+h,s.v=c}var Ea=class s{constructor(t,e){this.cam=t,this.P=e,this.settings={...gt.camera},this.yaw={x:0,v:0},this.pitch={x:-.07,v:0},this.dist={x:2.7,v:0},this.lift={x:0,v:0},this.lookYaw={x:0,v:0},this.lookPitch={x:0,v:0},this.headingYaw=0,this.aspect=16/9,this.vfov=1,this.initialized=!1,this.shake=0,this.replayPos=new C,this.setAspect(this.aspect)}setAspect(t){this.aspect=t,this.applyFov(0)}applyFov(t){let e=(this.settings.hFov+t)*Sn,n=2*Math.atan(Math.tan(e/2)/this.aspect);this.vfov=Oe(n,20*Sn,120*Sn),this.cam.fov=this.vfov/Sn,this.cam.aspect=this.aspect,this.cam.updateProjectionMatrix()}static yawOf(t,e){return Math.atan2(-t,-e)}update(t){let e=this.settings,n=Math.min(t.dt,.05),i=t.carPos,r=t.ballPos,a=this.headingYaw,o=Ti.set(r.x-i.x,0,r.z-i.z),l=o.length();if(t.ballCam)l>1.2&&(a=s.yawOf(o.x,o.z));else{let O=t.carFwd,$=Math.hypot(O.x,O.z),ht=t.carVel,ft=Math.hypot(ht.x,ht.z);t.onGround&&$>.35?a=s.yawOf(O.x,O.z):ft>4?a=s.yawOf(ht.x,ht.z):$>.35&&t.onGround&&(a=s.yawOf(O.x,O.z))}this.headingYaw=a,this.initialized||(this.yaw.x=a,this.yaw.v=0);let c=t.ballCam?4+e.stiffness*8:3+e.stiffness*10;ms(this.yaw,a,c,n,e.swivelSpeed*1.4,!0);let h=Oe(t.speed/gt.car.maxSpeed,0,1),u=e.distance*.01*(1+.12*h),d=e.height*.01,p=r.y-i.y;if(t.ballCam&&p>1&&l<10){let O=Oe((p-1)/6,0,1)*Oe(1-l/10,0,1);u*=1+.5*O,d*=1+.6*O}this.initialized||(this.dist.x=u,this.lift.x=d),ms(this.dist,u,4,n),ms(this.lift,d,4,n);let g=t.look||{x:0,y:0};ms(this.lookYaw,-(g.x||0)*e.freeLookMax,e.swivelSpeed*2,n),ms(this.lookPitch,-(g.y||0)*.7,e.swivelSpeed*2,n);let y=this.yaw.x+this.lookYaw.x,m=-Math.sin(y),f=-Math.cos(y),x=Hn.set(i.x,i.y+.25,i.z),_=x.x-m*this.dist.x,M=x.y+this.lift.x,E=x.z-f*this.dist.x,w=_-x.x,A=M-x.y,U=E-x.z,v=Math.hypot(w,A,U);w/=v,A/=v,U/=v;let b=this.P.rayArenaCast(x.x,x.y,x.z,w,A,U,v+.4);if(b&&b.ny>.45){let O=Math.max(.8,b.toi-.4);O<v&&(_=x.x+w*O,M=x.y+A*O,E=x.z+U*O)}let F=()=>{M=Oe(M,.35,cn.height-.5),_=Oe(_,-cn.halfWidth-3.5,cn.halfWidth+3.5),E=Oe(E,-cn.halfLength-cn.goalDepth,cn.halfLength+cn.goalDepth)};F();let k=1.9,nt=_-x.x,L=M-x.y,N=E-x.z;if(Math.hypot(nt,L,N)<k){let O=-x.x,$=7-x.y,ht=-x.z,ft=Math.hypot(O,$,ht)||1;nt+=O/ft*k,L+=$/ft*k*.6+.3,N+=ht/ft*k;let dt=Math.hypot(nt,L,N)||1,X=x.x+nt/dt*k*1.2,Q=x.y+L/dt*k*1.2,tt=x.z+N/dt*k*1.2;this.swing||(this.swing={x:_,y:M,z:E}),_=X,M=Q,E=tt,F()}(!this.smoothPos||!this.initialized)&&(this.smoothPos=new C(_,M,E));let V=1-Math.exp(-n*14);this.smoothPos.x+=(_-this.smoothPos.x)*V,this.smoothPos.y+=(M-this.smoothPos.y)*V,this.smoothPos.z+=(E-this.smoothPos.z)*V;{let O=_-this.smoothPos.x,$=M-this.smoothPos.y,ht=E-this.smoothPos.z,ft=Math.hypot(O,$,ht);if(ft>.6){let dt=(ft-.6)/ft;this.smoothPos.x+=O*dt,this.smoothPos.y+=$*dt,this.smoothPos.z+=ht*dt}}_=this.smoothPos.x,M=this.smoothPos.y,E=this.smoothPos.z;let et=this.vfov/2-6*Sn,Y=(O,$,ht)=>Math.atan2($-M,Math.max(.3,Math.hypot(O-_,ht-E))),J=Y(i.x,i.y,i.z),D=Y(r.x,r.y,r.z),j=e.angle*Sn,rt;if(t.ballCam){let O=Math.max(D,J)-et,$=Math.min(D,J)+et;rt=O<=$?Oe(j,O,$):Oe(j,D-et,D+et)}else rt=Oe(j,J-et,J+et);rt=Oe(rt,-65*Sn,60*Sn),this.initialized||(this.pitch.x=rt),ms(this.pitch,rt,7,n,3),this.cam.position.set(_,M,E),this.shake>0&&(this.cam.position.x+=(Math.random()-.5)*this.shake*.25,this.cam.position.y+=(Math.random()-.5)*this.shake*.25,this.shake=Math.max(0,this.shake-n*2.5)),this.cam.up.set(0,1,0),this.cam.rotation.set(Oe(this.pitch.x+this.lookPitch.x,-80*Sn,80*Sn),y,0,"YXZ"),this.applyFov(h*4+(t.boosting?2:0)),this.initialized=!0}updateReplay(t,e,n){let i=1-Math.exp(-t*2.5);Ti.copy(e).sub(n),Ti.y=0,Ti.lengthSq()<1e-4&&Ti.set(0,0,1),Ti.normalize(),Hn.copy(e).addScaledVector(Ti,14),Hn.y=Oe(e.y+5.5,2,cn.height-1),Hn.x=Oe(Hn.x,-cn.halfWidth+1,cn.halfWidth-1),Hn.z=Oe(Hn.z,-cn.halfLength+1,cn.halfLength-1),this.initialized||(this.replayPos.copy(Hn),this.initialized=!0),this.replayPos.lerp(Hn,i),this.cam.position.copy(this.replayPos),this.cam.up.set(0,1,0),this.cam.lookAt(e),this.applyFov(-25)}orbit(t,e=55,n=22){this.cam.position.set(Math.cos(t*.15)*e,n,Math.sin(t*.15)*e*1.4),this.cam.up.set(0,1,0),this.cam.lookAt(0,3,0),this.applyFov(-40),this.initialized=!1}};var Vn=(s,t,e)=>Math.max(t,Math.min(e,s)),wa=class{constructor(t){this.ctx=null,this.muted=gt.audio.mute,this.volume=gt.audio.master,this.engines=new Map,this.bus=t,this.ready=!1;let e=()=>{this.init()};for(let n of["pointerdown","keydown","touchstart"])window.addEventListener(n,e,{once:!1,passive:!0});this.subscribe()}init(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume().catch(()=>{});return}let t=window.AudioContext||window.webkitAudioContext;if(!t)return;try{this.ctx=new t}catch{return}let e=this.ctx;this.master=e.createGain(),this.master.gain.value=this.muted?0:this.volume;let n=e.createDynamicsCompressor();n.threshold.value=-14,n.ratio.value=4,this.master.connect(n),n.connect(e.destination);let i=e.sampleRate*2,r=e.createBuffer(1,i,e.sampleRate),a=r.getChannelData(0);for(let l=0;l<i;l++)a[l]=Math.random()*2-1;this.noiseBuf=r;let o=(l,c,h)=>{let u=e.createBufferSource();u.buffer=r,u.loop=!0,u.playbackRate.value=.7+Math.random()*.6;let d=e.createBiquadFilter();d.type=l,d.frequency.value=c,d.Q.value=h;let p=e.createGain();return p.gain.value=0,u.connect(d),d.connect(p),p.connect(this.master),u.start(),{s:u,f:d,g:p}};this.boostSnd=o("bandpass",700,.7),this.tireSnd=o("bandpass",1500,2.5),this.windSnd=o("highpass",2200,.5),this.crowd=o("lowpass",650,.4),this.crowd.g.gain.value=.05,this.crowd2=o("bandpass",1100,.6),this.crowd2.g.gain.value=.03,this.ready=!0,e.state==="suspended"&&e.resume().catch(()=>{})}setMute(t){this.muted=t,this.master&&this.master.gain.setTargetAtTime(t?0:this.volume,this.ctx.currentTime,.02)}setVolume(t){this.volume=t,this.master&&!this.muted&&this.master.gain.setTargetAtTime(t,this.ctx.currentTime,.02)}env(t,e,n,i,r){t.gain.cancelScheduledValues(e),t.gain.setValueAtTime(1e-4,e),t.gain.exponentialRampToValueAtTime(i,e+n),t.gain.exponentialRampToValueAtTime(1e-4,e+n+r)}tone(t,e,n=.2,i="sine",r=null,a=0){if(!this.ready)return;let o=this.ctx,l=o.currentTime+a,c=o.createOscillator(),h=o.createGain();c.type=i,c.frequency.setValueAtTime(t,l),r&&c.frequency.exponentialRampToValueAtTime(r,l+e),this.env(h,l,.005,n,e),c.connect(h),h.connect(this.master),c.start(l),c.stop(l+e+.05)}noise(t,e,n=.2,i="lowpass",r=.7,a=0,o=null){if(!this.ready)return;let l=this.ctx,c=l.currentTime+a,h=l.createBufferSource();h.buffer=this.noiseBuf,h.playbackRate.value=.6+Math.random()*.8;let u=l.createBiquadFilter();u.type=i,u.frequency.setValueAtTime(e,c),u.Q.value=r,o&&u.frequency.exponentialRampToValueAtTime(o,c+t);let d=l.createGain();this.env(d,c,.004,n,t),h.connect(u),u.connect(d),d.connect(this.master),h.start(c,Math.random()),h.stop(c+t+.05)}subscribe(){let t=this.bus;t.on("ballHit",e=>{let n=Vn(me(e.power)/2300,.05,1.5);this.tone(130+60*(1-n),.22,.28+n*.3,"sine",55),this.noise(.12,2500,.15+n*.3,"bandpass",1.2),n>.6&&this.tone(900,.08,.1,"square",300)}),t.on("ballImpact",e=>{let n=Vn(e.power/20,.05,1);this.tone(100+40*(1-n),.18,.08+n*.25,"sine",50),this.noise(.08,1800,.05+n*.15,"bandpass",1.5)}),t.on("jump",()=>{this.noise(.12,600,.12,"lowpass",.8,0,200),this.tone(180,.1,.1,"triangle",120)}),t.on("dodge",()=>{this.noise(.28,1200,.2,"bandpass",1,0,3500)}),t.on("land",e=>{let n=Vn(e.power,.1,1);this.tone(90,.16,.2*n+.05,"sine",45),this.noise(.1,700,.1*n,"lowpass")}),t.on("carBump",e=>{this.noise(.15,900,Vn(e.power/30,.05,.4),"bandpass",.8),this.tone(70,.18,.2,"sine",40)}),t.on("demolish",()=>{this.noise(.9,1800,.6,"lowpass",.6,0,120),this.tone(80,.7,.5,"sawtooth",25),this.tone(300,.2,.2,"square",60)}),t.on("padPickup",e=>{e.car&&!e.car.isHuman||(this.tone(e.pad.large?520:760,.14,.14,"sine",e.pad.large?980:1100),this.tone(e.pad.large?780:1140,.18,.08,"triangle",null,.04))}),t.on("count",()=>this.tone(520,.2,.25,"square")),t.on("go",()=>{this.tone(1040,.5,.28,"square"),this.tone(1560,.5,.12,"sine")}),t.on("goal",e=>{for(let[n,i]of[[262,0],[330,.02],[392,.04],[523,.06]])this.tone(n,1.8,.14,"sawtooth",n*.99,i);this.noise(1.6,900,.4,"bandpass",.5,0,300),this.tone(60,1.2,.5,"sine",30),this.crowdBoost=3.5}),t.on("overtime",()=>{this.tone(220,1,.2,"sawtooth",440)}),t.on("ended",()=>{this.tone(392,.4,.2,"triangle"),this.tone(523,.6,.2,"triangle",null,.25),this.tone(659,.9,.2,"triangle",null,.5)}),t.on("ui",()=>this.tone(660,.06,.1,"square"))}uiClick(){this.tone(700,.05,.08,"square")}engine(t){let e=this.engines.get(t);if(!e){let n=this.ctx,i=n.createOscillator(),r=n.createOscillator(),a=n.createOscillator(),o=n.createBiquadFilter(),l=n.createGain(),c=n.createStereoPanner();i.type="sawtooth",r.type="square",a.type="sine",o.type="lowpass",o.frequency.value=600,o.Q.value=3,l.gain.value=0;let h=n.createGain(),u=n.createGain();h.gain.value=.4,u.gain.value=.6,i.connect(o),r.connect(h),h.connect(o),a.connect(u),u.connect(o),o.connect(l),l.connect(c),c.connect(this.master),i.start(),r.start(),a.start(),e={o1:i,o2:r,o3:a,f:o,g:l,p:c},this.engines.set(t,e)}return e}update(t,e,n,i,r){if(!this.ready)return;let a=this.ctx.currentTime;for(let[u,d]of this.engines)t.cars.includes(u)||(d.g.gain.setTargetAtTime(0,a,.05),setTimeout(()=>{try{d.o1.stop(),d.o2.stop(),d.o3.stop()}catch{}},300),this.engines.delete(u));let o=0,l=0,c=0;for(let u of t.cars){let d=this.engine(u);if(!r||u.demolished){d.g.gain.setTargetAtTime(0,a,.05);continue}let p=Vn(u.speed/gt.car.maxSpeed,0,1.1),g=Math.abs(u.ctrl.throttle)+(u.boosting?.6:0),y=48+p*150+g*22+(u.contacts===0?20:0);d.o1.frequency.setTargetAtTime(y,a,.04),d.o2.frequency.setTargetAtTime(y*.5,a,.04),d.o3.frequency.setTargetAtTime(y*.25,a,.04),d.f.frequency.setTargetAtTime(350+p*900+g*500,a,.05),vl.copy(u.currT).sub(n);let m=vl.length(),f=u.isHuman?1:1/(1+m*.07);d.g.gain.setTargetAtTime((.05+g*.035+p*.03)*f,a,.05),d.p.pan.setTargetAtTime(u.isHuman?0:Vn(vl.normalize().dot(i),-1,1),a,.05);let x=f;u.boosting&&(l=Math.max(l,x)),o=Math.max(o,Vn(u.slipAmount/10,0,1)*x*(u.contacts?1:0)),c=Math.max(c,Vn(p-.55,0,.5)*2*(u.isHuman?1:.4))}this.boostSnd.g.gain.setTargetAtTime(l*.16,a,.04),this.boostSnd.f.frequency.setTargetAtTime(600+l*500,a,.1),this.tireSnd.g.gain.setTargetAtTime(o*.12,a,.05),this.windSnd.g.gain.setTargetAtTime(c*.06,a,.1),this.crowdBoost=Math.max(0,(this.crowdBoost||0)-e);let h=Vn(this.crowdBoost,0,1)+(t.mode==="versus"?.08:0);this.crowd.g.gain.setTargetAtTime(.03+h*.18+.02*Math.sin(performance.now()/1500),a,.2),this.crowd2.g.gain.setTargetAtTime(.015+h*.1,a,.2)}silenceAll(){if(!this.ready)return;let t=this.ctx.currentTime;for(let e of this.engines.values())e.g.gain.setTargetAtTime(0,t,.05);this.boostSnd.g.gain.setTargetAtTime(0,t,.05),this.tireSnd.g.gain.setTargetAtTime(0,t,.05),this.windSnd.g.gain.setTargetAtTime(0,t,.05)}},vl=new C;var Bt=s=>document.getElementById(s),zh="rl3d.ui.v2",C0=[["throttle","Throttle / Pitch down"],["brake","Brake / Reverse / Pitch up"],["left","Steer left / Yaw"],["right","Steer right / Yaw"],["jump","Jump / Dodge"],["boost","Boost"],["powerslide","Powerslide / Air roll"],["rollLeft","Air roll left"],["rollRight","Air roll right"],["ballCam","Toggle ball cam"],["reset","Reset (Free Play)"],["pause","Pause"],["lookLeft","Look left"],["lookRight","Look right"],["lookUp","Look up"],["lookDown","Look down"]],Ta=class{constructor(t){this.app=t,this.settings={volume:gt.audio.master,mute:!1,showFps:!1,fov:gt.camera.hFov,dist:gt.camera.distance,height:gt.camera.height,angle:gt.camera.angle,stiff:gt.camera.stiffness,swivel:gt.camera.swivelSpeed},this.load(),this.current=null,this.msgTimer=0,this.subTimer=0,this.prevScreen=null,this.wire(),this.applySettings()}load(){try{Object.assign(this.settings,JSON.parse(localStorage.getItem(zh)||"{}"))}catch{}}save(){try{localStorage.setItem(zh,JSON.stringify(this.settings))}catch{}}applySettings(){let t=this.settings,e=this.app;Object.assign(e.cam.settings,{hFov:t.fov,distance:t.dist,height:t.height,angle:t.angle,stiffness:t.stiff,swivelSpeed:t.swivel}),e.cam.applyFov(0),e.audio.setVolume(t.volume),e.audio.setMute(t.mute),Bt("fps").classList.toggle("hidden",!t.showFps)}wire(){let t=this.app;document.querySelectorAll("[data-start]").forEach(a=>a.addEventListener("click",()=>{t.audio.init(),t.bus.emit("ui"),t.startGame(a.dataset.start,Bt("difficulty").value)})),Bt("btn-settings").addEventListener("click",()=>this.openSettings("menu")),Bt("btn-pause-settings").addEventListener("click",()=>this.openSettings("pause")),Bt("btn-resume").addEventListener("click",()=>t.setPaused(!1)),Bt("btn-restart").addEventListener("click",()=>{t.match.restart(),t.setPaused(!1)}),Bt("btn-quit").addEventListener("click",()=>t.quitToMenu()),Bt("btn-rematch").addEventListener("click",()=>{t.match.restart(),this.showScreen(null),this.showHud(!0)}),Bt("btn-res-menu").addEventListener("click",()=>t.quitToMenu()),Bt("btn-settings-close").addEventListener("click",()=>this.closeSettings()),document.querySelectorAll("#practice [data-preset]").forEach(a=>a.addEventListener("click",()=>t.match.setPreset(a.dataset.preset))),document.querySelectorAll("#practice [data-act]").forEach(a=>a.addEventListener("click",()=>t.practiceAction(a.dataset.act))),document.querySelectorAll(".tabs button").forEach(a=>a.addEventListener("click",()=>{document.querySelectorAll(".tabs button").forEach(o=>o.classList.toggle("on",o===a)),document.querySelectorAll(".tab").forEach(o=>o.classList.toggle("on",o.id===a.dataset.tab))}));let e=(a,o,l,c=h=>h)=>{let h=Bt(a),u=h.parentElement.querySelector("output");h.value=o(),u.textContent=c(+h.value),h.addEventListener("input",()=>{l(+h.value),u.textContent=c(+h.value),this.save(),t.input.save(),this.applySettings()})},n=this.settings,i=t.input.settings;e("s-volume",()=>n.volume,a=>n.volume=a,a=>Math.round(a*100)+"%"),e("s-fov",()=>n.fov,a=>n.fov=a,a=>a+"\xB0"),e("s-dist",()=>n.dist,a=>n.dist=a),e("s-height",()=>n.height,a=>n.height=a),e("s-angle",()=>n.angle,a=>n.angle=a,a=>a.toFixed(1)),e("s-stiff",()=>n.stiff,a=>n.stiff=a,a=>a.toFixed(2)),e("s-swivel",()=>n.swivel,a=>n.swivel=a,a=>a.toFixed(1)),e("s-steer",()=>i.steerSensitivity,a=>i.steerSensitivity=a,a=>a.toFixed(2)),e("s-dz",()=>i.stickDeadzone,a=>i.stickDeadzone=a,a=>a.toFixed(2)),e("s-dodge",()=>i.dodgeDeadzone,a=>i.dodgeDeadzone=a,a=>a.toFixed(2)),e("s-mouse",()=>i.mouseSensitivity,a=>i.mouseSensitivity=a,a=>a.toFixed(4));let r=(a,o,l)=>{let c=Bt(a);c.checked=o(),c.addEventListener("change",()=>{l(c.checked),this.save(),t.input.save(),this.applySettings()})};r("s-mute",()=>n.mute,a=>n.mute=a),r("s-fps",()=>n.showFps,a=>n.showFps=a),r("s-ballcam",()=>i.ballCamDefault!==!1,a=>i.ballCamDefault=a),Bt("btn-keys-reset").addEventListener("click",()=>{t.input.resetBindings(),this.buildKeys()}),this.buildKeys()}buildKeys(){let t=Bt("keylist");t.innerHTML="";for(let[e,n]of C0){let i=document.createElement("div");i.className="k";let r=document.createElement("span");r.textContent=n;let a=document.createElement("button");a.textContent=this.app.input.bindings[e].map(Uh).join(" / "),a.addEventListener("click",()=>{a.textContent="press a key\u2026",a.classList.add("wait"),this.app.input.captureNext(o=>{a.classList.remove("wait"),o&&this.app.input.rebind(e,o),this.buildKeys()})}),i.append(r,a),t.append(i)}}showScreen(t){for(let e of["menu","pause","results","settings"])Bt(e).classList.toggle("hidden",e!==t);this.current=t}showHud(t){Bt("hud").classList.toggle("hidden",!t)}openSettings(t){this.prevScreen=t,this.buildKeys(),this.showScreen("settings")}closeSettings(){this.showScreen(this.prevScreen==="pause"?"pause":"menu"),this.save(),this.app.input.save()}showResults(t){let n=t.winner;Bt("res-title").textContent=n===-1?"DRAW":n===0?"VICTORY":"DEFEAT",Bt("res-score").innerHTML=`<span class="blue">${t.scores[0]}</span> \u2013 <span class="orange">${t.scores[1]}</span>`;let i=t.stats,r=(a,o,l)=>`<tr><td>${a}</td><td>${o}</td><td>${l}</td></tr>`;Bt("res-stats").innerHTML=r("","You","Bot")+r("Goals",t.scores[0],t.scores[1])+r("Ball touches",i.touches[0],i.touches[1])+r("Demolitions",i.demos[0],i.demos[1]),this.showScreen("results")}say(t,e,n,i=1.4,r=!0){let a=Bt("center-msg");a.textContent=t,a.style.color=e||"#fff",a.style.opacity=1,a.classList.remove("pop"),r&&(a.offsetWidth,a.classList.add("pop")),this.msgTimer=i,n!==void 0&&(Bt("sub-msg").textContent=n,this.subTimer=i)}sub(t,e=2){Bt("sub-msg").textContent=t,this.subTimer=e}update(t,e){this.msgTimer>0&&(this.msgTimer-=t,this.msgTimer<=0&&(Bt("center-msg").textContent="")),this.subTimer>0&&(this.subTimer-=t,this.subTimer<=0&&(Bt("sub-msg").textContent=""));let n=e.match;Bt("score-blue").textContent=n.scores[0],Bt("score-orange").textContent=n.scores[1];let i=Bt("clock");if(n.mode==="freeplay")i.textContent="\u221E",Bt("clock-sub").textContent="Free play",i.classList.remove("low");else if(n.overtime){let c=n.overtimeTime;i.textContent="+"+Math.floor(c/60)+":"+String(Math.floor(c%60)).padStart(2,"0"),Bt("clock-sub").textContent="Overtime",i.classList.add("low")}else{let c=Math.max(0,Math.ceil(n.timeLeft));i.textContent=Math.floor(c/60)+":"+String(c%60).padStart(2,"0"),Bt("clock-sub").textContent="",i.classList.toggle("low",c<=30)}let r=n.human;if(r){let c=Math.round(r.boost),h=Bt("boost-ring");Bt("boost-num").textContent=r.unlimitedBoost?"\u221E":c,h.style.strokeDashoffset=String(326.7*(1-(r.unlimitedBoost?1:r.boost/100))),Bt("boost").classList.toggle("boosting",r.boosting);let u=Math.round(me(r.speed)*.036);Bt("speed-num").textContent=u;let d=Math.max(0,Math.min(1,(me(r.speed)-1500)/800));Bt("speedfx").style.opacity=String(d*.9)}let a=Bt("camstatus");a.textContent=e.ballCam?"BALL CAM":"CAR CAM",a.classList.toggle("on",e.ballCam),Bt("practice").classList.toggle("hidden",n.mode!=="freeplay"||!e.practiceVisible),Bt("ub-state").textContent=n.unlimitedBoost?"on":"off",Bt("replay-tag").classList.toggle("hidden",n.state!=="replay");let o=Bt("ball-ind");e.ballScreen&&e.ballScreen.off&&n.state!=="replay"?(o.style.display="block",o.style.left=e.ballScreen.x+"px",o.style.top=e.ballScreen.y+"px",o.style.transform=`rotate(${e.ballScreen.angle}rad)`):o.style.display="none";let l=Bt("flashfx");l.style.opacity=String(e.flash||0),e.fps!==void 0&&this.settings.showFps&&(Bt("fps").textContent=e.fps.toFixed(0)+" fps")}};var qs=document.getElementById("loading"),Ml=document.getElementById("loading-text");function Bh(s){console.error(s),qs.classList.add("err"),qs.classList.remove("hidden"),Ml.innerHTML="Failed to start the game.<br><small>"+String(s&&s.message||s).replace(/</g,"&lt;")+"</small><br><small>Serve this folder over HTTP (e.g. <code>python3 -m http.server 8000</code>) and use a WebGL2-capable browser.</small>"}window.addEventListener("error",s=>{qs&&!qs.classList.contains("hidden")&&Bh(s.error||s.message)});async function P0(){let s=document.getElementById("game"),t=Lh();Ml.textContent="Starting physics engine (WebAssembly)\u2026";let e=await ha.create(t);Ml.textContent="Building arena\u2026";let n=new va,i=new ua(s),r=new Ma(e,t,i,n),a=new Sa(s,t,n),o=new Ea(a.camera,e),l=new wa(n),c={match:r,input:i,renderer:a,cam:o,audio:l,bus:n,physics:e,ui:null,practiceVisible:!0};c.setPaused=E=>{r.mode==="menu"||r.state==="ended"||(r.paused=E,c._pauseT=performance.now(),c.ui.showScreen(E?"pause":null),c.ui.showHud(!0),E?(i.releasePointerLock(),l.silenceAll()):i.requestPointerLock())},c.startGame=(E,w)=>{i.ballCam=i.settings.ballCamDefault!==!1,E==="freeplay"?r.startFreePlay():r.startVersus(w),a.markN=0,o.initialized=!1,c.ui.showScreen(null),c.ui.showHud(!0),i.requestPointerLock()},c.quitToMenu=()=>{r.quitToMenu(),c.ui.showScreen("menu"),c.ui.showHud(!1),i.releasePointerLock(),l.silenceAll(),document.getElementById("speedfx").style.opacity=0},c.practiceAction=E=>{r.mode==="freeplay"&&(E==="resetAll"?r.resetAll():E==="resetBall"?r.resetBall():E==="launch"?r.launchBall():E==="boost"&&r.toggleUnlimitedBoost())};let h=c.ui=new Ta(c),u=["#3b9bff","#ff8a2b"];n.on("count",E=>h.say(String(E.n),"#fff",void 0,.95)),n.on("go",()=>h.say("GO!","#7dffa0","",.8)),n.on("kickoff",()=>{o.initialized=!1}),n.on("goal",E=>{let w=E.by?E.by.isHuman?"You":"Bot":"";h.say((E.freeplay,"GOAL!"),u[E.team],w?`${w} scored \xB7 ${Math.round(E.speed||0)} uu/s`:"",2.2)}),n.on("overtime",()=>h.say("OVERTIME","#ffd36b","Next goal wins",2.5)),n.on("demolish",E=>{E.victim.isHuman?h.say("DEMOLISHED","#ff6a6a","Respawning\u2026",2.6,!1):E.attacker.isHuman&&h.sub("DEMOLITION",1.5)}),n.on("replayStart",()=>{o.initialized=!1}),n.on("ended",E=>{setTimeout(()=>{r.state==="ended"&&r.mode==="versus"&&(h.showResults(E),i.releasePointerLock())},gt.match.resultsDelay*1e3),h.say("FULL TIME","#fff","",1.6)}),n.on("matchStart",()=>{document.getElementById("boost").classList.toggle("orange",!1)}),window.addEventListener("keydown",E=>{if(!(E.target&&/^(INPUT|SELECT|TEXTAREA)$/.test(E.target.tagName))&&!i.capturing){if(r.state==="replay"&&(E.code==="Space"||E.code==="Enter")){r.skipReplay();return}if(r.mode==="freeplay"&&!r.paused&&h.current===null){let w=E.code;w==="KeyT"?r.resetBall():w==="KeyG"?r.launchBall():w==="KeyB"?r.toggleUnlimitedBoost():w==="Tab"?(E.preventDefault(),c.practiceVisible=!c.practiceVisible):/^Digit[1-6]$/.test(w)&&r.setPreset(["kickoff","shot","dribble","aerial","wall","defend"][+w.slice(5)-1])}}}),s.addEventListener("click",()=>{l.init(),r.mode!=="menu"&&!r.paused&&h.current===null&&i.requestPointerLock()}),document.addEventListener("pointerlockchange",()=>{!document.pointerLockElement&&r.mode!=="menu"&&!r.paused&&r.state!=="ended"&&h.current===null&&c._lockWanted&&performance.now()-(c._pauseT||0)>400&&c.setPaused(!0)}),setInterval(()=>{c._lockWanted=i.pointerLocked},100),window.addEventListener("resize",()=>o.setAspect(a.resize())),window.addEventListener("blur",()=>{r.mode!=="menu"&&!r.paused&&r.state!=="ended"&&h.current===null&&c.setPaused(!0)}),o.setAspect(a.resize());let d=new C,p=new C,g=new C,y=new C,m=performance.now(),f=0,x=0,_=60;c.practiceVisible=!0;function M(E){requestAnimationFrame(M);let w=(E-m)/1e3;m=E,w=Math.min(Math.max(w,1e-4),.1),f+=w,x++,f>.5&&(_=x/f,f=0,x=0);let A=r.mode!=="menu",U=A&&!r.paused&&h.current===null,v=i.get(w);A&&(i.edges.pause&&r.state!=="ended"&&performance.now()-(c._pauseT||0)>400&&c.setPaused(!r.paused&&h.current===null),i.edges.reset&&r.mode==="freeplay"&&U&&r.resetAll()),r.human&&(r.human.dodgeDeadzone=i.settings.dodgeDeadzone),r.humanCtrl=U?v:i.neutral(),r.human&&i.settings.steerSensitivity!==1&&(r.humanCtrl.steer=Math.max(-1,Math.min(1,r.humanCtrl.steer*i.settings.steerSensitivity))),r.frame(U||A&&h.current==="results"?w:A?0:w);let b=r.human;if(!A||!b)o.orbit(a.time+6);else if(r.state==="replay"||r.state==="goal"){let nt=r.lastScorer===0?gt.arena.halfLength:-gt.arena.halfLength;o.updateReplay(w,r.rBall.pos,d.set(0,0,nt))}else r.state==="ended"?o.orbit(a.time):(p.set(0,0,-1).applyQuaternion(b.rQuat),o.update({dt:w,carPos:b.rPos,carFwd:p,carVel:b.vel,onGround:b.contacts>=3,speed:b.speed,boosting:b.boosting,ballPos:r.rBall.pos,ballCam:i.ballCam,look:i.look,hasCar:!0}));a.camShake&&(o.shake=Math.max(o.shake,a.camShake),a.camShake=0),a.render(r,w),A&&!r.paused&&a.adaptQuality(_,w);let F=A&&!r.paused&&(r.state==="playing"||r.state==="goal"||r.state==="countdown");y.set(1,0,0).applyQuaternion(a.camera.quaternion),l.update(r,w,a.camera.position,y,F);let k=null;if(A&&b){g.copy(r.rBall.pos).project(a.camera);let nt=g.z>1,L=g.x,N=g.y;nt&&(L=-L,N=-N);let V=nt||Math.abs(L)>.94||Math.abs(N)>.9;if(V){let J=Math.max(Math.abs(L)/.9,Math.abs(N)/.84,.001);L/=J,N/=J,nt&&Math.abs(L)<.05&&Math.abs(N)<.05&&(N=-.84)}let et=a.width,Y=a.height;k={off:V,x:(L*.5+.5)*et,y:(-N*.5+.5)*Y,angle:Math.atan2(L,N)*1+0},k.angle=Math.atan2(- -N,L)+Math.PI/2,k.angle=Math.atan2(L,N)}h.update(w,{match:r,ballCam:i.ballCam,ballScreen:k,fps:_,flash:0,practiceVisible:c.practiceVisible})}qs.classList.add("hidden"),h.showScreen("menu"),requestAnimationFrame(M),window.__game=c}P0().catch(Bh);
/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */
