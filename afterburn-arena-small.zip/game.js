var Xh=0,Rl=1,qh=2;var ah=1,Yh=2,Cn=3,Qn=0,Te=1,Ge=2;var Zn=0,Jn=1,mn=2,Cl=3,Pl=4,Zh=5,fi=100,Jh=101,$h=102,Ll=103,Il=104,Kh=200,Qh=201,jh=202,tu=203,uo=204,fo=205,eu=206,nu=207,iu=208,su=209,ru=210,au=211,ou=212,lu=213,cu=214,hu=0,uu=1,du=2,Mr=3,fu=4,pu=5,mu=6,gu=7,oh=0,_u=1,xu=2,$n=0,yu=1,vu=2,Mu=3,rl=4,bu=5,Su=6;var lh=300,Yi=301,Zi=302,po=303,mo=304,na=306,As=1e3,fn=1001,go=1002,Ve=1003,Dl=1004;var Ca=1005;var Qe=1006,Eu=1007;var Rs=1008;var Kn=1009,wu=1010,Tu=1011,al=1012,ch=1013,qn=1014,Yn=1015,Cs=1016,hh=1017,uh=1018,mi=1020,Au=1021,pn=1023,Ru=1024,Cu=1025,gi=1026,Ji=1027,Pu=1028,dh=1029,Lu=1030,fh=1031,ph=1033,Pa=33776,La=33777,Ia=33778,Da=33779,Ul=35840,Nl=35841,Fl=35842,Ol=35843,mh=36196,zl=37492,Bl=37496,kl=37808,Hl=37809,Vl=37810,Gl=37811,Wl=37812,Xl=37813,ql=37814,Yl=37815,Zl=37816,Jl=37817,$l=37818,Kl=37819,Ql=37820,jl=37821,Ua=36492,tc=36494,ec=36495,Iu=36283,nc=36284,ic=36285,sc=36286;var br=2300,Sr=2301,Na=2302,rc=2400,ac=2401,oc=2402;var gh=3e3,_i=3001,Du=3200,Uu=3201,_h=0,Nu=1,je="",xe="srgb",In="srgb-linear",ol="display-p3",ia="display-p3-linear",Er="linear",ae="srgb",wr="rec709",Tr="p3";var Ei=7680;var lc=519,Fu=512,Ou=513,zu=514,xh=515,Bu=516,ku=517,Hu=518,Vu=519,cc=35044;var hc="300 es",_o=1035,Ln=2e3,Ar=2001,jn=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let i=this._listeners[t];if(i!==void 0){let r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let i=n.slice(0);for(let r=0,a=i.length;r<a;r++)i[r].call(this,t);t.target=null}}},Ue=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];var Fa=Math.PI/180,xo=180/Math.PI;function ns(){let s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ue[s&255]+Ue[s>>8&255]+Ue[s>>16&255]+Ue[s>>24&255]+"-"+Ue[t&255]+Ue[t>>8&255]+"-"+Ue[t>>16&15|64]+Ue[t>>24&255]+"-"+Ue[e&63|128]+Ue[e>>8&255]+"-"+Ue[e>>16&255]+Ue[e>>24&255]+Ue[n&255]+Ue[n>>8&255]+Ue[n>>16&255]+Ue[n>>24&255]).toLowerCase()}function Fe(s,t,e){return Math.max(t,Math.min(e,s))}function Gu(s,t){return(s%t+t)%t}function Oa(s,t,e){return(1-e)*s+e*t}function uc(s){return(s&s-1)===0&&s!==0}function yo(s){return Math.pow(2,Math.floor(Math.log(s)/Math.LN2))}function ps(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function We(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}var mt=class s{constructor(t=0,e=0){s.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Fe(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*i+t.x,this.y=r*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Yt=class s{constructor(t,e,n,i,r,a,o,l,c){s.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c)}set(t,e,n,i,r,a,o,l,c){let h=this.elements;return h[0]=t,h[1]=i,h[2]=o,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],y=i[0],m=i[3],p=i[6],x=i[1],_=i[4],M=i[7],T=i[2],E=i[5],R=i[8];return r[0]=a*y+o*x+l*T,r[3]=a*m+o*_+l*E,r[6]=a*p+o*M+l*R,r[1]=c*y+h*x+u*T,r[4]=c*m+h*_+u*E,r[7]=c*p+h*M+u*R,r[2]=d*y+f*x+g*T,r[5]=d*m+f*_+g*E,r[8]=d*p+f*M+g*R,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8];return e*a*h-e*o*c-n*r*h+n*o*l+i*r*c-i*a*l}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=h*a-o*c,d=o*l-h*r,f=c*r-a*l,g=e*u+n*d+i*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let y=1/g;return t[0]=u*y,t[1]=(i*c-h*n)*y,t[2]=(o*n-i*a)*y,t[3]=d*y,t[4]=(h*e-i*l)*y,t[5]=(i*r-o*e)*y,t[6]=f*y,t[7]=(n*l-c*e)*y,t[8]=(a*e-n*r)*y,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,a,o){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-i*c,i*l,-i*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(za.makeScale(t,e)),this}rotate(t){return this.premultiply(za.makeRotation(-t)),this}translate(t,e){return this.premultiply(za.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},za=new Yt;function yh(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function Rr(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function Wu(){let s=Rr("canvas");return s.style.display="block",s}var dc={};function bs(s){s in dc||(dc[s]=!0,console.warn(s))}var fc=new Yt().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),pc=new Yt().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),qs={[In]:{transfer:Er,primaries:wr,toReference:s=>s,fromReference:s=>s},[xe]:{transfer:ae,primaries:wr,toReference:s=>s.convertSRGBToLinear(),fromReference:s=>s.convertLinearToSRGB()},[ia]:{transfer:Er,primaries:Tr,toReference:s=>s.applyMatrix3(pc),fromReference:s=>s.applyMatrix3(fc)},[ol]:{transfer:ae,primaries:Tr,toReference:s=>s.convertSRGBToLinear().applyMatrix3(pc),fromReference:s=>s.applyMatrix3(fc).convertLinearToSRGB()}},Xu=new Set([In,ia]),Qt={enabled:!0,_workingColorSpace:In,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(s){if(!Xu.has(s))throw new Error(`Unsupported working color space, "${s}".`);this._workingColorSpace=s},convert:function(s,t,e){if(this.enabled===!1||t===e||!t||!e)return s;let n=qs[t].toReference,i=qs[e].fromReference;return i(n(s))},fromWorkingColorSpace:function(s,t){return this.convert(s,this._workingColorSpace,t)},toWorkingColorSpace:function(s,t){return this.convert(s,t,this._workingColorSpace)},getPrimaries:function(s){return qs[s].primaries},getTransfer:function(s){return s===je?Er:qs[s].transfer}};function Xi(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Ba(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}var wi,Cr=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{wi===void 0&&(wi=Rr("canvas")),wi.width=t.width,wi.height=t.height;let n=wi.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=wi}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=Rr("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let a=0;a<r.length;a++)r[a]=Xi(r[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Xi(e[n]/255)*255):e[n]=Xi(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},qu=0,Pr=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:qu++}),this.uuid=ns(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let a=0,o=i.length;a<o;a++)i[a].isDataTexture?r.push(ka(i[a].image)):r.push(ka(i[a]))}else r=ka(i);n.url=r}return e||(t.images[this.uuid]=n),n}};function ka(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Cr.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Yu=0,en=class s extends jn{constructor(t=s.DEFAULT_IMAGE,e=s.DEFAULT_MAPPING,n=fn,i=fn,r=Qe,a=Rs,o=pn,l=Kn,c=s.DEFAULT_ANISOTROPY,h=je){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Yu++}),this.uuid=ns(),this.name="",this.source=new Pr(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new mt(0,0),this.repeat=new mt(1,1),this.center=new mt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Yt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(bs("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===_i?xe:je),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==lh)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case As:t.x=t.x-Math.floor(t.x);break;case fn:t.x=t.x<0?0:1;break;case go:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case As:t.y=t.y-Math.floor(t.y);break;case fn:t.y=t.y<0?0:1;break;case go:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return bs("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===xe?_i:gh}set encoding(t){bs("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===_i?xe:je}};en.DEFAULT_IMAGE=null;en.DEFAULT_MAPPING=lh;en.DEFAULT_ANISOTROPY=1;var le=class s{constructor(t=0,e=0,n=0,i=1){s.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r,l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],y=l[2],m=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-y)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+y)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let _=(c+1)/2,M=(f+1)/2,T=(p+1)/2,E=(h+d)/4,R=(u+y)/4,U=(g+m)/4;return _>M&&_>T?_<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(_),i=E/n,r=R/n):M>T?M<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(M),n=E/i,r=U/i):T<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(T),n=R/r,i=U/r),this.set(n,i,r,e),this}let x=Math.sqrt((m-g)*(m-g)+(u-y)*(u-y)+(d-h)*(d-h));return Math.abs(x)<.001&&(x=1),this.x=(m-g)/x,this.y=(u-y)/x,this.z=(d-h)/x,this.w=Math.acos((c+f+p-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},vo=class extends jn{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new le(0,0,t,e),this.scissorTest=!1,this.viewport=new le(0,0,t,e);let i={width:t,height:e,depth:1};n.encoding!==void 0&&(bs("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===_i?xe:je),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Qe,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new en(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new Pr(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Dn=class extends vo{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},Lr=class extends en{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ve,this.minFilter=Ve,this.wrapR=fn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Mo=class extends en{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ve,this.minFilter=Ve,this.wrapR=fn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Jt=class{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,a,o){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3],d=r[a+0],f=r[a+1],g=r[a+2],y=r[a+3];if(o===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=d,t[e+1]=f,t[e+2]=g,t[e+3]=y;return}if(u!==y||l!==d||c!==f||h!==g){let m=1-o,p=l*d+c*f+h*g+u*y,x=p>=0?1:-1,_=1-p*p;if(_>Number.EPSILON){let T=Math.sqrt(_),E=Math.atan2(T,p*x);m=Math.sin(m*E)/T,o=Math.sin(o*E)/T}let M=o*x;if(l=l*m+d*M,c=c*m+f*M,h=h*m+g*M,u=u*m+y*M,m===1-o){let T=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=T,c*=T,h*=T,u*=T}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,r,a){let o=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=r[a],d=r[a+1],f=r[a+2],g=r[a+3];return t[e]=o*g+h*u+l*f-c*d,t[e+1]=l*g+h*d+c*u-o*f,t[e+2]=c*g+h*f+o*d-l*u,t[e+3]=h*g-o*u-l*d-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,i=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(i/2),u=o(r/2),d=l(n/2),f=l(i/2),g=l(r/2);switch(a){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],i=e[4],r=e[8],a=e[1],o=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=n+o+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(a-i)*f}else if(n>o&&n>u){let f=2*Math.sqrt(1+n-o-u);this._w=(h-l)/f,this._x=.25*f,this._y=(i+a)/f,this._z=(r+c)/f}else if(o>u){let f=2*Math.sqrt(1+o-n-u);this._w=(r-c)/f,this._x=(i+a)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-o);this._w=(a-i)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Fe(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,i=t._y,r=t._z,a=t._w,o=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+a*o+i*c-r*l,this._y=i*h+a*l+r*o-n*c,this._z=r*h+a*c+n*l-i*o,this._w=a*h-n*o-i*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,i=this._y,r=this._z,a=this._w,o=a*t._w+n*t._x+i*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=n,this._y=i,this._z=r,this;let l=1-o*o;if(l<=Number.EPSILON){let f=1-e;return this._w=f*a+e*this._w,this._x=f*n+e*this._x,this._y=f*i+e*this._y,this._z=f*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-e)*h)/c,d=Math.sin(e*h)/c;return this._w=a*u+this._w*d,this._x=n*u+this._x*d,this._y=i*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),i=2*Math.PI*Math.random(),r=2*Math.PI*Math.random();return this.set(e*Math.cos(i),n*Math.sin(r),n*Math.cos(r),e*Math.sin(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},C=class s{constructor(t=0,e=0,n=0){s.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(mc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(mc.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*a,this}applyQuaternion(t){let e=this.x,n=this.y,i=this.z,r=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*i-o*n),h=2*(o*e-r*i),u=2*(r*n-a*e);return this.x=e+l*c+a*u-o*h,this.y=n+l*h+o*c-r*u,this.z=i+l*u+r*h-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,i=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=i*l-r*o,this.y=r*a-n*l,this.z=n*o-i*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Ha.copy(this).projectOnVector(t),this.sub(Ha)}reflect(t){return this.sub(Ha.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Fe(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Ha=new C,mc=new Jt,Un=class{constructor(t=new C(1/0,1/0,1/0),e=new C(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(hn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(hn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=hn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,hn):hn.fromBufferAttribute(r,a),hn.applyMatrix4(t.matrixWorld),this.expandByPoint(hn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Ys.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Ys.copy(n.boundingBox)),Ys.applyMatrix4(t.matrixWorld),this.union(Ys)}let i=t.children;for(let r=0,a=i.length;r<a;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,hn),hn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(ms),Zs.subVectors(this.max,ms),Ti.subVectors(t.a,ms),Ai.subVectors(t.b,ms),Ri.subVectors(t.c,ms),Hn.subVectors(Ai,Ti),Vn.subVectors(Ri,Ai),li.subVectors(Ti,Ri);let e=[0,-Hn.z,Hn.y,0,-Vn.z,Vn.y,0,-li.z,li.y,Hn.z,0,-Hn.x,Vn.z,0,-Vn.x,li.z,0,-li.x,-Hn.y,Hn.x,0,-Vn.y,Vn.x,0,-li.y,li.x,0];return!Va(e,Ti,Ai,Ri,Zs)||(e=[1,0,0,0,1,0,0,0,1],!Va(e,Ti,Ai,Ri,Zs))?!1:(Js.crossVectors(Hn,Vn),e=[Js.x,Js.y,Js.z],Va(e,Ti,Ai,Ri,Zs))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,hn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(hn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(En[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),En[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),En[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),En[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),En[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),En[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),En[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),En[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(En),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},En=[new C,new C,new C,new C,new C,new C,new C,new C],hn=new C,Ys=new Un,Ti=new C,Ai=new C,Ri=new C,Hn=new C,Vn=new C,li=new C,ms=new C,Zs=new C,Js=new C,ci=new C;function Va(s,t,e,n,i){for(let r=0,a=s.length-3;r<=a;r+=3){ci.fromArray(s,r);let o=i.x*Math.abs(ci.x)+i.y*Math.abs(ci.y)+i.z*Math.abs(ci.z),l=t.dot(ci),c=e.dot(ci),h=n.dot(ci);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}var Zu=new Un,gs=new C,Ga=new C,ti=class{constructor(t=new C,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):Zu.setFromPoints(t).getCenter(n);let i=0;for(let r=0,a=t.length;r<a;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;gs.subVectors(t,this.center);let e=gs.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(gs,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Ga.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(gs.copy(t.center).add(Ga)),this.expandByPoint(gs.copy(t.center).sub(Ga))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},wn=new C,Wa=new C,$s=new C,Gn=new C,Xa=new C,Ks=new C,qa=new C,Ir=class{constructor(t=new C,e=new C(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,wn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=wn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(wn.copy(this.origin).addScaledVector(this.direction,e),wn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){Wa.copy(t).add(e).multiplyScalar(.5),$s.copy(e).sub(t).normalize(),Gn.copy(this.origin).sub(Wa);let r=t.distanceTo(e)*.5,a=-this.direction.dot($s),o=Gn.dot(this.direction),l=-Gn.dot($s),c=Gn.lengthSq(),h=Math.abs(1-a*a),u,d,f,g;if(h>0)if(u=a*l-o,d=a*o-l,g=r*h,u>=0)if(d>=-g)if(d<=g){let y=1/h;u*=y,d*=y,f=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-a*r+o)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(a*r+o)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=a>0?-r:r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(Wa).addScaledVector($s,d),f}intersectSphere(t,e){wn.subVectors(t.center,this.origin);let n=wn.dot(this.direction),i=wn.dot(wn)-n*n,r=t.radius*t.radius;if(i>r)return null;let a=Math.sqrt(r-i),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,a,o,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(t.min.x-d.x)*c,i=(t.max.x-d.x)*c):(n=(t.max.x-d.x)*c,i=(t.min.x-d.x)*c),h>=0?(r=(t.min.y-d.y)*h,a=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,a=(t.min.y-d.y)*h),n>a||r>i||((r>n||isNaN(n))&&(n=r),(a<i||isNaN(i))&&(i=a),u>=0?(o=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(o=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),n>l||o>i)||((o>n||n!==n)&&(n=o),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,wn)!==null}intersectTriangle(t,e,n,i,r){Xa.subVectors(e,t),Ks.subVectors(n,t),qa.crossVectors(Xa,Ks);let a=this.direction.dot(qa),o;if(a>0){if(i)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Gn.subVectors(this.origin,t);let l=o*this.direction.dot(Ks.crossVectors(Gn,Ks));if(l<0)return null;let c=o*this.direction.dot(Xa.cross(Gn));if(c<0||l+c>a)return null;let h=-o*Gn.dot(qa);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},se=class s{constructor(t,e,n,i,r,a,o,l,c,h,u,d,f,g,y,m){s.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c,h,u,d,f,g,y,m)}set(t,e,n,i,r,a,o,l,c,h,u,d,f,g,y,m){let p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=i,p[1]=r,p[5]=a,p[9]=o,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=y,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new s().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,i=1/Ci.setFromMatrixColumn(t,0).length(),r=1/Ci.setFromMatrixColumn(t,1).length(),a=1/Ci.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,i=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let d=a*h,f=a*u,g=o*h,y=o*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=f+g*c,e[5]=d-y*c,e[9]=-o*l,e[2]=y-d*c,e[6]=g+f*c,e[10]=a*l}else if(t.order==="YXZ"){let d=l*h,f=l*u,g=c*h,y=c*u;e[0]=d+y*o,e[4]=g*o-f,e[8]=a*c,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=f*o-g,e[6]=y+d*o,e[10]=a*l}else if(t.order==="ZXY"){let d=l*h,f=l*u,g=c*h,y=c*u;e[0]=d-y*o,e[4]=-a*u,e[8]=g+f*o,e[1]=f+g*o,e[5]=a*h,e[9]=y-d*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){let d=a*h,f=a*u,g=o*h,y=o*u;e[0]=l*h,e[4]=g*c-f,e[8]=d*c+y,e[1]=l*u,e[5]=y*c+d,e[9]=f*c-g,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){let d=a*l,f=a*c,g=o*l,y=o*c;e[0]=l*h,e[4]=y-d*u,e[8]=g*u+f,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-c*h,e[6]=f*u+g,e[10]=d-y*u}else if(t.order==="XZY"){let d=a*l,f=a*c,g=o*l,y=o*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+y,e[5]=a*h,e[9]=f*u-g,e[2]=g*u-f,e[6]=o*h,e[10]=y*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Ju,t,$u)}lookAt(t,e,n){let i=this.elements;return qe.subVectors(t,e),qe.lengthSq()===0&&(qe.z=1),qe.normalize(),Wn.crossVectors(n,qe),Wn.lengthSq()===0&&(Math.abs(n.z)===1?qe.x+=1e-4:qe.z+=1e-4,qe.normalize(),Wn.crossVectors(n,qe)),Wn.normalize(),Qs.crossVectors(qe,Wn),i[0]=Wn.x,i[4]=Qs.x,i[8]=qe.x,i[1]=Wn.y,i[5]=Qs.y,i[9]=qe.y,i[2]=Wn.z,i[6]=Qs.z,i[10]=qe.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],y=n[6],m=n[10],p=n[14],x=n[3],_=n[7],M=n[11],T=n[15],E=i[0],R=i[4],U=i[8],v=i[12],S=i[1],N=i[5],H=i[9],et=i[13],L=i[2],F=i[6],X=i[10],nt=i[14],Z=i[3],$=i[7],D=i[11],j=i[15];return r[0]=a*E+o*S+l*L+c*Z,r[4]=a*R+o*N+l*F+c*$,r[8]=a*U+o*H+l*X+c*D,r[12]=a*v+o*et+l*nt+c*j,r[1]=h*E+u*S+d*L+f*Z,r[5]=h*R+u*N+d*F+f*$,r[9]=h*U+u*H+d*X+f*D,r[13]=h*v+u*et+d*nt+f*j,r[2]=g*E+y*S+m*L+p*Z,r[6]=g*R+y*N+m*F+p*$,r[10]=g*U+y*H+m*X+p*D,r[14]=g*v+y*et+m*nt+p*j,r[3]=x*E+_*S+M*L+T*Z,r[7]=x*R+_*N+M*F+T*$,r[11]=x*U+_*H+M*X+T*D,r[15]=x*v+_*et+M*nt+T*j,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],a=t[1],o=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],f=t[14],g=t[3],y=t[7],m=t[11],p=t[15];return g*(+r*l*u-i*c*u-r*o*d+n*c*d+i*o*f-n*l*f)+y*(+e*l*f-e*c*d+r*a*d-i*a*f+i*c*h-r*l*h)+m*(+e*c*u-e*o*f-r*a*u+n*a*f+r*o*h-n*c*h)+p*(-i*o*h-e*l*u+e*o*d+i*a*u-n*a*d+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],f=t[11],g=t[12],y=t[13],m=t[14],p=t[15],x=u*m*c-y*d*c+y*l*f-o*m*f-u*l*p+o*d*p,_=g*d*c-h*m*c-g*l*f+a*m*f+h*l*p-a*d*p,M=h*y*c-g*u*c+g*o*f-a*y*f-h*o*p+a*u*p,T=g*u*l-h*y*l-g*o*d+a*y*d+h*o*m-a*u*m,E=e*x+n*_+i*M+r*T;if(E===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let R=1/E;return t[0]=x*R,t[1]=(y*d*r-u*m*r-y*i*f+n*m*f+u*i*p-n*d*p)*R,t[2]=(o*m*r-y*l*r+y*i*c-n*m*c-o*i*p+n*l*p)*R,t[3]=(u*l*r-o*d*r-u*i*c+n*d*c+o*i*f-n*l*f)*R,t[4]=_*R,t[5]=(h*m*r-g*d*r+g*i*f-e*m*f-h*i*p+e*d*p)*R,t[6]=(g*l*r-a*m*r-g*i*c+e*m*c+a*i*p-e*l*p)*R,t[7]=(a*d*r-h*l*r+h*i*c-e*d*c-a*i*f+e*l*f)*R,t[8]=M*R,t[9]=(g*u*r-h*y*r-g*n*f+e*y*f+h*n*p-e*u*p)*R,t[10]=(a*y*r-g*o*r+g*n*c-e*y*c-a*n*p+e*o*p)*R,t[11]=(h*o*r-a*u*r-h*n*c+e*u*c+a*n*f-e*o*f)*R,t[12]=T*R,t[13]=(h*y*i-g*u*i+g*n*d-e*y*d-h*n*m+e*u*m)*R,t[14]=(g*o*i-a*y*i-g*n*l+e*y*l+a*n*m-e*o*m)*R,t[15]=(a*u*i-h*o*i+h*n*l-e*u*l-a*n*d+e*o*d)*R,this}scale(t){let e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),i=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,c=r*a,h=r*o;return this.set(c*a+n,c*o-i*l,c*l+i*o,0,c*o+i*l,h*o+n,h*l-i*a,0,c*l-i*o,h*l+i*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,a){return this.set(1,n,r,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){let i=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,c=r+r,h=a+a,u=o+o,d=r*c,f=r*h,g=r*u,y=a*h,m=a*u,p=o*u,x=l*c,_=l*h,M=l*u,T=n.x,E=n.y,R=n.z;return i[0]=(1-(y+p))*T,i[1]=(f+M)*T,i[2]=(g-_)*T,i[3]=0,i[4]=(f-M)*E,i[5]=(1-(d+p))*E,i[6]=(m+x)*E,i[7]=0,i[8]=(g+_)*R,i[9]=(m-x)*R,i[10]=(1-(d+y))*R,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){let i=this.elements,r=Ci.set(i[0],i[1],i[2]).length(),a=Ci.set(i[4],i[5],i[6]).length(),o=Ci.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],un.copy(this);let c=1/r,h=1/a,u=1/o;return un.elements[0]*=c,un.elements[1]*=c,un.elements[2]*=c,un.elements[4]*=h,un.elements[5]*=h,un.elements[6]*=h,un.elements[8]*=u,un.elements[9]*=u,un.elements[10]*=u,e.setFromRotationMatrix(un),n.x=r,n.y=a,n.z=o,this}makePerspective(t,e,n,i,r,a,o=Ln){let l=this.elements,c=2*r/(e-t),h=2*r/(n-i),u=(e+t)/(e-t),d=(n+i)/(n-i),f,g;if(o===Ln)f=-(a+r)/(a-r),g=-2*a*r/(a-r);else if(o===Ar)f=-a/(a-r),g=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,i,r,a,o=Ln){let l=this.elements,c=1/(e-t),h=1/(n-i),u=1/(a-r),d=(e+t)*c,f=(n+i)*h,g,y;if(o===Ln)g=(a+r)*u,y=-2*u;else if(o===Ar)g=r*u,y=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=y,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},Ci=new C,un=new se,Ju=new C(0,0,0),$u=new C(1,1,1),Wn=new C,Qs=new C,qe=new C,gc=new se,_c=new Jt,Dr=class s{constructor(t=0,e=0,n=0,i=s.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let i=t.elements,r=i[0],a=i[4],o=i[8],l=i[1],c=i[5],h=i[9],u=i[2],d=i[6],f=i[10];switch(e){case"XYZ":this._y=Math.asin(Fe(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Fe(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Fe(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Fe(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Fe(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-Fe(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return gc.makeRotationFromQuaternion(t),this.setFromRotationMatrix(gc,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return _c.setFromEuler(this),this.setFromQuaternion(_c,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Dr.DEFAULT_ORDER="XYZ";var Ur=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Ku=0,xc=new C,Pi=new Jt,Tn=new se,js=new C,_s=new C,Qu=new C,ju=new Jt,yc=new C(1,0,0),vc=new C(0,1,0),Mc=new C(0,0,1),td={type:"added"},ed={type:"removed"},Ae=class s extends jn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ku++}),this.uuid=ns(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=s.DEFAULT_UP.clone();let t=new C,e=new Dr,n=new Jt,i=new C(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new se},normalMatrix:{value:new Yt}}),this.matrix=new se,this.matrixWorld=new se,this.matrixAutoUpdate=s.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=s.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ur,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Pi.setFromAxisAngle(t,e),this.quaternion.multiply(Pi),this}rotateOnWorldAxis(t,e){return Pi.setFromAxisAngle(t,e),this.quaternion.premultiply(Pi),this}rotateX(t){return this.rotateOnAxis(yc,t)}rotateY(t){return this.rotateOnAxis(vc,t)}rotateZ(t){return this.rotateOnAxis(Mc,t)}translateOnAxis(t,e){return xc.copy(t).applyQuaternion(this.quaternion),this.position.add(xc.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(yc,t)}translateY(t){return this.translateOnAxis(vc,t)}translateZ(t){return this.translateOnAxis(Mc,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Tn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?js.copy(t):js.set(t,e,n);let i=this.parent;this.updateWorldMatrix(!0,!1),_s.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Tn.lookAt(_s,js,this.up):Tn.lookAt(js,_s,this.up),this.quaternion.setFromRotationMatrix(Tn),i&&(Tn.extractRotation(i.matrixWorld),Pi.setFromRotationMatrix(Tn),this.quaternion.premultiply(Pi.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(td)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(ed)),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Tn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Tn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Tn),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){let a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let i=this.children;for(let r=0,a=i.length;r<a;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(_s,t,Qu),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(_s,ju,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,i=e.length;n<i;n++){let r=e[n];(r.matrixWorldAutoUpdate===!0||t===!0)&&r.updateMatrixWorld(t)}}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){let i=this.children;for(let r=0,a=i.length;r<a;r++){let o=i[r];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),i.maxGeometryCount=this._maxGeometryCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(t.materials,this.material[l]));i.material=o}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];i.animations.push(r(t.animations,l))}}if(e){let o=a(t.geometries),l=a(t.materials),c=a(t.textures),h=a(t.images),u=a(t.shapes),d=a(t.skeletons),f=a(t.animations),g=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=i,n;function a(o){let l=[];for(let c in o){let h=o[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let i=t.children[n];this.add(i.clone())}return this}};Ae.DEFAULT_UP=new C(0,1,0);Ae.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ae.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var dn=new C,An=new C,Ya=new C,Rn=new C,Li=new C,Ii=new C,bc=new C,Za=new C,Ja=new C,$a=new C,tr=!1,Hi=class s{constructor(t=new C,e=new C,n=new C){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),dn.subVectors(t,e),i.cross(dn);let r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){dn.subVectors(i,e),An.subVectors(n,e),Ya.subVectors(t,e);let a=dn.dot(dn),o=dn.dot(An),l=dn.dot(Ya),c=An.dot(An),h=An.dot(Ya),u=a*c-o*o;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-o*h)*d,g=(a*h-o*l)*d;return r.set(1-f-g,g,f)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,Rn)===null?!1:Rn.x>=0&&Rn.y>=0&&Rn.x+Rn.y<=1}static getUV(t,e,n,i,r,a,o,l){return tr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),tr=!0),this.getInterpolation(t,e,n,i,r,a,o,l)}static getInterpolation(t,e,n,i,r,a,o,l){return this.getBarycoord(t,e,n,i,Rn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Rn.x),l.addScaledVector(a,Rn.y),l.addScaledVector(o,Rn.z),l)}static isFrontFacing(t,e,n,i){return dn.subVectors(n,e),An.subVectors(t,e),dn.cross(An).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return dn.subVectors(this.c,this.b),An.subVectors(this.a,this.b),dn.cross(An).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return s.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return s.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,i,r){return tr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),tr=!0),s.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}getInterpolation(t,e,n,i,r){return s.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return s.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return s.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,i=this.b,r=this.c,a,o;Li.subVectors(i,n),Ii.subVectors(r,n),Za.subVectors(t,n);let l=Li.dot(Za),c=Ii.dot(Za);if(l<=0&&c<=0)return e.copy(n);Ja.subVectors(t,i);let h=Li.dot(Ja),u=Ii.dot(Ja);if(h>=0&&u<=h)return e.copy(i);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),e.copy(n).addScaledVector(Li,a);$a.subVectors(t,r);let f=Li.dot($a),g=Ii.dot($a);if(g>=0&&f<=g)return e.copy(r);let y=f*c-l*g;if(y<=0&&c>=0&&g<=0)return o=c/(c-g),e.copy(n).addScaledVector(Ii,o);let m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return bc.subVectors(r,i),o=(u-h)/(u-h+(f-g)),e.copy(i).addScaledVector(bc,o);let p=1/(m+y+d);return a=y*p,o=d*p,e.copy(n).addScaledVector(Li,a).addScaledVector(Ii,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},vh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Xn={h:0,s:0,l:0},er={h:0,s:0,l:0};function Ka(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}var Ct=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=xe){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Qt.toWorkingColorSpace(this,e),this}setRGB(t,e,n,i=Qt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Qt.toWorkingColorSpace(this,i),this}setHSL(t,e,n,i=Qt.workingColorSpace){if(t=Gu(t,1),e=Fe(e,0,1),n=Fe(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=Ka(a,r,t+1/3),this.g=Ka(a,r,t),this.b=Ka(a,r,t-1/3)}return Qt.toWorkingColorSpace(this,i),this}setStyle(t,e=xe){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=i[1],o=i[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=i[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=xe){let n=vh[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Xi(t.r),this.g=Xi(t.g),this.b=Xi(t.b),this}copyLinearToSRGB(t){return this.r=Ba(t.r),this.g=Ba(t.g),this.b=Ba(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=xe){return Qt.fromWorkingColorSpace(Ne.copy(this),t),Math.round(Fe(Ne.r*255,0,255))*65536+Math.round(Fe(Ne.g*255,0,255))*256+Math.round(Fe(Ne.b*255,0,255))}getHexString(t=xe){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Qt.workingColorSpace){Qt.fromWorkingColorSpace(Ne.copy(this),e);let n=Ne.r,i=Ne.g,r=Ne.b,a=Math.max(n,i,r),o=Math.min(n,i,r),l,c,h=(o+a)/2;if(o===a)l=0,c=0;else{let u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case n:l=(i-r)/u+(i<r?6:0);break;case i:l=(r-n)/u+2;break;case r:l=(n-i)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=Qt.workingColorSpace){return Qt.fromWorkingColorSpace(Ne.copy(this),e),t.r=Ne.r,t.g=Ne.g,t.b=Ne.b,t}getStyle(t=xe){Qt.fromWorkingColorSpace(Ne.copy(this),t);let e=Ne.r,n=Ne.g,i=Ne.b;return t!==xe?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(Xn),this.setHSL(Xn.h+t,Xn.s+e,Xn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Xn),t.getHSL(er);let n=Oa(Xn.h,er.h,e),i=Oa(Xn.s,er.s,e),r=Oa(Xn.l,er.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Ne=new Ct;Ct.NAMES=vh;var nd=0,ei=class extends jn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:nd++}),this.uuid=ns(),this.name="",this.type="Material",this.blending=Jn,this.side=Qn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=uo,this.blendDst=fo,this.blendEquation=fi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ct(0,0,0),this.blendAlpha=0,this.depthFunc=Mr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=lc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ei,this.stencilZFail=Ei,this.stencilZPass=Ei,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Jn&&(n.blending=this.blending),this.side!==Qn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==uo&&(n.blendSrc=this.blendSrc),this.blendDst!==fo&&(n.blendDst=this.blendDst),this.blendEquation!==fi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Mr&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==lc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ei&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ei&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ei&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){let a=[];for(let o in r){let l=r[o];delete l.metadata,a.push(l)}return a}if(e){let r=i(t.textures),a=i(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},me=class extends ei{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ct(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=oh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var _e=new C,nr=new mt,jt=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=cc,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Yn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)nr.fromBufferAttribute(this,e),nr.applyMatrix3(t),this.setXY(e,nr.x,nr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)_e.fromBufferAttribute(this,e),_e.applyMatrix3(t),this.setXYZ(e,_e.x,_e.y,_e.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)_e.fromBufferAttribute(this,e),_e.applyMatrix4(t),this.setXYZ(e,_e.x,_e.y,_e.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)_e.fromBufferAttribute(this,e),_e.applyNormalMatrix(t),this.setXYZ(e,_e.x,_e.y,_e.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)_e.fromBufferAttribute(this,e),_e.transformDirection(t),this.setXYZ(e,_e.x,_e.y,_e.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=ps(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=We(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=ps(e,this.array)),e}setX(t,e){return this.normalized&&(e=We(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=ps(e,this.array)),e}setY(t,e){return this.normalized&&(e=We(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=ps(e,this.array)),e}setZ(t,e){return this.normalized&&(e=We(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=ps(e,this.array)),e}setW(t,e){return this.normalized&&(e=We(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=We(e,this.array),n=We(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=We(e,this.array),n=We(n,this.array),i=We(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=We(e,this.array),n=We(n,this.array),i=We(i,this.array),r=We(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==cc&&(t.usage=this.usage),t}};var Nr=class extends jt{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var Fr=class extends jt{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var re=class extends jt{constructor(t,e,n){super(new Float32Array(t),e,n)}};var id=0,Ke=new se,Qa=new Ae,Di=new C,Ye=new Un,xs=new Un,we=new C,Re=class s extends jn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:id++}),this.uuid=ns(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(yh(t)?Fr:Nr)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Yt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Ke.makeRotationFromQuaternion(t),this.applyMatrix4(Ke),this}rotateX(t){return Ke.makeRotationX(t),this.applyMatrix4(Ke),this}rotateY(t){return Ke.makeRotationY(t),this.applyMatrix4(Ke),this}rotateZ(t){return Ke.makeRotationZ(t),this.applyMatrix4(Ke),this}translate(t,e,n){return Ke.makeTranslation(t,e,n),this.applyMatrix4(Ke),this}scale(t,e,n){return Ke.makeScale(t,e,n),this.applyMatrix4(Ke),this}lookAt(t){return Qa.lookAt(t),Qa.updateMatrix(),this.applyMatrix4(Qa.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Di).negate(),this.translate(Di.x,Di.y,Di.z),this}setFromPoints(t){let e=[];for(let n=0,i=t.length;n<i;n++){let r=t[n];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new re(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Un);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new C(-1/0,-1/0,-1/0),new C(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){let r=e[n];Ye.setFromBufferAttribute(r),this.morphTargetsRelative?(we.addVectors(this.boundingBox.min,Ye.min),this.boundingBox.expandByPoint(we),we.addVectors(this.boundingBox.max,Ye.max),this.boundingBox.expandByPoint(we)):(this.boundingBox.expandByPoint(Ye.min),this.boundingBox.expandByPoint(Ye.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ti);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new C,1/0);return}if(t){let n=this.boundingSphere.center;if(Ye.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];xs.setFromBufferAttribute(o),this.morphTargetsRelative?(we.addVectors(Ye.min,xs.min),Ye.expandByPoint(we),we.addVectors(Ye.max,xs.max),Ye.expandByPoint(we)):(Ye.expandByPoint(xs.min),Ye.expandByPoint(xs.max))}Ye.getCenter(n);let i=0;for(let r=0,a=t.count;r<a;r++)we.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(we));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)we.fromBufferAttribute(o,c),l&&(Di.fromBufferAttribute(t,c),we.add(Di)),i=Math.max(i,n.distanceToSquared(we))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.array,i=e.position.array,r=e.normal.array,a=e.uv.array,o=i.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new jt(new Float32Array(4*o),4));let l=this.getAttribute("tangent").array,c=[],h=[];for(let S=0;S<o;S++)c[S]=new C,h[S]=new C;let u=new C,d=new C,f=new C,g=new mt,y=new mt,m=new mt,p=new C,x=new C;function _(S,N,H){u.fromArray(i,S*3),d.fromArray(i,N*3),f.fromArray(i,H*3),g.fromArray(a,S*2),y.fromArray(a,N*2),m.fromArray(a,H*2),d.sub(u),f.sub(u),y.sub(g),m.sub(g);let et=1/(y.x*m.y-m.x*y.y);isFinite(et)&&(p.copy(d).multiplyScalar(m.y).addScaledVector(f,-y.y).multiplyScalar(et),x.copy(f).multiplyScalar(y.x).addScaledVector(d,-m.x).multiplyScalar(et),c[S].add(p),c[N].add(p),c[H].add(p),h[S].add(x),h[N].add(x),h[H].add(x))}let M=this.groups;M.length===0&&(M=[{start:0,count:n.length}]);for(let S=0,N=M.length;S<N;++S){let H=M[S],et=H.start,L=H.count;for(let F=et,X=et+L;F<X;F+=3)_(n[F+0],n[F+1],n[F+2])}let T=new C,E=new C,R=new C,U=new C;function v(S){R.fromArray(r,S*3),U.copy(R);let N=c[S];T.copy(N),T.sub(R.multiplyScalar(R.dot(N))).normalize(),E.crossVectors(U,N);let et=E.dot(h[S])<0?-1:1;l[S*4]=T.x,l[S*4+1]=T.y,l[S*4+2]=T.z,l[S*4+3]=et}for(let S=0,N=M.length;S<N;++S){let H=M[S],et=H.start,L=H.count;for(let F=et,X=et+L;F<X;F+=3)v(n[F+0]),v(n[F+1]),v(n[F+2])}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new jt(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let i=new C,r=new C,a=new C,o=new C,l=new C,c=new C,h=new C,u=new C;if(t)for(let d=0,f=t.count;d<f;d+=3){let g=t.getX(d+0),y=t.getX(d+1),m=t.getX(d+2);i.fromBufferAttribute(e,g),r.fromBufferAttribute(e,y),a.fromBufferAttribute(e,m),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,y),c.fromBufferAttribute(n,m),o.add(h),l.add(h),c.add(h),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(y,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=e.count;d<f;d+=3)i.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),a.fromBufferAttribute(e,d+2),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)we.fromBufferAttribute(t,e),we.normalize(),t.setXYZ(e,we.x,we.y,we.z)}toNonIndexed(){function t(o,l){let c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h),f=0,g=0;for(let y=0,m=l.length;y<m;y++){o.isInterleavedBufferAttribute?f=l[y]*o.data.stride+o.offset:f=l[y]*h;for(let p=0;p<h;p++)d[g++]=c[f++]}return new jt(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new s,n=this.index.array,i=this.attributes;for(let o in i){let l=i[o],c=t(l,n);e.setAttribute(o,c)}let r=this.morphAttributes;for(let o in r){let l=[],c=r[o];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=t(d,n);l.push(f)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let i={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(t.data))}h.length>0&&(i[l]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let i=t.attributes;for(let c in i){let h=i[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let c=0,h=a.length;c<h;c++){let u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Sc=new se,hi=new Ir,ir=new ti,Ec=new C,Ui=new C,Ni=new C,Fi=new C,ja=new C,sr=new C,rr=new mt,ar=new mt,or=new mt,wc=new C,Tc=new C,Ac=new C,lr=new C,cr=new C,It=class extends Ae{constructor(t=new Re,e=new me){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){let o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);let o=this.morphTargetInfluences;if(r&&o){sr.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=o[l],u=r[l];h!==0&&(ja.fromBufferAttribute(u,t),a?sr.addScaledVector(ja,h):sr.addScaledVector(ja.sub(e),h))}e.add(sr)}return e}raycast(t,e){let n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ir.copy(n.boundingSphere),ir.applyMatrix4(r),hi.copy(t.ray).recast(t.near),!(ir.containsPoint(hi.origin)===!1&&(hi.intersectSphere(ir,Ec)===null||hi.origin.distanceToSquared(Ec)>(t.far-t.near)**2))&&(Sc.copy(r).invert(),hi.copy(t.ray).applyMatrix4(Sc),!(n.boundingBox!==null&&hi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,hi)))}_computeIntersections(t,e,n){let i,r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,y=d.length;g<y;g++){let m=d[g],p=a[m.materialIndex],x=Math.max(m.start,f.start),_=Math.min(o.count,Math.min(m.start+m.count,f.start+f.count));for(let M=x,T=_;M<T;M+=3){let E=o.getX(M),R=o.getX(M+1),U=o.getX(M+2);i=hr(this,p,t,n,c,h,u,E,R,U),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{let g=Math.max(0,f.start),y=Math.min(o.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){let x=o.getX(m),_=o.getX(m+1),M=o.getX(m+2);i=hr(this,a,t,n,c,h,u,x,_,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,y=d.length;g<y;g++){let m=d[g],p=a[m.materialIndex],x=Math.max(m.start,f.start),_=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let M=x,T=_;M<T;M+=3){let E=M,R=M+1,U=M+2;i=hr(this,p,t,n,c,h,u,E,R,U),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{let g=Math.max(0,f.start),y=Math.min(l.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){let x=m,_=m+1,M=m+2;i=hr(this,a,t,n,c,h,u,x,_,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}};function sd(s,t,e,n,i,r,a,o){let l;if(t.side===Te?l=n.intersectTriangle(a,r,i,!0,o):l=n.intersectTriangle(i,r,a,t.side===Qn,o),l===null)return null;cr.copy(o),cr.applyMatrix4(s.matrixWorld);let c=e.ray.origin.distanceTo(cr);return c<e.near||c>e.far?null:{distance:c,point:cr.clone(),object:s}}function hr(s,t,e,n,i,r,a,o,l,c){s.getVertexPosition(o,Ui),s.getVertexPosition(l,Ni),s.getVertexPosition(c,Fi);let h=sd(s,t,e,n,Ui,Ni,Fi,lr);if(h){i&&(rr.fromBufferAttribute(i,o),ar.fromBufferAttribute(i,l),or.fromBufferAttribute(i,c),h.uv=Hi.getInterpolation(lr,Ui,Ni,Fi,rr,ar,or,new mt)),r&&(rr.fromBufferAttribute(r,o),ar.fromBufferAttribute(r,l),or.fromBufferAttribute(r,c),h.uv1=Hi.getInterpolation(lr,Ui,Ni,Fi,rr,ar,or,new mt),h.uv2=h.uv1),a&&(wc.fromBufferAttribute(a,o),Tc.fromBufferAttribute(a,l),Ac.fromBufferAttribute(a,c),h.normal=Hi.getInterpolation(lr,Ui,Ni,Fi,wc,Tc,Ac,new C),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:l,c,normal:new C,materialIndex:0};Hi.getNormal(Ui,Ni,Fi,u.normal),h.face=u}return h}var ye=class s extends Re{constructor(t=1,e=1,n=1,i=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:a};let o=this;i=Math.floor(i),r=Math.floor(r),a=Math.floor(a);let l=[],c=[],h=[],u=[],d=0,f=0;g("z","y","x",-1,-1,n,e,t,a,r,0),g("z","y","x",1,-1,n,e,-t,a,r,1),g("x","z","y",1,1,t,n,e,i,a,2),g("x","z","y",1,-1,t,n,-e,i,a,3),g("x","y","z",1,-1,t,e,n,i,r,4),g("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(l),this.setAttribute("position",new re(c,3)),this.setAttribute("normal",new re(h,3)),this.setAttribute("uv",new re(u,2));function g(y,m,p,x,_,M,T,E,R,U,v){let S=M/R,N=T/U,H=M/2,et=T/2,L=E/2,F=R+1,X=U+1,nt=0,Z=0,$=new C;for(let D=0;D<X;D++){let j=D*N-et;for(let ct=0;ct<F;ct++){let B=ct*S-H;$[y]=B*x,$[m]=j*_,$[p]=L,c.push($.x,$.y,$.z),$[y]=0,$[m]=0,$[p]=E>0?1:-1,h.push($.x,$.y,$.z),u.push(ct/R),u.push(1-D/U),nt+=1}}for(let D=0;D<U;D++)for(let j=0;j<R;j++){let ct=d+j+F*D,B=d+j+F*(D+1),tt=d+(j+1)+F*(D+1),ut=d+(j+1)+F*D;l.push(ct,B,ut),l.push(B,tt,ut),Z+=6}o.addGroup(f,Z,v),f+=Z,d+=nt}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function $i(s){let t={};for(let e in s){t[e]={};for(let n in s[e]){let i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function He(s){let t={};for(let e=0;e<s.length;e++){let n=$i(s[e]);for(let i in n)t[i]=n[i]}return t}function rd(s){let t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function Mh(s){return s.getRenderTarget()===null?s.outputColorSpace:Qt.workingColorSpace}var ad={clone:$i,merge:He},od=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,ld=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,nn=class extends ei{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=od,this.fragmentShader=ld,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=$i(t.uniforms),this.uniformsGroups=rd(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let i in this.uniforms){let a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},Or=class extends Ae{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new se,this.projectionMatrix=new se,this.projectionMatrixInverse=new se,this.coordinateSystem=Ln}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Oe=class extends Or{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=xo*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Fa*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return xo*2*Math.atan(Math.tan(Fa*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,i,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Fa*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*i/l,e-=a.offsetY*n/c,i*=a.width/l,n*=a.height/c}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Oi=-90,zi=1,bo=class extends Ae{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let i=new Oe(Oi,zi,t,e);i.layers=this.layers,this.add(i);let r=new Oe(Oi,zi,t,e);r.layers=this.layers,this.add(r);let a=new Oe(Oi,zi,t,e);a.layers=this.layers,this.add(a);let o=new Oe(Oi,zi,t,e);o.layers=this.layers,this.add(o);let l=new Oe(Oi,zi,t,e);l.layers=this.layers,this.add(l);let c=new Oe(Oi,zi,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,i,r,a,o,l]=e;for(let c of e)this.remove(c);if(t===Ln)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Ar)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;let y=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,a),t.setRenderTarget(n,2,i),t.render(e,o),t.setRenderTarget(n,3,i),t.render(e,l),t.setRenderTarget(n,4,i),t.render(e,c),n.texture.generateMipmaps=y,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},zr=class extends en{constructor(t,e,n,i,r,a,o,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:Yi,super(t,e,n,i,r,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},So=class extends Dn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];e.encoding!==void 0&&(bs("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===_i?xe:je),this.texture=new zr(i,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Qe}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new ye(5,5,5),r=new nn({name:"CubemapFromEquirect",uniforms:$i(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Te,blending:Zn});r.uniforms.tEquirect.value=e;let a=new It(i,r),o=e.minFilter;return e.minFilter===Rs&&(e.minFilter=Qe),new bo(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,i){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(r)}},to=new C,cd=new C,hd=new Yt,Pn=class{constructor(t=new C(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let i=to.subVectors(n,e).cross(cd.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(to),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||hd.getNormalMatrix(t),i=this.coplanarPoint(to).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},ui=new ti,ur=new C,Ps=class{constructor(t=new Pn,e=new Pn,n=new Pn,i=new Pn,r=new Pn,a=new Pn){this.planes=[t,e,n,i,r,a]}set(t,e,n,i,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(i),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Ln){let n=this.planes,i=t.elements,r=i[0],a=i[1],o=i[2],l=i[3],c=i[4],h=i[5],u=i[6],d=i[7],f=i[8],g=i[9],y=i[10],m=i[11],p=i[12],x=i[13],_=i[14],M=i[15];if(n[0].setComponents(l-r,d-c,m-f,M-p).normalize(),n[1].setComponents(l+r,d+c,m+f,M+p).normalize(),n[2].setComponents(l+a,d+h,m+g,M+x).normalize(),n[3].setComponents(l-a,d-h,m-g,M-x).normalize(),n[4].setComponents(l-o,d-u,m-y,M-_).normalize(),e===Ln)n[5].setComponents(l+o,d+u,m+y,M+_).normalize();else if(e===Ar)n[5].setComponents(o,u,y,_).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ui.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ui.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ui)}intersectsSprite(t){return ui.center.set(0,0,0),ui.radius=.7071067811865476,ui.applyMatrix4(t.matrixWorld),this.intersectsSphere(ui)}intersectsSphere(t){let e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let i=e[n];if(ur.x=i.normal.x>0?t.max.x:t.min.x,ur.y=i.normal.y>0?t.max.y:t.min.y,ur.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(ur)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function bh(){let s=null,t=!1,e=null,n=null;function i(r,a){e(r,a),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function ud(s,t){let e=t.isWebGL2,n=new WeakMap;function i(c,h){let u=c.array,d=c.usage,f=u.byteLength,g=s.createBuffer();s.bindBuffer(h,g),s.bufferData(h,u,d),c.onUploadCallback();let y;if(u instanceof Float32Array)y=s.FLOAT;else if(u instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(e)y=s.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else y=s.UNSIGNED_SHORT;else if(u instanceof Int16Array)y=s.SHORT;else if(u instanceof Uint32Array)y=s.UNSIGNED_INT;else if(u instanceof Int32Array)y=s.INT;else if(u instanceof Int8Array)y=s.BYTE;else if(u instanceof Uint8Array)y=s.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)y=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:g,type:y,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:f}}function r(c,h,u){let d=h.array,f=h._updateRange,g=h.updateRanges;if(s.bindBuffer(u,c),f.count===-1&&g.length===0&&s.bufferSubData(u,0,d),g.length!==0){for(let y=0,m=g.length;y<m;y++){let p=g[y];e?s.bufferSubData(u,p.start*d.BYTES_PER_ELEMENT,d,p.start,p.count):s.bufferSubData(u,p.start*d.BYTES_PER_ELEMENT,d.subarray(p.start,p.start+p.count))}h.clearUpdateRanges()}f.count!==-1&&(e?s.bufferSubData(u,f.offset*d.BYTES_PER_ELEMENT,d,f.offset,f.count):s.bufferSubData(u,f.offset*d.BYTES_PER_ELEMENT,d.subarray(f.offset,f.offset+f.count)),f.count=-1),h.onUploadCallback()}function a(c){return c.isInterleavedBufferAttribute&&(c=c.data),n.get(c)}function o(c){c.isInterleavedBufferAttribute&&(c=c.data);let h=n.get(c);h&&(s.deleteBuffer(h.buffer),n.delete(c))}function l(c,h){if(c.isGLBufferAttribute){let d=n.get(c);(!d||d.version<c.version)&&n.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);let u=n.get(c);if(u===void 0)n.set(c,i(c,h));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(u.buffer,c,h),u.version=c.version}}return{get:a,remove:o,update:l}}var Ki=class s extends Re{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};let r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(i),c=o+1,h=l+1,u=t/o,d=e/l,f=[],g=[],y=[],m=[];for(let p=0;p<h;p++){let x=p*d-a;for(let _=0;_<c;_++){let M=_*u-r;g.push(M,-x,0),y.push(0,0,1),m.push(_/o),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let x=0;x<o;x++){let _=x+c*p,M=x+c*(p+1),T=x+1+c*(p+1),E=x+1+c*p;f.push(_,M,E),f.push(M,T,E)}this.setIndex(f),this.setAttribute("position",new re(g,3)),this.setAttribute("normal",new re(y,3)),this.setAttribute("uv",new re(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.widthSegments,t.heightSegments)}},dd=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,fd=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,pd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,md=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,gd=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,_d=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,xd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,yd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,vd=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Md=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,bd=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Sd=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Ed=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,wd=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Td=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Ad=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Rd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Cd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Pd=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ld=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Id=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Dd=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Ud=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Nd=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Fd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Od=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,zd=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Bd=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,kd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Hd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Vd="gl_FragColor = linearToOutputTexel( gl_FragColor );",Gd=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Wd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Xd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,qd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Yd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Zd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Jd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,$d=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Kd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Qd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,jd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,tf=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,ef=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,nf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,sf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,rf=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,af=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,of=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lf=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,cf=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,hf=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,uf=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,df=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ff=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,pf=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,mf=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,gf=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_f=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,xf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,yf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,vf=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Mf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,bf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Sf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ef=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,wf=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Tf=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Af=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Rf=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Cf=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Pf=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Lf=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,If=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Df=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Uf=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Nf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Ff=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Of=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,zf=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Bf=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,kf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Hf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Vf=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Gf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Wf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Xf=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,qf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Yf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Zf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Jf=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,$f=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Kf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Qf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,jf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,tp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,ep=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,np=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,ip=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,sp=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,rp=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,ap=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,op=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,lp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,cp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,hp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,up=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,dp=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,fp=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,mp=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,gp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,_p=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,yp=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,vp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Mp=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,bp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Sp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ep=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,wp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Tp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Ap=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rp=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Cp=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pp=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Lp=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ip=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Dp=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Up=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Np=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fp=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Op=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zp=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Bp=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Hp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Vp=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Gp=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Wp=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Xp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Gt={alphahash_fragment:dd,alphahash_pars_fragment:fd,alphamap_fragment:pd,alphamap_pars_fragment:md,alphatest_fragment:gd,alphatest_pars_fragment:_d,aomap_fragment:xd,aomap_pars_fragment:yd,batching_pars_vertex:vd,batching_vertex:Md,begin_vertex:bd,beginnormal_vertex:Sd,bsdfs:Ed,iridescence_fragment:wd,bumpmap_pars_fragment:Td,clipping_planes_fragment:Ad,clipping_planes_pars_fragment:Rd,clipping_planes_pars_vertex:Cd,clipping_planes_vertex:Pd,color_fragment:Ld,color_pars_fragment:Id,color_pars_vertex:Dd,color_vertex:Ud,common:Nd,cube_uv_reflection_fragment:Fd,defaultnormal_vertex:Od,displacementmap_pars_vertex:zd,displacementmap_vertex:Bd,emissivemap_fragment:kd,emissivemap_pars_fragment:Hd,colorspace_fragment:Vd,colorspace_pars_fragment:Gd,envmap_fragment:Wd,envmap_common_pars_fragment:Xd,envmap_pars_fragment:qd,envmap_pars_vertex:Yd,envmap_physical_pars_fragment:af,envmap_vertex:Zd,fog_vertex:Jd,fog_pars_vertex:$d,fog_fragment:Kd,fog_pars_fragment:Qd,gradientmap_pars_fragment:jd,lightmap_fragment:tf,lightmap_pars_fragment:ef,lights_lambert_fragment:nf,lights_lambert_pars_fragment:sf,lights_pars_begin:rf,lights_toon_fragment:of,lights_toon_pars_fragment:lf,lights_phong_fragment:cf,lights_phong_pars_fragment:hf,lights_physical_fragment:uf,lights_physical_pars_fragment:df,lights_fragment_begin:ff,lights_fragment_maps:pf,lights_fragment_end:mf,logdepthbuf_fragment:gf,logdepthbuf_pars_fragment:_f,logdepthbuf_pars_vertex:xf,logdepthbuf_vertex:yf,map_fragment:vf,map_pars_fragment:Mf,map_particle_fragment:bf,map_particle_pars_fragment:Sf,metalnessmap_fragment:Ef,metalnessmap_pars_fragment:wf,morphcolor_vertex:Tf,morphnormal_vertex:Af,morphtarget_pars_vertex:Rf,morphtarget_vertex:Cf,normal_fragment_begin:Pf,normal_fragment_maps:Lf,normal_pars_fragment:If,normal_pars_vertex:Df,normal_vertex:Uf,normalmap_pars_fragment:Nf,clearcoat_normal_fragment_begin:Ff,clearcoat_normal_fragment_maps:Of,clearcoat_pars_fragment:zf,iridescence_pars_fragment:Bf,opaque_fragment:kf,packing:Hf,premultiplied_alpha_fragment:Vf,project_vertex:Gf,dithering_fragment:Wf,dithering_pars_fragment:Xf,roughnessmap_fragment:qf,roughnessmap_pars_fragment:Yf,shadowmap_pars_fragment:Zf,shadowmap_pars_vertex:Jf,shadowmap_vertex:$f,shadowmask_pars_fragment:Kf,skinbase_vertex:Qf,skinning_pars_vertex:jf,skinning_vertex:tp,skinnormal_vertex:ep,specularmap_fragment:np,specularmap_pars_fragment:ip,tonemapping_fragment:sp,tonemapping_pars_fragment:rp,transmission_fragment:ap,transmission_pars_fragment:op,uv_pars_fragment:lp,uv_pars_vertex:cp,uv_vertex:hp,worldpos_vertex:up,background_vert:dp,background_frag:fp,backgroundCube_vert:pp,backgroundCube_frag:mp,cube_vert:gp,cube_frag:_p,depth_vert:xp,depth_frag:yp,distanceRGBA_vert:vp,distanceRGBA_frag:Mp,equirect_vert:bp,equirect_frag:Sp,linedashed_vert:Ep,linedashed_frag:wp,meshbasic_vert:Tp,meshbasic_frag:Ap,meshlambert_vert:Rp,meshlambert_frag:Cp,meshmatcap_vert:Pp,meshmatcap_frag:Lp,meshnormal_vert:Ip,meshnormal_frag:Dp,meshphong_vert:Up,meshphong_frag:Np,meshphysical_vert:Fp,meshphysical_frag:Op,meshtoon_vert:zp,meshtoon_frag:Bp,points_vert:kp,points_frag:Hp,shadow_vert:Vp,shadow_frag:Gp,sprite_vert:Wp,sprite_frag:Xp},ft={common:{diffuse:{value:new Ct(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Yt}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Yt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Yt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Yt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Yt},normalScale:{value:new mt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Yt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Yt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Yt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Yt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ct(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ct(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0},uvTransform:{value:new Yt}},sprite:{diffuse:{value:new Ct(16777215)},opacity:{value:1},center:{value:new mt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}}},vn={basic:{uniforms:He([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.fog]),vertexShader:Gt.meshbasic_vert,fragmentShader:Gt.meshbasic_frag},lambert:{uniforms:He([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,ft.lights,{emissive:{value:new Ct(0)}}]),vertexShader:Gt.meshlambert_vert,fragmentShader:Gt.meshlambert_frag},phong:{uniforms:He([ft.common,ft.specularmap,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,ft.lights,{emissive:{value:new Ct(0)},specular:{value:new Ct(1118481)},shininess:{value:30}}]),vertexShader:Gt.meshphong_vert,fragmentShader:Gt.meshphong_frag},standard:{uniforms:He([ft.common,ft.envmap,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.roughnessmap,ft.metalnessmap,ft.fog,ft.lights,{emissive:{value:new Ct(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Gt.meshphysical_vert,fragmentShader:Gt.meshphysical_frag},toon:{uniforms:He([ft.common,ft.aomap,ft.lightmap,ft.emissivemap,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.gradientmap,ft.fog,ft.lights,{emissive:{value:new Ct(0)}}]),vertexShader:Gt.meshtoon_vert,fragmentShader:Gt.meshtoon_frag},matcap:{uniforms:He([ft.common,ft.bumpmap,ft.normalmap,ft.displacementmap,ft.fog,{matcap:{value:null}}]),vertexShader:Gt.meshmatcap_vert,fragmentShader:Gt.meshmatcap_frag},points:{uniforms:He([ft.points,ft.fog]),vertexShader:Gt.points_vert,fragmentShader:Gt.points_frag},dashed:{uniforms:He([ft.common,ft.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Gt.linedashed_vert,fragmentShader:Gt.linedashed_frag},depth:{uniforms:He([ft.common,ft.displacementmap]),vertexShader:Gt.depth_vert,fragmentShader:Gt.depth_frag},normal:{uniforms:He([ft.common,ft.bumpmap,ft.normalmap,ft.displacementmap,{opacity:{value:1}}]),vertexShader:Gt.meshnormal_vert,fragmentShader:Gt.meshnormal_frag},sprite:{uniforms:He([ft.sprite,ft.fog]),vertexShader:Gt.sprite_vert,fragmentShader:Gt.sprite_frag},background:{uniforms:{uvTransform:{value:new Yt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Gt.background_vert,fragmentShader:Gt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Gt.backgroundCube_vert,fragmentShader:Gt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Gt.cube_vert,fragmentShader:Gt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Gt.equirect_vert,fragmentShader:Gt.equirect_frag},distanceRGBA:{uniforms:He([ft.common,ft.displacementmap,{referencePosition:{value:new C},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Gt.distanceRGBA_vert,fragmentShader:Gt.distanceRGBA_frag},shadow:{uniforms:He([ft.lights,ft.fog,{color:{value:new Ct(0)},opacity:{value:1}}]),vertexShader:Gt.shadow_vert,fragmentShader:Gt.shadow_frag}};vn.physical={uniforms:He([vn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Yt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Yt},clearcoatNormalScale:{value:new mt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Yt},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Yt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Yt},sheen:{value:0},sheenColor:{value:new Ct(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Yt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Yt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Yt},transmissionSamplerSize:{value:new mt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Yt},attenuationDistance:{value:0},attenuationColor:{value:new Ct(0)},specularColor:{value:new Ct(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Yt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Yt},anisotropyVector:{value:new mt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Yt}}]),vertexShader:Gt.meshphysical_vert,fragmentShader:Gt.meshphysical_frag};var dr={r:0,b:0,g:0};function qp(s,t,e,n,i,r,a){let o=new Ct(0),l=r===!0?0:1,c,h,u=null,d=0,f=null;function g(m,p){let x=!1,_=p.isScene===!0?p.background:null;_&&_.isTexture&&(_=(p.backgroundBlurriness>0?e:t).get(_)),_===null?y(o,l):_&&_.isColor&&(y(_,1),x=!0);let M=s.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,a):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(s.autoClear||x)&&s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil),_&&(_.isCubeTexture||_.mapping===na)?(h===void 0&&(h=new It(new ye(1,1,1),new nn({name:"BackgroundCubeMaterial",uniforms:$i(vn.backgroundCube.uniforms),vertexShader:vn.backgroundCube.vertexShader,fragmentShader:vn.backgroundCube.fragmentShader,side:Te,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(T,E,R){this.matrixWorld.copyPosition(R.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),h.material.uniforms.envMap.value=_,h.material.uniforms.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=p.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,h.material.toneMapped=Qt.getTransfer(_.colorSpace)!==ae,(u!==_||d!==_.version||f!==s.toneMapping)&&(h.material.needsUpdate=!0,u=_,d=_.version,f=s.toneMapping),h.layers.enableAll(),m.unshift(h,h.geometry,h.material,0,0,null)):_&&_.isTexture&&(c===void 0&&(c=new It(new Ki(2,2),new nn({name:"BackgroundMaterial",uniforms:$i(vn.background.uniforms),vertexShader:vn.background.vertexShader,fragmentShader:vn.background.fragmentShader,side:Qn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=_,c.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,c.material.toneMapped=Qt.getTransfer(_.colorSpace)!==ae,_.matrixAutoUpdate===!0&&_.updateMatrix(),c.material.uniforms.uvTransform.value.copy(_.matrix),(u!==_||d!==_.version||f!==s.toneMapping)&&(c.material.needsUpdate=!0,u=_,d=_.version,f=s.toneMapping),c.layers.enableAll(),m.unshift(c,c.geometry,c.material,0,0,null))}function y(m,p){m.getRGB(dr,Mh(s)),n.buffers.color.setClear(dr.r,dr.g,dr.b,p,a)}return{getClearColor:function(){return o},setClearColor:function(m,p=1){o.set(m),l=p,y(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(m){l=m,y(o,l)},render:g}}function Yp(s,t,e,n){let i=s.getParameter(s.MAX_VERTEX_ATTRIBS),r=n.isWebGL2?null:t.get("OES_vertex_array_object"),a=n.isWebGL2||r!==null,o={},l=m(null),c=l,h=!1;function u(L,F,X,nt,Z){let $=!1;if(a){let D=y(nt,X,F);c!==D&&(c=D,f(c.object)),$=p(L,nt,X,Z),$&&x(L,nt,X,Z)}else{let D=F.wireframe===!0;(c.geometry!==nt.id||c.program!==X.id||c.wireframe!==D)&&(c.geometry=nt.id,c.program=X.id,c.wireframe=D,$=!0)}Z!==null&&e.update(Z,s.ELEMENT_ARRAY_BUFFER),($||h)&&(h=!1,U(L,F,X,nt),Z!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,e.get(Z).buffer))}function d(){return n.isWebGL2?s.createVertexArray():r.createVertexArrayOES()}function f(L){return n.isWebGL2?s.bindVertexArray(L):r.bindVertexArrayOES(L)}function g(L){return n.isWebGL2?s.deleteVertexArray(L):r.deleteVertexArrayOES(L)}function y(L,F,X){let nt=X.wireframe===!0,Z=o[L.id];Z===void 0&&(Z={},o[L.id]=Z);let $=Z[F.id];$===void 0&&($={},Z[F.id]=$);let D=$[nt];return D===void 0&&(D=m(d()),$[nt]=D),D}function m(L){let F=[],X=[],nt=[];for(let Z=0;Z<i;Z++)F[Z]=0,X[Z]=0,nt[Z]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:X,attributeDivisors:nt,object:L,attributes:{},index:null}}function p(L,F,X,nt){let Z=c.attributes,$=F.attributes,D=0,j=X.getAttributes();for(let ct in j)if(j[ct].location>=0){let tt=Z[ct],ut=$[ct];if(ut===void 0&&(ct==="instanceMatrix"&&L.instanceMatrix&&(ut=L.instanceMatrix),ct==="instanceColor"&&L.instanceColor&&(ut=L.instanceColor)),tt===void 0||tt.attribute!==ut||ut&&tt.data!==ut.data)return!0;D++}return c.attributesNum!==D||c.index!==nt}function x(L,F,X,nt){let Z={},$=F.attributes,D=0,j=X.getAttributes();for(let ct in j)if(j[ct].location>=0){let tt=$[ct];tt===void 0&&(ct==="instanceMatrix"&&L.instanceMatrix&&(tt=L.instanceMatrix),ct==="instanceColor"&&L.instanceColor&&(tt=L.instanceColor));let ut={};ut.attribute=tt,tt&&tt.data&&(ut.data=tt.data),Z[ct]=ut,D++}c.attributes=Z,c.attributesNum=D,c.index=nt}function _(){let L=c.newAttributes;for(let F=0,X=L.length;F<X;F++)L[F]=0}function M(L){T(L,0)}function T(L,F){let X=c.newAttributes,nt=c.enabledAttributes,Z=c.attributeDivisors;X[L]=1,nt[L]===0&&(s.enableVertexAttribArray(L),nt[L]=1),Z[L]!==F&&((n.isWebGL2?s:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](L,F),Z[L]=F)}function E(){let L=c.newAttributes,F=c.enabledAttributes;for(let X=0,nt=F.length;X<nt;X++)F[X]!==L[X]&&(s.disableVertexAttribArray(X),F[X]=0)}function R(L,F,X,nt,Z,$,D){D===!0?s.vertexAttribIPointer(L,F,X,Z,$):s.vertexAttribPointer(L,F,X,nt,Z,$)}function U(L,F,X,nt){if(n.isWebGL2===!1&&(L.isInstancedMesh||nt.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;_();let Z=nt.attributes,$=X.getAttributes(),D=F.defaultAttributeValues;for(let j in $){let ct=$[j];if(ct.location>=0){let B=Z[j];if(B===void 0&&(j==="instanceMatrix"&&L.instanceMatrix&&(B=L.instanceMatrix),j==="instanceColor"&&L.instanceColor&&(B=L.instanceColor)),B!==void 0){let tt=B.normalized,ut=B.itemSize,bt=e.get(B);if(bt===void 0)continue;let pt=bt.buffer,q=bt.type,K=bt.bytesPerElement,Q=n.isWebGL2===!0&&(q===s.INT||q===s.UNSIGNED_INT||B.gpuType===ch);if(B.isInterleavedBufferAttribute){let _t=B.data,P=_t.stride,st=B.offset;if(_t.isInstancedInterleavedBuffer){for(let k=0;k<ct.locationSize;k++)T(ct.location+k,_t.meshPerAttribute);L.isInstancedMesh!==!0&&nt._maxInstanceCount===void 0&&(nt._maxInstanceCount=_t.meshPerAttribute*_t.count)}else for(let k=0;k<ct.locationSize;k++)M(ct.location+k);s.bindBuffer(s.ARRAY_BUFFER,pt);for(let k=0;k<ct.locationSize;k++)R(ct.location+k,ut/ct.locationSize,q,tt,P*K,(st+ut/ct.locationSize*k)*K,Q)}else{if(B.isInstancedBufferAttribute){for(let _t=0;_t<ct.locationSize;_t++)T(ct.location+_t,B.meshPerAttribute);L.isInstancedMesh!==!0&&nt._maxInstanceCount===void 0&&(nt._maxInstanceCount=B.meshPerAttribute*B.count)}else for(let _t=0;_t<ct.locationSize;_t++)M(ct.location+_t);s.bindBuffer(s.ARRAY_BUFFER,pt);for(let _t=0;_t<ct.locationSize;_t++)R(ct.location+_t,ut/ct.locationSize,q,tt,ut*K,ut/ct.locationSize*_t*K,Q)}}else if(D!==void 0){let tt=D[j];if(tt!==void 0)switch(tt.length){case 2:s.vertexAttrib2fv(ct.location,tt);break;case 3:s.vertexAttrib3fv(ct.location,tt);break;case 4:s.vertexAttrib4fv(ct.location,tt);break;default:s.vertexAttrib1fv(ct.location,tt)}}}}E()}function v(){H();for(let L in o){let F=o[L];for(let X in F){let nt=F[X];for(let Z in nt)g(nt[Z].object),delete nt[Z];delete F[X]}delete o[L]}}function S(L){if(o[L.id]===void 0)return;let F=o[L.id];for(let X in F){let nt=F[X];for(let Z in nt)g(nt[Z].object),delete nt[Z];delete F[X]}delete o[L.id]}function N(L){for(let F in o){let X=o[F];if(X[L.id]===void 0)continue;let nt=X[L.id];for(let Z in nt)g(nt[Z].object),delete nt[Z];delete X[L.id]}}function H(){et(),h=!0,c!==l&&(c=l,f(c.object))}function et(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:u,reset:H,resetDefaultState:et,dispose:v,releaseStatesOfGeometry:S,releaseStatesOfProgram:N,initAttributes:_,enableAttribute:M,disableUnusedAttributes:E}}function Zp(s,t,e,n){let i=n.isWebGL2,r;function a(h){r=h}function o(h,u){s.drawArrays(r,h,u),e.update(u,r,1)}function l(h,u,d){if(d===0)return;let f,g;if(i)f=s,g="drawArraysInstanced";else if(f=t.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",f===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}f[g](r,h,u,d),e.update(u,r,d)}function c(h,u,d){if(d===0)return;let f=t.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<d;g++)this.render(h[g],u[g]);else{f.multiDrawArraysWEBGL(r,h,0,u,0,d);let g=0;for(let y=0;y<d;y++)g+=u[y];e.update(g,r,1)}}this.setMode=a,this.render=o,this.renderInstances=l,this.renderMultiDraw=c}function Jp(s,t,e){let n;function i(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){let R=t.get("EXT_texture_filter_anisotropic");n=s.getParameter(R.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function r(R){if(R==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";R="mediump"}return R==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let a=typeof WebGL2RenderingContext<"u"&&s.constructor.name==="WebGL2RenderingContext",o=e.precision!==void 0?e.precision:"highp",l=r(o);l!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",l,"instead."),o=l);let c=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,u=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),d=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),f=s.getParameter(s.MAX_TEXTURE_SIZE),g=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),y=s.getParameter(s.MAX_VERTEX_ATTRIBS),m=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),p=s.getParameter(s.MAX_VARYING_VECTORS),x=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),_=d>0,M=a||t.has("OES_texture_float"),T=_&&M,E=a?s.getParameter(s.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:c,getMaxAnisotropy:i,getMaxPrecision:r,precision:o,logarithmicDepthBuffer:h,maxTextures:u,maxVertexTextures:d,maxTextureSize:f,maxCubemapSize:g,maxAttributes:y,maxVertexUniforms:m,maxVaryings:p,maxFragmentUniforms:x,vertexTextures:_,floatFragmentTextures:M,floatVertexTextures:T,maxSamples:E}}function $p(s){let t=this,e=null,n=0,i=!1,r=!1,a=new Pn,o=new Yt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||i;return i=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){let g=u.clippingPlanes,y=u.clipIntersection,m=u.clipShadows,p=s.get(u);if(!i||g===null||g.length===0||r&&!m)r?h(null):c();else{let x=r?0:n,_=x*4,M=p.clippingState||null;l.value=M,M=h(g,d,_,f);for(let T=0;T!==_;++T)M[T]=e[T];p.clippingState=M,this.numIntersection=y?this.numPlanes:0,this.numPlanes+=x}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,f,g){let y=u!==null?u.length:0,m=null;if(y!==0){if(m=l.value,g!==!0||m===null){let p=f+y*4,x=d.matrixWorldInverse;o.getNormalMatrix(x),(m===null||m.length<p)&&(m=new Float32Array(p));for(let _=0,M=f;_!==y;++_,M+=4)a.copy(u[_]).applyMatrix4(x,o),a.normal.toArray(m,M),m[M+3]=a.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=y,t.numIntersection=0,m}}function Kp(s){let t=new WeakMap;function e(a,o){return o===po?a.mapping=Yi:o===mo&&(a.mapping=Zi),a}function n(a){if(a&&a.isTexture){let o=a.mapping;if(o===po||o===mo)if(t.has(a)){let l=t.get(a).texture;return e(l,a.mapping)}else{let l=a.image;if(l&&l.height>0){let c=new So(l.height/2);return c.fromEquirectangularTexture(s,a),t.set(a,c),a.addEventListener("dispose",i),e(c.texture,a.mapping)}else return null}}return a}function i(a){let o=a.target;o.removeEventListener("dispose",i);let l=t.get(o);l!==void 0&&(t.delete(o),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var Br=class extends Or{constructor(t=-1,e=1,n=1,i=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,r=n-t,a=n+t,o=i+e,l=i-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Vi=4,Rc=[.125,.215,.35,.446,.526,.582],pi=20,eo=new Br,Cc=new Ct,no=null,io=0,so=0,di=(1+Math.sqrt(5))/2,Bi=1/di,Pc=[new C(1,1,1),new C(-1,1,1),new C(1,1,-1),new C(-1,1,-1),new C(0,di,Bi),new C(0,di,-Bi),new C(Bi,0,di),new C(-Bi,0,di),new C(di,Bi,0),new C(-di,Bi,0)],Qi=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100){no=this._renderer.getRenderTarget(),io=this._renderer.getActiveCubeFace(),so=this._renderer.getActiveMipmapLevel(),this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,i,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Dc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Ic(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(no,io,so),t.scissorTest=!1,fr(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Yi||t.mapping===Zi?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),no=this._renderer.getRenderTarget(),io=this._renderer.getActiveCubeFace(),so=this._renderer.getActiveMipmapLevel();let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Qe,minFilter:Qe,generateMipmaps:!1,type:Cs,format:pn,colorSpace:In,depthBuffer:!1},i=Lc(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Lc(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Qp(r)),this._blurMaterial=jp(r,t,e)}return i}_compileMaterial(t){let e=new It(this._lodPlanes[0],t);this._renderer.compile(e,eo)}_sceneToCubeUV(t,e,n,i){let o=new Oe(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(Cc),h.toneMapping=$n,h.autoClear=!1;let f=new me({name:"PMREM.Background",side:Te,depthWrite:!1,depthTest:!1}),g=new It(new ye,f),y=!1,m=t.background;m?m.isColor&&(f.color.copy(m),t.background=null,y=!0):(f.color.copy(Cc),y=!0);for(let p=0;p<6;p++){let x=p%3;x===0?(o.up.set(0,l[p],0),o.lookAt(c[p],0,0)):x===1?(o.up.set(0,0,l[p]),o.lookAt(0,c[p],0)):(o.up.set(0,l[p],0),o.lookAt(0,0,c[p]));let _=this._cubeSize;fr(i,x*_,p>2?_:0,_,_),h.setRenderTarget(i),y&&h.render(g,o),h.render(t,o)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,t.background=m}_textureToCubeUV(t,e){let n=this._renderer,i=t.mapping===Yi||t.mapping===Zi;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=Dc()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Ic());let r=i?this._cubemapMaterial:this._equirectMaterial,a=new It(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let l=this._cubeSize;fr(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,eo)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let i=1;i<this._lodPlanes.length;i++){let r=Math.sqrt(this._sigmas[i]*this._sigmas[i]-this._sigmas[i-1]*this._sigmas[i-1]),a=Pc[(i-1)%Pc.length];this._blur(t,i-1,i,r,a)}e.autoClear=n}_blur(t,e,n,i,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,i,"latitudinal",r),this._halfBlur(a,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,a,o){let l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new It(this._lodPlanes[i],c),d=c.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*pi-1),y=r/g,m=isFinite(r)?1+Math.floor(h*y):pi;m>pi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${pi}`);let p=[],x=0;for(let R=0;R<pi;++R){let U=R/y,v=Math.exp(-U*U/2);p.push(v),R===0?x+=v:R<m&&(x+=2*v)}for(let R=0;R<p.length;R++)p[R]=p[R]/x;d.envMap.value=t.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);let{_lodMax:_}=this;d.dTheta.value=g,d.mipInt.value=_-n;let M=this._sizeLods[i],T=3*M*(i>_-Vi?i-_+Vi:0),E=4*(this._cubeSize-M);fr(e,T,E,3*M,2*M),l.setRenderTarget(e),l.render(u,eo)}};function Qp(s){let t=[],e=[],n=[],i=s,r=s-Vi+1+Rc.length;for(let a=0;a<r;a++){let o=Math.pow(2,i);e.push(o);let l=1/o;a>s-Vi?l=Rc[a-s+Vi-1]:a===0&&(l=0),n.push(l);let c=1/(o-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,y=3,m=2,p=1,x=new Float32Array(y*g*f),_=new Float32Array(m*g*f),M=new Float32Array(p*g*f);for(let E=0;E<f;E++){let R=E%3*2/3-1,U=E>2?0:-1,v=[R,U,0,R+2/3,U,0,R+2/3,U+1,0,R,U,0,R+2/3,U+1,0,R,U+1,0];x.set(v,y*g*E),_.set(d,m*g*E);let S=[E,E,E,E,E,E];M.set(S,p*g*E)}let T=new Re;T.setAttribute("position",new jt(x,y)),T.setAttribute("uv",new jt(_,m)),T.setAttribute("faceIndex",new jt(M,p)),t.push(T),i>Vi&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function Lc(s,t,e){let n=new Dn(s,t,e);return n.texture.mapping=na,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function fr(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function jp(s,t,e){let n=new Float32Array(pi),i=new C(0,1,0);return new nn({name:"SphericalGaussianBlur",defines:{n:pi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:ll(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Zn,depthTest:!1,depthWrite:!1})}function Ic(){return new nn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:ll(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Zn,depthTest:!1,depthWrite:!1})}function Dc(){return new nn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:ll(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Zn,depthTest:!1,depthWrite:!1})}function ll(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function tm(s){let t=new WeakMap,e=null;function n(o){if(o&&o.isTexture){let l=o.mapping,c=l===po||l===mo,h=l===Yi||l===Zi;if(c||h)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=t.get(o);return e===null&&(e=new Qi(s)),u=c?e.fromEquirectangular(o,u):e.fromCubemap(o,u),t.set(o,u),u.texture}else{if(t.has(o))return t.get(o).texture;{let u=o.image;if(c&&u&&u.height>0||h&&u&&i(u)){e===null&&(e=new Qi(s));let d=c?e.fromEquirectangular(o):e.fromCubemap(o);return t.set(o,d),o.addEventListener("dispose",r),d.texture}else return null}}}return o}function i(o){let l=0,c=6;for(let h=0;h<c;h++)o[h]!==void 0&&l++;return l===c}function r(o){let l=o.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function em(s){let t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=s.getExtension("WEBGL_depth_texture")||s.getExtension("MOZ_WEBGL_depth_texture")||s.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=s.getExtension("EXT_texture_filter_anisotropic")||s.getExtension("MOZ_EXT_texture_filter_anisotropic")||s.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=s.getExtension("WEBGL_compressed_texture_s3tc")||s.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=s.getExtension("WEBGL_compressed_texture_pvrtc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=s.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){let i=e(n);return i===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function nm(s,t,e,n){let i={},r=new WeakMap;function a(u){let d=u.target;d.index!==null&&t.remove(d.index);for(let g in d.attributes)t.remove(d.attributes[g]);for(let g in d.morphAttributes){let y=d.morphAttributes[g];for(let m=0,p=y.length;m<p;m++)t.remove(y[m])}d.removeEventListener("dispose",a),delete i[d.id];let f=r.get(d);f&&(t.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function o(u,d){return i[d.id]===!0||(d.addEventListener("dispose",a),i[d.id]=!0,e.memory.geometries++),d}function l(u){let d=u.attributes;for(let g in d)t.update(d[g],s.ARRAY_BUFFER);let f=u.morphAttributes;for(let g in f){let y=f[g];for(let m=0,p=y.length;m<p;m++)t.update(y[m],s.ARRAY_BUFFER)}}function c(u){let d=[],f=u.index,g=u.attributes.position,y=0;if(f!==null){let x=f.array;y=f.version;for(let _=0,M=x.length;_<M;_+=3){let T=x[_+0],E=x[_+1],R=x[_+2];d.push(T,E,E,R,R,T)}}else if(g!==void 0){let x=g.array;y=g.version;for(let _=0,M=x.length/3-1;_<M;_+=3){let T=_+0,E=_+1,R=_+2;d.push(T,E,E,R,R,T)}}else return;let m=new(yh(d)?Fr:Nr)(d,1);m.version=y;let p=r.get(u);p&&t.remove(p),r.set(u,m)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:o,update:l,getWireframeAttribute:h}}function im(s,t,e,n){let i=n.isWebGL2,r;function a(f){r=f}let o,l;function c(f){o=f.type,l=f.bytesPerElement}function h(f,g){s.drawElements(r,g,o,f*l),e.update(g,r,1)}function u(f,g,y){if(y===0)return;let m,p;if(i)m=s,p="drawElementsInstanced";else if(m=t.get("ANGLE_instanced_arrays"),p="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[p](r,g,o,f*l,y),e.update(g,r,y)}function d(f,g,y){if(y===0)return;let m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<y;p++)this.render(f[p]/l,g[p]);else{m.multiDrawElementsWEBGL(r,g,0,o,f,0,y);let p=0;for(let x=0;x<y;x++)p+=g[x];e.update(p,r,1)}}this.setMode=a,this.setIndex=c,this.render=h,this.renderInstances=u,this.renderMultiDraw=d}function sm(s){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case s.TRIANGLES:e.triangles+=o*(r/3);break;case s.LINES:e.lines+=o*(r/2);break;case s.LINE_STRIP:e.lines+=o*(r-1);break;case s.LINE_LOOP:e.lines+=o*r;break;case s.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function rm(s,t){return s[0]-t[0]}function am(s,t){return Math.abs(t[1])-Math.abs(s[1])}function om(s,t,e){let n={},i=new Float32Array(8),r=new WeakMap,a=new le,o=[];for(let c=0;c<8;c++)o[c]=[c,0];function l(c,h,u){let d=c.morphTargetInfluences;if(t.isWebGL2===!0){let f=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,g=f!==void 0?f.length:0,y=r.get(h);if(y===void 0||y.count!==g){let L=function(){H.dispose(),r.delete(h),h.removeEventListener("dispose",L)};y!==void 0&&y.texture.dispose();let x=h.morphAttributes.position!==void 0,_=h.morphAttributes.normal!==void 0,M=h.morphAttributes.color!==void 0,T=h.morphAttributes.position||[],E=h.morphAttributes.normal||[],R=h.morphAttributes.color||[],U=0;x===!0&&(U=1),_===!0&&(U=2),M===!0&&(U=3);let v=h.attributes.position.count*U,S=1;v>t.maxTextureSize&&(S=Math.ceil(v/t.maxTextureSize),v=t.maxTextureSize);let N=new Float32Array(v*S*4*g),H=new Lr(N,v,S,g);H.type=Yn,H.needsUpdate=!0;let et=U*4;for(let F=0;F<g;F++){let X=T[F],nt=E[F],Z=R[F],$=v*S*4*F;for(let D=0;D<X.count;D++){let j=D*et;x===!0&&(a.fromBufferAttribute(X,D),N[$+j+0]=a.x,N[$+j+1]=a.y,N[$+j+2]=a.z,N[$+j+3]=0),_===!0&&(a.fromBufferAttribute(nt,D),N[$+j+4]=a.x,N[$+j+5]=a.y,N[$+j+6]=a.z,N[$+j+7]=0),M===!0&&(a.fromBufferAttribute(Z,D),N[$+j+8]=a.x,N[$+j+9]=a.y,N[$+j+10]=a.z,N[$+j+11]=Z.itemSize===4?a.w:1)}}y={count:g,texture:H,size:new mt(v,S)},r.set(h,y),h.addEventListener("dispose",L)}let m=0;for(let x=0;x<d.length;x++)m+=d[x];let p=h.morphTargetsRelative?1:1-m;u.getUniforms().setValue(s,"morphTargetBaseInfluence",p),u.getUniforms().setValue(s,"morphTargetInfluences",d),u.getUniforms().setValue(s,"morphTargetsTexture",y.texture,e),u.getUniforms().setValue(s,"morphTargetsTextureSize",y.size)}else{let f=d===void 0?0:d.length,g=n[h.id];if(g===void 0||g.length!==f){g=[];for(let _=0;_<f;_++)g[_]=[_,0];n[h.id]=g}for(let _=0;_<f;_++){let M=g[_];M[0]=_,M[1]=d[_]}g.sort(am);for(let _=0;_<8;_++)_<f&&g[_][1]?(o[_][0]=g[_][0],o[_][1]=g[_][1]):(o[_][0]=Number.MAX_SAFE_INTEGER,o[_][1]=0);o.sort(rm);let y=h.morphAttributes.position,m=h.morphAttributes.normal,p=0;for(let _=0;_<8;_++){let M=o[_],T=M[0],E=M[1];T!==Number.MAX_SAFE_INTEGER&&E?(y&&h.getAttribute("morphTarget"+_)!==y[T]&&h.setAttribute("morphTarget"+_,y[T]),m&&h.getAttribute("morphNormal"+_)!==m[T]&&h.setAttribute("morphNormal"+_,m[T]),i[_]=E,p+=E):(y&&h.hasAttribute("morphTarget"+_)===!0&&h.deleteAttribute("morphTarget"+_),m&&h.hasAttribute("morphNormal"+_)===!0&&h.deleteAttribute("morphNormal"+_),i[_]=0)}let x=h.morphTargetsRelative?1:1-p;u.getUniforms().setValue(s,"morphTargetBaseInfluence",x),u.getUniforms().setValue(s,"morphTargetInfluences",i)}}return{update:l}}function lm(s,t,e,n){let i=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=t.get(l,h);if(i.get(u)!==c&&(t.update(u),i.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),i.get(l)!==c&&(e.update(l.instanceMatrix,s.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,s.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;i.get(d)!==c&&(d.update(),i.set(d,c))}return u}function a(){i=new WeakMap}function o(l){let c=l.target;c.removeEventListener("dispose",o),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:a}}var kr=class extends en{constructor(t,e,n,i,r,a,o,l,c,h){if(h=h!==void 0?h:gi,h!==gi&&h!==Ji)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===gi&&(n=qn),n===void 0&&h===Ji&&(n=mi),super(null,i,r,a,o,l,h,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:Ve,this.minFilter=l!==void 0?l:Ve,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},Sh=new en,Eh=new kr(1,1);Eh.compareFunction=xh;var wh=new Lr,Th=new Mo,Ah=new zr,Uc=[],Nc=[],Fc=new Float32Array(16),Oc=new Float32Array(9),zc=new Float32Array(4);function is(s,t,e){let n=s[0];if(n<=0||n>0)return s;let i=t*e,r=Uc[i];if(r===void 0&&(r=new Float32Array(i),Uc[i]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,s[a].toArray(r,o)}return r}function ve(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function Me(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function sa(s,t){let e=Nc[t];e===void 0&&(e=new Int32Array(t),Nc[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function cm(s,t){let e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function hm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ve(e,t))return;s.uniform2fv(this.addr,t),Me(e,t)}}function um(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(ve(e,t))return;s.uniform3fv(this.addr,t),Me(e,t)}}function dm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ve(e,t))return;s.uniform4fv(this.addr,t),Me(e,t)}}function fm(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ve(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),Me(e,t)}else{if(ve(e,n))return;zc.set(n),s.uniformMatrix2fv(this.addr,!1,zc),Me(e,n)}}function pm(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ve(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),Me(e,t)}else{if(ve(e,n))return;Oc.set(n),s.uniformMatrix3fv(this.addr,!1,Oc),Me(e,n)}}function mm(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ve(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),Me(e,t)}else{if(ve(e,n))return;Fc.set(n),s.uniformMatrix4fv(this.addr,!1,Fc),Me(e,n)}}function gm(s,t){let e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function _m(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ve(e,t))return;s.uniform2iv(this.addr,t),Me(e,t)}}function xm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ve(e,t))return;s.uniform3iv(this.addr,t),Me(e,t)}}function ym(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ve(e,t))return;s.uniform4iv(this.addr,t),Me(e,t)}}function vm(s,t){let e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function Mm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ve(e,t))return;s.uniform2uiv(this.addr,t),Me(e,t)}}function bm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ve(e,t))return;s.uniform3uiv(this.addr,t),Me(e,t)}}function Sm(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ve(e,t))return;s.uniform4uiv(this.addr,t),Me(e,t)}}function Em(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r=this.type===s.SAMPLER_2D_SHADOW?Eh:Sh;e.setTexture2D(t||r,i)}function wm(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Th,i)}function Tm(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||Ah,i)}function Am(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||wh,i)}function Rm(s){switch(s){case 5126:return cm;case 35664:return hm;case 35665:return um;case 35666:return dm;case 35674:return fm;case 35675:return pm;case 35676:return mm;case 5124:case 35670:return gm;case 35667:case 35671:return _m;case 35668:case 35672:return xm;case 35669:case 35673:return ym;case 5125:return vm;case 36294:return Mm;case 36295:return bm;case 36296:return Sm;case 35678:case 36198:case 36298:case 36306:case 35682:return Em;case 35679:case 36299:case 36307:return wm;case 35680:case 36300:case 36308:case 36293:return Tm;case 36289:case 36303:case 36311:case 36292:return Am}}function Cm(s,t){s.uniform1fv(this.addr,t)}function Pm(s,t){let e=is(t,this.size,2);s.uniform2fv(this.addr,e)}function Lm(s,t){let e=is(t,this.size,3);s.uniform3fv(this.addr,e)}function Im(s,t){let e=is(t,this.size,4);s.uniform4fv(this.addr,e)}function Dm(s,t){let e=is(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function Um(s,t){let e=is(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function Nm(s,t){let e=is(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function Fm(s,t){s.uniform1iv(this.addr,t)}function Om(s,t){s.uniform2iv(this.addr,t)}function zm(s,t){s.uniform3iv(this.addr,t)}function Bm(s,t){s.uniform4iv(this.addr,t)}function km(s,t){s.uniform1uiv(this.addr,t)}function Hm(s,t){s.uniform2uiv(this.addr,t)}function Vm(s,t){s.uniform3uiv(this.addr,t)}function Gm(s,t){s.uniform4uiv(this.addr,t)}function Wm(s,t,e){let n=this.cache,i=t.length,r=sa(e,i);ve(n,r)||(s.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==i;++a)e.setTexture2D(t[a]||Sh,r[a])}function Xm(s,t,e){let n=this.cache,i=t.length,r=sa(e,i);ve(n,r)||(s.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||Th,r[a])}function qm(s,t,e){let n=this.cache,i=t.length,r=sa(e,i);ve(n,r)||(s.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||Ah,r[a])}function Ym(s,t,e){let n=this.cache,i=t.length,r=sa(e,i);ve(n,r)||(s.uniform1iv(this.addr,r),Me(n,r));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||wh,r[a])}function Zm(s){switch(s){case 5126:return Cm;case 35664:return Pm;case 35665:return Lm;case 35666:return Im;case 35674:return Dm;case 35675:return Um;case 35676:return Nm;case 5124:case 35670:return Fm;case 35667:case 35671:return Om;case 35668:case 35672:return zm;case 35669:case 35673:return Bm;case 5125:return km;case 36294:return Hm;case 36295:return Vm;case 36296:return Gm;case 35678:case 36198:case 36298:case 36306:case 35682:return Wm;case 35679:case 36299:case 36307:return Xm;case 35680:case 36300:case 36308:case 36293:return qm;case 36289:case 36303:case 36311:case 36292:return Ym}}var Eo=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Rm(e.type)}},wo=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Zm(e.type)}},To=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let i=this.seq;for(let r=0,a=i.length;r!==a;++r){let o=i[r];o.setValue(t,e[o.id],n)}}},ro=/(\w+)(\])?(\[|\.)?/g;function Bc(s,t){s.seq.push(t),s.map[t.id]=t}function Jm(s,t,e){let n=s.name,i=n.length;for(ro.lastIndex=0;;){let r=ro.exec(n),a=ro.lastIndex,o=r[1],l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===i){Bc(e,c===void 0?new Eo(o,s,t):new wo(o,s,t));break}else{let u=e.map[o];u===void 0&&(u=new To(o),Bc(e,u)),e=u}}}var qi=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){let r=t.getActiveUniform(e,i),a=t.getUniformLocation(e,r.name);Jm(r,a,this)}}setValue(t,e,n,i){let r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){let i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,a=e.length;r!==a;++r){let o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,i)}}static seqWithValue(t,e){let n=[];for(let i=0,r=t.length;i!==r;++i){let a=t[i];a.id in e&&n.push(a)}return n}};function kc(s,t,e){let n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}var $m=37297,Km=0;function Qm(s,t){let e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=i;a<r;a++){let o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}function jm(s){let t=Qt.getPrimaries(Qt.workingColorSpace),e=Qt.getPrimaries(s),n;switch(t===e?n="":t===Tr&&e===wr?n="LinearDisplayP3ToLinearSRGB":t===wr&&e===Tr&&(n="LinearSRGBToLinearDisplayP3"),s){case In:case ia:return[n,"LinearTransferOETF"];case xe:case ol:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",s),[n,"LinearTransferOETF"]}}function Hc(s,t,e){let n=s.getShaderParameter(t,s.COMPILE_STATUS),i=s.getShaderInfoLog(t).trim();if(n&&i==="")return"";let r=/ERROR: 0:(\d+)/.exec(i);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+i+`

`+Qm(s.getShaderSource(t),a)}else return i}function tg(s,t){let e=jm(t);return`vec4 ${s}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function eg(s,t){let e;switch(t){case yu:e="Linear";break;case vu:e="Reinhard";break;case Mu:e="OptimizedCineon";break;case rl:e="ACESFilmic";break;case Su:e="AgX";break;case bu:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function ng(s){return[s.extensionDerivatives||s.envMapCubeUVHeight||s.bumpMap||s.normalMapTangentSpace||s.clearcoatNormalMap||s.flatShading||s.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(s.extensionFragDepth||s.logarithmicDepthBuffer)&&s.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",s.extensionDrawBuffers&&s.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(s.extensionShaderTextureLOD||s.envMap||s.transmission)&&s.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Gi).join(`
`)}function ig(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Gi).join(`
`)}function sg(s){let t=[];for(let e in s){let n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function rg(s,t){let e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){let r=s.getActiveAttrib(t,i),a=r.name,o=1;r.type===s.FLOAT_MAT2&&(o=2),r.type===s.FLOAT_MAT3&&(o=3),r.type===s.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:s.getAttribLocation(t,a),locationSize:o}}return e}function Gi(s){return s!==""}function Vc(s,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Gc(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var ag=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ao(s){return s.replace(ag,lg)}var og=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function lg(s,t){let e=Gt[t];if(e===void 0){let n=og.get(t);if(n!==void 0)e=Gt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Ao(e)}var cg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Wc(s){return s.replace(cg,hg)}function hg(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function Xc(s){let t="precision "+s.precision+` float;
precision `+s.precision+" int;";return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function ug(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===ah?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===Yh?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===Cn&&(t="SHADOWMAP_TYPE_VSM"),t}function dg(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case Yi:case Zi:t="ENVMAP_TYPE_CUBE";break;case na:t="ENVMAP_TYPE_CUBE_UV";break}return t}function fg(s){let t="ENVMAP_MODE_REFLECTION";return s.envMap&&s.envMapMode===Zi&&(t="ENVMAP_MODE_REFRACTION"),t}function pg(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case oh:t="ENVMAP_BLENDING_MULTIPLY";break;case _u:t="ENVMAP_BLENDING_MIX";break;case xu:t="ENVMAP_BLENDING_ADD";break}return t}function mg(s){let t=s.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function gg(s,t,e,n){let i=s.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,l=ug(e),c=dg(e),h=fg(e),u=pg(e),d=mg(e),f=e.isWebGL2?"":ng(e),g=ig(e),y=sg(r),m=i.createProgram(),p,x,_=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(Gi).join(`
`),p.length>0&&(p+=`
`),x=[f,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(Gi).join(`
`),x.length>0&&(x+=`
`)):(p=[Xc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Gi).join(`
`),x=[f,Xc(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==$n?"#define TONE_MAPPING":"",e.toneMapping!==$n?Gt.tonemapping_pars_fragment:"",e.toneMapping!==$n?eg("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Gt.colorspace_pars_fragment,tg("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Gi).join(`
`)),a=Ao(a),a=Vc(a,e),a=Gc(a,e),o=Ao(o),o=Vc(o,e),o=Gc(o,e),a=Wc(a),o=Wc(o),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(_=`#version 300 es
`,p=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,x=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===hc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===hc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);let M=_+p+a,T=_+x+o,E=kc(i,i.VERTEX_SHADER,M),R=kc(i,i.FRAGMENT_SHADER,T);i.attachShader(m,E),i.attachShader(m,R),e.index0AttributeName!==void 0?i.bindAttribLocation(m,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(m,0,"position"),i.linkProgram(m);function U(H){if(s.debug.checkShaderErrors){let et=i.getProgramInfoLog(m).trim(),L=i.getShaderInfoLog(E).trim(),F=i.getShaderInfoLog(R).trim(),X=!0,nt=!0;if(i.getProgramParameter(m,i.LINK_STATUS)===!1)if(X=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,m,E,R);else{let Z=Hc(i,E,"vertex"),$=Hc(i,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(m,i.VALIDATE_STATUS)+`

Program Info Log: `+et+`
`+Z+`
`+$)}else et!==""?console.warn("THREE.WebGLProgram: Program Info Log:",et):(L===""||F==="")&&(nt=!1);nt&&(H.diagnostics={runnable:X,programLog:et,vertexShader:{log:L,prefix:p},fragmentShader:{log:F,prefix:x}})}i.deleteShader(E),i.deleteShader(R),v=new qi(i,m),S=rg(i,m)}let v;this.getUniforms=function(){return v===void 0&&U(this),v};let S;this.getAttributes=function(){return S===void 0&&U(this),S};let N=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return N===!1&&(N=i.getProgramParameter(m,$m)),N},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(m),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Km++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=E,this.fragmentShader=R,this}var _g=0,Ro=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new Co(t),e.set(t,n)),n}},Co=class{constructor(t){this.id=_g++,this.code=t,this.usedTimes=0}};function xg(s,t,e,n,i,r,a){let o=new Ur,l=new Ro,c=[],h=i.isWebGL2,u=i.logarithmicDepthBuffer,d=i.vertexTextures,f=i.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(v){return v===0?"uv":`uv${v}`}function m(v,S,N,H,et){let L=H.fog,F=et.geometry,X=v.isMeshStandardMaterial?H.environment:null,nt=(v.isMeshStandardMaterial?e:t).get(v.envMap||X),Z=nt&&nt.mapping===na?nt.image.height:null,$=g[v.type];v.precision!==null&&(f=i.getMaxPrecision(v.precision),f!==v.precision&&console.warn("THREE.WebGLProgram.getParameters:",v.precision,"not supported, using",f,"instead."));let D=F.morphAttributes.position||F.morphAttributes.normal||F.morphAttributes.color,j=D!==void 0?D.length:0,ct=0;F.morphAttributes.position!==void 0&&(ct=1),F.morphAttributes.normal!==void 0&&(ct=2),F.morphAttributes.color!==void 0&&(ct=3);let B,tt,ut,bt;if($){let Be=vn[$];B=Be.vertexShader,tt=Be.fragmentShader}else B=v.vertexShader,tt=v.fragmentShader,l.update(v),ut=l.getVertexShaderID(v),bt=l.getFragmentShaderID(v);let pt=s.getRenderTarget(),q=et.isInstancedMesh===!0,K=et.isBatchedMesh===!0,Q=!!v.map,_t=!!v.matcap,P=!!nt,st=!!v.aoMap,k=!!v.lightMap,J=!!v.bumpMap,V=!!v.normalMap,xt=!!v.displacementMap,ht=!!v.emissiveMap,w=!!v.metalnessMap,b=!!v.roughnessMap,O=v.anisotropy>0,it=v.clearcoat>0,at=v.iridescence>0,rt=v.sheen>0,Tt=v.transmission>0,yt=O&&!!v.anisotropyMap,Et=it&&!!v.clearcoatMap,Pt=it&&!!v.clearcoatNormalMap,kt=it&&!!v.clearcoatRoughnessMap,ot=at&&!!v.iridescenceMap,$t=at&&!!v.iridescenceThicknessMap,Zt=rt&&!!v.sheenColorMap,Ft=rt&&!!v.sheenRoughnessMap,Rt=!!v.specularMap,wt=!!v.specularColorMap,Vt=!!v.specularIntensityMap,Kt=Tt&&!!v.transmissionMap,ue=Tt&&!!v.thicknessMap,Xt=!!v.gradientMap,dt=!!v.alphaMap,I=v.alphaTest>0,vt=!!v.alphaHash,Mt=!!v.extensions,Ut=!!F.attributes.uv1,Lt=!!F.attributes.uv2,ee=!!F.attributes.uv3,ne=$n;return v.toneMapped&&(pt===null||pt.isXRRenderTarget===!0)&&(ne=s.toneMapping),{isWebGL2:h,shaderID:$,shaderType:v.type,shaderName:v.name,vertexShader:B,fragmentShader:tt,defines:v.defines,customVertexShaderID:ut,customFragmentShaderID:bt,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:f,batching:K,instancing:q,instancingColor:q&&et.instanceColor!==null,supportsVertexTextures:d,outputColorSpace:pt===null?s.outputColorSpace:pt.isXRRenderTarget===!0?pt.texture.colorSpace:In,map:Q,matcap:_t,envMap:P,envMapMode:P&&nt.mapping,envMapCubeUVHeight:Z,aoMap:st,lightMap:k,bumpMap:J,normalMap:V,displacementMap:d&&xt,emissiveMap:ht,normalMapObjectSpace:V&&v.normalMapType===Nu,normalMapTangentSpace:V&&v.normalMapType===_h,metalnessMap:w,roughnessMap:b,anisotropy:O,anisotropyMap:yt,clearcoat:it,clearcoatMap:Et,clearcoatNormalMap:Pt,clearcoatRoughnessMap:kt,iridescence:at,iridescenceMap:ot,iridescenceThicknessMap:$t,sheen:rt,sheenColorMap:Zt,sheenRoughnessMap:Ft,specularMap:Rt,specularColorMap:wt,specularIntensityMap:Vt,transmission:Tt,transmissionMap:Kt,thicknessMap:ue,gradientMap:Xt,opaque:v.transparent===!1&&v.blending===Jn,alphaMap:dt,alphaTest:I,alphaHash:vt,combine:v.combine,mapUv:Q&&y(v.map.channel),aoMapUv:st&&y(v.aoMap.channel),lightMapUv:k&&y(v.lightMap.channel),bumpMapUv:J&&y(v.bumpMap.channel),normalMapUv:V&&y(v.normalMap.channel),displacementMapUv:xt&&y(v.displacementMap.channel),emissiveMapUv:ht&&y(v.emissiveMap.channel),metalnessMapUv:w&&y(v.metalnessMap.channel),roughnessMapUv:b&&y(v.roughnessMap.channel),anisotropyMapUv:yt&&y(v.anisotropyMap.channel),clearcoatMapUv:Et&&y(v.clearcoatMap.channel),clearcoatNormalMapUv:Pt&&y(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:kt&&y(v.clearcoatRoughnessMap.channel),iridescenceMapUv:ot&&y(v.iridescenceMap.channel),iridescenceThicknessMapUv:$t&&y(v.iridescenceThicknessMap.channel),sheenColorMapUv:Zt&&y(v.sheenColorMap.channel),sheenRoughnessMapUv:Ft&&y(v.sheenRoughnessMap.channel),specularMapUv:Rt&&y(v.specularMap.channel),specularColorMapUv:wt&&y(v.specularColorMap.channel),specularIntensityMapUv:Vt&&y(v.specularIntensityMap.channel),transmissionMapUv:Kt&&y(v.transmissionMap.channel),thicknessMapUv:ue&&y(v.thicknessMap.channel),alphaMapUv:dt&&y(v.alphaMap.channel),vertexTangents:!!F.attributes.tangent&&(V||O),vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!F.attributes.color&&F.attributes.color.itemSize===4,vertexUv1s:Ut,vertexUv2s:Lt,vertexUv3s:ee,pointsUvs:et.isPoints===!0&&!!F.attributes.uv&&(Q||dt),fog:!!L,useFog:v.fog===!0,fogExp2:L&&L.isFogExp2,flatShading:v.flatShading===!0,sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:et.isSkinnedMesh===!0,morphTargets:F.morphAttributes.position!==void 0,morphNormals:F.morphAttributes.normal!==void 0,morphColors:F.morphAttributes.color!==void 0,morphTargetsCount:j,morphTextureStride:ct,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:v.dithering,shadowMapEnabled:s.shadowMap.enabled&&N.length>0,shadowMapType:s.shadowMap.type,toneMapping:ne,useLegacyLights:s._useLegacyLights,decodeVideoTexture:Q&&v.map.isVideoTexture===!0&&Qt.getTransfer(v.map.colorSpace)===ae,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===Ge,flipSided:v.side===Te,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionDerivatives:Mt&&v.extensions.derivatives===!0,extensionFragDepth:Mt&&v.extensions.fragDepth===!0,extensionDrawBuffers:Mt&&v.extensions.drawBuffers===!0,extensionShaderTextureLOD:Mt&&v.extensions.shaderTextureLOD===!0,extensionClipCullDistance:Mt&&v.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()}}function p(v){let S=[];if(v.shaderID?S.push(v.shaderID):(S.push(v.customVertexShaderID),S.push(v.customFragmentShaderID)),v.defines!==void 0)for(let N in v.defines)S.push(N),S.push(v.defines[N]);return v.isRawShaderMaterial===!1&&(x(S,v),_(S,v),S.push(s.outputColorSpace)),S.push(v.customProgramCacheKey),S.join()}function x(v,S){v.push(S.precision),v.push(S.outputColorSpace),v.push(S.envMapMode),v.push(S.envMapCubeUVHeight),v.push(S.mapUv),v.push(S.alphaMapUv),v.push(S.lightMapUv),v.push(S.aoMapUv),v.push(S.bumpMapUv),v.push(S.normalMapUv),v.push(S.displacementMapUv),v.push(S.emissiveMapUv),v.push(S.metalnessMapUv),v.push(S.roughnessMapUv),v.push(S.anisotropyMapUv),v.push(S.clearcoatMapUv),v.push(S.clearcoatNormalMapUv),v.push(S.clearcoatRoughnessMapUv),v.push(S.iridescenceMapUv),v.push(S.iridescenceThicknessMapUv),v.push(S.sheenColorMapUv),v.push(S.sheenRoughnessMapUv),v.push(S.specularMapUv),v.push(S.specularColorMapUv),v.push(S.specularIntensityMapUv),v.push(S.transmissionMapUv),v.push(S.thicknessMapUv),v.push(S.combine),v.push(S.fogExp2),v.push(S.sizeAttenuation),v.push(S.morphTargetsCount),v.push(S.morphAttributeCount),v.push(S.numDirLights),v.push(S.numPointLights),v.push(S.numSpotLights),v.push(S.numSpotLightMaps),v.push(S.numHemiLights),v.push(S.numRectAreaLights),v.push(S.numDirLightShadows),v.push(S.numPointLightShadows),v.push(S.numSpotLightShadows),v.push(S.numSpotLightShadowsWithMaps),v.push(S.numLightProbes),v.push(S.shadowMapType),v.push(S.toneMapping),v.push(S.numClippingPlanes),v.push(S.numClipIntersection),v.push(S.depthPacking)}function _(v,S){o.disableAll(),S.isWebGL2&&o.enable(0),S.supportsVertexTextures&&o.enable(1),S.instancing&&o.enable(2),S.instancingColor&&o.enable(3),S.matcap&&o.enable(4),S.envMap&&o.enable(5),S.normalMapObjectSpace&&o.enable(6),S.normalMapTangentSpace&&o.enable(7),S.clearcoat&&o.enable(8),S.iridescence&&o.enable(9),S.alphaTest&&o.enable(10),S.vertexColors&&o.enable(11),S.vertexAlphas&&o.enable(12),S.vertexUv1s&&o.enable(13),S.vertexUv2s&&o.enable(14),S.vertexUv3s&&o.enable(15),S.vertexTangents&&o.enable(16),S.anisotropy&&o.enable(17),S.alphaHash&&o.enable(18),S.batching&&o.enable(19),v.push(o.mask),o.disableAll(),S.fog&&o.enable(0),S.useFog&&o.enable(1),S.flatShading&&o.enable(2),S.logarithmicDepthBuffer&&o.enable(3),S.skinning&&o.enable(4),S.morphTargets&&o.enable(5),S.morphNormals&&o.enable(6),S.morphColors&&o.enable(7),S.premultipliedAlpha&&o.enable(8),S.shadowMapEnabled&&o.enable(9),S.useLegacyLights&&o.enable(10),S.doubleSided&&o.enable(11),S.flipSided&&o.enable(12),S.useDepthPacking&&o.enable(13),S.dithering&&o.enable(14),S.transmission&&o.enable(15),S.sheen&&o.enable(16),S.opaque&&o.enable(17),S.pointsUvs&&o.enable(18),S.decodeVideoTexture&&o.enable(19),v.push(o.mask)}function M(v){let S=g[v.type],N;if(S){let H=vn[S];N=ad.clone(H.uniforms)}else N=v.uniforms;return N}function T(v,S){let N;for(let H=0,et=c.length;H<et;H++){let L=c[H];if(L.cacheKey===S){N=L,++N.usedTimes;break}}return N===void 0&&(N=new gg(s,S,v,r),c.push(N)),N}function E(v){if(--v.usedTimes===0){let S=c.indexOf(v);c[S]=c[c.length-1],c.pop(),v.destroy()}}function R(v){l.remove(v)}function U(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:M,acquireProgram:T,releaseProgram:E,releaseShaderCache:R,programs:c,dispose:U}}function yg(){let s=new WeakMap;function t(r){let a=s.get(r);return a===void 0&&(a={},s.set(r,a)),a}function e(r){s.delete(r)}function n(r,a,o){s.get(r)[a]=o}function i(){s=new WeakMap}return{get:t,remove:e,update:n,dispose:i}}function vg(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function qc(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function Yc(){let s=[],t=0,e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function a(u,d,f,g,y,m){let p=s[t];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:y,group:m},s[t]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=y,p.group=m),t++,p}function o(u,d,f,g,y,m){let p=a(u,d,f,g,y,m);f.transmission>0?n.push(p):f.transparent===!0?i.push(p):e.push(p)}function l(u,d,f,g,y,m){let p=a(u,d,f,g,y,m);f.transmission>0?n.unshift(p):f.transparent===!0?i.unshift(p):e.unshift(p)}function c(u,d){e.length>1&&e.sort(u||vg),n.length>1&&n.sort(d||qc),i.length>1&&i.sort(d||qc)}function h(){for(let u=t,d=s.length;u<d;u++){let f=s[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:o,unshift:l,finish:h,sort:c}}function Mg(){let s=new WeakMap;function t(n,i){let r=s.get(n),a;return r===void 0?(a=new Yc,s.set(n,[a])):i>=r.length?(a=new Yc,r.push(a)):a=r[i],a}function e(){s=new WeakMap}return{get:t,dispose:e}}function bg(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new C,color:new Ct};break;case"SpotLight":e={position:new C,direction:new C,color:new Ct,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new C,color:new Ct,distance:0,decay:0};break;case"HemisphereLight":e={direction:new C,skyColor:new Ct,groundColor:new Ct};break;case"RectAreaLight":e={color:new Ct,position:new C,halfWidth:new C,halfHeight:new C};break}return s[t.id]=e,e}}}function Sg(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new mt};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new mt};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new mt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}var Eg=0;function wg(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function Tg(s,t){let e=new bg,n=Sg(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)i.probe.push(new C);let r=new C,a=new se,o=new se;function l(h,u){let d=0,f=0,g=0;for(let H=0;H<9;H++)i.probe[H].set(0,0,0);let y=0,m=0,p=0,x=0,_=0,M=0,T=0,E=0,R=0,U=0,v=0;h.sort(wg);let S=u===!0?Math.PI:1;for(let H=0,et=h.length;H<et;H++){let L=h[H],F=L.color,X=L.intensity,nt=L.distance,Z=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)d+=F.r*X*S,f+=F.g*X*S,g+=F.b*X*S;else if(L.isLightProbe){for(let $=0;$<9;$++)i.probe[$].addScaledVector(L.sh.coefficients[$],X);v++}else if(L.isDirectionalLight){let $=e.get(L);if($.color.copy(L.color).multiplyScalar(L.intensity*S),L.castShadow){let D=L.shadow,j=n.get(L);j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,i.directionalShadow[y]=j,i.directionalShadowMap[y]=Z,i.directionalShadowMatrix[y]=L.shadow.matrix,M++}i.directional[y]=$,y++}else if(L.isSpotLight){let $=e.get(L);$.position.setFromMatrixPosition(L.matrixWorld),$.color.copy(F).multiplyScalar(X*S),$.distance=nt,$.coneCos=Math.cos(L.angle),$.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),$.decay=L.decay,i.spot[p]=$;let D=L.shadow;if(L.map&&(i.spotLightMap[R]=L.map,R++,D.updateMatrices(L),L.castShadow&&U++),i.spotLightMatrix[p]=D.matrix,L.castShadow){let j=n.get(L);j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,i.spotShadow[p]=j,i.spotShadowMap[p]=Z,E++}p++}else if(L.isRectAreaLight){let $=e.get(L);$.color.copy(F).multiplyScalar(X),$.halfWidth.set(L.width*.5,0,0),$.halfHeight.set(0,L.height*.5,0),i.rectArea[x]=$,x++}else if(L.isPointLight){let $=e.get(L);if($.color.copy(L.color).multiplyScalar(L.intensity*S),$.distance=L.distance,$.decay=L.decay,L.castShadow){let D=L.shadow,j=n.get(L);j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,j.shadowCameraNear=D.camera.near,j.shadowCameraFar=D.camera.far,i.pointShadow[m]=j,i.pointShadowMap[m]=Z,i.pointShadowMatrix[m]=L.shadow.matrix,T++}i.point[m]=$,m++}else if(L.isHemisphereLight){let $=e.get(L);$.skyColor.copy(L.color).multiplyScalar(X*S),$.groundColor.copy(L.groundColor).multiplyScalar(X*S),i.hemi[_]=$,_++}}x>0&&(t.isWebGL2?s.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ft.LTC_FLOAT_1,i.rectAreaLTC2=ft.LTC_FLOAT_2):(i.rectAreaLTC1=ft.LTC_HALF_1,i.rectAreaLTC2=ft.LTC_HALF_2):s.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ft.LTC_FLOAT_1,i.rectAreaLTC2=ft.LTC_FLOAT_2):s.has("OES_texture_half_float_linear")===!0?(i.rectAreaLTC1=ft.LTC_HALF_1,i.rectAreaLTC2=ft.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),i.ambient[0]=d,i.ambient[1]=f,i.ambient[2]=g;let N=i.hash;(N.directionalLength!==y||N.pointLength!==m||N.spotLength!==p||N.rectAreaLength!==x||N.hemiLength!==_||N.numDirectionalShadows!==M||N.numPointShadows!==T||N.numSpotShadows!==E||N.numSpotMaps!==R||N.numLightProbes!==v)&&(i.directional.length=y,i.spot.length=p,i.rectArea.length=x,i.point.length=m,i.hemi.length=_,i.directionalShadow.length=M,i.directionalShadowMap.length=M,i.pointShadow.length=T,i.pointShadowMap.length=T,i.spotShadow.length=E,i.spotShadowMap.length=E,i.directionalShadowMatrix.length=M,i.pointShadowMatrix.length=T,i.spotLightMatrix.length=E+R-U,i.spotLightMap.length=R,i.numSpotLightShadowsWithMaps=U,i.numLightProbes=v,N.directionalLength=y,N.pointLength=m,N.spotLength=p,N.rectAreaLength=x,N.hemiLength=_,N.numDirectionalShadows=M,N.numPointShadows=T,N.numSpotShadows=E,N.numSpotMaps=R,N.numLightProbes=v,i.version=Eg++)}function c(h,u){let d=0,f=0,g=0,y=0,m=0,p=u.matrixWorldInverse;for(let x=0,_=h.length;x<_;x++){let M=h[x];if(M.isDirectionalLight){let T=i.directional[d];T.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),T.direction.sub(r),T.direction.transformDirection(p),d++}else if(M.isSpotLight){let T=i.spot[g];T.position.setFromMatrixPosition(M.matrixWorld),T.position.applyMatrix4(p),T.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),T.direction.sub(r),T.direction.transformDirection(p),g++}else if(M.isRectAreaLight){let T=i.rectArea[y];T.position.setFromMatrixPosition(M.matrixWorld),T.position.applyMatrix4(p),o.identity(),a.copy(M.matrixWorld),a.premultiply(p),o.extractRotation(a),T.halfWidth.set(M.width*.5,0,0),T.halfHeight.set(0,M.height*.5,0),T.halfWidth.applyMatrix4(o),T.halfHeight.applyMatrix4(o),y++}else if(M.isPointLight){let T=i.point[f];T.position.setFromMatrixPosition(M.matrixWorld),T.position.applyMatrix4(p),f++}else if(M.isHemisphereLight){let T=i.hemi[m];T.direction.setFromMatrixPosition(M.matrixWorld),T.direction.transformDirection(p),m++}}}return{setup:l,setupView:c,state:i}}function Zc(s,t){let e=new Tg(s,t),n=[],i=[];function r(){n.length=0,i.length=0}function a(u){n.push(u)}function o(u){i.push(u)}function l(u){e.setup(n,u)}function c(u){e.setupView(n,u)}return{init:r,state:{lightsArray:n,shadowsArray:i,lights:e},setupLights:l,setupLightsView:c,pushLight:a,pushShadow:o}}function Ag(s,t){let e=new WeakMap;function n(r,a=0){let o=e.get(r),l;return o===void 0?(l=new Zc(s,t),e.set(r,[l])):a>=o.length?(l=new Zc(s,t),o.push(l)):l=o[a],l}function i(){e=new WeakMap}return{get:n,dispose:i}}var Po=class extends ei{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Du,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},Lo=class extends ei{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},Rg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Cg=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Pg(s,t,e){let n=new Ps,i=new mt,r=new mt,a=new le,o=new Po({depthPacking:Uu}),l=new Lo,c={},h=e.maxTextureSize,u={[Qn]:Te,[Te]:Qn,[Ge]:Ge},d=new nn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new mt},radius:{value:4}},vertexShader:Rg,fragmentShader:Cg}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let g=new Re;g.setAttribute("position",new jt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let y=new It(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ah;let p=this.type;this.render=function(E,R,U){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;let v=s.getRenderTarget(),S=s.getActiveCubeFace(),N=s.getActiveMipmapLevel(),H=s.state;H.setBlending(Zn),H.buffers.color.setClear(1,1,1,1),H.buffers.depth.setTest(!0),H.setScissorTest(!1);let et=p!==Cn&&this.type===Cn,L=p===Cn&&this.type!==Cn;for(let F=0,X=E.length;F<X;F++){let nt=E[F],Z=nt.shadow;if(Z===void 0){console.warn("THREE.WebGLShadowMap:",nt,"has no shadow.");continue}if(Z.autoUpdate===!1&&Z.needsUpdate===!1)continue;i.copy(Z.mapSize);let $=Z.getFrameExtents();if(i.multiply($),r.copy(Z.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/$.x),i.x=r.x*$.x,Z.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/$.y),i.y=r.y*$.y,Z.mapSize.y=r.y)),Z.map===null||et===!0||L===!0){let j=this.type!==Cn?{minFilter:Ve,magFilter:Ve}:{};Z.map!==null&&Z.map.dispose(),Z.map=new Dn(i.x,i.y,j),Z.map.texture.name=nt.name+".shadowMap",Z.camera.updateProjectionMatrix()}s.setRenderTarget(Z.map),s.clear();let D=Z.getViewportCount();for(let j=0;j<D;j++){let ct=Z.getViewport(j);a.set(r.x*ct.x,r.y*ct.y,r.x*ct.z,r.y*ct.w),H.viewport(a),Z.updateMatrices(nt,j),n=Z.getFrustum(),M(R,U,Z.camera,nt,this.type)}Z.isPointLightShadow!==!0&&this.type===Cn&&x(Z,U),Z.needsUpdate=!1}p=this.type,m.needsUpdate=!1,s.setRenderTarget(v,S,N)};function x(E,R){let U=t.update(y);d.defines.VSM_SAMPLES!==E.blurSamples&&(d.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new Dn(i.x,i.y)),d.uniforms.shadow_pass.value=E.map.texture,d.uniforms.resolution.value=E.mapSize,d.uniforms.radius.value=E.radius,s.setRenderTarget(E.mapPass),s.clear(),s.renderBufferDirect(R,null,U,d,y,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value=E.mapSize,f.uniforms.radius.value=E.radius,s.setRenderTarget(E.map),s.clear(),s.renderBufferDirect(R,null,U,f,y,null)}function _(E,R,U,v){let S=null,N=U.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(N!==void 0)S=N;else if(S=U.isPointLight===!0?l:o,s.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0){let H=S.uuid,et=R.uuid,L=c[H];L===void 0&&(L={},c[H]=L);let F=L[et];F===void 0&&(F=S.clone(),L[et]=F,R.addEventListener("dispose",T)),S=F}if(S.visible=R.visible,S.wireframe=R.wireframe,v===Cn?S.side=R.shadowSide!==null?R.shadowSide:R.side:S.side=R.shadowSide!==null?R.shadowSide:u[R.side],S.alphaMap=R.alphaMap,S.alphaTest=R.alphaTest,S.map=R.map,S.clipShadows=R.clipShadows,S.clippingPlanes=R.clippingPlanes,S.clipIntersection=R.clipIntersection,S.displacementMap=R.displacementMap,S.displacementScale=R.displacementScale,S.displacementBias=R.displacementBias,S.wireframeLinewidth=R.wireframeLinewidth,S.linewidth=R.linewidth,U.isPointLight===!0&&S.isMeshDistanceMaterial===!0){let H=s.properties.get(S);H.light=U}return S}function M(E,R,U,v,S){if(E.visible===!1)return;if(E.layers.test(R.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&S===Cn)&&(!E.frustumCulled||n.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,E.matrixWorld);let et=t.update(E),L=E.material;if(Array.isArray(L)){let F=et.groups;for(let X=0,nt=F.length;X<nt;X++){let Z=F[X],$=L[Z.materialIndex];if($&&$.visible){let D=_(E,$,v,S);E.onBeforeShadow(s,E,R,U,et,D,Z),s.renderBufferDirect(U,null,et,D,E,Z),E.onAfterShadow(s,E,R,U,et,D,Z)}}}else if(L.visible){let F=_(E,L,v,S);E.onBeforeShadow(s,E,R,U,et,F,null),s.renderBufferDirect(U,null,et,F,E,null),E.onAfterShadow(s,E,R,U,et,F,null)}}let H=E.children;for(let et=0,L=H.length;et<L;et++)M(H[et],R,U,v,S)}function T(E){E.target.removeEventListener("dispose",T);for(let U in c){let v=c[U],S=E.target.uuid;S in v&&(v[S].dispose(),delete v[S])}}}function Lg(s,t,e){let n=e.isWebGL2;function i(){let I=!1,vt=new le,Mt=null,Ut=new le(0,0,0,0);return{setMask:function(Lt){Mt!==Lt&&!I&&(s.colorMask(Lt,Lt,Lt,Lt),Mt=Lt)},setLocked:function(Lt){I=Lt},setClear:function(Lt,ee,ne,Se,Be){Be===!0&&(Lt*=Se,ee*=Se,ne*=Se),vt.set(Lt,ee,ne,Se),Ut.equals(vt)===!1&&(s.clearColor(Lt,ee,ne,Se),Ut.copy(vt))},reset:function(){I=!1,Mt=null,Ut.set(-1,0,0,0)}}}function r(){let I=!1,vt=null,Mt=null,Ut=null;return{setTest:function(Lt){Lt?K(s.DEPTH_TEST):Q(s.DEPTH_TEST)},setMask:function(Lt){vt!==Lt&&!I&&(s.depthMask(Lt),vt=Lt)},setFunc:function(Lt){if(Mt!==Lt){switch(Lt){case hu:s.depthFunc(s.NEVER);break;case uu:s.depthFunc(s.ALWAYS);break;case du:s.depthFunc(s.LESS);break;case Mr:s.depthFunc(s.LEQUAL);break;case fu:s.depthFunc(s.EQUAL);break;case pu:s.depthFunc(s.GEQUAL);break;case mu:s.depthFunc(s.GREATER);break;case gu:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}Mt=Lt}},setLocked:function(Lt){I=Lt},setClear:function(Lt){Ut!==Lt&&(s.clearDepth(Lt),Ut=Lt)},reset:function(){I=!1,vt=null,Mt=null,Ut=null}}}function a(){let I=!1,vt=null,Mt=null,Ut=null,Lt=null,ee=null,ne=null,Se=null,Be=null;return{setTest:function(ie){I||(ie?K(s.STENCIL_TEST):Q(s.STENCIL_TEST))},setMask:function(ie){vt!==ie&&!I&&(s.stencilMask(ie),vt=ie)},setFunc:function(ie,ke,yn){(Mt!==ie||Ut!==ke||Lt!==yn)&&(s.stencilFunc(ie,ke,yn),Mt=ie,Ut=ke,Lt=yn)},setOp:function(ie,ke,yn){(ee!==ie||ne!==ke||Se!==yn)&&(s.stencilOp(ie,ke,yn),ee=ie,ne=ke,Se=yn)},setLocked:function(ie){I=ie},setClear:function(ie){Be!==ie&&(s.clearStencil(ie),Be=ie)},reset:function(){I=!1,vt=null,Mt=null,Ut=null,Lt=null,ee=null,ne=null,Se=null,Be=null}}}let o=new i,l=new r,c=new a,h=new WeakMap,u=new WeakMap,d={},f={},g=new WeakMap,y=[],m=null,p=!1,x=null,_=null,M=null,T=null,E=null,R=null,U=null,v=new Ct(0,0,0),S=0,N=!1,H=null,et=null,L=null,F=null,X=null,nt=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS),Z=!1,$=0,D=s.getParameter(s.VERSION);D.indexOf("WebGL")!==-1?($=parseFloat(/^WebGL (\d)/.exec(D)[1]),Z=$>=1):D.indexOf("OpenGL ES")!==-1&&($=parseFloat(/^OpenGL ES (\d)/.exec(D)[1]),Z=$>=2);let j=null,ct={},B=s.getParameter(s.SCISSOR_BOX),tt=s.getParameter(s.VIEWPORT),ut=new le().fromArray(B),bt=new le().fromArray(tt);function pt(I,vt,Mt,Ut){let Lt=new Uint8Array(4),ee=s.createTexture();s.bindTexture(I,ee),s.texParameteri(I,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(I,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let ne=0;ne<Mt;ne++)n&&(I===s.TEXTURE_3D||I===s.TEXTURE_2D_ARRAY)?s.texImage3D(vt,0,s.RGBA,1,1,Ut,0,s.RGBA,s.UNSIGNED_BYTE,Lt):s.texImage2D(vt+ne,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,Lt);return ee}let q={};q[s.TEXTURE_2D]=pt(s.TEXTURE_2D,s.TEXTURE_2D,1),q[s.TEXTURE_CUBE_MAP]=pt(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(q[s.TEXTURE_2D_ARRAY]=pt(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),q[s.TEXTURE_3D]=pt(s.TEXTURE_3D,s.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),l.setClear(1),c.setClear(0),K(s.DEPTH_TEST),l.setFunc(Mr),ht(!1),w(Rl),K(s.CULL_FACE),V(Zn);function K(I){d[I]!==!0&&(s.enable(I),d[I]=!0)}function Q(I){d[I]!==!1&&(s.disable(I),d[I]=!1)}function _t(I,vt){return f[I]!==vt?(s.bindFramebuffer(I,vt),f[I]=vt,n&&(I===s.DRAW_FRAMEBUFFER&&(f[s.FRAMEBUFFER]=vt),I===s.FRAMEBUFFER&&(f[s.DRAW_FRAMEBUFFER]=vt)),!0):!1}function P(I,vt){let Mt=y,Ut=!1;if(I)if(Mt=g.get(vt),Mt===void 0&&(Mt=[],g.set(vt,Mt)),I.isWebGLMultipleRenderTargets){let Lt=I.texture;if(Mt.length!==Lt.length||Mt[0]!==s.COLOR_ATTACHMENT0){for(let ee=0,ne=Lt.length;ee<ne;ee++)Mt[ee]=s.COLOR_ATTACHMENT0+ee;Mt.length=Lt.length,Ut=!0}}else Mt[0]!==s.COLOR_ATTACHMENT0&&(Mt[0]=s.COLOR_ATTACHMENT0,Ut=!0);else Mt[0]!==s.BACK&&(Mt[0]=s.BACK,Ut=!0);Ut&&(e.isWebGL2?s.drawBuffers(Mt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(Mt))}function st(I){return m!==I?(s.useProgram(I),m=I,!0):!1}let k={[fi]:s.FUNC_ADD,[Jh]:s.FUNC_SUBTRACT,[$h]:s.FUNC_REVERSE_SUBTRACT};if(n)k[Ll]=s.MIN,k[Il]=s.MAX;else{let I=t.get("EXT_blend_minmax");I!==null&&(k[Ll]=I.MIN_EXT,k[Il]=I.MAX_EXT)}let J={[Kh]:s.ZERO,[Qh]:s.ONE,[jh]:s.SRC_COLOR,[uo]:s.SRC_ALPHA,[ru]:s.SRC_ALPHA_SATURATE,[iu]:s.DST_COLOR,[eu]:s.DST_ALPHA,[tu]:s.ONE_MINUS_SRC_COLOR,[fo]:s.ONE_MINUS_SRC_ALPHA,[su]:s.ONE_MINUS_DST_COLOR,[nu]:s.ONE_MINUS_DST_ALPHA,[au]:s.CONSTANT_COLOR,[ou]:s.ONE_MINUS_CONSTANT_COLOR,[lu]:s.CONSTANT_ALPHA,[cu]:s.ONE_MINUS_CONSTANT_ALPHA};function V(I,vt,Mt,Ut,Lt,ee,ne,Se,Be,ie){if(I===Zn){p===!0&&(Q(s.BLEND),p=!1);return}if(p===!1&&(K(s.BLEND),p=!0),I!==Zh){if(I!==x||ie!==N){if((_!==fi||E!==fi)&&(s.blendEquation(s.FUNC_ADD),_=fi,E=fi),ie)switch(I){case Jn:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case mn:s.blendFunc(s.ONE,s.ONE);break;case Cl:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case Pl:s.blendFuncSeparate(s.ZERO,s.SRC_COLOR,s.ZERO,s.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}else switch(I){case Jn:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case mn:s.blendFunc(s.SRC_ALPHA,s.ONE);break;case Cl:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case Pl:s.blendFunc(s.ZERO,s.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",I);break}M=null,T=null,R=null,U=null,v.set(0,0,0),S=0,x=I,N=ie}return}Lt=Lt||vt,ee=ee||Mt,ne=ne||Ut,(vt!==_||Lt!==E)&&(s.blendEquationSeparate(k[vt],k[Lt]),_=vt,E=Lt),(Mt!==M||Ut!==T||ee!==R||ne!==U)&&(s.blendFuncSeparate(J[Mt],J[Ut],J[ee],J[ne]),M=Mt,T=Ut,R=ee,U=ne),(Se.equals(v)===!1||Be!==S)&&(s.blendColor(Se.r,Se.g,Se.b,Be),v.copy(Se),S=Be),x=I,N=!1}function xt(I,vt){I.side===Ge?Q(s.CULL_FACE):K(s.CULL_FACE);let Mt=I.side===Te;vt&&(Mt=!Mt),ht(Mt),I.blending===Jn&&I.transparent===!1?V(Zn):V(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),l.setFunc(I.depthFunc),l.setTest(I.depthTest),l.setMask(I.depthWrite),o.setMask(I.colorWrite);let Ut=I.stencilWrite;c.setTest(Ut),Ut&&(c.setMask(I.stencilWriteMask),c.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),c.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),O(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?K(s.SAMPLE_ALPHA_TO_COVERAGE):Q(s.SAMPLE_ALPHA_TO_COVERAGE)}function ht(I){H!==I&&(I?s.frontFace(s.CW):s.frontFace(s.CCW),H=I)}function w(I){I!==Xh?(K(s.CULL_FACE),I!==et&&(I===Rl?s.cullFace(s.BACK):I===qh?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):Q(s.CULL_FACE),et=I}function b(I){I!==L&&(Z&&s.lineWidth(I),L=I)}function O(I,vt,Mt){I?(K(s.POLYGON_OFFSET_FILL),(F!==vt||X!==Mt)&&(s.polygonOffset(vt,Mt),F=vt,X=Mt)):Q(s.POLYGON_OFFSET_FILL)}function it(I){I?K(s.SCISSOR_TEST):Q(s.SCISSOR_TEST)}function at(I){I===void 0&&(I=s.TEXTURE0+nt-1),j!==I&&(s.activeTexture(I),j=I)}function rt(I,vt,Mt){Mt===void 0&&(j===null?Mt=s.TEXTURE0+nt-1:Mt=j);let Ut=ct[Mt];Ut===void 0&&(Ut={type:void 0,texture:void 0},ct[Mt]=Ut),(Ut.type!==I||Ut.texture!==vt)&&(j!==Mt&&(s.activeTexture(Mt),j=Mt),s.bindTexture(I,vt||q[I]),Ut.type=I,Ut.texture=vt)}function Tt(){let I=ct[j];I!==void 0&&I.type!==void 0&&(s.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function yt(){try{s.compressedTexImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Et(){try{s.compressedTexImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Pt(){try{s.texSubImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function kt(){try{s.texSubImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function ot(){try{s.compressedTexSubImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function $t(){try{s.compressedTexSubImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Zt(){try{s.texStorage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Ft(){try{s.texStorage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Rt(){try{s.texImage2D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function wt(){try{s.texImage3D.apply(s,arguments)}catch(I){console.error("THREE.WebGLState:",I)}}function Vt(I){ut.equals(I)===!1&&(s.scissor(I.x,I.y,I.z,I.w),ut.copy(I))}function Kt(I){bt.equals(I)===!1&&(s.viewport(I.x,I.y,I.z,I.w),bt.copy(I))}function ue(I,vt){let Mt=u.get(vt);Mt===void 0&&(Mt=new WeakMap,u.set(vt,Mt));let Ut=Mt.get(I);Ut===void 0&&(Ut=s.getUniformBlockIndex(vt,I.name),Mt.set(I,Ut))}function Xt(I,vt){let Ut=u.get(vt).get(I);h.get(vt)!==Ut&&(s.uniformBlockBinding(vt,Ut,I.__bindingPointIndex),h.set(vt,Ut))}function dt(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),n===!0&&(s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null)),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),d={},j=null,ct={},f={},g=new WeakMap,y=[],m=null,p=!1,x=null,_=null,M=null,T=null,E=null,R=null,U=null,v=new Ct(0,0,0),S=0,N=!1,H=null,et=null,L=null,F=null,X=null,ut.set(0,0,s.canvas.width,s.canvas.height),bt.set(0,0,s.canvas.width,s.canvas.height),o.reset(),l.reset(),c.reset()}return{buffers:{color:o,depth:l,stencil:c},enable:K,disable:Q,bindFramebuffer:_t,drawBuffers:P,useProgram:st,setBlending:V,setMaterial:xt,setFlipSided:ht,setCullFace:w,setLineWidth:b,setPolygonOffset:O,setScissorTest:it,activeTexture:at,bindTexture:rt,unbindTexture:Tt,compressedTexImage2D:yt,compressedTexImage3D:Et,texImage2D:Rt,texImage3D:wt,updateUBOMapping:ue,uniformBlockBinding:Xt,texStorage2D:Zt,texStorage3D:Ft,texSubImage2D:Pt,texSubImage3D:kt,compressedTexSubImage2D:ot,compressedTexSubImage3D:$t,scissor:Vt,viewport:Kt,reset:dt}}function Ig(s,t,e,n,i,r,a){let o=i.isWebGL2,l=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap,u,d=new WeakMap,f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(w,b){return f?new OffscreenCanvas(w,b):Rr("canvas")}function y(w,b,O,it){let at=1;if((w.width>it||w.height>it)&&(at=it/Math.max(w.width,w.height)),at<1||b===!0)if(typeof HTMLImageElement<"u"&&w instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&w instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&w instanceof ImageBitmap){let rt=b?yo:Math.floor,Tt=rt(at*w.width),yt=rt(at*w.height);u===void 0&&(u=g(Tt,yt));let Et=O?g(Tt,yt):u;return Et.width=Tt,Et.height=yt,Et.getContext("2d").drawImage(w,0,0,Tt,yt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+w.width+"x"+w.height+") to ("+Tt+"x"+yt+")."),Et}else return"data"in w&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+w.width+"x"+w.height+")."),w;return w}function m(w){return uc(w.width)&&uc(w.height)}function p(w){return o?!1:w.wrapS!==fn||w.wrapT!==fn||w.minFilter!==Ve&&w.minFilter!==Qe}function x(w,b){return w.generateMipmaps&&b&&w.minFilter!==Ve&&w.minFilter!==Qe}function _(w){s.generateMipmap(w)}function M(w,b,O,it,at=!1){if(o===!1)return b;if(w!==null){if(s[w]!==void 0)return s[w];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+w+"'")}let rt=b;if(b===s.RED&&(O===s.FLOAT&&(rt=s.R32F),O===s.HALF_FLOAT&&(rt=s.R16F),O===s.UNSIGNED_BYTE&&(rt=s.R8)),b===s.RED_INTEGER&&(O===s.UNSIGNED_BYTE&&(rt=s.R8UI),O===s.UNSIGNED_SHORT&&(rt=s.R16UI),O===s.UNSIGNED_INT&&(rt=s.R32UI),O===s.BYTE&&(rt=s.R8I),O===s.SHORT&&(rt=s.R16I),O===s.INT&&(rt=s.R32I)),b===s.RG&&(O===s.FLOAT&&(rt=s.RG32F),O===s.HALF_FLOAT&&(rt=s.RG16F),O===s.UNSIGNED_BYTE&&(rt=s.RG8)),b===s.RGBA){let Tt=at?Er:Qt.getTransfer(it);O===s.FLOAT&&(rt=s.RGBA32F),O===s.HALF_FLOAT&&(rt=s.RGBA16F),O===s.UNSIGNED_BYTE&&(rt=Tt===ae?s.SRGB8_ALPHA8:s.RGBA8),O===s.UNSIGNED_SHORT_4_4_4_4&&(rt=s.RGBA4),O===s.UNSIGNED_SHORT_5_5_5_1&&(rt=s.RGB5_A1)}return(rt===s.R16F||rt===s.R32F||rt===s.RG16F||rt===s.RG32F||rt===s.RGBA16F||rt===s.RGBA32F)&&t.get("EXT_color_buffer_float"),rt}function T(w,b,O){return x(w,O)===!0||w.isFramebufferTexture&&w.minFilter!==Ve&&w.minFilter!==Qe?Math.log2(Math.max(b.width,b.height))+1:w.mipmaps!==void 0&&w.mipmaps.length>0?w.mipmaps.length:w.isCompressedTexture&&Array.isArray(w.image)?b.mipmaps.length:1}function E(w){return w===Ve||w===Dl||w===Ca?s.NEAREST:s.LINEAR}function R(w){let b=w.target;b.removeEventListener("dispose",R),v(b),b.isVideoTexture&&h.delete(b)}function U(w){let b=w.target;b.removeEventListener("dispose",U),N(b)}function v(w){let b=n.get(w);if(b.__webglInit===void 0)return;let O=w.source,it=d.get(O);if(it){let at=it[b.__cacheKey];at.usedTimes--,at.usedTimes===0&&S(w),Object.keys(it).length===0&&d.delete(O)}n.remove(w)}function S(w){let b=n.get(w);s.deleteTexture(b.__webglTexture);let O=w.source,it=d.get(O);delete it[b.__cacheKey],a.memory.textures--}function N(w){let b=w.texture,O=n.get(w),it=n.get(b);if(it.__webglTexture!==void 0&&(s.deleteTexture(it.__webglTexture),a.memory.textures--),w.depthTexture&&w.depthTexture.dispose(),w.isWebGLCubeRenderTarget)for(let at=0;at<6;at++){if(Array.isArray(O.__webglFramebuffer[at]))for(let rt=0;rt<O.__webglFramebuffer[at].length;rt++)s.deleteFramebuffer(O.__webglFramebuffer[at][rt]);else s.deleteFramebuffer(O.__webglFramebuffer[at]);O.__webglDepthbuffer&&s.deleteRenderbuffer(O.__webglDepthbuffer[at])}else{if(Array.isArray(O.__webglFramebuffer))for(let at=0;at<O.__webglFramebuffer.length;at++)s.deleteFramebuffer(O.__webglFramebuffer[at]);else s.deleteFramebuffer(O.__webglFramebuffer);if(O.__webglDepthbuffer&&s.deleteRenderbuffer(O.__webglDepthbuffer),O.__webglMultisampledFramebuffer&&s.deleteFramebuffer(O.__webglMultisampledFramebuffer),O.__webglColorRenderbuffer)for(let at=0;at<O.__webglColorRenderbuffer.length;at++)O.__webglColorRenderbuffer[at]&&s.deleteRenderbuffer(O.__webglColorRenderbuffer[at]);O.__webglDepthRenderbuffer&&s.deleteRenderbuffer(O.__webglDepthRenderbuffer)}if(w.isWebGLMultipleRenderTargets)for(let at=0,rt=b.length;at<rt;at++){let Tt=n.get(b[at]);Tt.__webglTexture&&(s.deleteTexture(Tt.__webglTexture),a.memory.textures--),n.remove(b[at])}n.remove(b),n.remove(w)}let H=0;function et(){H=0}function L(){let w=H;return w>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+w+" texture units while this GPU supports only "+i.maxTextures),H+=1,w}function F(w){let b=[];return b.push(w.wrapS),b.push(w.wrapT),b.push(w.wrapR||0),b.push(w.magFilter),b.push(w.minFilter),b.push(w.anisotropy),b.push(w.internalFormat),b.push(w.format),b.push(w.type),b.push(w.generateMipmaps),b.push(w.premultiplyAlpha),b.push(w.flipY),b.push(w.unpackAlignment),b.push(w.colorSpace),b.join()}function X(w,b){let O=n.get(w);if(w.isVideoTexture&&xt(w),w.isRenderTargetTexture===!1&&w.version>0&&O.__version!==w.version){let it=w.image;if(it===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(it.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ut(O,w,b);return}}e.bindTexture(s.TEXTURE_2D,O.__webglTexture,s.TEXTURE0+b)}function nt(w,b){let O=n.get(w);if(w.version>0&&O.__version!==w.version){ut(O,w,b);return}e.bindTexture(s.TEXTURE_2D_ARRAY,O.__webglTexture,s.TEXTURE0+b)}function Z(w,b){let O=n.get(w);if(w.version>0&&O.__version!==w.version){ut(O,w,b);return}e.bindTexture(s.TEXTURE_3D,O.__webglTexture,s.TEXTURE0+b)}function $(w,b){let O=n.get(w);if(w.version>0&&O.__version!==w.version){bt(O,w,b);return}e.bindTexture(s.TEXTURE_CUBE_MAP,O.__webglTexture,s.TEXTURE0+b)}let D={[As]:s.REPEAT,[fn]:s.CLAMP_TO_EDGE,[go]:s.MIRRORED_REPEAT},j={[Ve]:s.NEAREST,[Dl]:s.NEAREST_MIPMAP_NEAREST,[Ca]:s.NEAREST_MIPMAP_LINEAR,[Qe]:s.LINEAR,[Eu]:s.LINEAR_MIPMAP_NEAREST,[Rs]:s.LINEAR_MIPMAP_LINEAR},ct={[Fu]:s.NEVER,[Vu]:s.ALWAYS,[Ou]:s.LESS,[xh]:s.LEQUAL,[zu]:s.EQUAL,[Hu]:s.GEQUAL,[Bu]:s.GREATER,[ku]:s.NOTEQUAL};function B(w,b,O){if(O?(s.texParameteri(w,s.TEXTURE_WRAP_S,D[b.wrapS]),s.texParameteri(w,s.TEXTURE_WRAP_T,D[b.wrapT]),(w===s.TEXTURE_3D||w===s.TEXTURE_2D_ARRAY)&&s.texParameteri(w,s.TEXTURE_WRAP_R,D[b.wrapR]),s.texParameteri(w,s.TEXTURE_MAG_FILTER,j[b.magFilter]),s.texParameteri(w,s.TEXTURE_MIN_FILTER,j[b.minFilter])):(s.texParameteri(w,s.TEXTURE_WRAP_S,s.CLAMP_TO_EDGE),s.texParameteri(w,s.TEXTURE_WRAP_T,s.CLAMP_TO_EDGE),(w===s.TEXTURE_3D||w===s.TEXTURE_2D_ARRAY)&&s.texParameteri(w,s.TEXTURE_WRAP_R,s.CLAMP_TO_EDGE),(b.wrapS!==fn||b.wrapT!==fn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),s.texParameteri(w,s.TEXTURE_MAG_FILTER,E(b.magFilter)),s.texParameteri(w,s.TEXTURE_MIN_FILTER,E(b.minFilter)),b.minFilter!==Ve&&b.minFilter!==Qe&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),b.compareFunction&&(s.texParameteri(w,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(w,s.TEXTURE_COMPARE_FUNC,ct[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){let it=t.get("EXT_texture_filter_anisotropic");if(b.magFilter===Ve||b.minFilter!==Ca&&b.minFilter!==Rs||b.type===Yn&&t.has("OES_texture_float_linear")===!1||o===!1&&b.type===Cs&&t.has("OES_texture_half_float_linear")===!1)return;(b.anisotropy>1||n.get(b).__currentAnisotropy)&&(s.texParameterf(w,it.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,i.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy)}}function tt(w,b){let O=!1;w.__webglInit===void 0&&(w.__webglInit=!0,b.addEventListener("dispose",R));let it=b.source,at=d.get(it);at===void 0&&(at={},d.set(it,at));let rt=F(b);if(rt!==w.__cacheKey){at[rt]===void 0&&(at[rt]={texture:s.createTexture(),usedTimes:0},a.memory.textures++,O=!0),at[rt].usedTimes++;let Tt=at[w.__cacheKey];Tt!==void 0&&(at[w.__cacheKey].usedTimes--,Tt.usedTimes===0&&S(b)),w.__cacheKey=rt,w.__webglTexture=at[rt].texture}return O}function ut(w,b,O){let it=s.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(it=s.TEXTURE_2D_ARRAY),b.isData3DTexture&&(it=s.TEXTURE_3D);let at=tt(w,b),rt=b.source;e.bindTexture(it,w.__webglTexture,s.TEXTURE0+O);let Tt=n.get(rt);if(rt.version!==Tt.__version||at===!0){e.activeTexture(s.TEXTURE0+O);let yt=Qt.getPrimaries(Qt.workingColorSpace),Et=b.colorSpace===je?null:Qt.getPrimaries(b.colorSpace),Pt=b.colorSpace===je||yt===Et?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,b.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,b.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Pt);let kt=p(b)&&m(b.image)===!1,ot=y(b.image,kt,!1,i.maxTextureSize);ot=ht(b,ot);let $t=m(ot)||o,Zt=r.convert(b.format,b.colorSpace),Ft=r.convert(b.type),Rt=M(b.internalFormat,Zt,Ft,b.colorSpace,b.isVideoTexture);B(it,b,$t);let wt,Vt=b.mipmaps,Kt=o&&b.isVideoTexture!==!0&&Rt!==mh,ue=Tt.__version===void 0||at===!0,Xt=T(b,ot,$t);if(b.isDepthTexture)Rt=s.DEPTH_COMPONENT,o?b.type===Yn?Rt=s.DEPTH_COMPONENT32F:b.type===qn?Rt=s.DEPTH_COMPONENT24:b.type===mi?Rt=s.DEPTH24_STENCIL8:Rt=s.DEPTH_COMPONENT16:b.type===Yn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),b.format===gi&&Rt===s.DEPTH_COMPONENT&&b.type!==al&&b.type!==qn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),b.type=qn,Ft=r.convert(b.type)),b.format===Ji&&Rt===s.DEPTH_COMPONENT&&(Rt=s.DEPTH_STENCIL,b.type!==mi&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),b.type=mi,Ft=r.convert(b.type))),ue&&(Kt?e.texStorage2D(s.TEXTURE_2D,1,Rt,ot.width,ot.height):e.texImage2D(s.TEXTURE_2D,0,Rt,ot.width,ot.height,0,Zt,Ft,null));else if(b.isDataTexture)if(Vt.length>0&&$t){Kt&&ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,Vt[0].width,Vt[0].height);for(let dt=0,I=Vt.length;dt<I;dt++)wt=Vt[dt],Kt?e.texSubImage2D(s.TEXTURE_2D,dt,0,0,wt.width,wt.height,Zt,Ft,wt.data):e.texImage2D(s.TEXTURE_2D,dt,Rt,wt.width,wt.height,0,Zt,Ft,wt.data);b.generateMipmaps=!1}else Kt?(ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,ot.width,ot.height),e.texSubImage2D(s.TEXTURE_2D,0,0,0,ot.width,ot.height,Zt,Ft,ot.data)):e.texImage2D(s.TEXTURE_2D,0,Rt,ot.width,ot.height,0,Zt,Ft,ot.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){Kt&&ue&&e.texStorage3D(s.TEXTURE_2D_ARRAY,Xt,Rt,Vt[0].width,Vt[0].height,ot.depth);for(let dt=0,I=Vt.length;dt<I;dt++)wt=Vt[dt],b.format!==pn?Zt!==null?Kt?e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,dt,0,0,0,wt.width,wt.height,ot.depth,Zt,wt.data,0,0):e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,dt,Rt,wt.width,wt.height,ot.depth,0,wt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Kt?e.texSubImage3D(s.TEXTURE_2D_ARRAY,dt,0,0,0,wt.width,wt.height,ot.depth,Zt,Ft,wt.data):e.texImage3D(s.TEXTURE_2D_ARRAY,dt,Rt,wt.width,wt.height,ot.depth,0,Zt,Ft,wt.data)}else{Kt&&ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,Vt[0].width,Vt[0].height);for(let dt=0,I=Vt.length;dt<I;dt++)wt=Vt[dt],b.format!==pn?Zt!==null?Kt?e.compressedTexSubImage2D(s.TEXTURE_2D,dt,0,0,wt.width,wt.height,Zt,wt.data):e.compressedTexImage2D(s.TEXTURE_2D,dt,Rt,wt.width,wt.height,0,wt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Kt?e.texSubImage2D(s.TEXTURE_2D,dt,0,0,wt.width,wt.height,Zt,Ft,wt.data):e.texImage2D(s.TEXTURE_2D,dt,Rt,wt.width,wt.height,0,Zt,Ft,wt.data)}else if(b.isDataArrayTexture)Kt?(ue&&e.texStorage3D(s.TEXTURE_2D_ARRAY,Xt,Rt,ot.width,ot.height,ot.depth),e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,ot.width,ot.height,ot.depth,Zt,Ft,ot.data)):e.texImage3D(s.TEXTURE_2D_ARRAY,0,Rt,ot.width,ot.height,ot.depth,0,Zt,Ft,ot.data);else if(b.isData3DTexture)Kt?(ue&&e.texStorage3D(s.TEXTURE_3D,Xt,Rt,ot.width,ot.height,ot.depth),e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,ot.width,ot.height,ot.depth,Zt,Ft,ot.data)):e.texImage3D(s.TEXTURE_3D,0,Rt,ot.width,ot.height,ot.depth,0,Zt,Ft,ot.data);else if(b.isFramebufferTexture){if(ue)if(Kt)e.texStorage2D(s.TEXTURE_2D,Xt,Rt,ot.width,ot.height);else{let dt=ot.width,I=ot.height;for(let vt=0;vt<Xt;vt++)e.texImage2D(s.TEXTURE_2D,vt,Rt,dt,I,0,Zt,Ft,null),dt>>=1,I>>=1}}else if(Vt.length>0&&$t){Kt&&ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,Vt[0].width,Vt[0].height);for(let dt=0,I=Vt.length;dt<I;dt++)wt=Vt[dt],Kt?e.texSubImage2D(s.TEXTURE_2D,dt,0,0,Zt,Ft,wt):e.texImage2D(s.TEXTURE_2D,dt,Rt,Zt,Ft,wt);b.generateMipmaps=!1}else Kt?(ue&&e.texStorage2D(s.TEXTURE_2D,Xt,Rt,ot.width,ot.height),e.texSubImage2D(s.TEXTURE_2D,0,0,0,Zt,Ft,ot)):e.texImage2D(s.TEXTURE_2D,0,Rt,Zt,Ft,ot);x(b,$t)&&_(it),Tt.__version=rt.version,b.onUpdate&&b.onUpdate(b)}w.__version=b.version}function bt(w,b,O){if(b.image.length!==6)return;let it=tt(w,b),at=b.source;e.bindTexture(s.TEXTURE_CUBE_MAP,w.__webglTexture,s.TEXTURE0+O);let rt=n.get(at);if(at.version!==rt.__version||it===!0){e.activeTexture(s.TEXTURE0+O);let Tt=Qt.getPrimaries(Qt.workingColorSpace),yt=b.colorSpace===je?null:Qt.getPrimaries(b.colorSpace),Et=b.colorSpace===je||Tt===yt?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,b.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,b.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Et);let Pt=b.isCompressedTexture||b.image[0].isCompressedTexture,kt=b.image[0]&&b.image[0].isDataTexture,ot=[];for(let dt=0;dt<6;dt++)!Pt&&!kt?ot[dt]=y(b.image[dt],!1,!0,i.maxCubemapSize):ot[dt]=kt?b.image[dt].image:b.image[dt],ot[dt]=ht(b,ot[dt]);let $t=ot[0],Zt=m($t)||o,Ft=r.convert(b.format,b.colorSpace),Rt=r.convert(b.type),wt=M(b.internalFormat,Ft,Rt,b.colorSpace),Vt=o&&b.isVideoTexture!==!0,Kt=rt.__version===void 0||it===!0,ue=T(b,$t,Zt);B(s.TEXTURE_CUBE_MAP,b,Zt);let Xt;if(Pt){Vt&&Kt&&e.texStorage2D(s.TEXTURE_CUBE_MAP,ue,wt,$t.width,$t.height);for(let dt=0;dt<6;dt++){Xt=ot[dt].mipmaps;for(let I=0;I<Xt.length;I++){let vt=Xt[I];b.format!==pn?Ft!==null?Vt?e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I,0,0,vt.width,vt.height,Ft,vt.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I,wt,vt.width,vt.height,0,vt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I,0,0,vt.width,vt.height,Ft,Rt,vt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I,wt,vt.width,vt.height,0,Ft,Rt,vt.data)}}}else{Xt=b.mipmaps,Vt&&Kt&&(Xt.length>0&&ue++,e.texStorage2D(s.TEXTURE_CUBE_MAP,ue,wt,ot[0].width,ot[0].height));for(let dt=0;dt<6;dt++)if(kt){Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,0,0,ot[dt].width,ot[dt].height,Ft,Rt,ot[dt].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,wt,ot[dt].width,ot[dt].height,0,Ft,Rt,ot[dt].data);for(let I=0;I<Xt.length;I++){let Mt=Xt[I].image[dt].image;Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I+1,0,0,Mt.width,Mt.height,Ft,Rt,Mt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I+1,wt,Mt.width,Mt.height,0,Ft,Rt,Mt.data)}}else{Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,0,0,Ft,Rt,ot[dt]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0,wt,Ft,Rt,ot[dt]);for(let I=0;I<Xt.length;I++){let vt=Xt[I];Vt?e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I+1,0,0,Ft,Rt,vt.image[dt]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+dt,I+1,wt,Ft,Rt,vt.image[dt])}}}x(b,Zt)&&_(s.TEXTURE_CUBE_MAP),rt.__version=at.version,b.onUpdate&&b.onUpdate(b)}w.__version=b.version}function pt(w,b,O,it,at,rt){let Tt=r.convert(O.format,O.colorSpace),yt=r.convert(O.type),Et=M(O.internalFormat,Tt,yt,O.colorSpace);if(!n.get(b).__hasExternalTextures){let kt=Math.max(1,b.width>>rt),ot=Math.max(1,b.height>>rt);at===s.TEXTURE_3D||at===s.TEXTURE_2D_ARRAY?e.texImage3D(at,rt,Et,kt,ot,b.depth,0,Tt,yt,null):e.texImage2D(at,rt,Et,kt,ot,0,Tt,yt,null)}e.bindFramebuffer(s.FRAMEBUFFER,w),V(b)?l.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,it,at,n.get(O).__webglTexture,0,J(b)):(at===s.TEXTURE_2D||at>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&at<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,it,at,n.get(O).__webglTexture,rt),e.bindFramebuffer(s.FRAMEBUFFER,null)}function q(w,b,O){if(s.bindRenderbuffer(s.RENDERBUFFER,w),b.depthBuffer&&!b.stencilBuffer){let it=o===!0?s.DEPTH_COMPONENT24:s.DEPTH_COMPONENT16;if(O||V(b)){let at=b.depthTexture;at&&at.isDepthTexture&&(at.type===Yn?it=s.DEPTH_COMPONENT32F:at.type===qn&&(it=s.DEPTH_COMPONENT24));let rt=J(b);V(b)?l.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,rt,it,b.width,b.height):s.renderbufferStorageMultisample(s.RENDERBUFFER,rt,it,b.width,b.height)}else s.renderbufferStorage(s.RENDERBUFFER,it,b.width,b.height);s.framebufferRenderbuffer(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.RENDERBUFFER,w)}else if(b.depthBuffer&&b.stencilBuffer){let it=J(b);O&&V(b)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,it,s.DEPTH24_STENCIL8,b.width,b.height):V(b)?l.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,it,s.DEPTH24_STENCIL8,b.width,b.height):s.renderbufferStorage(s.RENDERBUFFER,s.DEPTH_STENCIL,b.width,b.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.RENDERBUFFER,w)}else{let it=b.isWebGLMultipleRenderTargets===!0?b.texture:[b.texture];for(let at=0;at<it.length;at++){let rt=it[at],Tt=r.convert(rt.format,rt.colorSpace),yt=r.convert(rt.type),Et=M(rt.internalFormat,Tt,yt,rt.colorSpace),Pt=J(b);O&&V(b)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,Pt,Et,b.width,b.height):V(b)?l.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,Pt,Et,b.width,b.height):s.renderbufferStorage(s.RENDERBUFFER,Et,b.width,b.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function K(w,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,w),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(b.depthTexture).__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),X(b.depthTexture,0);let it=n.get(b.depthTexture).__webglTexture,at=J(b);if(b.depthTexture.format===gi)V(b)?l.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,it,0,at):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,it,0);else if(b.depthTexture.format===Ji)V(b)?l.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,it,0,at):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,it,0);else throw new Error("Unknown depthTexture format")}function Q(w){let b=n.get(w),O=w.isWebGLCubeRenderTarget===!0;if(w.depthTexture&&!b.__autoAllocateDepthBuffer){if(O)throw new Error("target.depthTexture not supported in Cube render targets");K(b.__webglFramebuffer,w)}else if(O){b.__webglDepthbuffer=[];for(let it=0;it<6;it++)e.bindFramebuffer(s.FRAMEBUFFER,b.__webglFramebuffer[it]),b.__webglDepthbuffer[it]=s.createRenderbuffer(),q(b.__webglDepthbuffer[it],w,!1)}else e.bindFramebuffer(s.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer=s.createRenderbuffer(),q(b.__webglDepthbuffer,w,!1);e.bindFramebuffer(s.FRAMEBUFFER,null)}function _t(w,b,O){let it=n.get(w);b!==void 0&&pt(it.__webglFramebuffer,w,w.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),O!==void 0&&Q(w)}function P(w){let b=w.texture,O=n.get(w),it=n.get(b);w.addEventListener("dispose",U),w.isWebGLMultipleRenderTargets!==!0&&(it.__webglTexture===void 0&&(it.__webglTexture=s.createTexture()),it.__version=b.version,a.memory.textures++);let at=w.isWebGLCubeRenderTarget===!0,rt=w.isWebGLMultipleRenderTargets===!0,Tt=m(w)||o;if(at){O.__webglFramebuffer=[];for(let yt=0;yt<6;yt++)if(o&&b.mipmaps&&b.mipmaps.length>0){O.__webglFramebuffer[yt]=[];for(let Et=0;Et<b.mipmaps.length;Et++)O.__webglFramebuffer[yt][Et]=s.createFramebuffer()}else O.__webglFramebuffer[yt]=s.createFramebuffer()}else{if(o&&b.mipmaps&&b.mipmaps.length>0){O.__webglFramebuffer=[];for(let yt=0;yt<b.mipmaps.length;yt++)O.__webglFramebuffer[yt]=s.createFramebuffer()}else O.__webglFramebuffer=s.createFramebuffer();if(rt)if(i.drawBuffers){let yt=w.texture;for(let Et=0,Pt=yt.length;Et<Pt;Et++){let kt=n.get(yt[Et]);kt.__webglTexture===void 0&&(kt.__webglTexture=s.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&w.samples>0&&V(w)===!1){let yt=rt?b:[b];O.__webglMultisampledFramebuffer=s.createFramebuffer(),O.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,O.__webglMultisampledFramebuffer);for(let Et=0;Et<yt.length;Et++){let Pt=yt[Et];O.__webglColorRenderbuffer[Et]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,O.__webglColorRenderbuffer[Et]);let kt=r.convert(Pt.format,Pt.colorSpace),ot=r.convert(Pt.type),$t=M(Pt.internalFormat,kt,ot,Pt.colorSpace,w.isXRRenderTarget===!0),Zt=J(w);s.renderbufferStorageMultisample(s.RENDERBUFFER,Zt,$t,w.width,w.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Et,s.RENDERBUFFER,O.__webglColorRenderbuffer[Et])}s.bindRenderbuffer(s.RENDERBUFFER,null),w.depthBuffer&&(O.__webglDepthRenderbuffer=s.createRenderbuffer(),q(O.__webglDepthRenderbuffer,w,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(at){e.bindTexture(s.TEXTURE_CUBE_MAP,it.__webglTexture),B(s.TEXTURE_CUBE_MAP,b,Tt);for(let yt=0;yt<6;yt++)if(o&&b.mipmaps&&b.mipmaps.length>0)for(let Et=0;Et<b.mipmaps.length;Et++)pt(O.__webglFramebuffer[yt][Et],w,b,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Et);else pt(O.__webglFramebuffer[yt],w,b,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+yt,0);x(b,Tt)&&_(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(rt){let yt=w.texture;for(let Et=0,Pt=yt.length;Et<Pt;Et++){let kt=yt[Et],ot=n.get(kt);e.bindTexture(s.TEXTURE_2D,ot.__webglTexture),B(s.TEXTURE_2D,kt,Tt),pt(O.__webglFramebuffer,w,kt,s.COLOR_ATTACHMENT0+Et,s.TEXTURE_2D,0),x(kt,Tt)&&_(s.TEXTURE_2D)}e.unbindTexture()}else{let yt=s.TEXTURE_2D;if((w.isWebGL3DRenderTarget||w.isWebGLArrayRenderTarget)&&(o?yt=w.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(yt,it.__webglTexture),B(yt,b,Tt),o&&b.mipmaps&&b.mipmaps.length>0)for(let Et=0;Et<b.mipmaps.length;Et++)pt(O.__webglFramebuffer[Et],w,b,s.COLOR_ATTACHMENT0,yt,Et);else pt(O.__webglFramebuffer,w,b,s.COLOR_ATTACHMENT0,yt,0);x(b,Tt)&&_(yt),e.unbindTexture()}w.depthBuffer&&Q(w)}function st(w){let b=m(w)||o,O=w.isWebGLMultipleRenderTargets===!0?w.texture:[w.texture];for(let it=0,at=O.length;it<at;it++){let rt=O[it];if(x(rt,b)){let Tt=w.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:s.TEXTURE_2D,yt=n.get(rt).__webglTexture;e.bindTexture(Tt,yt),_(Tt),e.unbindTexture()}}}function k(w){if(o&&w.samples>0&&V(w)===!1){let b=w.isWebGLMultipleRenderTargets?w.texture:[w.texture],O=w.width,it=w.height,at=s.COLOR_BUFFER_BIT,rt=[],Tt=w.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,yt=n.get(w),Et=w.isWebGLMultipleRenderTargets===!0;if(Et)for(let Pt=0;Pt<b.length;Pt++)e.bindFramebuffer(s.FRAMEBUFFER,yt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,yt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,yt.__webglMultisampledFramebuffer),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,yt.__webglFramebuffer);for(let Pt=0;Pt<b.length;Pt++){rt.push(s.COLOR_ATTACHMENT0+Pt),w.depthBuffer&&rt.push(Tt);let kt=yt.__ignoreDepthValues!==void 0?yt.__ignoreDepthValues:!1;if(kt===!1&&(w.depthBuffer&&(at|=s.DEPTH_BUFFER_BIT),w.stencilBuffer&&(at|=s.STENCIL_BUFFER_BIT)),Et&&s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,yt.__webglColorRenderbuffer[Pt]),kt===!0&&(s.invalidateFramebuffer(s.READ_FRAMEBUFFER,[Tt]),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[Tt])),Et){let ot=n.get(b[Pt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,ot,0)}s.blitFramebuffer(0,0,O,it,0,0,O,it,at,s.NEAREST),c&&s.invalidateFramebuffer(s.READ_FRAMEBUFFER,rt)}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),Et)for(let Pt=0;Pt<b.length;Pt++){e.bindFramebuffer(s.FRAMEBUFFER,yt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.RENDERBUFFER,yt.__webglColorRenderbuffer[Pt]);let kt=n.get(b[Pt]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,yt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Pt,s.TEXTURE_2D,kt,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,yt.__webglMultisampledFramebuffer)}}function J(w){return Math.min(i.maxSamples,w.samples)}function V(w){let b=n.get(w);return o&&w.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function xt(w){let b=a.render.frame;h.get(w)!==b&&(h.set(w,b),w.update())}function ht(w,b){let O=w.colorSpace,it=w.format,at=w.type;return w.isCompressedTexture===!0||w.isVideoTexture===!0||w.format===_o||O!==In&&O!==je&&(Qt.getTransfer(O)===ae?o===!1?t.has("EXT_sRGB")===!0&&it===pn?(w.format=_o,w.minFilter=Qe,w.generateMipmaps=!1):b=Cr.sRGBToLinear(b):(it!==pn||at!==Kn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",O)),b}this.allocateTextureUnit=L,this.resetTextureUnits=et,this.setTexture2D=X,this.setTexture2DArray=nt,this.setTexture3D=Z,this.setTextureCube=$,this.rebindTextures=_t,this.setupRenderTarget=P,this.updateRenderTargetMipmap=st,this.updateMultisampleRenderTarget=k,this.setupDepthRenderbuffer=Q,this.setupFrameBufferTexture=pt,this.useMultisampledRTT=V}function Dg(s,t,e){let n=e.isWebGL2;function i(r,a=je){let o,l=Qt.getTransfer(a);if(r===Kn)return s.UNSIGNED_BYTE;if(r===hh)return s.UNSIGNED_SHORT_4_4_4_4;if(r===uh)return s.UNSIGNED_SHORT_5_5_5_1;if(r===wu)return s.BYTE;if(r===Tu)return s.SHORT;if(r===al)return s.UNSIGNED_SHORT;if(r===ch)return s.INT;if(r===qn)return s.UNSIGNED_INT;if(r===Yn)return s.FLOAT;if(r===Cs)return n?s.HALF_FLOAT:(o=t.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(r===Au)return s.ALPHA;if(r===pn)return s.RGBA;if(r===Ru)return s.LUMINANCE;if(r===Cu)return s.LUMINANCE_ALPHA;if(r===gi)return s.DEPTH_COMPONENT;if(r===Ji)return s.DEPTH_STENCIL;if(r===_o)return o=t.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(r===Pu)return s.RED;if(r===dh)return s.RED_INTEGER;if(r===Lu)return s.RG;if(r===fh)return s.RG_INTEGER;if(r===ph)return s.RGBA_INTEGER;if(r===Pa||r===La||r===Ia||r===Da)if(l===ae)if(o=t.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(r===Pa)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===La)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Ia)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===Da)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=t.get("WEBGL_compressed_texture_s3tc"),o!==null){if(r===Pa)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===La)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Ia)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===Da)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Ul||r===Nl||r===Fl||r===Ol)if(o=t.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(r===Ul)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===Nl)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Fl)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Ol)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===mh)return o=t.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(r===zl||r===Bl)if(o=t.get("WEBGL_compressed_texture_etc"),o!==null){if(r===zl)return l===ae?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(r===Bl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===kl||r===Hl||r===Vl||r===Gl||r===Wl||r===Xl||r===ql||r===Yl||r===Zl||r===Jl||r===$l||r===Kl||r===Ql||r===jl)if(o=t.get("WEBGL_compressed_texture_astc"),o!==null){if(r===kl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Hl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Vl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Gl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Wl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===Xl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===ql)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Yl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Zl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Jl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===$l)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Kl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Ql)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===jl)return l===ae?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Ua||r===tc||r===ec)if(o=t.get("EXT_texture_compression_bptc"),o!==null){if(r===Ua)return l===ae?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===tc)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===ec)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===Iu||r===nc||r===ic||r===sc)if(o=t.get("EXT_texture_compression_rgtc"),o!==null){if(r===Ua)return o.COMPRESSED_RED_RGTC1_EXT;if(r===nc)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===ic)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===sc)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===mi?n?s.UNSIGNED_INT_24_8:(o=t.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):s[r]!==void 0?s[r]:null}return{convert:i}}var Io=class extends Oe{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},tn=class extends Ae{constructor(){super(),this.isGroup=!0,this.type="Group"}},Ug={type:"move"},Ss=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new tn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new tn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new C,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new C),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new tn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new C,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new C),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(let y of t.hand.values()){let m=e.getJointPose(y,n),p=this._getHandJoint(c,y);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(o.matrix.fromArray(i.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,i.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(i.linearVelocity)):o.hasLinearVelocity=!1,i.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(i.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Ug)))}return o!==null&&(o.visible=i!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new tn;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},Do=class extends jn{constructor(t,e){super();let n=this,i=null,r=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null,y=e.getContextAttributes(),m=null,p=null,x=[],_=[],M=new mt,T=null,E=new Oe;E.layers.enable(1),E.viewport=new le;let R=new Oe;R.layers.enable(2),R.viewport=new le;let U=[E,R],v=new Io;v.layers.enable(1),v.layers.enable(2);let S=null,N=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(B){let tt=x[B];return tt===void 0&&(tt=new Ss,x[B]=tt),tt.getTargetRaySpace()},this.getControllerGrip=function(B){let tt=x[B];return tt===void 0&&(tt=new Ss,x[B]=tt),tt.getGripSpace()},this.getHand=function(B){let tt=x[B];return tt===void 0&&(tt=new Ss,x[B]=tt),tt.getHandSpace()};function H(B){let tt=_.indexOf(B.inputSource);if(tt===-1)return;let ut=x[tt];ut!==void 0&&(ut.update(B.inputSource,B.frame,c||a),ut.dispatchEvent({type:B.type,data:B.inputSource}))}function et(){i.removeEventListener("select",H),i.removeEventListener("selectstart",H),i.removeEventListener("selectend",H),i.removeEventListener("squeeze",H),i.removeEventListener("squeezestart",H),i.removeEventListener("squeezeend",H),i.removeEventListener("end",et),i.removeEventListener("inputsourceschange",L);for(let B=0;B<x.length;B++){let tt=_[B];tt!==null&&(_[B]=null,x[B].disconnect(tt))}S=null,N=null,t.setRenderTarget(m),f=null,d=null,u=null,i=null,p=null,ct.stop(),n.isPresenting=!1,t.setPixelRatio(T),t.setSize(M.width,M.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(B){r=B,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(B){o=B,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(B){c=B},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(B){if(i=B,i!==null){if(m=t.getRenderTarget(),i.addEventListener("select",H),i.addEventListener("selectstart",H),i.addEventListener("selectend",H),i.addEventListener("squeeze",H),i.addEventListener("squeezestart",H),i.addEventListener("squeezeend",H),i.addEventListener("end",et),i.addEventListener("inputsourceschange",L),y.xrCompatible!==!0&&await e.makeXRCompatible(),T=t.getPixelRatio(),t.getSize(M),i.renderState.layers===void 0||t.capabilities.isWebGL2===!1){let tt={antialias:i.renderState.layers===void 0?y.antialias:!0,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(i,e,tt),i.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),p=new Dn(f.framebufferWidth,f.framebufferHeight,{format:pn,type:Kn,colorSpace:t.outputColorSpace,stencilBuffer:y.stencil})}else{let tt=null,ut=null,bt=null;y.depth&&(bt=y.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,tt=y.stencil?Ji:gi,ut=y.stencil?mi:qn);let pt={colorFormat:e.RGBA8,depthFormat:bt,scaleFactor:r};u=new XRWebGLBinding(i,e),d=u.createProjectionLayer(pt),i.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),p=new Dn(d.textureWidth,d.textureHeight,{format:pn,type:Kn,depthTexture:new kr(d.textureWidth,d.textureHeight,ut,void 0,void 0,void 0,void 0,void 0,void 0,tt),stencilBuffer:y.stencil,colorSpace:t.outputColorSpace,samples:y.antialias?4:0});let q=t.properties.get(p);q.__ignoreDepthValues=d.ignoreDepthValues}p.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await i.requestReferenceSpace(o),ct.setContext(i),ct.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode};function L(B){for(let tt=0;tt<B.removed.length;tt++){let ut=B.removed[tt],bt=_.indexOf(ut);bt>=0&&(_[bt]=null,x[bt].disconnect(ut))}for(let tt=0;tt<B.added.length;tt++){let ut=B.added[tt],bt=_.indexOf(ut);if(bt===-1){for(let q=0;q<x.length;q++)if(q>=_.length){_.push(ut),bt=q;break}else if(_[q]===null){_[q]=ut,bt=q;break}if(bt===-1)break}let pt=x[bt];pt&&pt.connect(ut)}}let F=new C,X=new C;function nt(B,tt,ut){F.setFromMatrixPosition(tt.matrixWorld),X.setFromMatrixPosition(ut.matrixWorld);let bt=F.distanceTo(X),pt=tt.projectionMatrix.elements,q=ut.projectionMatrix.elements,K=pt[14]/(pt[10]-1),Q=pt[14]/(pt[10]+1),_t=(pt[9]+1)/pt[5],P=(pt[9]-1)/pt[5],st=(pt[8]-1)/pt[0],k=(q[8]+1)/q[0],J=K*st,V=K*k,xt=bt/(-st+k),ht=xt*-st;tt.matrixWorld.decompose(B.position,B.quaternion,B.scale),B.translateX(ht),B.translateZ(xt),B.matrixWorld.compose(B.position,B.quaternion,B.scale),B.matrixWorldInverse.copy(B.matrixWorld).invert();let w=K+xt,b=Q+xt,O=J-ht,it=V+(bt-ht),at=_t*Q/b*w,rt=P*Q/b*w;B.projectionMatrix.makePerspective(O,it,at,rt,w,b),B.projectionMatrixInverse.copy(B.projectionMatrix).invert()}function Z(B,tt){tt===null?B.matrixWorld.copy(B.matrix):B.matrixWorld.multiplyMatrices(tt.matrixWorld,B.matrix),B.matrixWorldInverse.copy(B.matrixWorld).invert()}this.updateCamera=function(B){if(i===null)return;v.near=R.near=E.near=B.near,v.far=R.far=E.far=B.far,(S!==v.near||N!==v.far)&&(i.updateRenderState({depthNear:v.near,depthFar:v.far}),S=v.near,N=v.far);let tt=B.parent,ut=v.cameras;Z(v,tt);for(let bt=0;bt<ut.length;bt++)Z(ut[bt],tt);ut.length===2?nt(v,E,R):v.projectionMatrix.copy(E.projectionMatrix),$(B,v,tt)};function $(B,tt,ut){ut===null?B.matrix.copy(tt.matrixWorld):(B.matrix.copy(ut.matrixWorld),B.matrix.invert(),B.matrix.multiply(tt.matrixWorld)),B.matrix.decompose(B.position,B.quaternion,B.scale),B.updateMatrixWorld(!0),B.projectionMatrix.copy(tt.projectionMatrix),B.projectionMatrixInverse.copy(tt.projectionMatrixInverse),B.isPerspectiveCamera&&(B.fov=xo*2*Math.atan(1/B.projectionMatrix.elements[5]),B.zoom=1)}this.getCamera=function(){return v},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(B){l=B,d!==null&&(d.fixedFoveation=B),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=B)};let D=null;function j(B,tt){if(h=tt.getViewerPose(c||a),g=tt,h!==null){let ut=h.views;f!==null&&(t.setRenderTargetFramebuffer(p,f.framebuffer),t.setRenderTarget(p));let bt=!1;ut.length!==v.cameras.length&&(v.cameras.length=0,bt=!0);for(let pt=0;pt<ut.length;pt++){let q=ut[pt],K=null;if(f!==null)K=f.getViewport(q);else{let _t=u.getViewSubImage(d,q);K=_t.viewport,pt===0&&(t.setRenderTargetTextures(p,_t.colorTexture,d.ignoreDepthValues?void 0:_t.depthStencilTexture),t.setRenderTarget(p))}let Q=U[pt];Q===void 0&&(Q=new Oe,Q.layers.enable(pt),Q.viewport=new le,U[pt]=Q),Q.matrix.fromArray(q.transform.matrix),Q.matrix.decompose(Q.position,Q.quaternion,Q.scale),Q.projectionMatrix.fromArray(q.projectionMatrix),Q.projectionMatrixInverse.copy(Q.projectionMatrix).invert(),Q.viewport.set(K.x,K.y,K.width,K.height),pt===0&&(v.matrix.copy(Q.matrix),v.matrix.decompose(v.position,v.quaternion,v.scale)),bt===!0&&v.cameras.push(Q)}}for(let ut=0;ut<x.length;ut++){let bt=_[ut],pt=x[ut];bt!==null&&pt!==void 0&&pt.update(bt,tt,c||a)}D&&D(B,tt),tt.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:tt}),g=null}let ct=new bh;ct.setAnimationLoop(j),this.setAnimationLoop=function(B){D=B},this.dispose=function(){}}};function Ng(s,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,Mh(s)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function i(m,p,x,_,M){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,M)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),y(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(a(m,p),p.isLineDashedMaterial&&o(m,p)):p.isPointsMaterial?l(m,p,x,_):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Te&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Te&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);let x=t.get(p).envMap;if(x&&(m.envMap.value=x,m.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap){m.lightMap.value=p.lightMap;let _=s._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=p.lightMapIntensity*_,e(p.lightMap,m.lightMapTransform)}p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function a(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function o(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,x,_){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*x,m.scale.value=_*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),t.get(p).envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,x){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Te&&m.clearcoatNormalScale.value.negate())),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=x.texture,m.transmissionSamplerSize.value.set(x.width,x.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function y(m,p){let x=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(x.matrixWorld),m.nearDistance.value=x.shadow.camera.near,m.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function Fg(s,t,e,n){let i={},r={},a=[],o=e.isWebGL2?s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(x,_){let M=_.program;n.uniformBlockBinding(x,M)}function c(x,_){let M=i[x.id];M===void 0&&(g(x),M=h(x),i[x.id]=M,x.addEventListener("dispose",m));let T=_.program;n.updateUBOMapping(x,T);let E=t.render.frame;r[x.id]!==E&&(d(x),r[x.id]=E)}function h(x){let _=u();x.__bindingPointIndex=_;let M=s.createBuffer(),T=x.__size,E=x.usage;return s.bindBuffer(s.UNIFORM_BUFFER,M),s.bufferData(s.UNIFORM_BUFFER,T,E),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,_,M),M}function u(){for(let x=0;x<o;x++)if(a.indexOf(x)===-1)return a.push(x),x;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(x){let _=i[x.id],M=x.uniforms,T=x.__cache;s.bindBuffer(s.UNIFORM_BUFFER,_);for(let E=0,R=M.length;E<R;E++){let U=Array.isArray(M[E])?M[E]:[M[E]];for(let v=0,S=U.length;v<S;v++){let N=U[v];if(f(N,E,v,T)===!0){let H=N.__offset,et=Array.isArray(N.value)?N.value:[N.value],L=0;for(let F=0;F<et.length;F++){let X=et[F],nt=y(X);typeof X=="number"||typeof X=="boolean"?(N.__data[0]=X,s.bufferSubData(s.UNIFORM_BUFFER,H+L,N.__data)):X.isMatrix3?(N.__data[0]=X.elements[0],N.__data[1]=X.elements[1],N.__data[2]=X.elements[2],N.__data[3]=0,N.__data[4]=X.elements[3],N.__data[5]=X.elements[4],N.__data[6]=X.elements[5],N.__data[7]=0,N.__data[8]=X.elements[6],N.__data[9]=X.elements[7],N.__data[10]=X.elements[8],N.__data[11]=0):(X.toArray(N.__data,L),L+=nt.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,H,N.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function f(x,_,M,T){let E=x.value,R=_+"_"+M;if(T[R]===void 0)return typeof E=="number"||typeof E=="boolean"?T[R]=E:T[R]=E.clone(),!0;{let U=T[R];if(typeof E=="number"||typeof E=="boolean"){if(U!==E)return T[R]=E,!0}else if(U.equals(E)===!1)return U.copy(E),!0}return!1}function g(x){let _=x.uniforms,M=0,T=16;for(let R=0,U=_.length;R<U;R++){let v=Array.isArray(_[R])?_[R]:[_[R]];for(let S=0,N=v.length;S<N;S++){let H=v[S],et=Array.isArray(H.value)?H.value:[H.value];for(let L=0,F=et.length;L<F;L++){let X=et[L],nt=y(X),Z=M%T;Z!==0&&T-Z<nt.boundary&&(M+=T-Z),H.__data=new Float32Array(nt.storage/Float32Array.BYTES_PER_ELEMENT),H.__offset=M,M+=nt.storage}}}let E=M%T;return E>0&&(M+=T-E),x.__size=M,x.__cache={},this}function y(x){let _={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(_.boundary=4,_.storage=4):x.isVector2?(_.boundary=8,_.storage=8):x.isVector3||x.isColor?(_.boundary=16,_.storage=12):x.isVector4?(_.boundary=16,_.storage=16):x.isMatrix3?(_.boundary=48,_.storage=48):x.isMatrix4?(_.boundary=64,_.storage=64):x.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",x),_}function m(x){let _=x.target;_.removeEventListener("dispose",m);let M=a.indexOf(_.__bindingPointIndex);a.splice(M,1),s.deleteBuffer(i[_.id]),delete i[_.id],delete r[_.id]}function p(){for(let x in i)s.deleteBuffer(i[x]);a=[],i={},r={}}return{bind:l,update:c,dispose:p}}var Ls=class{constructor(t={}){let{canvas:e=Wu(),context:n=null,depth:i=!0,stencil:r=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1}=t;this.isWebGLRenderer=!0;let d;n!==null?d=n.getContextAttributes().alpha:d=a;let f=new Uint32Array(4),g=new Int32Array(4),y=null,m=null,p=[],x=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=xe,this._useLegacyLights=!1,this.toneMapping=$n,this.toneMappingExposure=1;let _=this,M=!1,T=0,E=0,R=null,U=-1,v=null,S=new le,N=new le,H=null,et=new Ct(0),L=0,F=e.width,X=e.height,nt=1,Z=null,$=null,D=new le(0,0,F,X),j=new le(0,0,F,X),ct=!1,B=new Ps,tt=!1,ut=!1,bt=null,pt=new se,q=new mt,K=new C,Q={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function _t(){return R===null?nt:1}let P=n;function st(A,z){for(let W=0;W<A.length;W++){let Y=A[W],G=e.getContext(Y,z);if(G!==null)return G}return null}try{let A={alpha:!0,depth:i,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine","three.js r160"),e.addEventListener("webglcontextlost",dt,!1),e.addEventListener("webglcontextrestored",I,!1),e.addEventListener("webglcontextcreationerror",vt,!1),P===null){let z=["webgl2","webgl","experimental-webgl"];if(_.isWebGL1Renderer===!0&&z.shift(),P=st(z,A),P===null)throw st(z)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&P instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),P.getShaderPrecisionFormat===void 0&&(P.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(A){throw console.error("THREE.WebGLRenderer: "+A.message),A}let k,J,V,xt,ht,w,b,O,it,at,rt,Tt,yt,Et,Pt,kt,ot,$t,Zt,Ft,Rt,wt,Vt,Kt;function ue(){k=new em(P),J=new Jp(P,k,t),k.init(J),wt=new Dg(P,k,J),V=new Lg(P,k,J),xt=new sm(P),ht=new yg,w=new Ig(P,k,V,ht,J,wt,xt),b=new Kp(_),O=new tm(_),it=new ud(P,J),Vt=new Yp(P,k,it,J),at=new nm(P,it,xt,Vt),rt=new lm(P,at,it,xt),Zt=new om(P,J,w),kt=new $p(ht),Tt=new xg(_,b,O,k,J,Vt,kt),yt=new Ng(_,ht),Et=new Mg,Pt=new Ag(k,J),$t=new qp(_,b,O,V,rt,d,l),ot=new Pg(_,rt,J),Kt=new Fg(P,xt,J,V),Ft=new Zp(P,k,xt,J),Rt=new im(P,k,xt,J),xt.programs=Tt.programs,_.capabilities=J,_.extensions=k,_.properties=ht,_.renderLists=Et,_.shadowMap=ot,_.state=V,_.info=xt}ue();let Xt=new Do(_,P);this.xr=Xt,this.getContext=function(){return P},this.getContextAttributes=function(){return P.getContextAttributes()},this.forceContextLoss=function(){let A=k.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){let A=k.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return nt},this.setPixelRatio=function(A){A!==void 0&&(nt=A,this.setSize(F,X,!1))},this.getSize=function(A){return A.set(F,X)},this.setSize=function(A,z,W=!0){if(Xt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}F=A,X=z,e.width=Math.floor(A*nt),e.height=Math.floor(z*nt),W===!0&&(e.style.width=A+"px",e.style.height=z+"px"),this.setViewport(0,0,A,z)},this.getDrawingBufferSize=function(A){return A.set(F*nt,X*nt).floor()},this.setDrawingBufferSize=function(A,z,W){F=A,X=z,nt=W,e.width=Math.floor(A*W),e.height=Math.floor(z*W),this.setViewport(0,0,A,z)},this.getCurrentViewport=function(A){return A.copy(S)},this.getViewport=function(A){return A.copy(D)},this.setViewport=function(A,z,W,Y){A.isVector4?D.set(A.x,A.y,A.z,A.w):D.set(A,z,W,Y),V.viewport(S.copy(D).multiplyScalar(nt).floor())},this.getScissor=function(A){return A.copy(j)},this.setScissor=function(A,z,W,Y){A.isVector4?j.set(A.x,A.y,A.z,A.w):j.set(A,z,W,Y),V.scissor(N.copy(j).multiplyScalar(nt).floor())},this.getScissorTest=function(){return ct},this.setScissorTest=function(A){V.setScissorTest(ct=A)},this.setOpaqueSort=function(A){Z=A},this.setTransparentSort=function(A){$=A},this.getClearColor=function(A){return A.copy($t.getClearColor())},this.setClearColor=function(){$t.setClearColor.apply($t,arguments)},this.getClearAlpha=function(){return $t.getClearAlpha()},this.setClearAlpha=function(){$t.setClearAlpha.apply($t,arguments)},this.clear=function(A=!0,z=!0,W=!0){let Y=0;if(A){let G=!1;if(R!==null){let St=R.texture.format;G=St===ph||St===fh||St===dh}if(G){let St=R.texture.type,At=St===Kn||St===qn||St===al||St===mi||St===hh||St===uh,Dt=$t.getClearColor(),Nt=$t.getClearAlpha(),Wt=Dt.r,Ot=Dt.g,Ht=Dt.b;At?(f[0]=Wt,f[1]=Ot,f[2]=Ht,f[3]=Nt,P.clearBufferuiv(P.COLOR,0,f)):(g[0]=Wt,g[1]=Ot,g[2]=Ht,g[3]=Nt,P.clearBufferiv(P.COLOR,0,g))}else Y|=P.COLOR_BUFFER_BIT}z&&(Y|=P.DEPTH_BUFFER_BIT),W&&(Y|=P.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),P.clear(Y)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",dt,!1),e.removeEventListener("webglcontextrestored",I,!1),e.removeEventListener("webglcontextcreationerror",vt,!1),Et.dispose(),Pt.dispose(),ht.dispose(),b.dispose(),O.dispose(),rt.dispose(),Vt.dispose(),Kt.dispose(),Tt.dispose(),Xt.dispose(),Xt.removeEventListener("sessionstart",Be),Xt.removeEventListener("sessionend",ie),bt&&(bt.dispose(),bt=null),ke.stop()};function dt(A){A.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),M=!0}function I(){console.log("THREE.WebGLRenderer: Context Restored."),M=!1;let A=xt.autoReset,z=ot.enabled,W=ot.autoUpdate,Y=ot.needsUpdate,G=ot.type;ue(),xt.autoReset=A,ot.enabled=z,ot.autoUpdate=W,ot.needsUpdate=Y,ot.type=G}function vt(A){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function Mt(A){let z=A.target;z.removeEventListener("dispose",Mt),Ut(z)}function Ut(A){Lt(A),ht.remove(A)}function Lt(A){let z=ht.get(A).programs;z!==void 0&&(z.forEach(function(W){Tt.releaseProgram(W)}),A.isShaderMaterial&&Tt.releaseShaderCache(A))}this.renderBufferDirect=function(A,z,W,Y,G,St){z===null&&(z=Q);let At=G.isMesh&&G.matrixWorld.determinant()<0,Dt=Hh(A,z,W,Y,G);V.setMaterial(Y,At);let Nt=W.index,Wt=1;if(Y.wireframe===!0){if(Nt=at.getWireframeAttribute(W),Nt===void 0)return;Wt=2}let Ot=W.drawRange,Ht=W.attributes.position,pe=Ot.start*Wt,Xe=(Ot.start+Ot.count)*Wt;St!==null&&(pe=Math.max(pe,St.start*Wt),Xe=Math.min(Xe,(St.start+St.count)*Wt)),Nt!==null?(pe=Math.max(pe,0),Xe=Math.min(Xe,Nt.count)):Ht!=null&&(pe=Math.max(pe,0),Xe=Math.min(Xe,Ht.count));let Ee=Xe-pe;if(Ee<0||Ee===1/0)return;Vt.setup(G,Y,Dt,W,Nt);let Sn,ce=Ft;if(Nt!==null&&(Sn=it.get(Nt),ce=Rt,ce.setIndex(Sn)),G.isMesh)Y.wireframe===!0?(V.setLineWidth(Y.wireframeLinewidth*_t()),ce.setMode(P.LINES)):ce.setMode(P.TRIANGLES);else if(G.isLine){let qt=Y.linewidth;qt===void 0&&(qt=1),V.setLineWidth(qt*_t()),G.isLineSegments?ce.setMode(P.LINES):G.isLineLoop?ce.setMode(P.LINE_LOOP):ce.setMode(P.LINE_STRIP)}else G.isPoints?ce.setMode(P.POINTS):G.isSprite&&ce.setMode(P.TRIANGLES);if(G.isBatchedMesh)ce.renderMultiDraw(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount);else if(G.isInstancedMesh)ce.renderInstances(pe,Ee,G.count);else if(W.isInstancedBufferGeometry){let qt=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,wa=Math.min(W.instanceCount,qt);ce.renderInstances(pe,Ee,wa)}else ce.render(pe,Ee)};function ee(A,z,W){A.transparent===!0&&A.side===Ge&&A.forceSinglePass===!1?(A.side=Te,A.needsUpdate=!0,Xs(A,z,W),A.side=Qn,A.needsUpdate=!0,Xs(A,z,W),A.side=Ge):Xs(A,z,W)}this.compile=function(A,z,W=null){W===null&&(W=A),m=Pt.get(W),m.init(),x.push(m),W.traverseVisible(function(G){G.isLight&&G.layers.test(z.layers)&&(m.pushLight(G),G.castShadow&&m.pushShadow(G))}),A!==W&&A.traverseVisible(function(G){G.isLight&&G.layers.test(z.layers)&&(m.pushLight(G),G.castShadow&&m.pushShadow(G))}),m.setupLights(_._useLegacyLights);let Y=new Set;return A.traverse(function(G){let St=G.material;if(St)if(Array.isArray(St))for(let At=0;At<St.length;At++){let Dt=St[At];ee(Dt,W,G),Y.add(Dt)}else ee(St,W,G),Y.add(St)}),x.pop(),m=null,Y},this.compileAsync=function(A,z,W=null){let Y=this.compile(A,z,W);return new Promise(G=>{function St(){if(Y.forEach(function(At){ht.get(At).currentProgram.isReady()&&Y.delete(At)}),Y.size===0){G(A);return}setTimeout(St,10)}k.get("KHR_parallel_shader_compile")!==null?St():setTimeout(St,10)})};let ne=null;function Se(A){ne&&ne(A)}function Be(){ke.stop()}function ie(){ke.start()}let ke=new bh;ke.setAnimationLoop(Se),typeof self<"u"&&ke.setContext(self),this.setAnimationLoop=function(A){ne=A,Xt.setAnimationLoop(A),A===null?ke.stop():ke.start()},Xt.addEventListener("sessionstart",Be),Xt.addEventListener("sessionend",ie),this.render=function(A,z){if(z!==void 0&&z.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(M===!0)return;A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),z.parent===null&&z.matrixWorldAutoUpdate===!0&&z.updateMatrixWorld(),Xt.enabled===!0&&Xt.isPresenting===!0&&(Xt.cameraAutoUpdate===!0&&Xt.updateCamera(z),z=Xt.getCamera()),A.isScene===!0&&A.onBeforeRender(_,A,z,R),m=Pt.get(A,x.length),m.init(),x.push(m),pt.multiplyMatrices(z.projectionMatrix,z.matrixWorldInverse),B.setFromProjectionMatrix(pt),ut=this.localClippingEnabled,tt=kt.init(this.clippingPlanes,ut),y=Et.get(A,p.length),y.init(),p.push(y),yn(A,z,0,_.sortObjects),y.finish(),_.sortObjects===!0&&y.sort(Z,$),this.info.render.frame++,tt===!0&&kt.beginShadows();let W=m.state.shadowsArray;if(ot.render(W,A,z),tt===!0&&kt.endShadows(),this.info.autoReset===!0&&this.info.reset(),$t.render(y,A),m.setupLights(_._useLegacyLights),z.isArrayCamera){let Y=z.cameras;for(let G=0,St=Y.length;G<St;G++){let At=Y[G];bl(y,A,At,At.viewport)}}else bl(y,A,z);R!==null&&(w.updateMultisampleRenderTarget(R),w.updateRenderTargetMipmap(R)),A.isScene===!0&&A.onAfterRender(_,A,z),Vt.resetDefaultState(),U=-1,v=null,x.pop(),x.length>0?m=x[x.length-1]:m=null,p.pop(),p.length>0?y=p[p.length-1]:y=null};function yn(A,z,W,Y){if(A.visible===!1)return;if(A.layers.test(z.layers)){if(A.isGroup)W=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(z);else if(A.isLight)m.pushLight(A),A.castShadow&&m.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||B.intersectsSprite(A)){Y&&K.setFromMatrixPosition(A.matrixWorld).applyMatrix4(pt);let At=rt.update(A),Dt=A.material;Dt.visible&&y.push(A,At,Dt,W,K.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(!A.frustumCulled||B.intersectsObject(A))){let At=rt.update(A),Dt=A.material;if(Y&&(A.boundingSphere!==void 0?(A.boundingSphere===null&&A.computeBoundingSphere(),K.copy(A.boundingSphere.center)):(At.boundingSphere===null&&At.computeBoundingSphere(),K.copy(At.boundingSphere.center)),K.applyMatrix4(A.matrixWorld).applyMatrix4(pt)),Array.isArray(Dt)){let Nt=At.groups;for(let Wt=0,Ot=Nt.length;Wt<Ot;Wt++){let Ht=Nt[Wt],pe=Dt[Ht.materialIndex];pe&&pe.visible&&y.push(A,At,pe,W,K.z,Ht)}}else Dt.visible&&y.push(A,At,Dt,W,K.z,null)}}let St=A.children;for(let At=0,Dt=St.length;At<Dt;At++)yn(St[At],z,W,Y)}function bl(A,z,W,Y){let G=A.opaque,St=A.transmissive,At=A.transparent;m.setupLightsView(W),tt===!0&&kt.setGlobalState(_.clippingPlanes,W),St.length>0&&kh(G,St,z,W),Y&&V.viewport(S.copy(Y)),G.length>0&&Ws(G,z,W),St.length>0&&Ws(St,z,W),At.length>0&&Ws(At,z,W),V.buffers.depth.setTest(!0),V.buffers.depth.setMask(!0),V.buffers.color.setMask(!0),V.setPolygonOffset(!1)}function kh(A,z,W,Y){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;let St=J.isWebGL2;bt===null&&(bt=new Dn(1,1,{generateMipmaps:!0,type:k.has("EXT_color_buffer_half_float")?Cs:Kn,minFilter:Rs,samples:St?4:0})),_.getDrawingBufferSize(q),St?bt.setSize(q.x,q.y):bt.setSize(yo(q.x),yo(q.y));let At=_.getRenderTarget();_.setRenderTarget(bt),_.getClearColor(et),L=_.getClearAlpha(),L<1&&_.setClearColor(16777215,.5),_.clear();let Dt=_.toneMapping;_.toneMapping=$n,Ws(A,W,Y),w.updateMultisampleRenderTarget(bt),w.updateRenderTargetMipmap(bt);let Nt=!1;for(let Wt=0,Ot=z.length;Wt<Ot;Wt++){let Ht=z[Wt],pe=Ht.object,Xe=Ht.geometry,Ee=Ht.material,Sn=Ht.group;if(Ee.side===Ge&&pe.layers.test(Y.layers)){let ce=Ee.side;Ee.side=Te,Ee.needsUpdate=!0,Sl(pe,W,Y,Xe,Ee,Sn),Ee.side=ce,Ee.needsUpdate=!0,Nt=!0}}Nt===!0&&(w.updateMultisampleRenderTarget(bt),w.updateRenderTargetMipmap(bt)),_.setRenderTarget(At),_.setClearColor(et,L),_.toneMapping=Dt}function Ws(A,z,W){let Y=z.isScene===!0?z.overrideMaterial:null;for(let G=0,St=A.length;G<St;G++){let At=A[G],Dt=At.object,Nt=At.geometry,Wt=Y===null?At.material:Y,Ot=At.group;Dt.layers.test(W.layers)&&Sl(Dt,z,W,Nt,Wt,Ot)}}function Sl(A,z,W,Y,G,St){A.onBeforeRender(_,z,W,Y,G,St),A.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),G.onBeforeRender(_,z,W,Y,A,St),G.transparent===!0&&G.side===Ge&&G.forceSinglePass===!1?(G.side=Te,G.needsUpdate=!0,_.renderBufferDirect(W,z,Y,G,A,St),G.side=Qn,G.needsUpdate=!0,_.renderBufferDirect(W,z,Y,G,A,St),G.side=Ge):_.renderBufferDirect(W,z,Y,G,A,St),A.onAfterRender(_,z,W,Y,G,St)}function Xs(A,z,W){z.isScene!==!0&&(z=Q);let Y=ht.get(A),G=m.state.lights,St=m.state.shadowsArray,At=G.state.version,Dt=Tt.getParameters(A,G.state,St,z,W),Nt=Tt.getProgramCacheKey(Dt),Wt=Y.programs;Y.environment=A.isMeshStandardMaterial?z.environment:null,Y.fog=z.fog,Y.envMap=(A.isMeshStandardMaterial?O:b).get(A.envMap||Y.environment),Wt===void 0&&(A.addEventListener("dispose",Mt),Wt=new Map,Y.programs=Wt);let Ot=Wt.get(Nt);if(Ot!==void 0){if(Y.currentProgram===Ot&&Y.lightsStateVersion===At)return wl(A,Dt),Ot}else Dt.uniforms=Tt.getUniforms(A),A.onBuild(W,Dt,_),A.onBeforeCompile(Dt,_),Ot=Tt.acquireProgram(Dt,Nt),Wt.set(Nt,Ot),Y.uniforms=Dt.uniforms;let Ht=Y.uniforms;return(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&(Ht.clippingPlanes=kt.uniform),wl(A,Dt),Y.needsLights=Gh(A),Y.lightsStateVersion=At,Y.needsLights&&(Ht.ambientLightColor.value=G.state.ambient,Ht.lightProbe.value=G.state.probe,Ht.directionalLights.value=G.state.directional,Ht.directionalLightShadows.value=G.state.directionalShadow,Ht.spotLights.value=G.state.spot,Ht.spotLightShadows.value=G.state.spotShadow,Ht.rectAreaLights.value=G.state.rectArea,Ht.ltc_1.value=G.state.rectAreaLTC1,Ht.ltc_2.value=G.state.rectAreaLTC2,Ht.pointLights.value=G.state.point,Ht.pointLightShadows.value=G.state.pointShadow,Ht.hemisphereLights.value=G.state.hemi,Ht.directionalShadowMap.value=G.state.directionalShadowMap,Ht.directionalShadowMatrix.value=G.state.directionalShadowMatrix,Ht.spotShadowMap.value=G.state.spotShadowMap,Ht.spotLightMatrix.value=G.state.spotLightMatrix,Ht.spotLightMap.value=G.state.spotLightMap,Ht.pointShadowMap.value=G.state.pointShadowMap,Ht.pointShadowMatrix.value=G.state.pointShadowMatrix),Y.currentProgram=Ot,Y.uniformsList=null,Ot}function El(A){if(A.uniformsList===null){let z=A.currentProgram.getUniforms();A.uniformsList=qi.seqWithValue(z.seq,A.uniforms)}return A.uniformsList}function wl(A,z){let W=ht.get(A);W.outputColorSpace=z.outputColorSpace,W.batching=z.batching,W.instancing=z.instancing,W.instancingColor=z.instancingColor,W.skinning=z.skinning,W.morphTargets=z.morphTargets,W.morphNormals=z.morphNormals,W.morphColors=z.morphColors,W.morphTargetsCount=z.morphTargetsCount,W.numClippingPlanes=z.numClippingPlanes,W.numIntersection=z.numClipIntersection,W.vertexAlphas=z.vertexAlphas,W.vertexTangents=z.vertexTangents,W.toneMapping=z.toneMapping}function Hh(A,z,W,Y,G){z.isScene!==!0&&(z=Q),w.resetTextureUnits();let St=z.fog,At=Y.isMeshStandardMaterial?z.environment:null,Dt=R===null?_.outputColorSpace:R.isXRRenderTarget===!0?R.texture.colorSpace:In,Nt=(Y.isMeshStandardMaterial?O:b).get(Y.envMap||At),Wt=Y.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,Ot=!!W.attributes.tangent&&(!!Y.normalMap||Y.anisotropy>0),Ht=!!W.morphAttributes.position,pe=!!W.morphAttributes.normal,Xe=!!W.morphAttributes.color,Ee=$n;Y.toneMapped&&(R===null||R.isXRRenderTarget===!0)&&(Ee=_.toneMapping);let Sn=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,ce=Sn!==void 0?Sn.length:0,qt=ht.get(Y),wa=m.state.lights;if(tt===!0&&(ut===!0||A!==v)){let $e=A===v&&Y.id===U;kt.setState(Y,A,$e)}let de=!1;Y.version===qt.__version?(qt.needsLights&&qt.lightsStateVersion!==wa.state.version||qt.outputColorSpace!==Dt||G.isBatchedMesh&&qt.batching===!1||!G.isBatchedMesh&&qt.batching===!0||G.isInstancedMesh&&qt.instancing===!1||!G.isInstancedMesh&&qt.instancing===!0||G.isSkinnedMesh&&qt.skinning===!1||!G.isSkinnedMesh&&qt.skinning===!0||G.isInstancedMesh&&qt.instancingColor===!0&&G.instanceColor===null||G.isInstancedMesh&&qt.instancingColor===!1&&G.instanceColor!==null||qt.envMap!==Nt||Y.fog===!0&&qt.fog!==St||qt.numClippingPlanes!==void 0&&(qt.numClippingPlanes!==kt.numPlanes||qt.numIntersection!==kt.numIntersection)||qt.vertexAlphas!==Wt||qt.vertexTangents!==Ot||qt.morphTargets!==Ht||qt.morphNormals!==pe||qt.morphColors!==Xe||qt.toneMapping!==Ee||J.isWebGL2===!0&&qt.morphTargetsCount!==ce)&&(de=!0):(de=!0,qt.__version=Y.version);let ai=qt.currentProgram;de===!0&&(ai=Xs(Y,z,G));let Tl=!1,fs=!1,Ta=!1,De=ai.getUniforms(),oi=qt.uniforms;if(V.useProgram(ai.program)&&(Tl=!0,fs=!0,Ta=!0),Y.id!==U&&(U=Y.id,fs=!0),Tl||v!==A){De.setValue(P,"projectionMatrix",A.projectionMatrix),De.setValue(P,"viewMatrix",A.matrixWorldInverse);let $e=De.map.cameraPosition;$e!==void 0&&$e.setValue(P,K.setFromMatrixPosition(A.matrixWorld)),J.logarithmicDepthBuffer&&De.setValue(P,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),(Y.isMeshPhongMaterial||Y.isMeshToonMaterial||Y.isMeshLambertMaterial||Y.isMeshBasicMaterial||Y.isMeshStandardMaterial||Y.isShaderMaterial)&&De.setValue(P,"isOrthographic",A.isOrthographicCamera===!0),v!==A&&(v=A,fs=!0,Ta=!0)}if(G.isSkinnedMesh){De.setOptional(P,G,"bindMatrix"),De.setOptional(P,G,"bindMatrixInverse");let $e=G.skeleton;$e&&(J.floatVertexTextures?($e.boneTexture===null&&$e.computeBoneTexture(),De.setValue(P,"boneTexture",$e.boneTexture,w)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}G.isBatchedMesh&&(De.setOptional(P,G,"batchingTexture"),De.setValue(P,"batchingTexture",G._matricesTexture,w));let Aa=W.morphAttributes;if((Aa.position!==void 0||Aa.normal!==void 0||Aa.color!==void 0&&J.isWebGL2===!0)&&Zt.update(G,W,ai),(fs||qt.receiveShadow!==G.receiveShadow)&&(qt.receiveShadow=G.receiveShadow,De.setValue(P,"receiveShadow",G.receiveShadow)),Y.isMeshGouraudMaterial&&Y.envMap!==null&&(oi.envMap.value=Nt,oi.flipEnvMap.value=Nt.isCubeTexture&&Nt.isRenderTargetTexture===!1?-1:1),fs&&(De.setValue(P,"toneMappingExposure",_.toneMappingExposure),qt.needsLights&&Vh(oi,Ta),St&&Y.fog===!0&&yt.refreshFogUniforms(oi,St),yt.refreshMaterialUniforms(oi,Y,nt,X,bt),qi.upload(P,El(qt),oi,w)),Y.isShaderMaterial&&Y.uniformsNeedUpdate===!0&&(qi.upload(P,El(qt),oi,w),Y.uniformsNeedUpdate=!1),Y.isSpriteMaterial&&De.setValue(P,"center",G.center),De.setValue(P,"modelViewMatrix",G.modelViewMatrix),De.setValue(P,"normalMatrix",G.normalMatrix),De.setValue(P,"modelMatrix",G.matrixWorld),Y.isShaderMaterial||Y.isRawShaderMaterial){let $e=Y.uniformsGroups;for(let Ra=0,Wh=$e.length;Ra<Wh;Ra++)if(J.isWebGL2){let Al=$e[Ra];Kt.update(Al,ai),Kt.bind(Al,ai)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return ai}function Vh(A,z){A.ambientLightColor.needsUpdate=z,A.lightProbe.needsUpdate=z,A.directionalLights.needsUpdate=z,A.directionalLightShadows.needsUpdate=z,A.pointLights.needsUpdate=z,A.pointLightShadows.needsUpdate=z,A.spotLights.needsUpdate=z,A.spotLightShadows.needsUpdate=z,A.rectAreaLights.needsUpdate=z,A.hemisphereLights.needsUpdate=z}function Gh(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return T},this.getActiveMipmapLevel=function(){return E},this.getRenderTarget=function(){return R},this.setRenderTargetTextures=function(A,z,W){ht.get(A.texture).__webglTexture=z,ht.get(A.depthTexture).__webglTexture=W;let Y=ht.get(A);Y.__hasExternalTextures=!0,Y.__hasExternalTextures&&(Y.__autoAllocateDepthBuffer=W===void 0,Y.__autoAllocateDepthBuffer||k.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),Y.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(A,z){let W=ht.get(A);W.__webglFramebuffer=z,W.__useDefaultFramebuffer=z===void 0},this.setRenderTarget=function(A,z=0,W=0){R=A,T=z,E=W;let Y=!0,G=null,St=!1,At=!1;if(A){let Nt=ht.get(A);Nt.__useDefaultFramebuffer!==void 0?(V.bindFramebuffer(P.FRAMEBUFFER,null),Y=!1):Nt.__webglFramebuffer===void 0?w.setupRenderTarget(A):Nt.__hasExternalTextures&&w.rebindTextures(A,ht.get(A.texture).__webglTexture,ht.get(A.depthTexture).__webglTexture);let Wt=A.texture;(Wt.isData3DTexture||Wt.isDataArrayTexture||Wt.isCompressedArrayTexture)&&(At=!0);let Ot=ht.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(Array.isArray(Ot[z])?G=Ot[z][W]:G=Ot[z],St=!0):J.isWebGL2&&A.samples>0&&w.useMultisampledRTT(A)===!1?G=ht.get(A).__webglMultisampledFramebuffer:Array.isArray(Ot)?G=Ot[W]:G=Ot,S.copy(A.viewport),N.copy(A.scissor),H=A.scissorTest}else S.copy(D).multiplyScalar(nt).floor(),N.copy(j).multiplyScalar(nt).floor(),H=ct;if(V.bindFramebuffer(P.FRAMEBUFFER,G)&&J.drawBuffers&&Y&&V.drawBuffers(A,G),V.viewport(S),V.scissor(N),V.setScissorTest(H),St){let Nt=ht.get(A.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_CUBE_MAP_POSITIVE_X+z,Nt.__webglTexture,W)}else if(At){let Nt=ht.get(A.texture),Wt=z||0;P.framebufferTextureLayer(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,Nt.__webglTexture,W||0,Wt)}U=-1},this.readRenderTargetPixels=function(A,z,W,Y,G,St,At){if(!(A&&A.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Dt=ht.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&At!==void 0&&(Dt=Dt[At]),Dt){V.bindFramebuffer(P.FRAMEBUFFER,Dt);try{let Nt=A.texture,Wt=Nt.format,Ot=Nt.type;if(Wt!==pn&&wt.convert(Wt)!==P.getParameter(P.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let Ht=Ot===Cs&&(k.has("EXT_color_buffer_half_float")||J.isWebGL2&&k.has("EXT_color_buffer_float"));if(Ot!==Kn&&wt.convert(Ot)!==P.getParameter(P.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Ot===Yn&&(J.isWebGL2||k.has("OES_texture_float")||k.has("WEBGL_color_buffer_float")))&&!Ht){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}z>=0&&z<=A.width-Y&&W>=0&&W<=A.height-G&&P.readPixels(z,W,Y,G,wt.convert(Wt),wt.convert(Ot),St)}finally{let Nt=R!==null?ht.get(R).__webglFramebuffer:null;V.bindFramebuffer(P.FRAMEBUFFER,Nt)}}},this.copyFramebufferToTexture=function(A,z,W=0){let Y=Math.pow(2,-W),G=Math.floor(z.image.width*Y),St=Math.floor(z.image.height*Y);w.setTexture2D(z,0),P.copyTexSubImage2D(P.TEXTURE_2D,W,0,0,A.x,A.y,G,St),V.unbindTexture()},this.copyTextureToTexture=function(A,z,W,Y=0){let G=z.image.width,St=z.image.height,At=wt.convert(W.format),Dt=wt.convert(W.type);w.setTexture2D(W,0),P.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,W.flipY),P.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),P.pixelStorei(P.UNPACK_ALIGNMENT,W.unpackAlignment),z.isDataTexture?P.texSubImage2D(P.TEXTURE_2D,Y,A.x,A.y,G,St,At,Dt,z.image.data):z.isCompressedTexture?P.compressedTexSubImage2D(P.TEXTURE_2D,Y,A.x,A.y,z.mipmaps[0].width,z.mipmaps[0].height,At,z.mipmaps[0].data):P.texSubImage2D(P.TEXTURE_2D,Y,A.x,A.y,At,Dt,z.image),Y===0&&W.generateMipmaps&&P.generateMipmap(P.TEXTURE_2D),V.unbindTexture()},this.copyTextureToTexture3D=function(A,z,W,Y,G=0){if(_.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let St=A.max.x-A.min.x+1,At=A.max.y-A.min.y+1,Dt=A.max.z-A.min.z+1,Nt=wt.convert(Y.format),Wt=wt.convert(Y.type),Ot;if(Y.isData3DTexture)w.setTexture3D(Y,0),Ot=P.TEXTURE_3D;else if(Y.isDataArrayTexture||Y.isCompressedArrayTexture)w.setTexture2DArray(Y,0),Ot=P.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}P.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,Y.flipY),P.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),P.pixelStorei(P.UNPACK_ALIGNMENT,Y.unpackAlignment);let Ht=P.getParameter(P.UNPACK_ROW_LENGTH),pe=P.getParameter(P.UNPACK_IMAGE_HEIGHT),Xe=P.getParameter(P.UNPACK_SKIP_PIXELS),Ee=P.getParameter(P.UNPACK_SKIP_ROWS),Sn=P.getParameter(P.UNPACK_SKIP_IMAGES),ce=W.isCompressedTexture?W.mipmaps[G]:W.image;P.pixelStorei(P.UNPACK_ROW_LENGTH,ce.width),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,ce.height),P.pixelStorei(P.UNPACK_SKIP_PIXELS,A.min.x),P.pixelStorei(P.UNPACK_SKIP_ROWS,A.min.y),P.pixelStorei(P.UNPACK_SKIP_IMAGES,A.min.z),W.isDataTexture||W.isData3DTexture?P.texSubImage3D(Ot,G,z.x,z.y,z.z,St,At,Dt,Nt,Wt,ce.data):W.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),P.compressedTexSubImage3D(Ot,G,z.x,z.y,z.z,St,At,Dt,Nt,ce.data)):P.texSubImage3D(Ot,G,z.x,z.y,z.z,St,At,Dt,Nt,Wt,ce),P.pixelStorei(P.UNPACK_ROW_LENGTH,Ht),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,pe),P.pixelStorei(P.UNPACK_SKIP_PIXELS,Xe),P.pixelStorei(P.UNPACK_SKIP_ROWS,Ee),P.pixelStorei(P.UNPACK_SKIP_IMAGES,Sn),G===0&&Y.generateMipmaps&&P.generateMipmap(Ot),V.unbindTexture()},this.initTexture=function(A){A.isCubeTexture?w.setTextureCube(A,0):A.isData3DTexture?w.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?w.setTexture2DArray(A,0):w.setTexture2D(A,0),V.unbindTexture()},this.resetState=function(){T=0,E=0,R=null,V.reset(),Vt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ln}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=t===ol?"display-p3":"srgb",e.unpackColorSpace=Qt.workingColorSpace===ia?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===xe?_i:gh}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===_i?xe:In}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}},Uo=class extends Ls{};Uo.prototype.isWebGL1Renderer=!0;var Hr=class s{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new Ct(t),this.density=e}clone(){return new s(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var Is=class extends Ae{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}};var Vr=class extends jt{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},ki=new se,Jc=new se,pr=[],$c=new Un,Og=new se,ys=new It,vs=new ti,Gr=class extends It{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Vr(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,Og)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Un),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,ki),$c.copy(t.boundingBox).applyMatrix4(ki),this.boundingBox.union($c)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new ti),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,ki),vs.copy(t.boundingSphere).applyMatrix4(ki),this.boundingSphere.union(vs)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}raycast(t,e){let n=this.matrixWorld,i=this.count;if(ys.geometry=this.geometry,ys.material=this.material,ys.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),vs.copy(this.boundingSphere),vs.applyMatrix4(n),t.ray.intersectsSphere(vs)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,ki),Jc.multiplyMatrices(n,ki),ys.matrixWorld=Jc,ys.raycast(t,pr);for(let a=0,o=pr.length;a<o;a++){let l=pr[a];l.instanceId=r,l.object=this,e.push(l)}pr.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Vr(new Float32Array(this.instanceMatrix.count*3),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}};var No=class extends ei{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ct(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Kc=new se,Fo=new Ir,mr=new ti,gr=new C,Ds=class extends Ae{constructor(t=new Re,e=new No){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let n=this.geometry,i=this.matrixWorld,r=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),mr.copy(n.boundingSphere),mr.applyMatrix4(i),mr.radius+=r,t.ray.intersectsSphere(mr)===!1)return;Kc.copy(i).invert(),Fo.copy(t.ray).applyMatrix4(Kc);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,a.start),f=Math.min(c.count,a.start+a.count);for(let g=d,y=f;g<y;g++){let m=c.getX(g);gr.fromBufferAttribute(u,m),Qc(gr,m,l,i,t,e,this)}}else{let d=Math.max(0,a.start),f=Math.min(u.count,a.start+a.count);for(let g=d,y=f;g<y;g++)gr.fromBufferAttribute(u,g),Qc(gr,g,l,i,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){let o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Qc(s,t,e,n,i,r,a){let o=Fo.distanceSqToPoint(s);if(o<e){let l=new C;Fo.closestPointToPoint(s,l),l.applyMatrix4(n);let c=i.ray.origin.distanceTo(l);if(c<i.near||c>i.far)return;r.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,object:a})}}var Wr=class extends en{constructor(t,e,n,i,r,a,o,l,c){super(t,e,n,i,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},sn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],n,i=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),r+=n.distanceTo(i),e.push(r),i=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let n=this.getLengths(),i=0,r=n.length,a;e?a=e:a=t*n[r-1];let o=0,l=r-1,c;for(;o<=l;)if(i=Math.floor(o+(l-o)/2),c=n[i]-a,c<0)o=i+1;else if(c>0)l=i-1;else{l=i;break}if(i=l,n[i]===a)return i/(r-1);let h=n[i],d=n[i+1]-h,f=(a-h)/d;return(i+f)/(r-1)}getTangent(t,e){let i=t-1e-4,r=t+1e-4;i<0&&(i=0),r>1&&(r=1);let a=this.getPoint(i),o=this.getPoint(r),l=e||(a.isVector2?new mt:new C);return l.copy(o).sub(a).normalize(),l}getTangentAt(t,e){let n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){let n=new C,i=[],r=[],a=[],o=new C,l=new se;for(let f=0;f<=t;f++){let g=f/t;i[f]=this.getTangentAt(g,new C)}r[0]=new C,a[0]=new C;let c=Number.MAX_VALUE,h=Math.abs(i[0].x),u=Math.abs(i[0].y),d=Math.abs(i[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(i[0],n).normalize(),r[0].crossVectors(i[0],o),a[0].crossVectors(i[0],r[0]);for(let f=1;f<=t;f++){if(r[f]=r[f-1].clone(),a[f]=a[f-1].clone(),o.crossVectors(i[f-1],i[f]),o.length()>Number.EPSILON){o.normalize();let g=Math.acos(Fe(i[f-1].dot(i[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(o,g))}a[f].crossVectors(i[f],r[f])}if(e===!0){let f=Math.acos(Fe(r[0].dot(r[t]),-1,1));f/=t,i[0].dot(o.crossVectors(r[0],r[t]))>0&&(f=-f);for(let g=1;g<=t;g++)r[g].applyMatrix4(l.makeRotationAxis(i[g],f*g)),a[g].crossVectors(i[g],r[g])}return{tangents:i,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},Us=class extends sn{constructor(t=0,e=0,n=1,i=1,r=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=i,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(t,e){let n=e||new mt,i=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=i;for(;r>i;)r-=i;r<Number.EPSILON&&(a?r=0:r=i),this.aClockwise===!0&&!a&&(r===i?r=-i:r=r-i);let o=this.aStartAngle+t*r,l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return n.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},Oo=class extends Us{constructor(t,e,n,i,r,a){super(t,e,n,n,i,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function cl(){let s=0,t=0,e=0,n=0;function i(r,a,o,l){s=r,t=o,e=-3*r+3*a-2*o-l,n=2*r-2*a+o+l}return{initCatmullRom:function(r,a,o,l,c){i(a,o,c*(o-r),c*(l-a))},initNonuniformCatmullRom:function(r,a,o,l,c,h,u){let d=(a-r)/c-(o-r)/(c+h)+(o-a)/h,f=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,f*=h,i(a,o,d,f)},calc:function(r){let a=r*r,o=a*r;return s+t*r+e*a+n*o}}}var _r=new C,ao=new cl,oo=new cl,lo=new cl,zo=class extends sn{constructor(t=[],e=!1,n="centripetal",i=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=i}getPoint(t,e=new C){let n=e,i=this.points,r=i.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:l===0&&o===r-1&&(o=r-2,l=1);let c,h;this.closed||o>0?c=i[(o-1)%r]:(_r.subVectors(i[0],i[1]).add(i[0]),c=_r);let u=i[o%r],d=i[(o+1)%r];if(this.closed||o+2<r?h=i[(o+2)%r]:(_r.subVectors(i[r-1],i[r-2]).add(i[r-1]),h=_r),this.curveType==="centripetal"||this.curveType==="chordal"){let f=this.curveType==="chordal"?.5:.25,g=Math.pow(c.distanceToSquared(u),f),y=Math.pow(u.distanceToSquared(d),f),m=Math.pow(d.distanceToSquared(h),f);y<1e-4&&(y=1),g<1e-4&&(g=y),m<1e-4&&(m=y),ao.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,y,m),oo.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,y,m),lo.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,y,m)}else this.curveType==="catmullrom"&&(ao.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),oo.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),lo.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(ao.calc(l),oo.calc(l),lo.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(i.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let i=this.points[e];t.points.push(i.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(new C().fromArray(i))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function jc(s,t,e,n,i){let r=(n-t)*.5,a=(i-e)*.5,o=s*s,l=s*o;return(2*e-2*n+r+a)*l+(-3*e+3*n-2*r-a)*o+r*s+e}function zg(s,t){let e=1-s;return e*e*t}function Bg(s,t){return 2*(1-s)*s*t}function kg(s,t){return s*s*t}function Es(s,t,e,n){return zg(s,t)+Bg(s,e)+kg(s,n)}function Hg(s,t){let e=1-s;return e*e*e*t}function Vg(s,t){let e=1-s;return 3*e*e*s*t}function Gg(s,t){return 3*(1-s)*s*s*t}function Wg(s,t){return s*s*s*t}function ws(s,t,e,n,i){return Hg(s,t)+Vg(s,e)+Gg(s,n)+Wg(s,i)}var Xr=class extends sn{constructor(t=new mt,e=new mt,n=new mt,i=new mt){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new mt){let n=e,i=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(ws(t,i.x,r.x,a.x,o.x),ws(t,i.y,r.y,a.y,o.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Bo=class extends sn{constructor(t=new C,e=new C,n=new C,i=new C){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new C){let n=e,i=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(ws(t,i.x,r.x,a.x,o.x),ws(t,i.y,r.y,a.y,o.y),ws(t,i.z,r.z,a.z,o.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},qr=class extends sn{constructor(t=new mt,e=new mt){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new mt){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new mt){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},ko=class extends sn{constructor(t=new C,e=new C){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new C){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new C){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Yr=class extends sn{constructor(t=new mt,e=new mt,n=new mt){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new mt){let n=e,i=this.v0,r=this.v1,a=this.v2;return n.set(Es(t,i.x,r.x,a.x),Es(t,i.y,r.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Ho=class extends sn{constructor(t=new C,e=new C,n=new C){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new C){let n=e,i=this.v0,r=this.v1,a=this.v2;return n.set(Es(t,i.x,r.x,a.x),Es(t,i.y,r.y,a.y),Es(t,i.z,r.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Zr=class extends sn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new mt){let n=e,i=this.points,r=(i.length-1)*t,a=Math.floor(r),o=r-a,l=i[a===0?a:a-1],c=i[a],h=i[a>i.length-2?i.length-1:a+1],u=i[a>i.length-3?i.length-1:a+2];return n.set(jc(o,l.x,c.x,h.x,u.x),jc(o,l.y,c.y,h.y,u.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(i.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let i=this.points[e];t.points.push(i.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(new mt().fromArray(i))}return this}},Vo=Object.freeze({__proto__:null,ArcCurve:Oo,CatmullRomCurve3:zo,CubicBezierCurve:Xr,CubicBezierCurve3:Bo,EllipseCurve:Us,LineCurve:qr,LineCurve3:ko,QuadraticBezierCurve:Yr,QuadraticBezierCurve3:Ho,SplineCurve:Zr}),Go=class extends sn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Vo[n](e,t))}return this}getPoint(t,e){let n=t*this.getLength(),i=this.getCurveLengths(),r=0;for(;r<i.length;){if(i[r]>=n){let a=i[r]-n,o=this.curves[r],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let n=0,i=this.curves.length;n<i;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],n;for(let i=0,r=this.curves;i<r.length;i++){let a=r[i],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,l=a.getPoints(o);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let i=t.curves[e];this.curves.push(i.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){let i=this.curves[e];t.curves.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let i=t.curves[e];this.curves.push(new Vo[i.type]().fromJSON(i))}return this}},Jr=class extends Go{constructor(t){super(),this.type="Path",this.currentPoint=new mt,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let n=new qr(this.currentPoint.clone(),new mt(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,i){let r=new Yr(this.currentPoint.clone(),new mt(t,e),new mt(n,i));return this.curves.push(r),this.currentPoint.set(n,i),this}bezierCurveTo(t,e,n,i,r,a){let o=new Xr(this.currentPoint.clone(),new mt(t,e),new mt(n,i),new mt(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),n=new Zr(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,i,r,a){let o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+o,e+l,n,i,r,a),this}absarc(t,e,n,i,r,a){return this.absellipse(t,e,n,n,i,r,a),this}ellipse(t,e,n,i,r,a,o,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,n,i,r,a,o,l),this}absellipse(t,e,n,i,r,a,o,l){let c=new Us(t,e,n,i,r,a,o,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}};var rn=class s extends Re{constructor(t=1,e=1,n=1,i=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};let c=this;i=Math.floor(i),r=Math.floor(r);let h=[],u=[],d=[],f=[],g=0,y=[],m=n/2,p=0;x(),a===!1&&(t>0&&_(!0),e>0&&_(!1)),this.setIndex(h),this.setAttribute("position",new re(u,3)),this.setAttribute("normal",new re(d,3)),this.setAttribute("uv",new re(f,2));function x(){let M=new C,T=new C,E=0,R=(e-t)/n;for(let U=0;U<=r;U++){let v=[],S=U/r,N=S*(e-t)+t;for(let H=0;H<=i;H++){let et=H/i,L=et*l+o,F=Math.sin(L),X=Math.cos(L);T.x=N*F,T.y=-S*n+m,T.z=N*X,u.push(T.x,T.y,T.z),M.set(F,R,X).normalize(),d.push(M.x,M.y,M.z),f.push(et,1-S),v.push(g++)}y.push(v)}for(let U=0;U<i;U++)for(let v=0;v<r;v++){let S=y[v][U],N=y[v+1][U],H=y[v+1][U+1],et=y[v][U+1];h.push(S,N,et),h.push(N,H,et),E+=6}c.addGroup(p,E,0),p+=E}function _(M){let T=g,E=new mt,R=new C,U=0,v=M===!0?t:e,S=M===!0?1:-1;for(let H=1;H<=i;H++)u.push(0,m*S,0),d.push(0,S,0),f.push(.5,.5),g++;let N=g;for(let H=0;H<=i;H++){let L=H/i*l+o,F=Math.cos(L),X=Math.sin(L);R.x=v*X,R.y=m*S,R.z=v*F,u.push(R.x,R.y,R.z),d.push(0,S,0),E.x=F*.5+.5,E.y=X*.5*S+.5,f.push(E.x,E.y),g++}for(let H=0;H<i;H++){let et=T+H,L=N+H;M===!0?h.push(L,L+1,et):h.push(L+1,L,et),U+=3}c.addGroup(p,U,M===!0?1:2),p+=U}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},ji=class s extends rn{constructor(t=1,e=1,n=32,i=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,n,i,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new s(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Wo=class s extends Re{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};let r=[],a=[];o(i),c(n),h(),this.setAttribute("position",new re(r,3)),this.setAttribute("normal",new re(r.slice(),3)),this.setAttribute("uv",new re(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function o(x){let _=new C,M=new C,T=new C;for(let E=0;E<e.length;E+=3)f(e[E+0],_),f(e[E+1],M),f(e[E+2],T),l(_,M,T,x)}function l(x,_,M,T){let E=T+1,R=[];for(let U=0;U<=E;U++){R[U]=[];let v=x.clone().lerp(M,U/E),S=_.clone().lerp(M,U/E),N=E-U;for(let H=0;H<=N;H++)H===0&&U===E?R[U][H]=v:R[U][H]=v.clone().lerp(S,H/N)}for(let U=0;U<E;U++)for(let v=0;v<2*(E-U)-1;v++){let S=Math.floor(v/2);v%2===0?(d(R[U][S+1]),d(R[U+1][S]),d(R[U][S])):(d(R[U][S+1]),d(R[U+1][S+1]),d(R[U+1][S]))}}function c(x){let _=new C;for(let M=0;M<r.length;M+=3)_.x=r[M+0],_.y=r[M+1],_.z=r[M+2],_.normalize().multiplyScalar(x),r[M+0]=_.x,r[M+1]=_.y,r[M+2]=_.z}function h(){let x=new C;for(let _=0;_<r.length;_+=3){x.x=r[_+0],x.y=r[_+1],x.z=r[_+2];let M=m(x)/2/Math.PI+.5,T=p(x)/Math.PI+.5;a.push(M,1-T)}g(),u()}function u(){for(let x=0;x<a.length;x+=6){let _=a[x+0],M=a[x+2],T=a[x+4],E=Math.max(_,M,T),R=Math.min(_,M,T);E>.9&&R<.1&&(_<.2&&(a[x+0]+=1),M<.2&&(a[x+2]+=1),T<.2&&(a[x+4]+=1))}}function d(x){r.push(x.x,x.y,x.z)}function f(x,_){let M=x*3;_.x=t[M+0],_.y=t[M+1],_.z=t[M+2]}function g(){let x=new C,_=new C,M=new C,T=new C,E=new mt,R=new mt,U=new mt;for(let v=0,S=0;v<r.length;v+=9,S+=6){x.set(r[v+0],r[v+1],r[v+2]),_.set(r[v+3],r[v+4],r[v+5]),M.set(r[v+6],r[v+7],r[v+8]),E.set(a[S+0],a[S+1]),R.set(a[S+2],a[S+3]),U.set(a[S+4],a[S+5]),T.copy(x).add(_).add(M).divideScalar(3);let N=m(T);y(E,S+0,x,N),y(R,S+2,_,N),y(U,S+4,M,N)}}function y(x,_,M,T){T<0&&x.x===1&&(a[_]=x.x-1),M.x===0&&M.z===0&&(a[_]=T/2/Math.PI+.5)}function m(x){return Math.atan2(x.z,-x.x)}function p(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.vertices,t.indices,t.radius,t.details)}};var Ns=class extends Jr{constructor(t){super(t),this.uuid=ns(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let n=0,i=this.holes.length;n<i;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let i=t.holes[e];this.holes.push(i.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){let i=this.holes[e];t.holes.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){let i=t.holes[e];this.holes.push(new Jr().fromJSON(i))}return this}},Xg={triangulate:function(s,t,e=2){let n=t&&t.length,i=n?t[0]*e:s.length,r=Rh(s,0,i,e,!0),a=[];if(!r||r.next===r.prev)return a;let o,l,c,h,u,d,f;if(n&&(r=$g(s,t,r,e)),s.length>80*e){o=c=s[0],l=h=s[1];for(let g=e;g<i;g+=e)u=s[g],d=s[g+1],u<o&&(o=u),d<l&&(l=d),u>c&&(c=u),d>h&&(h=d);f=Math.max(c-o,h-l),f=f!==0?32767/f:0}return Fs(r,a,e,o,l,f,0),a}};function Rh(s,t,e,n,i){let r,a;if(i===o0(s,t,e,n)>0)for(r=t;r<e;r+=n)a=th(r,s[r],s[r+1],a);else for(r=e-n;r>=t;r-=n)a=th(r,s[r],s[r+1],a);return a&&ra(a,a.next)&&(zs(a),a=a.next),a}function xi(s,t){if(!s)return s;t||(t=s);let e=s,n;do if(n=!1,!e.steiner&&(ra(e,e.next)||he(e.prev,e,e.next)===0)){if(zs(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function Fs(s,t,e,n,i,r,a){if(!s)return;!a&&r&&e0(s,n,i,r);let o=s,l,c;for(;s.prev!==s.next;){if(l=s.prev,c=s.next,r?Yg(s,n,i,r):qg(s)){t.push(l.i/e|0),t.push(s.i/e|0),t.push(c.i/e|0),zs(s),s=c.next,o=c.next;continue}if(s=c,s===o){a?a===1?(s=Zg(xi(s),t,e),Fs(s,t,e,n,i,r,2)):a===2&&Jg(s,t,e,n,i,r):Fs(xi(s),t,e,n,i,r,1);break}}}function qg(s){let t=s.prev,e=s,n=s.next;if(he(t,e,n)>=0)return!1;let i=t.x,r=e.x,a=n.x,o=t.y,l=e.y,c=n.y,h=i<r?i<a?i:a:r<a?r:a,u=o<l?o<c?o:c:l<c?l:c,d=i>r?i>a?i:a:r>a?r:a,f=o>l?o>c?o:c:l>c?l:c,g=n.next;for(;g!==t;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=f&&Wi(i,o,r,l,a,c,g.x,g.y)&&he(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function Yg(s,t,e,n){let i=s.prev,r=s,a=s.next;if(he(i,r,a)>=0)return!1;let o=i.x,l=r.x,c=a.x,h=i.y,u=r.y,d=a.y,f=o<l?o<c?o:c:l<c?l:c,g=h<u?h<d?h:d:u<d?u:d,y=o>l?o>c?o:c:l>c?l:c,m=h>u?h>d?h:d:u>d?u:d,p=Xo(f,g,t,e,n),x=Xo(y,m,t,e,n),_=s.prevZ,M=s.nextZ;for(;_&&_.z>=p&&M&&M.z<=x;){if(_.x>=f&&_.x<=y&&_.y>=g&&_.y<=m&&_!==i&&_!==a&&Wi(o,h,l,u,c,d,_.x,_.y)&&he(_.prev,_,_.next)>=0||(_=_.prevZ,M.x>=f&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&Wi(o,h,l,u,c,d,M.x,M.y)&&he(M.prev,M,M.next)>=0))return!1;M=M.nextZ}for(;_&&_.z>=p;){if(_.x>=f&&_.x<=y&&_.y>=g&&_.y<=m&&_!==i&&_!==a&&Wi(o,h,l,u,c,d,_.x,_.y)&&he(_.prev,_,_.next)>=0)return!1;_=_.prevZ}for(;M&&M.z<=x;){if(M.x>=f&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&Wi(o,h,l,u,c,d,M.x,M.y)&&he(M.prev,M,M.next)>=0)return!1;M=M.nextZ}return!0}function Zg(s,t,e){let n=s;do{let i=n.prev,r=n.next.next;!ra(i,r)&&Ch(i,n,n.next,r)&&Os(i,r)&&Os(r,i)&&(t.push(i.i/e|0),t.push(n.i/e|0),t.push(r.i/e|0),zs(n),zs(n.next),n=s=r),n=n.next}while(n!==s);return xi(n)}function Jg(s,t,e,n,i,r){let a=s;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&s0(a,o)){let l=Ph(a,o);a=xi(a,a.next),l=xi(l,l.next),Fs(a,t,e,n,i,r,0),Fs(l,t,e,n,i,r,0);return}o=o.next}a=a.next}while(a!==s)}function $g(s,t,e,n){let i=[],r,a,o,l,c;for(r=0,a=t.length;r<a;r++)o=t[r]*n,l=r<a-1?t[r+1]*n:s.length,c=Rh(s,o,l,n,!1),c===c.next&&(c.steiner=!0),i.push(i0(c));for(i.sort(Kg),r=0;r<i.length;r++)e=Qg(i[r],e);return e}function Kg(s,t){return s.x-t.x}function Qg(s,t){let e=jg(s,t);if(!e)return t;let n=Ph(e,s);return xi(n,n.next),xi(e,e.next)}function jg(s,t){let e=t,n=-1/0,i,r=s.x,a=s.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){let d=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(d<=r&&d>n&&(n=d,i=e.x<e.next.x?e:e.next,d===r))return i}e=e.next}while(e!==t);if(!i)return null;let o=i,l=i.x,c=i.y,h=1/0,u;e=i;do r>=e.x&&e.x>=l&&r!==e.x&&Wi(a<c?r:n,a,l,c,a<c?n:r,a,e.x,e.y)&&(u=Math.abs(a-e.y)/(r-e.x),Os(e,s)&&(u<h||u===h&&(e.x>i.x||e.x===i.x&&t0(i,e)))&&(i=e,h=u)),e=e.next;while(e!==o);return i}function t0(s,t){return he(s.prev,s,t.prev)<0&&he(t.next,s,s.next)<0}function e0(s,t,e,n){let i=s;do i.z===0&&(i.z=Xo(i.x,i.y,t,e,n)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==s);i.prevZ.nextZ=null,i.prevZ=null,n0(i)}function n0(s){let t,e,n,i,r,a,o,l,c=1;do{for(e=s,s=null,r=null,a=0;e;){for(a++,n=e,o=0,t=0;t<c&&(o++,n=n.nextZ,!!n);t++);for(l=c;o>0||l>0&&n;)o!==0&&(l===0||!n||e.z<=n.z)?(i=e,e=e.nextZ,o--):(i=n,n=n.nextZ,l--),r?r.nextZ=i:s=i,i.prevZ=r,r=i;e=n}r.nextZ=null,c*=2}while(a>1);return s}function Xo(s,t,e,n,i){return s=(s-e)*i|0,t=(t-n)*i|0,s=(s|s<<8)&16711935,s=(s|s<<4)&252645135,s=(s|s<<2)&858993459,s=(s|s<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,s|t<<1}function i0(s){let t=s,e=s;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==s);return e}function Wi(s,t,e,n,i,r,a,o){return(i-a)*(t-o)>=(s-a)*(r-o)&&(s-a)*(n-o)>=(e-a)*(t-o)&&(e-a)*(r-o)>=(i-a)*(n-o)}function s0(s,t){return s.next.i!==t.i&&s.prev.i!==t.i&&!r0(s,t)&&(Os(s,t)&&Os(t,s)&&a0(s,t)&&(he(s.prev,s,t.prev)||he(s,t.prev,t))||ra(s,t)&&he(s.prev,s,s.next)>0&&he(t.prev,t,t.next)>0)}function he(s,t,e){return(t.y-s.y)*(e.x-t.x)-(t.x-s.x)*(e.y-t.y)}function ra(s,t){return s.x===t.x&&s.y===t.y}function Ch(s,t,e,n){let i=yr(he(s,t,e)),r=yr(he(s,t,n)),a=yr(he(e,n,s)),o=yr(he(e,n,t));return!!(i!==r&&a!==o||i===0&&xr(s,e,t)||r===0&&xr(s,n,t)||a===0&&xr(e,s,n)||o===0&&xr(e,t,n))}function xr(s,t,e){return t.x<=Math.max(s.x,e.x)&&t.x>=Math.min(s.x,e.x)&&t.y<=Math.max(s.y,e.y)&&t.y>=Math.min(s.y,e.y)}function yr(s){return s>0?1:s<0?-1:0}function r0(s,t){let e=s;do{if(e.i!==s.i&&e.next.i!==s.i&&e.i!==t.i&&e.next.i!==t.i&&Ch(e,e.next,s,t))return!0;e=e.next}while(e!==s);return!1}function Os(s,t){return he(s.prev,s,s.next)<0?he(s,t,s.next)>=0&&he(s,s.prev,t)>=0:he(s,t,s.prev)<0||he(s,s.next,t)<0}function a0(s,t){let e=s,n=!1,i=(s.x+t.x)/2,r=(s.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&i<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==s);return n}function Ph(s,t){let e=new qo(s.i,s.x,s.y),n=new qo(t.i,t.x,t.y),i=s.next,r=t.prev;return s.next=t,t.prev=s,e.next=i,i.prev=e,n.next=e,e.prev=n,r.next=n,n.prev=r,n}function th(s,t,e,n){let i=new qo(s,t,e);return n?(i.next=n.next,i.prev=n,n.next.prev=i,n.next=i):(i.prev=i,i.next=i),i}function zs(s){s.next.prev=s.prev,s.prev.next=s.next,s.prevZ&&(s.prevZ.nextZ=s.nextZ),s.nextZ&&(s.nextZ.prevZ=s.prevZ)}function qo(s,t,e){this.i=s,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function o0(s,t,e,n){let i=0;for(let r=t,a=e-n;r<e;r+=n)i+=(s[a]-s[r])*(s[r+1]+s[a+1]),a=r;return i}var Ts=class s{static area(t){let e=t.length,n=0;for(let i=e-1,r=0;r<e;i=r++)n+=t[i].x*t[r].y-t[r].x*t[i].y;return n*.5}static isClockWise(t){return s.area(t)<0}static triangulateShape(t,e){let n=[],i=[],r=[];eh(t),nh(n,t);let a=t.length;e.forEach(eh);for(let l=0;l<e.length;l++)i.push(a),a+=e[l].length,nh(n,e[l]);let o=Xg.triangulate(n,i);for(let l=0;l<o.length;l+=3)r.push(o.slice(l,l+3));return r}};function eh(s){let t=s.length;t>2&&s[t-1].equals(s[0])&&s.pop()}function nh(s,t){for(let e=0;e<t.length;e++)s.push(t[e].x),s.push(t[e].y)}var $r=class s extends Re{constructor(t=new Ns([new mt(.5,.5),new mt(-.5,.5),new mt(-.5,-.5),new mt(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let n=this,i=[],r=[];for(let o=0,l=t.length;o<l;o++){let c=t[o];a(c)}this.setAttribute("position",new re(i,3)),this.setAttribute("uv",new re(r,2)),this.computeVertexNormals();function a(o){let l=[],c=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,u=e.depth!==void 0?e.depth:1,d=e.bevelEnabled!==void 0?e.bevelEnabled:!0,f=e.bevelThickness!==void 0?e.bevelThickness:.2,g=e.bevelSize!==void 0?e.bevelSize:f-.1,y=e.bevelOffset!==void 0?e.bevelOffset:0,m=e.bevelSegments!==void 0?e.bevelSegments:3,p=e.extrudePath,x=e.UVGenerator!==void 0?e.UVGenerator:l0,_,M=!1,T,E,R,U;p&&(_=p.getSpacedPoints(h),M=!0,d=!1,T=p.computeFrenetFrames(h,!1),E=new C,R=new C,U=new C),d||(m=0,f=0,g=0,y=0);let v=o.extractPoints(c),S=v.shape,N=v.holes;if(!Ts.isClockWise(S)){S=S.reverse();for(let P=0,st=N.length;P<st;P++){let k=N[P];Ts.isClockWise(k)&&(N[P]=k.reverse())}}let et=Ts.triangulateShape(S,N),L=S;for(let P=0,st=N.length;P<st;P++){let k=N[P];S=S.concat(k)}function F(P,st,k){return st||console.error("THREE.ExtrudeGeometry: vec does not exist"),P.clone().addScaledVector(st,k)}let X=S.length,nt=et.length;function Z(P,st,k){let J,V,xt,ht=P.x-st.x,w=P.y-st.y,b=k.x-P.x,O=k.y-P.y,it=ht*ht+w*w,at=ht*O-w*b;if(Math.abs(at)>Number.EPSILON){let rt=Math.sqrt(it),Tt=Math.sqrt(b*b+O*O),yt=st.x-w/rt,Et=st.y+ht/rt,Pt=k.x-O/Tt,kt=k.y+b/Tt,ot=((Pt-yt)*O-(kt-Et)*b)/(ht*O-w*b);J=yt+ht*ot-P.x,V=Et+w*ot-P.y;let $t=J*J+V*V;if($t<=2)return new mt(J,V);xt=Math.sqrt($t/2)}else{let rt=!1;ht>Number.EPSILON?b>Number.EPSILON&&(rt=!0):ht<-Number.EPSILON?b<-Number.EPSILON&&(rt=!0):Math.sign(w)===Math.sign(O)&&(rt=!0),rt?(J=-w,V=ht,xt=Math.sqrt(it)):(J=ht,V=w,xt=Math.sqrt(it/2))}return new mt(J/xt,V/xt)}let $=[];for(let P=0,st=L.length,k=st-1,J=P+1;P<st;P++,k++,J++)k===st&&(k=0),J===st&&(J=0),$[P]=Z(L[P],L[k],L[J]);let D=[],j,ct=$.concat();for(let P=0,st=N.length;P<st;P++){let k=N[P];j=[];for(let J=0,V=k.length,xt=V-1,ht=J+1;J<V;J++,xt++,ht++)xt===V&&(xt=0),ht===V&&(ht=0),j[J]=Z(k[J],k[xt],k[ht]);D.push(j),ct=ct.concat(j)}for(let P=0;P<m;P++){let st=P/m,k=f*Math.cos(st*Math.PI/2),J=g*Math.sin(st*Math.PI/2)+y;for(let V=0,xt=L.length;V<xt;V++){let ht=F(L[V],$[V],J);pt(ht.x,ht.y,-k)}for(let V=0,xt=N.length;V<xt;V++){let ht=N[V];j=D[V];for(let w=0,b=ht.length;w<b;w++){let O=F(ht[w],j[w],J);pt(O.x,O.y,-k)}}}let B=g+y;for(let P=0;P<X;P++){let st=d?F(S[P],ct[P],B):S[P];M?(R.copy(T.normals[0]).multiplyScalar(st.x),E.copy(T.binormals[0]).multiplyScalar(st.y),U.copy(_[0]).add(R).add(E),pt(U.x,U.y,U.z)):pt(st.x,st.y,0)}for(let P=1;P<=h;P++)for(let st=0;st<X;st++){let k=d?F(S[st],ct[st],B):S[st];M?(R.copy(T.normals[P]).multiplyScalar(k.x),E.copy(T.binormals[P]).multiplyScalar(k.y),U.copy(_[P]).add(R).add(E),pt(U.x,U.y,U.z)):pt(k.x,k.y,u/h*P)}for(let P=m-1;P>=0;P--){let st=P/m,k=f*Math.cos(st*Math.PI/2),J=g*Math.sin(st*Math.PI/2)+y;for(let V=0,xt=L.length;V<xt;V++){let ht=F(L[V],$[V],J);pt(ht.x,ht.y,u+k)}for(let V=0,xt=N.length;V<xt;V++){let ht=N[V];j=D[V];for(let w=0,b=ht.length;w<b;w++){let O=F(ht[w],j[w],J);M?pt(O.x,O.y+_[h-1].y,_[h-1].x+k):pt(O.x,O.y,u+k)}}}tt(),ut();function tt(){let P=i.length/3;if(d){let st=0,k=X*st;for(let J=0;J<nt;J++){let V=et[J];q(V[2]+k,V[1]+k,V[0]+k)}st=h+m*2,k=X*st;for(let J=0;J<nt;J++){let V=et[J];q(V[0]+k,V[1]+k,V[2]+k)}}else{for(let st=0;st<nt;st++){let k=et[st];q(k[2],k[1],k[0])}for(let st=0;st<nt;st++){let k=et[st];q(k[0]+X*h,k[1]+X*h,k[2]+X*h)}}n.addGroup(P,i.length/3-P,0)}function ut(){let P=i.length/3,st=0;bt(L,st),st+=L.length;for(let k=0,J=N.length;k<J;k++){let V=N[k];bt(V,st),st+=V.length}n.addGroup(P,i.length/3-P,1)}function bt(P,st){let k=P.length;for(;--k>=0;){let J=k,V=k-1;V<0&&(V=P.length-1);for(let xt=0,ht=h+m*2;xt<ht;xt++){let w=X*xt,b=X*(xt+1),O=st+J+w,it=st+V+w,at=st+V+b,rt=st+J+b;K(O,it,at,rt)}}}function pt(P,st,k){l.push(P),l.push(st),l.push(k)}function q(P,st,k){Q(P),Q(st),Q(k);let J=i.length/3,V=x.generateTopUV(n,i,J-3,J-2,J-1);_t(V[0]),_t(V[1]),_t(V[2])}function K(P,st,k,J){Q(P),Q(st),Q(J),Q(st),Q(k),Q(J);let V=i.length/3,xt=x.generateSideWallUV(n,i,V-6,V-3,V-2,V-1);_t(xt[0]),_t(xt[1]),_t(xt[3]),_t(xt[1]),_t(xt[2]),_t(xt[3])}function Q(P){i.push(l[P*3+0]),i.push(l[P*3+1]),i.push(l[P*3+2])}function _t(P){r.push(P.x),r.push(P.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,n=this.parameters.options;return c0(e,n,t)}static fromJSON(t,e){let n=[];for(let r=0,a=t.shapes.length;r<a;r++){let o=e[t.shapes[r]];n.push(o)}let i=t.options.extrudePath;return i!==void 0&&(t.options.extrudePath=new Vo[i.type]().fromJSON(i)),new s(n,t.options)}},l0={generateTopUV:function(s,t,e,n,i){let r=t[e*3],a=t[e*3+1],o=t[n*3],l=t[n*3+1],c=t[i*3],h=t[i*3+1];return[new mt(r,a),new mt(o,l),new mt(c,h)]},generateSideWallUV:function(s,t,e,n,i,r){let a=t[e*3],o=t[e*3+1],l=t[e*3+2],c=t[n*3],h=t[n*3+1],u=t[n*3+2],d=t[i*3],f=t[i*3+1],g=t[i*3+2],y=t[r*3],m=t[r*3+1],p=t[r*3+2];return Math.abs(o-h)<Math.abs(a-c)?[new mt(a,1-l),new mt(c,1-u),new mt(d,1-g),new mt(y,1-p)]:[new mt(o,1-l),new mt(h,1-u),new mt(f,1-g),new mt(m,1-p)]}};function c0(s,t,e){if(e.shapes=[],Array.isArray(s))for(let n=0,i=s.length;n<i;n++){let r=s[n];e.shapes.push(r.uuid)}else e.shapes.push(s.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var Kr=class s extends Wo{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,i=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(i,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new s(t.radius,t.detail)}};var Qr=class s extends Re{constructor(t=.5,e=1,n=32,i=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:i,thetaStart:r,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);let o=[],l=[],c=[],h=[],u=t,d=(e-t)/i,f=new C,g=new mt;for(let y=0;y<=i;y++){for(let m=0;m<=n;m++){let p=r+m/n*a;f.x=u*Math.cos(p),f.y=u*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),g.x=(f.x/e+1)/2,g.y=(f.y/e+1)/2,h.push(g.x,g.y)}u+=d}for(let y=0;y<i;y++){let m=y*(n+1);for(let p=0;p<n;p++){let x=p+m,_=x,M=x+n+1,T=x+n+2,E=x+1;o.push(_,M,E),o.push(M,T,E)}}this.setIndex(o),this.setAttribute("position",new re(l,3)),this.setAttribute("normal",new re(c,3)),this.setAttribute("uv",new re(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var yi=class s extends Re{constructor(t=1,e=32,n=16,i=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(a+o,Math.PI),c=0,h=[],u=new C,d=new C,f=[],g=[],y=[],m=[];for(let p=0;p<=n;p++){let x=[],_=p/n,M=0;p===0&&a===0?M=.5/e:p===n&&l===Math.PI&&(M=-.5/e);for(let T=0;T<=e;T++){let E=T/e;u.x=-t*Math.cos(i+E*r)*Math.sin(a+_*o),u.y=t*Math.cos(a+_*o),u.z=t*Math.sin(i+E*r)*Math.sin(a+_*o),g.push(u.x,u.y,u.z),d.copy(u).normalize(),y.push(d.x,d.y,d.z),m.push(E+M,1-_),x.push(c++)}h.push(x)}for(let p=0;p<n;p++)for(let x=0;x<e;x++){let _=h[p][x+1],M=h[p][x],T=h[p+1][x],E=h[p+1][x+1];(p!==0||a>0)&&f.push(_,M,E),(p!==n-1||l<Math.PI)&&f.push(M,T,E)}this.setIndex(f),this.setAttribute("position",new re(g,3)),this.setAttribute("normal",new re(y,3)),this.setAttribute("uv",new re(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var Le=class extends ei{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Ct(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ct(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=_h,this.normalScale=new mt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}};function vr(s,t,e){return!s||!e&&s.constructor===t?s:typeof t.BYTES_PER_ELEMENT=="number"?new t(s):Array.prototype.slice.call(s)}function h0(s){return ArrayBuffer.isView(s)&&!(s instanceof DataView)}var ts=class{constructor(t,e,n,i){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,i=e[n],r=e[n-1];n:{t:{let a;e:{i:if(!(t<i)){for(let o=n+2;;){if(i===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(r=i,i=e[++n],t<i)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(n=2,r=o);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(i=r,r=e[--n-1],t>=r)break t}a=n,n=0;break e}break n}for(;n<a;){let o=n+a>>>1;t<e[o]?a=o:n=o+1}if(i=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,i)}return this.interpolate_(n,r,t,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,i=this.valueSize,r=t*i;for(let a=0;a!==i;++a)e[a]=n[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Yo=class extends ts{constructor(t,e,n,i){super(t,e,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:rc,endingEnd:rc}}intervalChanged_(t,e,n){let i=this.parameterPositions,r=t-2,a=t+1,o=i[r],l=i[a];if(o===void 0)switch(this.getSettings_().endingStart){case ac:r=t,o=2*e-n;break;case oc:r=i.length-2,o=e+i[r]-i[r+1];break;default:r=t,o=n}if(l===void 0)switch(this.getSettings_().endingEnd){case ac:a=t,l=2*n-e;break;case oc:a=1,l=n+i[1]-i[0];break;default:a=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-o),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,g=(n-e)/(i-e),y=g*g,m=y*g,p=-d*m+2*d*y-d*g,x=(1+d)*m+(-1.5-2*d)*y+(-.5+d)*g+1,_=(-1-f)*m+(1.5+f)*y+.5*g,M=f*m-f*y;for(let T=0;T!==o;++T)r[T]=p*a[h+T]+x*a[c+T]+_*a[l+T]+M*a[u+T];return r}},Zo=class extends ts{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=(n-e)/(i-e),u=1-h;for(let d=0;d!==o;++d)r[d]=a[c+d]*u+a[l+d]*h;return r}},Jo=class extends ts{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t){return this.copySampleValue_(t-1)}},gn=class{constructor(t,e,n,i){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=vr(e,this.TimeBufferType),this.values=vr(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:vr(t.times,Array),values:vr(t.values,Array)};let i=t.getInterpolation();i!==t.DefaultInterpolation&&(n.interpolation=i)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new Jo(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Zo(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Yo(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case br:e=this.InterpolantFactoryMethodDiscrete;break;case Sr:e=this.InterpolantFactoryMethodLinear;break;case Na:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return br;case this.InterpolantFactoryMethodLinear:return Sr;case this.InterpolantFactoryMethodSmooth:return Na}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]*=t}return this}trim(t,e){let n=this.times,i=n.length,r=0,a=i-1;for(;r!==i&&n[r]<t;)++r;for(;a!==-1&&n[a]>e;)--a;if(++a,r!==0||a!==i){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=n.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,i=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let l=n[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),t=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),t=!1;break}a=l}if(i!==void 0&&h0(i))for(let o=0,l=i.length;o!==l;++o){let c=i[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===Na,r=t.length-1,a=1;for(let o=1;o<r;++o){let l=!1,c=t[o],h=t[o+1];if(c!==h&&(o!==1||c!==t[0]))if(i)l=!0;else{let u=o*n,d=u-n,f=u+n;for(let g=0;g!==n;++g){let y=e[u+g];if(y!==e[d+g]||y!==e[f+g]){l=!0;break}}}if(l){if(o!==a){t[a]=t[o];let u=o*n,d=a*n;for(let f=0;f!==n;++f)e[d+f]=e[u+f]}++a}}if(r>0){t[a]=t[r];for(let o=r*n,l=a*n,c=0;c!==n;++c)e[l+c]=e[o+c];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,i=new n(this.name,t,e);return i.createInterpolant=this.createInterpolant,i}};gn.prototype.TimeBufferType=Float32Array;gn.prototype.ValueBufferType=Float32Array;gn.prototype.DefaultInterpolation=Sr;var vi=class extends gn{};vi.prototype.ValueTypeName="bool";vi.prototype.ValueBufferType=Array;vi.prototype.DefaultInterpolation=br;vi.prototype.InterpolantFactoryMethodLinear=void 0;vi.prototype.InterpolantFactoryMethodSmooth=void 0;var $o=class extends gn{};$o.prototype.ValueTypeName="color";var Ko=class extends gn{};Ko.prototype.ValueTypeName="number";var Qo=class extends ts{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(n-e)/(i-e),c=t*o;for(let h=c+o;c!==h;c+=4)Jt.slerpFlat(r,0,a,c-o,a,c,l);return r}},Bs=class extends gn{InterpolantFactoryMethodLinear(t){return new Qo(this.times,this.values,this.getValueSize(),t)}};Bs.prototype.ValueTypeName="quaternion";Bs.prototype.DefaultInterpolation=Sr;Bs.prototype.InterpolantFactoryMethodSmooth=void 0;var Mi=class extends gn{};Mi.prototype.ValueTypeName="string";Mi.prototype.ValueBufferType=Array;Mi.prototype.DefaultInterpolation=br;Mi.prototype.InterpolantFactoryMethodLinear=void 0;Mi.prototype.InterpolantFactoryMethodSmooth=void 0;var jo=class extends gn{};jo.prototype.ValueTypeName="vector";var tl=class{constructor(t,e,n){let i=this,r=!1,a=0,o=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(h){o++,r===!1&&i.onStart!==void 0&&i.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,i.onProgress!==void 0&&i.onProgress(h,a,o),a===o&&(r=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(h){i.onError!==void 0&&i.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],g=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return g}return null}}},u0=new tl,el=class{constructor(t){this.manager=t!==void 0?t:u0,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(i,r){n.load(t,i,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};el.DEFAULT_MATERIAL_NAME="__DEFAULT";var ks=class extends Ae{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Ct(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}},jr=class extends ks{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ae.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ct(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},co=new se,ih=new C,sh=new C,ta=class{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new mt(512,512),this.map=null,this.mapPass=null,this.matrix=new se,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ps,this._frameExtents=new mt(1,1),this._viewportCount=1,this._viewports=[new le(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;ih.setFromMatrixPosition(t.matrixWorld),e.position.copy(ih),sh.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(sh),e.updateMatrixWorld(),co.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(co),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(co)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var rh=new se,Ms=new C,ho=new C,nl=class extends ta{constructor(){super(new Oe(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new mt(4,2),this._viewportCount=6,this._viewports=[new le(2,1,1,1),new le(0,1,1,1),new le(3,1,1,1),new le(1,1,1,1),new le(3,0,1,1),new le(1,0,1,1)],this._cubeDirections=[new C(1,0,0),new C(-1,0,0),new C(0,0,1),new C(0,0,-1),new C(0,1,0),new C(0,-1,0)],this._cubeUps=[new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,0,1),new C(0,0,-1)]}updateMatrices(t,e=0){let n=this.camera,i=this.matrix,r=t.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),Ms.setFromMatrixPosition(t.matrixWorld),n.position.copy(Ms),ho.copy(n.position),ho.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(ho),n.updateMatrixWorld(),i.makeTranslation(-Ms.x,-Ms.y,-Ms.z),rh.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(rh)}},es=class extends ks{constructor(t,e,n=0,i=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new nl}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}},il=class extends ta{constructor(){super(new Br(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},ea=class extends ks{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ae.DEFAULT_UP),this.updateMatrix(),this.target=new Ae,this.shadow=new il}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var hl="\\[\\]\\.:\\/",d0=new RegExp("["+hl+"]","g"),ul="[^"+hl+"]",f0="[^"+hl.replace("\\.","")+"]",p0=/((?:WC+[\/:])*)/.source.replace("WC",ul),m0=/(WCOD+)?/.source.replace("WCOD",f0),g0=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",ul),_0=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",ul),x0=new RegExp("^"+p0+m0+g0+_0+"$"),y0=["material","materials","bones","map"],sl=class{constructor(t,e,n){let i=n||oe.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,i)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,r=n.length;i!==r;++i)n[i].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},oe=class s{constructor(t,e,n){this.path=e,this.parsedPath=n||s.parseTrackName(e),this.node=s.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new s.Composite(t,e,n):new s(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(d0,"")}static parseTrackName(t){let e=x0.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let r=n.nodeName.substring(i+1);y0.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let l=n(o.children);if(l)return l}return null},i=n(t.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)t[e++]=n[i]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,i=e.propertyName,r=e.propertyIndex;if(t||(t=s.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let a=t[i];if(a===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+i+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(i==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=i;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};oe.Composite=sl;oe.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};oe.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};oe.prototype.GetterByBindingType=[oe.prototype._getValue_direct,oe.prototype._getValue_array,oe.prototype._getValue_arrayElement,oe.prototype._getValue_toArray];oe.prototype.SetterByBindingTypeAndVersioning=[[oe.prototype._setValue_direct,oe.prototype._setValue_direct_setNeedsUpdate,oe.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[oe.prototype._setValue_array,oe.prototype._setValue_array_setNeedsUpdate,oe.prototype._setValue_array_setMatrixWorldNeedsUpdate],[oe.prototype._setValue_arrayElement,oe.prototype._setValue_arrayElement_setNeedsUpdate,oe.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[oe.prototype._setValue_fromArray,oe.prototype._setValue_fromArray_setNeedsUpdate,oe.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var I0=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"160"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="160");var zt=s=>s*.01,ge=s=>s/.01,gt={version:"1.0.0",sim:{hz:120,maxCatchupSteps:8,gravity:zt(650),solverIterations:10},arena:{halfWidth:zt(4096),halfLength:zt(5120),height:zt(2044),floorRampRadius:zt(260),ceilingRampRadius:zt(260),cornerRadius:zt(1152),goalHalfWidth:zt(892.75),goalHeight:zt(642.775),goalDepth:zt(880),postRadius:zt(30),arcSegments:14,friction:.5,restitution:.75},car:{halfLength:zt(120.5)/2,halfWidth:zt(86.7)/2,halfHeight:zt(38.7)/2,mass:180,comOffsetY:-.04,restHeight:.205,wheelRadius:.14,wheelbase:zt(101.5),wheelX:.4,wheelZFront:-.43,wheelZRear:.38,wheelAttachY:-.02,suspensionDroop:.05,springEquilibrium:.07,springDampingRatio:.55,bumpStopStart:.1,bumpStopStiffness:9,rollInfluence:.06,lateralGrip:1,frictionCoeff:4,powerslideGrip:.1,powerslideYawRate:4.2,powerslideYawAccel:22,gripRecoveryTime:.18,stickyAccel:zt(325),throttleAccel0:zt(1600),maxDriveSpeed:zt(1410),brakeAccel:zt(3500),coastAccel:zt(525),reverseMaxSpeed:zt(1410),boostAccelGround:zt(992),boostAccelAir:zt(1058),maxSpeed:zt(2300),supersonic:zt(2200),airThrottleAccel:zt(66.7),steerAngles:[[0,35],[500,20],[1e3,11],[1500,6.25],[1750,5],[3e3,2]],jumpImpulse:zt(292),jumpHoldAccel:zt(1458),jumpHoldTime:.2,dodgeWindow:1.25,fallOffJumpWindow:1.45,dodgeImpulse:zt(500),dodgeSpeedBonus:.9,dodgeDeadzone:.5,flipTime:.65,flipTorqueAccel:55,flipVerticalDamp:.35,flipVerticalDampTime:.15,flipCancelThreshold:.5,airPitchAccel:12.46,airYawAccel:9.11,airRollAccel:38.34,airPitchDamp:2.798,airYawDamp:1.886,airRollDamp:4,maxAngularSpeed:5.5,demoRespawn:3,demoMinRelSpeed:zt(300),boostStart:33.33,boostMax:100,boostPerSecond:33.3,colliderFriction:.4,colliderRestitution:.15},ball:{radius:zt(91.25),mass:30,maxSpeed:zt(6e3),maxAngularSpeed:6,linearDamping:.03,angularDamping:.05,restitution:.8,friction:.7,carRestitution:.35,hitVerticalScale:.35,hitCurve:[[0,.65],[500,.65],[2300,.55],[4600,.3]],hitCooldown:.05},boost:{smallAmount:12,smallRespawn:4,smallRadius:zt(144),largeAmount:100,largeRespawn:10,largeRadius:zt(208),pickupHeight:zt(165)},camera:{hFov:110,distance:270,height:100,angle:-4,stiffness:.4,swivelSpeed:4,transitionSpeed:6,ballCamPitchMax:45,freeLookMax:1.9},match:{duration:300,countdown:3,goalCelebration:2.2,replayDuration:5,replaySpeed:.5,resultsDelay:1,kickoffHalfWidth:0},input:{stickDeadzone:.12,triggerDeadzone:.05,steerSensitivity:1,dodgeDeadzone:.5,mouseSensitivity:.0022,bindings:{throttle:["KeyW"],brake:["KeyS"],left:["KeyA"],right:["KeyD"],jump:["Space"],boost:["ShiftLeft","ShiftRight"],powerslide:["ControlLeft","ControlRight"],rollLeft:["KeyQ"],rollRight:["KeyE"],ballCam:["KeyC"],reset:["KeyR"],lookLeft:["ArrowLeft"],lookRight:["ArrowRight"],lookUp:["ArrowUp"],lookDown:["ArrowDown"],pause:["Escape"]}},ai:{difficulties:{rookie:{reaction:.28,steerNoise:.18,boostUse:.5,aerial:!1,dodge:!1,predictTime:2,speedLimit:.8,powerslide:!1},pro:{reaction:.14,steerNoise:.07,boostUse:.8,aerial:!1,dodge:!0,predictTime:3,speedLimit:1,powerslide:!0},allstar:{reaction:.05,steerNoise:.02,boostUse:1,aerial:!0,dodge:!0,predictTime:4,speedLimit:1,powerslide:!0}}},audio:{master:.6,mute:!1},ui:{showFps:!1}};function aa(s,t){if(t<=s[0][0])return s[0][1];for(let e=1;e<s.length;e++)if(t<=s[e][0]){let[n,i]=s[e-1],[r,a]=s[e];return i+(t-n)/(r-n)*(a-i)}return s[s.length-1][1]}var ss=class{constructor(){this.pos=[],this.nor=[],this.uv=[],this.idx=[]}vert(t,e,n){return this.pos.push(t[0],t[1],t[2]),this.nor.push(e[0],e[1],e[2]),this.uv.push(n[0],n[1]),this.pos.length/3-1}tri(t,e,n){let i=this.pos,r=this.nor,a=i[t*3],o=i[t*3+1],l=i[t*3+2],c=[i[e*3]-a,i[e*3+1]-o,i[e*3+2]-l],h=[i[n*3]-a,i[n*3+1]-o,i[n*3+2]-l],u=c[1]*h[2]-c[2]*h[1],d=c[2]*h[0]-c[0]*h[2],f=c[0]*h[1]-c[1]*h[0];if(u*u+d*d+f*f<1e-14)return;u*(r[t*3]+r[e*3]+r[n*3])+d*(r[t*3+1]+r[e*3+1]+r[n*3+1])+f*(r[t*3+2]+r[e*3+2]+r[n*3+2])>=0?this.idx.push(t,e,n):this.idx.push(t,n,e)}quad(t,e,n,i){this.tri(t,e,n),this.tri(t,n,i)}finish(){return{positions:new Float32Array(this.pos),normals:new Float32Array(this.nor),uvs:new Float32Array(this.uv),indices:new Uint32Array(this.idx)}}},v0=[[0,-4240],[-1792,-4184],[1792,-4184],[-940,-3308],[940,-3308],[0,-2816],[-3584,-2484],[3584,-2484],[-1788,-2300],[1788,-2300],[-2048,-1036],[0,-1024],[2048,-1036],[-1024,0],[1024,0],[-2048,1036],[0,1024],[2048,1036],[-1788,2300],[1788,2300],[-3584,2484],[3584,2484],[0,2816],[-940,3308],[940,3308],[-1792,4184],[1792,4184],[0,4240]],M0=[[-3584,0],[3584,0],[-3072,4096],[3072,4096],[-3072,-4096],[3072,-4096]];function b0(){let s=[];for(let[t,e]of v0)s.push({x:zt(t),z:zt(e),large:!1});for(let[t,e]of M0)s.push({x:zt(t),z:zt(e),large:!0});return s}function S0(){return[{x:0,z:-4608,yaw:0},{x:-2048,z:-2560,yaw:0},{x:2048,z:-2560,yaw:0},{x:-256,z:-3840,yaw:0},{x:256,z:-3840,yaw:0}].map(s=>({x:zt(s.x),z:zt(s.z),yaw:s.yaw}))}function Lh(s=gt.arena){let t=s.halfWidth,e=s.halfLength,n=s.height,i=s.floorRampRadius,r=s.ceilingRampRadius,a=s.cornerRadius,o=s.goalHalfWidth,l=s.goalHeight,c=s.goalDepth,h=1e-4,u=s.arcSegments,d=[],f=(q,K,Q,_t,P)=>d.push({x:q,z:K,nx:Q,nz:_t,end:P}),g=(q,K,Q,_t,P,st,k,J=[])=>{let V=Math.hypot(Q-q,_t-K),xt=new Set([0]),ht=Math.max(1,Math.ceil(V/10));for(let w=1;w<ht;w++)xt.add(w/ht);for(let w of J)xt.add(w);[...xt].sort((w,b)=>w-b).forEach(w=>f(q+(Q-q)*w,K+(_t-K)*w,P,st,k))},y=(q,K,Q,_t)=>{for(let P=0;P<=u;P++){let st=Q+(_t-Q)*P/u,k=Math.cos(st),J=Math.sin(st);f(q+k*a,K+J*a,-k,-J,0)}},m=t-a,p=e-a,x=(o- -m)/(2*m),_=q=>(m-q)/(2*m);g(m,e,-m,e,0,-1,1,[_(o),_(-o)]),y(-m,p,Math.PI/2,Math.PI),g(-t,p,-t,-p,1,0,0),y(-m,-p,Math.PI,Math.PI*1.5),g(-m,-e,m,-e,0,1,-1,[_(-o),_(o)].map(q=>1-q)),y(m,-p,Math.PI*1.5,Math.PI*2),g(t,-p,t,p,-1,0,0),y(m,p,0,Math.PI/2);let M=[];for(let q of d){let K=M[M.length-1];if(K&&Math.abs(K.x-q.x)<h&&Math.abs(K.z-q.z)<h){q.end&&(K.end=q.end,K.nx=q.nx,K.nz=q.nz);continue}M.push(q)}let T=M[0],E=M[M.length-1];Math.abs(T.x-E.x)<h&&Math.abs(T.z-E.z)<h&&M.pop();let R=0;M.forEach((q,K)=>{K>0&&(R+=Math.hypot(q.x-M[K-1].x,q.z-M[K-1].z)),q.s=R});let U=R+Math.hypot(M[0].x-M[M.length-1].x,M[0].z-M[M.length-1].z),v=[],S=(q,K,Q,_t)=>v.push({d:q,y:K,nd:Q,ny:_t});for(let q=0;q<=u;q++){let K=Math.PI/2*(q/u);S(i*(1-Math.sin(K)),i*(1-Math.cos(K)),Math.sin(K),Math.cos(K))}S(0,l,1,0),S(0,n-r,1,0);for(let q=1;q<=u;q++){let K=Math.PI/2*(q/u);S(r*(1-Math.cos(K)),n-r+r*Math.sin(K),Math.cos(K),-Math.sin(K))}let N=0;v.forEach((q,K)=>{K>0&&(N+=Math.hypot(q.d-v[K-1].d,q.y-v[K-1].y)),q.v=N});let H=new ss,et=new ss,L=[new ss,new ss],F=M.map(q=>v.map(K=>H.vert([q.x+q.nx*K.d,K.y,q.z+q.nz*K.d],[q.nx*K.nd,K.ny,q.nz*K.nd],[q.s/8,K.v/8]))),X=M.length;for(let q=0;q<X;q++){let K=(q+1)%X,Q=M[q],_t=M[K],P=Q.end!==0&&Q.end===_t.end&&Math.abs(Q.x)<=o+h&&Math.abs(_t.x)<=o+h,st=K===0;for(let k=0;k<v.length-1;k++){if(P&&Math.max(v[k].y,v[k+1].y)<=l+h)continue;let J=F[q][k],V=F[q][k+1],xt=F[K][k],ht=F[K][k+1];if(st){let w=(b,O,it)=>H.vert([b.x+b.nx*O.d,O.y,b.z+b.nz*O.d],[b.nx*O.nd,O.ny,b.nz*O.nd],[it,O.v/8]);xt=w(_t,v[k],U/8),ht=w(_t,v[k+1],U/8)}H.quad(J,xt,ht,V)}}let nt=(q,K,Q,_t,P)=>{let st=q.vert([0,K,0],[0,Q,0],P(0,0)),k=M.map(J=>{let V=J.x+J.nx*_t,xt=J.z+J.nz*_t;return q.vert([V,K,xt],[0,Q,0],P(V,xt))});for(let J=0;J<k.length;J++)q.tri(st,k[J],k[(J+1)%k.length])};nt(et,0,1,i,(q,K)=>[(q+t)/(2*t),(K+e)/(2*e)]),nt(H,n,-1,r,(q,K)=>[q/8+40,K/8+40]);let Z=(q,K,Q,_t)=>q.vert(K,Q,_t),$=[...new Set(M.filter(q=>q.end!==0&&Math.abs(q.x)<=o+h).map(q=>+q.x.toFixed(4)))].sort((q,K)=>q-K);for(let q=0;q<2;q++){let K=q===0?-1:1,Q=L[q],_t=K*e,P=K*(e+c),st=K*(e-i);for(let J=0;J<$.length-1;J++){let V=$[J],xt=$[J+1],ht=[Z(Q,[V,0,st],[0,1,0],[0,0]),Z(Q,[xt,0,st],[0,1,0],[1,0]),Z(Q,[xt,0,P],[0,1,0],[1,1]),Z(Q,[V,0,P],[0,1,0],[0,1])];Q.quad(ht[0],ht[1],ht[2],ht[3]),ht=[Z(Q,[V,l,_t],[0,-1,0],[0,0]),Z(Q,[xt,l,_t],[0,-1,0],[1,0]),Z(Q,[xt,l,P],[0,-1,0],[1,1]),Z(Q,[V,l,P],[0,-1,0],[0,1])],Q.quad(ht[0],ht[1],ht[2],ht[3])}let k;k=[Z(Q,[-o,0,P],[0,0,-K],[0,0]),Z(Q,[o,0,P],[0,0,-K],[1,0]),Z(Q,[o,l,P],[0,0,-K],[1,1]),Z(Q,[-o,l,P],[0,0,-K],[0,1])],Q.quad(k[0],k[1],k[2],k[3]);for(let J of[-1,1]){let V=J*o;k=[Z(Q,[V,0,_t],[-J,0,0],[0,0]),Z(Q,[V,0,P],[-J,0,0],[1,0]),Z(Q,[V,l,P],[-J,0,0],[1,1]),Z(Q,[V,l,_t],[-J,0,0],[0,1])],Q.quad(k[0],k[1],k[2],k[3]);for(let xt=0;xt<u;xt++){let ht=v[xt],w=v[xt+1],b=K*(e-ht.d),O=K*(e-w.d),it=[Z(Q,[V,0,b],[-J,0,0],[0,0]),Z(Q,[V,ht.y,b],[-J,0,0],[0,1]),Z(Q,[V,w.y,O],[-J,0,0],[1,1]),Z(Q,[V,0,O],[-J,0,0],[1,0])];Q.quad(it[0],it[1],it[2],it[3])}}}let D={floor:et.finish(),shell:H.finish(),goalBlue:L[0].finish(),goalOrange:L[1].finish()},j=(q,K,Q)=>`${Math.round(q*1e4)},${Math.round(K*1e4)},${Math.round(Q*1e4)}`,ct=new Map,B=[],tt=[];for(let q of Object.values(D)){let K=new Uint32Array(q.positions.length/3);for(let Q=0;Q<K.length;Q++){let _t=q.positions[Q*3],P=q.positions[Q*3+1],st=q.positions[Q*3+2],k=j(_t,P,st),J=ct.get(k);J===void 0&&(J=B.length/3,B.push(_t,P,st),ct.set(k,J)),K[Q]=J}for(let Q=0;Q<q.indices.length;Q+=3){let _t=K[q.indices[Q]],P=K[q.indices[Q+1]],st=K[q.indices[Q+2]];_t!==P&&P!==st&&_t!==st&&tt.push(_t,P,st)}}let ut={positions:new Float32Array(B),indices:new Uint32Array(tt)},bt=s.postRadius,pt=[];for(let q of[-1,1]){for(let K of[-1,1])pt.push({kind:"post",x:K*(o+bt),y:l/2,z:q*e,halfHeight:l/2+bt,radius:bt});pt.push({kind:"bar",x:0,y:l+bt,z:q*e,halfLength:o+2*bt,radius:bt})}return{groups:D,collider:ut,frame:pt,dims:{W:t,L:e,H:n,GW:o,Hg:l,Dg:c,Rf:i,Rc:r,Rk:a},boostPads:b0(),kickoff:S0()}}import ii from"./rapier.js";var Ie={ARENA:1,CAR:2,BALL:4},Hs=(s,t)=>(s<<16|t)>>>0,oa=class s{static async create(t){return await ii.init(),new s(t)}constructor(t){this.R=ii,this.world=new ii.World({x:0,y:-gt.sim.gravity,z:0}),this.world.timestep=1/gt.sim.hz,this.world.numSolverIterations=gt.sim.solverIterations,this.events=new ii.EventQueue(!0),this.rayArena=Hs(Ie.ARENA|Ie.CAR|Ie.BALL,Ie.ARENA),this.buildArena(t)}buildArena(t){let e=ii,n=gt.arena,i=this.world.createRigidBody(e.RigidBodyDesc.fixed()),r=e.ColliderDesc.trimesh(t.collider.positions,t.collider.indices).setFriction(n.friction).setRestitution(n.restitution).setFrictionCombineRule(e.CoefficientCombineRule.Multiply).setRestitutionCombineRule(e.CoefficientCombineRule.Multiply).setCollisionGroups(Hs(Ie.ARENA,Ie.CAR|Ie.BALL));this.arenaCollider=this.world.createCollider(r,i);for(let a of t.frame){let o;a.kind==="post"?o=e.ColliderDesc.cylinder(a.halfHeight,a.radius).setTranslation(a.x,a.y,a.z):o=e.ColliderDesc.cylinder(a.halfLength,a.radius).setTranslation(a.x,a.y,a.z).setRotation({x:0,y:0,z:Math.SQRT1_2,w:Math.SQRT1_2}),o.setFriction(n.friction).setRestitution(n.restitution).setFrictionCombineRule(e.CoefficientCombineRule.Multiply).setRestitutionCombineRule(e.CoefficientCombineRule.Multiply).setCollisionGroups(Hs(Ie.ARENA,Ie.CAR|Ie.BALL)),this.world.createCollider(o,i)}}createBall(t,e,n){let i=ii,r=gt.ball,a=this.world.createRigidBody(i.RigidBodyDesc.dynamic().setTranslation(t,e,n).setLinearDamping(r.linearDamping).setAngularDamping(r.angularDamping).setCcdEnabled(!0)),o=this.world.createCollider(i.ColliderDesc.ball(r.radius).setMass(r.mass).setRestitution(r.restitution).setFriction(r.friction).setFrictionCombineRule(i.CoefficientCombineRule.Multiply).setRestitutionCombineRule(i.CoefficientCombineRule.Multiply).setCollisionGroups(Hs(Ie.BALL,Ie.ARENA|Ie.CAR)),a);return{body:a,collider:o}}createChassis(t,e,n,i){let r=ii,a=gt.car,o={x:0,y:Math.sin(i/2),z:0,w:Math.cos(i/2)},l=this.world.createRigidBody(r.RigidBodyDesc.dynamic().setTranslation(t,e,n).setRotation(o).setLinearDamping(0).setAngularDamping(0).setCcdEnabled(!0).setAdditionalMassProperties(a.mass,{x:0,y:a.comOffsetY,z:0},this.carInertia(),{x:0,y:0,z:0,w:1})),c=this.world.createCollider(r.ColliderDesc.cuboid(a.halfWidth,a.halfHeight,a.halfLength).setDensity(0).setFriction(a.colliderFriction).setRestitution(a.colliderRestitution).setFrictionCombineRule(r.CoefficientCombineRule.Multiply).setRestitutionCombineRule(r.CoefficientCombineRule.Min).setCollisionGroups(Hs(Ie.CAR,Ie.ARENA|Ie.BALL|Ie.CAR)).setActiveEvents(r.ActiveEvents.COLLISION_EVENTS),l);return l.recomputeMassPropertiesFromColliders(),{body:l,collider:c}}carInertia(){let t=gt.car,e=t.mass,n=t.halfWidth*2,i=t.halfHeight*2*1.6,r=t.halfLength*2;return{x:e/12*(i*i+r*r),y:e/12*(n*n+r*r),z:e/12*(n*n+i*i)}}step(){this.world.step(this.events)}rayArenaCast(t,e,n,i,r,a,o){let l=new ii.Ray({x:t,y:e,z:n},{x:i,y:r,z:a}),c=this.world.castRayAndGetNormal(l,o,!0,void 0,this.rayArena);return c?{toi:c.toi,nx:c.normal.x,ny:c.normal.y,nz:c.normal.z}:null}touchesArena(t){let e=!1;return this.world.contactPair(t,this.arenaCollider,n=>{n.numSolverContacts()>0&&(e=!0)}),e}};var lt=gt.car,Ih=gt.sim.gravity,E0=new C(0,1,0),Ze=(s,t,e)=>Math.max(t,Math.min(e,s)),rs=s=>s>0?1:s<0?-1:0,Dh=new Jt,as=new Jt,Nn=new C,dl=new C,an=new C,os=new C,Fn=new C;function _n(){return{throttle:0,steer:0,pitch:0,roll:0,jump:!1,boost:!1,handbrake:!1,airRoll:!1}}var ls=class{constructor(t,e){this.P=t,this.team=e.team,this.index=e.index||0,this.isHuman=!!e.isHuman,this.name=e.name||(this.isHuman?"You":"Bot");let n=t.createChassis(0,5,0,0);this.body=n.body,this.collider=n.collider,this.inertia=t.carInertia();let i=Ih+lt.stickyAccel;this.spring=lt.mass*i/4/lt.springEquilibrium,this.damper=2*lt.springDampingRatio*Math.sqrt(this.spring*lt.mass/4),this.restLen=lt.restHeight+lt.wheelAttachY+lt.springEquilibrium,this.rayLen=this.restLen+lt.suspensionDroop,this.wheels=[{x:-lt.wheelX,z:lt.wheelZFront,front:!0},{x:lt.wheelX,z:lt.wheelZFront,front:!0},{x:-lt.wheelX,z:lt.wheelZRear,front:!1},{x:lt.wheelX,z:lt.wheelZRear,front:!1}].map(r=>({...r,contact:!1,compression:0,spin:0,slip:0,steer:0,px:0,py:0,pz:0,nx:0,ny:1,nz:0,load:0})),this.ctrl=_n(),this.prevJump=!1,this.boost=lt.boostStart,this.unlimitedBoost=!1,this.demolished=!1,this.respawnTimer=0,this.spawn={x:0,y:lt.restHeight,z:0,yaw:0},this.resetState(),this.prevT=new C,this.currT=new C,this.prevQ=new Jt,this.currQ=new Jt,this.vel=new C,this.angVel=new C,this.prevVel=new C,this.speed=0,this.prevSpeed=0,this.forwardSpeed=0,this.up=new C(0,1,0),this.fwd=new C(0,0,-1),this.right=new C(1,0,0),this.surfaceNormal=new C(0,1,0),this.readState(),this.prevT.copy(this.currT),this.prevQ.copy(this.currQ)}resetState(){this.contacts=0,this.onGround=!1,this.bodyTouch=!1,this.airTime=0,this.hasJumped=!1,this.jumpTime=99,this.jumpHolding=!1,this.holdTime=0,this.hasDodged=!1,this.dodgeTime=99,this.flipActive=!1,this.dodgeAxis=new C,this.dodgeF=0,this.dodgeS=0,this.grip=1,this.boosting=!1,this.supersonic=!1,this.slipAmount=0,this.landedEvent=0,this.lastJumpEvent=0,this.dodgeEvent=0,this.boostSpent=0,this.prevJump=!1,this.handbrakeAmount=0}place(t){this.spawn=t;let e=this.body;e.setEnabled(!0),e.setTranslation({x:t.x,y:t.y??lt.restHeight,z:t.z},!0),e.setRotation({x:0,y:Math.sin(t.yaw/2),z:0,w:Math.cos(t.yaw/2)},!0),e.setLinvel({x:0,y:0,z:0},!0),e.setAngvel({x:0,y:0,z:0},!0),e.resetForces(!0),e.resetTorques(!0),this.resetState(),this.demolished=!1,this.readState(),this.prevT.copy(this.currT),this.prevQ.copy(this.currQ)}setControls(t){this.ctrl=t}readState(){let t=this.body,e=t.translation(),n=t.rotation(),i=t.linvel(),r=t.angvel();this.currT.set(e.x,e.y,e.z),this.currQ.set(n.x,n.y,n.z,n.w),this.vel.set(i.x,i.y,i.z),this.angVel.set(r.x,r.y,r.z),this.up.set(0,1,0).applyQuaternion(this.currQ),this.fwd.set(0,0,-1).applyQuaternion(this.currQ),this.right.set(1,0,0).applyQuaternion(this.currQ),this.speed=this.vel.length(),this.forwardSpeed=this.vel.dot(this.fwd),this.supersonic=ge(this.speed)>=ge(lt.supersonic)}snapshot(){this.prevT.copy(this.currT),this.prevQ.copy(this.currQ)}addBoost(t){this.boost=Math.min(lt.boostMax,this.boost+t)}preStep(t){if(this.demolished)return;this.readState();let e=this.body,n=lt.mass,i=this.ctrl;this.prevSpeed=this.speed,this.prevVel.copy(this.vel);let r=this.currQ;as.copy(r).invert();let a=e.worldCom(),o=a.x,l=a.y,c=a.z,h=this.up,u=this.fwd,d=0;this.surfaceNormal.set(0,0,0);for(let D of this.wheels){an.set(D.x,lt.wheelAttachY,D.z).applyQuaternion(r);let j=this.currT.x+an.x,ct=this.currT.y+an.y,B=this.currT.z+an.z;D.ax=j,D.ay=ct,D.az=B;let tt=this.P.rayArenaCast(j,ct,B,-h.x,-h.y,-h.z,this.rayLen);if(tt){D.contact=!0,D.dist=tt.toi,D.px=j-h.x*tt.toi,D.py=ct-h.y*tt.toi,D.pz=B-h.z*tt.toi;let ut=tt.nx,bt=tt.ny,pt=tt.nz;ut*h.x+bt*h.y+pt*h.z<0&&(ut=-ut,bt=-bt,pt=-pt),D.nx=ut,D.ny=bt,D.nz=pt,this.surfaceNormal.x+=ut,this.surfaceNormal.y+=bt,this.surfaceNormal.z+=pt,d++}else D.contact=!1,D.dist=this.rayLen;D.compression=Ze(1-(D.dist-0)/this.rayLen,0,1)}this.contacts=d;let f=this.jumpTime<.12;d>0?this.surfaceNormal.normalize():this.surfaceNormal.copy(h);let g=this.surfaceNormal;this.bodyTouch=d===0&&this.P.touchesArena(this.collider),this.landedEvent=0,(d>0||this.bodyTouch)&&!f&&!(this.hasDodged&&this.dodgeTime<.25)?((this.airTime>.15||this.hasJumped||this.hasDodged)&&(this.landedEvent=Math.min(1,this.airTime/.6)),this.airTime=0,this.hasJumped=!1,this.hasDodged=!1,d>0&&(this.flipActive=!1)):d===0&&!this.bodyTouch&&(this.airTime+=t),this.onGround=d>0,this.jumpTime+=t,this.hasDodged&&(this.dodgeTime+=t);let y=i.jump&&!this.prevJump;this.prevJump=i.jump,this.lastJumpEvent=0,this.dodgeEvent=0;let m=Ze(i.pitch,-1,1),p=Ze(i.steer,-1,1);if(y)if(d>0&&!this.hasJumped&&!this.demolished){let D=h;this.applyLinear(D.x*lt.jumpImpulse,D.y*lt.jumpImpulse,D.z*lt.jumpImpulse),this.hasJumped=!0,this.jumpTime=0,this.jumpHolding=!0,this.holdTime=0,this.lastJumpEvent=1,this.airTime=0}else!this.hasDodged&&d===0&&(this.hasJumped&&this.jumpTime<=lt.dodgeWindow||!this.hasJumped&&this.airTime<=lt.fallOffJumpWindow||this.bodyTouch&&!this.hasJumped)&&this.doDodge(m,p);this.jumpHolding&&(this.holdTime+=t,!i.jump||this.holdTime>lt.jumpHoldTime||this.hasDodged?this.jumpHolding=!1:this.applyLinear(h.x*lt.jumpHoldAccel*t,h.y*lt.jumpHoldAccel*t,h.z*lt.jumpHoldAccel*t));let x=this.spring,_=this.damper,M=!f||this.jumpTime>.04;for(let D of this.wheels){if(D.load=0,!D.contact||!M)continue;let j=this.restLen-D.dist;if(j<=0)continue;an.set(D.ax-o,D.ay-l,D.az-c),os.copy(this.angVel).cross(an).add(this.vel);let ct=os.x*D.nx+os.y*D.ny+os.z*D.nz,B=x*j-_*ct;j>lt.bumpStopStart&&(B+=x*lt.bumpStopStiffness*(j-lt.bumpStopStart)),B<0&&(B=0),D.load=B,e.applyImpulseAtPoint({x:D.nx*B*t,y:D.ny*B*t,z:D.nz*B*t},{x:D.ax,y:D.ay,z:D.az},!0)}let T=d>0&&this.jumpTime>.2?lt.stickyAccel*n*(d/4)*t:0;T&&this.applyLinear(-g.x*T/n,-g.y*T/n,-g.z*T/n);let E=Fn.copy(u).addScaledVector(g,-u.dot(g));E.lengthSq()<1e-6?E.copy(u):E.normalize();let R=this.vel.dot(E),U=ge(Math.abs(R)),v=d>=3?1:d/3,S=Ze(i.throttle,-1,1);if(d>0&&!f){let D=0;if(Math.abs(S)<.02)Math.abs(R)>.001&&(D=-rs(R)*Math.min(lt.coastAccel,Math.abs(R)/t));else if(rs(S)===rs(R)||Math.abs(R)<.05){let j=Math.max(0,1-U/ge(lt.maxDriveSpeed));D=S*lt.throttleAccel0*j}else D=S*Math.min(lt.brakeAccel,Math.abs(R)/t/Math.max(Math.abs(S),.01)*1),D=rs(S)*Math.min(lt.brakeAccel*Math.abs(S),Math.abs(R)/t+lt.throttleAccel0*0);D*=v,D!==0&&this.applyLinear(E.x*D*t,E.y*D*t,E.z*D*t)}let N=i.handbrake&&d>0,H=N?lt.powerslideGrip:1,et=N?1/.04:1/lt.gripRecoveryTime;this.grip+=Ze(H-this.grip,-et*t,et*t);let F=aa(lt.steerAngles,U)*Math.PI/180*Ze(i.steer,-1,1),X=0,nt=0;if(d>0&&!f)for(let D of this.wheels){if(!D.contact)continue;let j=an.set(D.nx,D.ny,D.nz),ct=os.copy(u).addScaledVector(j,-u.dot(j));if(ct.lengthSq()<1e-6)continue;ct.normalize(),D.front&&(Dh.setFromAxisAngle(j,-F),ct.applyQuaternion(Dh)),D.steer=D.front?F:0;let B=dl.copy(ct).cross(j).normalize(),tt=D.px-o,ut=D.py-l,bt=D.pz-c;Nn.copy(this.angVel).cross(Fn.set(tt,ut,bt)).add(this.vel);let pt=Nn.dot(B),q=Nn.dot(ct);D.spin+=q/lt.wheelRadius*t,D.slip=pt,X+=Math.abs(pt),nt++;let Q=((o-D.px)*D.nx+(l-D.py)*D.ny+(c-D.pz)*D.nz)*(1-lt.rollInfluence),_t=D.px+D.nx*Q,P=D.py+D.ny*Q,st=D.pz+D.nz*Q;Fn.set(_t-o,P-l,st-c).cross(B).applyQuaternion(as);let k=Fn.x*Fn.x/this.inertia.x+Fn.y*Fn.y/this.inertia.y+Fn.z*Fn.z/this.inertia.z,J=1/(1/n+k),V=-pt*J*lt.lateralGrip*.32*this.grip,xt=D.load+T/t/4||n*Ih/4,ht=lt.frictionCoeff*xt*t*Math.max(this.grip,.02);V=Ze(V,-ht,ht),e.applyImpulseAtPoint({x:B.x*V,y:B.y*V,z:B.z*V},{x:_t,y:P,z:st},!0)}else for(let D of this.wheels)D.spin+=this.forwardSpeed/lt.wheelRadius*t*.98,D.steer=0,D.slip=0;if(this.slipAmount=nt?X/nt:0,N&&Math.abs(i.steer)>.05&&!f){let D=Ze(Math.abs(R)/4,0,1),j=-Ze(i.steer,-1,1)*lt.powerslideYawRate*D*(R>=0?1:-1),ct=this.angVel.dot(g),B=Ze(j-ct,-lt.powerslideYawAccel*t,lt.powerslideYawAccel*t),tt=this.inertia.y;e.applyTorqueImpulse({x:g.x*tt*B,y:g.y*tt*B,z:g.z*tt*B},!0)}if(this.boosting=!1,i.boost&&(this.boost>0||this.unlimitedBoost)&&!this.demolished){this.boosting=!0;let D=d>0?lt.boostAccelGround:lt.boostAccelAir;Nn.copy(this.vel).addScaledVector(u,D*t);let j=lt.maxSpeed,ct=Nn.length();ct>j&&ct>this.speed&&Nn.multiplyScalar(Math.max(j,this.speed)/ct),this.applyLinear(Nn.x-this.vel.x,Nn.y-this.vel.y,Nn.z-this.vel.z),this.unlimitedBoost||(this.boost=Math.max(0,this.boost-lt.boostPerSecond*t),this.boostSpent+=lt.boostPerSecond*t)}if(d<=2&&!(d>0&&!this.hasJumped&&d>=2&&!1)){if(Math.abs(S)>.02&&d===0){let D=lt.airThrottleAccel*S*t;this.applyLinear(u.x*D,u.y*D,u.z*D)}this.airControl(t,m,p)}else this.clampAngular(t);this.vel.copy(e.linvel());let $=this.vel.length();if($>lt.maxSpeed){let D=lt.maxSpeed/$-1;this.applyLinear(this.vel.x*D,this.vel.y*D,this.vel.z*D)}}applyLinear(t,e,n){let i=lt.mass;this.body.applyImpulse({x:t*i,y:e*i,z:n*i},!0)}applyAngularDeltaLocal(t,e,n){an.set(this.inertia.x*t,this.inertia.y*e,this.inertia.z*n).applyQuaternion(this.currQ),this.body.applyTorqueImpulse({x:an.x,y:an.y,z:an.z},!0)}clampAngular(t){as.copy(this.currQ).invert();let e=dl.copy(this.body.angvel()).applyQuaternion(as),n=e.length();if(n>lt.maxAngularSpeed){let i=lt.maxAngularSpeed/n-1;this.applyAngularDeltaLocal(e.x*i,e.y*i,e.z*i)}}airControl(t,e,n){let i=this.ctrl;as.copy(this.currQ).invert();let r=dl.copy(this.body.angvel()).applyQuaternion(as),a=e,o=n,l=Ze(i.roll,-1,1);i.airRoll&&(l=Ze(l+n,-1,1),o=0);let c=0,h=0,u=0;if(this.flipActive&&(this.dodgeTime=this.dodgeTime,this.dodgeTime>lt.flipTime?this.flipActive=!1:this.dodgeF!==0&&e*this.dodgeF<-lt.flipCancelThreshold&&(this.flipActive=!1)),this.flipActive){if(c+=this.dodgeAxis.x*lt.flipTorqueAccel*t,u+=this.dodgeAxis.z*lt.flipTorqueAccel*t,this.dodgeTime<lt.flipVerticalDampTime){let m=this.body.linvel().y;this.applyLinear(0,-m*lt.flipVerticalDamp*(t/lt.flipVerticalDampTime),0)}this.dodgeAxis.x!==0&&(a=0),this.dodgeAxis.z!==0&&(l=0)}c+=(-a*lt.airPitchAccel-lt.airPitchDamp*r.x*(1-Math.abs(a)))*t,h+=(-o*lt.airYawAccel-lt.airYawDamp*r.y*(1-Math.abs(o)))*t,u+=(-l*lt.airRollAccel-lt.airRollDamp*r.z*(1-Math.abs(l)))*t,this.flipActive&&(this.dodgeAxis.x!==0&&(c=this.dodgeAxis.x*lt.flipTorqueAccel*t),this.dodgeAxis.z!==0&&(u=this.dodgeAxis.z*lt.flipTorqueAccel*t));let d=r.x+c,f=r.y+h,g=r.z+u,y=Math.hypot(d,f,g);if(y>lt.maxAngularSpeed){let m=lt.maxAngularSpeed/y;c=d*m-r.x,h=f*m-r.y,u=g*m-r.z}this.applyAngularDeltaLocal(c,h,u)}doDodge(t,e){let n=Math.hypot(t,e);this.hasDodged=!0,this.dodgeTime=0,this.jumpHolding=!1,this.dodgeEvent=1;let i=this.up;if(n<(this.dodgeDeadzone??lt.dodgeDeadzone)){i.y<-.2&&this.bodyTouch?(this.applyLinear(0,lt.jumpImpulse,0),this.flipActive=!0,this.dodgeAxis.set(0,0,-1),this.dodgeF=0,this.dodgeS=1):this.applyLinear(i.x*lt.jumpImpulse,i.y*lt.jumpImpulse,i.z*lt.jumpImpulse);return}let r=t/n,a=e/n;i.y<-.2&&this.bodyTouch&&this.applyLinear(0,lt.jumpImpulse,0),this.dodgeF=r,this.dodgeS=a;let o=an.copy(this.fwd).setY(0);o.lengthSq()<.04&&o.copy(this.up).multiplyScalar(-1).setY(0),o.lengthSq()<1e-6&&o.set(0,0,-1),o.normalize();let l=os.copy(o).cross(E0).normalize(),c=this.vel.dot(this.fwd),h=Ze(this.speed/lt.maxSpeed,0,1),u=r!==0&&rs(r)===rs(c)&&Math.abs(c)>1?1+lt.dodgeSpeedBonus*h:1,d=r*lt.dodgeImpulse*u,f=a*lt.dodgeImpulse;this.applyLinear(o.x*d+l.x*f,o.y*d+l.y*f,o.z*d+l.z*f),this.dodgeAxis.set(-r,0,-a),this.flipActive=!0}demolish(){this.demolished=!0,this.respawnTimer=lt.demoRespawn,this.body.setLinvel({x:0,y:0,z:0},!0),this.body.setAngvel({x:0,y:0,z:0},!0),this.body.setEnabled(!1)}postStep(){this.readState()}};var fl="rl3d.settings.v1",On=(s,t,e)=>Math.max(t,Math.min(e,s)),la=class{constructor(t){this.keys=new Set,this.bindings=JSON.parse(JSON.stringify(gt.input.bindings)),this.settings={stickDeadzone:gt.input.stickDeadzone,triggerDeadzone:gt.input.triggerDeadzone,steerSensitivity:gt.input.steerSensitivity,dodgeDeadzone:gt.input.dodgeDeadzone,mouseSensitivity:gt.input.mouseSensitivity,ballCamDefault:!0},this.ballCam=!0,this.look={x:0,y:0},this.mouseLook={x:0,y:0},this.pointerLocked=!1,this.edges={ballCam:!1,pause:!1,reset:!1,any:!1},this.prevEdge={ballCam:!1,pause:!1,reset:!1,padPause:!1,padBall:!1},this.capturing=null,this.enabled=!0,this.pad=null,this.padActive=!1,this.target=t,this.load(),this.bind()}load(){try{let t=JSON.parse(localStorage.getItem(fl)||"null");if(t){if(t.bindings)for(let e of Object.keys(this.bindings))Array.isArray(t.bindings[e])&&(this.bindings[e]=t.bindings[e]);t.input&&Object.assign(this.settings,t.input)}}catch{}this.ballCam=this.settings.ballCamDefault!==!1}bind(){let t=e=>e.target&&/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName);window.addEventListener("keydown",e=>{if(this.capturing){if(e.preventDefault(),e.code!=="Escape"){let n=this.capturing;this.capturing=null,n(e.code)}else{let n=this.capturing;this.capturing=null,n(null)}return}t(e)||(this.isBound(e.code)&&e.preventDefault(),!e.repeat&&(this.keys.add(e.code),this.edges.any=!0,this.bindings.jump.includes(e.code)&&(this.jumpLatch=!0)))}),window.addEventListener("keyup",e=>{this.keys.delete(e.code)}),window.addEventListener("blur",()=>{this.keys.clear(),this.mouseLook.x=this.mouseLook.y=0}),document.addEventListener("visibilitychange",()=>{document.hidden&&this.keys.clear()}),window.addEventListener("contextmenu",e=>{this.enabled&&e.preventDefault()}),document.addEventListener("pointerlockchange",()=>{this.pointerLocked=document.pointerLockElement===this.target}),window.addEventListener("mousemove",e=>{if(!this.pointerLocked)return;let n=this.settings.mouseSensitivity;this.mouseLook.x=On(this.mouseLook.x+e.movementX*n,-1.2,1.2),this.mouseLook.y=On(this.mouseLook.y+e.movementY*n,-1.2,1.2)})}isBound(t){return Object.values(this.bindings).some(e=>e.includes(t))}down(t){return this.bindings[t].some(e=>this.keys.has(e))}save(){try{localStorage.setItem(fl,JSON.stringify({bindings:this.bindings,input:this.settings,ui:this.uiSettings||{}}))}catch{}}loadUi(){try{return(JSON.parse(localStorage.getItem(fl)||"null")||{}).ui||{}}catch{return{}}}rebind(t,e){this.bindings[t]=[e],this.save()}resetBindings(){this.bindings=JSON.parse(JSON.stringify(gt.input.bindings)),this.save()}captureNext(t){this.capturing=t,this.keys.clear()}requestPointerLock(){if(this.enabled&&this.target.requestPointerLock&&!this.pointerLocked)try{let t=this.target.requestPointerLock();t&&t.catch&&t.catch(()=>{})}catch{}}releasePointerLock(){document.pointerLockElement&&document.exitPointerLock()}radial(t,e,n){let i=Math.hypot(t,e);if(i<n)return[0,0];let r=(i-n)/(1-n)/i;return[On(t*r,-1,1),On(e*r,-1,1)]}pollPad(){let t=navigator.getGamepads?navigator.getGamepads():[];this.pad=null;for(let e of t)if(e&&e.connected){this.pad=e;break}}get(t){let e=_n(),n=this.settings;this.pollPad();let i=(this.down("throttle")?1:0)-(this.down("brake")?1:0),r=(this.down("right")?1:0)-(this.down("left")?1:0);e.throttle=i,e.pitch=i,e.steer=r,e.roll=(this.down("rollRight")?1:0)-(this.down("rollLeft")?1:0),e.jump=this.down("jump")||this.jumpLatch,this.jumpLatch=!1,e.boost=this.down("boost");let a=this.down("powerslide");e.handbrake=a,e.airRoll=a;let o=(this.down("lookRight")?1:0)-(this.down("lookLeft")?1:0),l=(this.down("lookDown")?1:0)-(this.down("lookUp")?1:0),c=!1,h=!1;if(this.pad){let g=this.pad,y=v=>g.buttons[v]?g.buttons[v].value:0,m=v=>!!(g.buttons[v]&&g.buttons[v].pressed),[p,x]=this.radial(g.axes[0]||0,g.axes[1]||0,n.stickDeadzone),[_,M]=this.radial(g.axes[2]||0,g.axes[3]||0,n.stickDeadzone),T=n.triggerDeadzone,E=y(7)>T?y(7):0,R=y(6)>T?y(6):0;(Math.abs(p)+Math.abs(x)+E+R+Math.abs(_)+Math.abs(M)>0||m(0)||m(1)||m(2)||m(4)||m(5))&&(this.padActive=!0,(E||R)&&(e.throttle=E-R),(x!==0||i===0)&&(e.pitch=i!==0?e.pitch:-x),p!==0&&(e.steer=On(p*n.steerSensitivity,-1,1)),m(0)&&(e.jump=!0),m(1)&&(e.boost=!0),m(2)&&(e.handbrake=!0,e.airRoll=!0),m(4)&&(e.roll-=1),m(5)&&(e.roll+=1),Math.abs(_)>0&&(o=_),Math.abs(M)>0&&(l=M)),c=m(3),h=m(9)}e.steer=On(e.steer*(e.steer===r&&r!==0,1),-1,1),e.roll=On(e.roll,-1,1),this.mouseLook.x*=Math.exp(-t*3.2),this.mouseLook.y*=Math.exp(-t*3.2),this.look.x=On(o+this.mouseLook.x,-1,1),this.look.y=On(l+this.mouseLook.y,-1,1);let u=this.down("ballCam")||c,d=this.down("pause")||h,f=this.down("reset");return this.edges.ballCam=u&&!this.prevEdge.ballCam,this.edges.pause=d&&!this.prevEdge.pause,this.edges.reset=f&&!this.prevEdge.reset,this.prevEdge.ballCam=u,this.prevEdge.pause=d,this.prevEdge.reset=f,this.edges.ballCam&&(this.ballCam=!this.ballCam),e}neutral(){return _n()}};function Uh(s){return s?s.replace(/^Key/,"").replace(/^Digit/,"").replace("Arrow","").replace("Left",s.startsWith("Arrow")?"\u2190":" L").replace("Right",s.startsWith("Arrow")?"\u2192":" R").replace("Up","\u2191").replace("Down","\u2193").replace("Control","Ctrl").replace("Space","Space"):"\u2014"}var on=gt.ball,zn=gt.car,X0=new Jt,ca=new Jt,q0=new C,xn=new C,bi=new C,Nh=new C,cs=new C,ha=new C,si=new C,ua=new C,pl=(s,t,e)=>Math.max(t,Math.min(e,s)),da=class s{constructor(t){this.P=t;let e=t.createBall(0,on.radius+.01,0);this.body=e.body,this.collider=e.collider,this.radius=on.radius,this.pos=new C,this.vel=new C,this.angVel=new C,this.quat=new Jt,this.prevPos=new C,this.prevQuat=new Jt,this.pending=[],this.hitEvents=[],this.lastHitCar=null,this.lastTouchTeam=-1,this.cool=new Map,this.readState(),this.prevPos.copy(this.pos),this.prevQuat.copy(this.quat)}reset(t,e,n,i=0,r=0,a=0){let o=this.body;o.setTranslation({x:t,y:e,z:n},!0),o.setRotation({x:0,y:0,z:0,w:1},!0),o.setLinvel({x:i,y:r,z:a},!0),o.setAngvel({x:0,y:0,z:0},!0),o.resetForces(!0),o.resetTorques(!0),this.lastHitCar=null,this.lastTouchTeam=-1,this.pending.length=0,this.cool.clear(),this.readState(),this.prevPos.copy(this.pos),this.prevQuat.copy(this.quat)}readState(){let t=this.body.translation(),e=this.body.rotation(),n=this.body.linvel(),i=this.body.angvel();this.pos.set(t.x,t.y,t.z),this.quat.set(e.x,e.y,e.z,e.w),this.vel.set(n.x,n.y,n.z),this.angVel.set(i.x,i.y,i.z)}snapshot(){this.prevPos.copy(this.pos),this.prevQuat.copy(this.quat)}static closest(t,e,n,i){ca.copy(t.currQ).invert(),i.copy(e).sub(t.currT).applyQuaternion(ca),n.set(pl(i.x,-zn.halfWidth,zn.halfWidth),pl(i.y,-zn.halfHeight,zn.halfHeight),pl(i.z,-zn.halfLength,zn.halfLength));let r=Math.abs(i.x)<zn.halfWidth&&Math.abs(i.y)<zn.halfHeight&&Math.abs(i.z)<zn.halfLength;Nh.copy(i).sub(n);let a=Nh.length();return r&&(a=0),n.applyQuaternion(t.currQ).add(t.currT),a}beginStep(t,e){this.readState();for(let n of t){if(n.demolished)continue;let i=s.closest(n,this.pos,bi,xn);ua.copy(bi).sub(n.currT),ha.copy(n.angVel).cross(ua).add(n.vel),cs.copy(this.vel).sub(ha),si.copy(this.pos).sub(bi);let r=si.length();if(r<1e-6)continue;si.multiplyScalar(1/r);let a=-cs.dot(si),o=i-this.radius;if(a>.3&&o<a*e*2.5+.03){let l=this.pending.find(c=>c.car===n);l?a>l.closing&&(l.closing=a,l.relSpeed=cs.length()):this.pending.push({car:n,relSpeed:cs.length(),closing:a,age:0})}}}endStep(t,e,n){this.readState(),this.hitEvents.length=0;for(let l=this.pending.length-1;l>=0;l--){let c=this.pending[l],h=c.car;if(c.age++,h.demolished||c.age>4){this.pending.splice(l,1);continue}h.readState();let u=s.closest(h,this.pos,bi,xn);ua.copy(bi).sub(h.currT),ha.copy(h.angVel).cross(ua).add(h.vel),cs.copy(this.vel).sub(ha),si.copy(this.pos).sub(bi);let d=si.length();if(d<1e-6)continue;si.multiplyScalar(1/d);let f=-cs.dot(si);if(!(u-this.radius<.08&&f<Math.max(.35*c.closing,.5)))continue;this.pending.splice(l,1);let y=this.cool.get(h)??-1;if(n-y<on.hitCooldown||(xn.copy(this.pos).sub(h.currT),ca.copy(h.currQ).invert(),xn.applyQuaternion(ca),xn.y*=on.hitVerticalScale,xn.lengthSq()<1e-8))continue;xn.normalize().applyQuaternion(h.currQ);let m=c.relSpeed,p=m*aa(on.hitCurve,ge(m));this.body.applyImpulse({x:xn.x*p*on.mass,y:xn.y*p*on.mass,z:xn.z*p*on.mass},!0),this.cool.set(h,n),this.lastHitCar=h,this.lastTouchTeam=h.team,this.hitEvents.push({car:h,power:m,point:bi.clone(),normal:xn.clone()})}let i=this.body.linvel(),r=Math.hypot(i.x,i.y,i.z);if(r>on.maxSpeed){let l=on.maxSpeed/r;this.body.setLinvel({x:i.x*l,y:i.y*l,z:i.z*l},!0)}let a=this.body.angvel(),o=Math.hypot(a.x,a.y,a.z);if(o>on.maxAngularSpeed){let l=on.maxAngularSpeed/o;this.body.setAngvel({x:a.x*l,y:a.y*l,z:a.z*l},!0)}this.readState()}};var fa=class{constructor(t){let e=gt.boost;this.pads=t.map((n,i)=>({id:i,x:n.x,z:n.z,large:n.large,radius:n.large?e.largeRadius:e.smallRadius,amount:n.large?e.largeAmount:e.smallAmount,respawn:n.large?e.largeRespawn:e.smallRespawn,active:!0,timer:0,pickedAt:-99})),this.events=[]}reset(){for(let t of this.pads)t.active=!0,t.timer=0;this.events.length=0}update(t,e,n){this.events.length=0;for(let i of this.pads){if(!i.active){i.timer-=t,i.timer<=0&&(i.active=!0,this.events.push({pad:i,car:null,respawned:!0}));continue}for(let r of e){if(r.demolished||r.boost>=gt.car.boostMax)continue;let a=r.currT;if(a.y>gt.boost.pickupHeight)continue;let o=a.x-i.x,l=a.z-i.z;if(o*o+l*l<i.radius*i.radius){i.large?r.boost=gt.car.boostMax:r.addBoost(i.amount),i.active=!1,i.timer=i.respawn,i.pickedAt=n,this.events.push({pad:i,car:r,respawned:!1});break}}}}};var ml=gt.car,Je=gt.arena,Si=gt.ball.radius,Mn=(s,t,e)=>Math.max(t,Math.min(e,s)),w0=s=>{for(;s>Math.PI;)s-=2*Math.PI;for(;s<-Math.PI;)s+=2*Math.PI;return s},Q0=new Jt,bn=new Jt,Ce=new C,ln=new C;function T0(s,t,e=1/30){let n=[],i=s.pos.x,r=s.pos.y,a=s.pos.z,o=s.vel.x,l=s.vel.y,c=s.vel.z,h=gt.sim.gravity,u=.6,d=Je.halfWidth-Si,f=Je.halfLength-Si,g=Je.height-Si;for(let y=0;y<t;y+=e){l-=h*e,i+=o*e,r+=l*e,a+=c*e,r<Si&&(r=Si,l<0&&(l=-l*u,Math.abs(l)<1.5&&(l=0)),o*=.995,c*=.995),r>g&&(r=g,l>0&&(l=-l*u)),i>d?(i=d,o>0&&(o=-o*u)):i<-d&&(i=-d,o<0&&(o=-o*u));let p=Math.abs(i)<Je.goalHalfWidth-Si*.3&&r<Je.goalHeight-Si*.5?f+Je.goalDepth:f;a>p?(a=p,c>0&&(c=-c*u)):a<-p&&(a=-p,c<0&&(c=-c*u)),n.push({t:y+e,x:i,y:r,z:a,vx:o,vy:l,vz:c})}return n}var pa=class{constructor(t,e="pro"){this.car=t,this.setDifficulty(e),this.ctrl=_n(),this.timer=0,this.plan=null,this.pred=[],this.predTimer=0,this.seq=null,this.noise=0,this.noiseT=0,this.mode="kickoff",this.target=new C,this.wantBoost=!1,this.stuckT=0,this.reactT=0,this.padTarget=null}setDifficulty(t){this.diff=gt.ai.difficulties[t]||gt.ai.difficulties.pro,this.diffName=t}update(t,e){let n=this.car,i=e.ball,r=this.ctrl;r.throttle=0,r.steer=0,r.pitch=0,r.roll=0,r.boost=!1,r.handbrake=!1,r.airRoll=!1;let a=r.jump;if(r.jump=!1,n.demolished||!e.active)return this.seq=null,r;this.timer+=t,this.predTimer-=t,this.noiseT-=t,this.noiseT<=0&&(this.noise=(Math.random()*2-1)*this.diff.steerNoise,this.noiseT=.3+Math.random()*.5),this.predTimer<=0&&(this.pred=T0(i,this.diff.predictTime),this.predTimer=this.diff.reaction*.7+.05);let o=n.team===0?-1:1,l=o*Je.halfLength,c=-l,h=n.currT,u=i.pos,d=n.contacts>=2,f=Ce.copy(u).sub(h).length();if(this.seq&&(this.runSeq(t,r),this.seq))return r;if(!d&&n.contacts===0)return this.airLogic(t,r,e,l,c),r;let g=e.kickoff&&Math.hypot(i.vel.x,i.vel.z)<.3&&Math.abs(u.x)<.5&&Math.abs(u.z)<.5,y=e.cars.find(v=>v.team!==n.team&&!v.demolished),m=y?Ce.copy(u).sub(y.currT).length():99,p=u.z*o>0,x=null,_=this.diff.speedLimit*(n.boost>10?18:14);for(let v of this.pred){if(v.y>4.5)continue;if(Math.hypot(v.x-h.x,v.z-h.z)/_<v.t+.1){x=v;break}}let M=this.pred.some(v=>Math.abs(v.z)>Je.halfLength-.5&&Math.sign(v.z)===o&&Math.abs(v.x)<Je.goalHalfWidth),T=this.target,E=1,R=!1,U=!1;if(g)this.mode="kickoff",T.set(u.x,0,u.z),R=this.diff.boostUse>.3,U=!0;else if(M||p&&m<f*.8&&x){this.mode="save";let v=x||this.pred.find(N=>N.y<5)||{x:u.x,z:u.z,y:1},S=ln.set(v.x,0,v.z-c).normalize();T.set(v.x+(l-v.z)*0,0,v.z).addScaledVector(ln.set(0,0,o*1),.2),R=!0,U=!0}else if(x&&(!p||f<m)){this.mode="attack";let v=x,S=ln.set(0-v.x,0,c-v.z).normalize(),N=2.1,H=new C(v.x-S.x*N,0,v.z-S.z*N),et=Ce.set(v.x-h.x,0,v.z-h.z),L=et.lengthSq()>1e-4?et.normalize().dot(S)>.55:!0,F=Math.hypot(v.x-h.x,v.z-h.z);L||F<5?T.set(v.x,0,v.z):T.copy(H),T.x=Mn(T.x,-Je.halfWidth+1.5,Je.halfWidth-1.5),T.z=Mn(T.z,-Je.halfLength+1.5,Je.halfLength-1.5),R=!0,U=!0}else{let S=n.boost<60?this.nearestPad(e,h):null;if(S&&(!p||n.boost<25))this.mode="boost",T.set(S.x,0,S.z),R=!1;else{this.mode="defend";let N=l*.62+u.z*.38;T.set(Mn(u.x*.5,-6,6),0,N),E=.9}}return this.drive(t,r,T,E,R,U,e),this.tryTouch(t,r,e,U),Math.abs(n.forwardSpeed)<1&&r.throttle>.5&&n.contacts>0?this.stuckT+=t:Math.abs(n.forwardSpeed)>3&&(this.stuckT=0),this.stuckT>1&&(this.stuckT=0,this.seq={type:"reverse",t:0,s:Math.random()<.5?-1:1}),n.up.y<-.4&&n.contacts===0&&!n.hasDodged&&this.startDodge(0,1,!1,!0),r}nearestPad(t,e){let n=null,i=1e9,r=this.car.team===0?-1:1;for(let a of t.pads.pads){if(!a.active)continue;let o=Math.hypot(a.x-e.x,a.z-e.z)-(a.large?14:0)+(a.z*r<0?12:0);o<i&&(i=o,n=a)}return n}drive(t,e,n,i,r,a,o){let l=this.car;bn.copy(l.currQ).invert(),Ce.set(n.x-l.currT.x,n.y-l.currT.y,n.z-l.currT.z).applyQuaternion(bn);let c=Math.hypot(Ce.x,Ce.z),h=Math.atan2(Ce.x,-Ce.z),u=l.forwardSpeed;if(Math.abs(h)>2.2&&c<14&&u<7){e.throttle=-1,e.steer=Mn(-w0(h-Math.PI*Math.sign(h))*2+this.noise,-1,1)*-1;return}e.steer=Mn(h*2.4+this.noise,-1,1),e.throttle=i*(c<2.2&&Math.abs(u)>12?.3:1),Math.abs(h)>1.3&&u>14&&c>4&&(e.throttle=.2),this.diff.powerslide&&Math.abs(h)>.9&&u>9&&c>6&&(e.handbrake=!0);let f=r&&l.boost>3&&Math.abs(h)<.18&&c>14&&ge(u)<2150&&Math.random()<this.diff.boostUse+.1;e.boost=f,a&&this.diff.dodge&&l.onGround&&Math.abs(h)<.12&&c>26&&ge(u)>1e3&&ge(u)<2e3&&l.boost>5&&Math.random()<.01&&this.startDodge(1,0,!0)}tryTouch(t,e,n,i){let r=this.car,a=n.ball;if(!r.onGround)return;Ce.copy(a.pos).sub(r.currT);let o=Ce.length();bn.copy(r.currQ).invert(),ln.copy(Ce).applyQuaternion(bn);let l=Math.abs(r.forwardSpeed);if(!this.diff.dodge){o<3.4&&a.pos.y>1.6&&a.pos.y<3.3&&ln.z<0&&this.startJump();return}o<4.2&&o>1.8&&ln.z<-1&&Math.abs(ln.x)<1.2&&a.pos.y<2.6&&l>6&&i?this.startDodge(1,Mn(ln.x*.2,-.4,.4),!1):this.diff.aerial&&a.pos.y>3.2&&a.pos.y<12&&o<24&&r.boost>25&&ln.z<-2?this.seq={type:"aerial",t:0,target:a.pos.clone()}:o<3.6&&a.pos.y>1.9&&a.pos.y<4.5&&ln.z<0&&this.startJump()}startJump(){this.seq||(this.seq={type:"jump",t:0})}startDodge(t,e,n,i){this.seq||(this.seq={type:"dodge",t:0,f:t,s:e,speedflip:!!n,righting:!!i})}runSeq(t,e){let n=this.seq,i=this.car;if(n.t+=t,n.type==="reverse"){e.throttle=-1,e.steer=n.s,n.t>1.1&&(this.seq=null);return}if(n.type==="jump"){e.jump=n.t<.18,e.throttle=1,n.t>.4&&(this.seq=null);return}if(n.type==="dodge"){if(e.throttle=1,n.righting){e.jump=n.t>.05&&n.t<.2,e.pitch=0,e.steer=n.s||1,n.t>.7&&(this.seq=null);return}n.t<.06?e.jump=!0:n.t<.12?e.jump=!1:n.t<.2?(e.jump=!0,e.pitch=n.f,e.steer=n.s):(e.pitch=n.speedflip?-0:0,n.speedflip&&n.t<.55&&(e.pitch=-1,e.boost=!0),n.t>.2&&n.t<.5&&(e.boost=e.boost||n.speedflip),n.t>.9&&(this.seq=null)),n.speedflip&&n.t<.2&&(e.boost=!0);return}if(n.type==="aerial"){let r=n.target;if(n.t<.15){e.jump=!0;return}if(n.t<.22){e.jump=!1;return}if(n.t<.3){e.jump=!0,e.pitch=0;return}this.aim(e,Ce.copy(r).sub(i.currT).normalize(),null);let a=Ce.copy(r).sub(i.currT);e.boost=bn.copy(i.currQ)&&i.fwd.dot(a.clone().normalize())>.9&&i.boost>1,(n.t>2.4||i.contacts>0&&n.t>.5)&&(this.seq=null);return}}aim(t,e,n){let i=this.car;bn.copy(i.currQ).invert();let r=Ce.copy(e).applyQuaternion(bn),a=ln.copy(i.body.angvel()).applyQuaternion(bn),o=Math.atan2(r.y,-r.z),l=Math.atan2(-r.x,-r.z),c=0,h=(n?Ce.copy(n):Ce.set(0,1,0)).applyQuaternion(bn);c=Math.atan2(-h.x,h.y);let u=9*o-3.2*a.x,d=9*l-3.2*a.y,f=9*c-3.2*a.z;t.pitch=Mn(-u/ml.airPitchAccel,-1,1),t.steer=Mn(-d/ml.airYawAccel,-1,1),t.roll=Mn(-f/ml.airRollAccel,-1,1),t.airRoll=!1}airLogic(t,e,n,i,r){let a=this.car,o=n.ball;if(a.bodyTouch&&a.up.y<.5&&a.speed<12){this.startDodge(0,Math.random()<.5?1:-1,!1,!0);return}let l=Ce.copy(a.vel),c=ln.set(l.x,Math.max(l.y*.2,-3),l.z);c.lengthSq()<1&&c.copy(a.fwd).setY(0),c.normalize();let h=o.pos.distanceTo(a.currT);if(this.diff.aerial&&h<8&&o.pos.y>2.5&&c.copy(o.pos).sub(a.currT).normalize(),this.aim(e,c.clone(),null),e.throttle=0,c.dot(a.fwd)>.92&&h<14&&a.boost>5&&this.diff.aerial&&o.pos.y>3&&(e.boost=!0),this.diff.dodge&&!a.hasDodged&&h<4.2&&o.pos.y>2&&a.airTime<1.1&&a.airTime>.2){let u=Ce.copy(o.pos).sub(a.currT).applyQuaternion(bn.copy(a.currQ).invert());u.z<-.5&&(this.seq={type:"dodge",t:.1,f:1,s:Mn(u.x*.3,-.6,.6),speedflip:!1})}}};var gl=gt.arena,Bn=gt.match,hs=gt.ball.radius,ma=1/gt.sim.hz,ga=new C,Fh=new C,_a=class{constructor(){this.h={}}on(t,e){var n;((n=this.h)[t]||(n[t]=[])).push(e)}emit(t,e){let n=this.h[t];if(n)for(let i of n)i(e)}},xa=class{constructor(t,e,n,i){this.P=t,this.geo=e,this.input=n,this.bus=i,this.ball=new da(t),this.pads=new fa(e.boostPads),this.cars=[],this.bots=[],this.mode="menu",this.state="idle",this.paused=!1,this.scores=[0,0],this.timeLeft=Bn.duration,this.overtime=!1,this.overtimeTime=0,this.countdown=0,this.stateTime=0,this.simTime=0,this.acc=0,this.lastScorer=-1,this.lastGoalInfo=null,this.humanCtrl=_n(),this.unlimitedBoost=!1,this.preset="kickoff",this.record=[],this.maxRecord=Math.ceil(gt.sim.hz*(Bn.replayDuration+3)),this.replay=null,this.difficulty="pro",this.stats={shots:[0,0],saves:[0,0],demos:[0,0],touches:[0,0]},this.human=null,this.fps=60,this.ballPrevVel=new C,this.rBall={pos:new C,quat:new Jt}}clearCars(){for(let t of this.cars)this.P.world.removeRigidBody(t.body);this.cars=[],this.bots=[],this.human=null}startFreePlay(){this.clearCars(),this.mode="freeplay";let t=new ls(this.P,{team:0,isHuman:!0,name:"You"});this.cars.push(t),this.human=t,this.scores=[0,0],this.timeLeft=Bn.duration,this.overtime=!1,this.pads.reset(),this.setPreset("kickoff"),this.state="playing",this.stateTime=0,this.paused=!1,this.replay=null,this.record.length=0,this.bus.emit("matchStart",{mode:"freeplay"})}startVersus(t="pro"){this.clearCars(),this.mode="versus",this.difficulty=t;let e=new ls(this.P,{team:0,isHuman:!0,name:"You",index:0}),n=new ls(this.P,{team:1,isHuman:!1,name:"Bot",index:1});this.cars.push(e,n),this.human=e,this.bots=[new pa(n,t)],this.scores=[0,0],this.timeLeft=Bn.duration,this.overtime=!1,this.overtimeTime=0,this.stats={shots:[0,0],saves:[0,0],demos:[0,0],touches:[0,0]},this.pads.reset(),this.replay=null,this.record.length=0,this.paused=!1,this.kickoff(),this.bus.emit("matchStart",{mode:"versus"})}spawnFor(t,e=0){let n=this.geo.kickoff[e%this.geo.kickoff.length],i=t===0?1:-1;return{x:n.x*i,y:gt.car.restHeight,z:n.z*i,yaw:t===0?Math.PI:0}}kickoff(){this.cars.forEach(t=>{t.place(this.spawnFor(t.team,0)),t.boost=gt.car.boostStart,t.setControls(_n())});for(let t of this.bots)t.seq=null,t.stuckT=0;this.ball.reset(0,hs+.02,0),this.state="countdown",this.countdown=Bn.countdown,this.stateTime=0,this.lastGoalInfo=null,this.pads.reset(),this.bus.emit("kickoff",{}),this.lastCountInt=Math.ceil(this.countdown),this.bus.emit("count",{n:this.lastCountInt})}setPreset(t){this.preset=t;let e=this.human,n=this.ball,i=hs,r=(a,o,l,c=100)=>{e.place({x:a,y:gt.car.restHeight,z:o,yaw:l}),e.boost=c};switch(t){case"shot":r(-12,-30,Math.PI),n.reset(6,i+.02,-8);break;case"dribble":r(0,-38,Math.PI,60),n.reset(0,gt.car.restHeight+gt.car.halfHeight+i+.06,-38);break;case"aerial":r(0,-30,Math.PI),n.reset(2,11,6,0,8,6);break;case"wall":r(-8,-10,-Math.PI/2*0+Math.PI/2*0-Math.PI/2),n.reset(30,5,-6,4,9,10);break;case"defend":r(0,-44,Math.PI,100),n.reset(-6,6,18,2,4,-34);break;default:r(0,-46.08,Math.PI,gt.car.boostStart),n.reset(0,i+.02,0);break}e.unlimitedBoost=this.unlimitedBoost,this.pads.reset(),this.bus.emit("reset",{preset:t})}resetAll(){this.setPreset(this.preset)}resetBall(){this.ball.reset(0,hs+.02,0),this.bus.emit("reset",{})}launchBall(){if(!this.human)return;let e=this.human.currT.z<0?-1:1;this.ball.reset((Math.random()-.5)*20,6+Math.random()*4,-e*10,(Math.random()-.5)*16,6+Math.random()*6,e*(20+Math.random()*25))}toggleUnlimitedBoost(){return this.unlimitedBoost=!this.unlimitedBoost,this.human&&(this.human.unlimitedBoost=this.unlimitedBoost,this.human.boost=100),this.unlimitedBoost}frame(t){if(t=Math.min(t,.25),this.mode==="menu"||this.paused)return this.acc=0,this.updateRender(1);if(this.state==="replay")return this.stepReplay(t),1;this.acc+=t;let e=0;for(;this.acc>=ma&&e<gt.sim.maxCatchupSteps;)this.step(ma),this.acc-=ma,e++;return e===gt.sim.maxCatchupSteps&&(this.acc=0),this.updateRender(this.acc/ma)}updateRender(t){for(let e of this.cars)e.rPos||(e.rPos=new C),e.rQuat||(e.rQuat=new Jt),e.rPos.copy(e.prevT).lerp(e.currT,t),e.rQuat.copy(e.prevQ).slerp(e.currQ,t);return this.rBall.pos.copy(this.ball.prevPos).lerp(this.ball.pos,t),this.rBall.quat.copy(this.ball.prevQuat).slerp(this.ball.quat,t),t}step(t){let e=this.cars,n=this.ball;for(let r of e)r.snapshot();n.snapshot(),this.ballPrevVel.copy(n.vel);let i=this.state==="playing"||this.mode==="freeplay";for(let r of e)r.isHuman&&r.setControls(i?this.humanCtrl:_n());for(let r of this.bots){let a=r.update(t,{ball:n,cars:e,pads:this.pads,active:this.state==="playing",kickoff:this.stateTime<4&&this.lastTouchless()});r.car.setControls(this.state==="playing"?a:_n())}for(let r of e)r.demolished&&(r.respawnTimer-=t,r.respawnTimer<=0&&(r.place(this.spawnFor(r.team,0)),r.boost=gt.car.boostStart,this.bus.emit("respawn",{car:r})));for(let r of e)r.preStep(t);for(let r of e)r.lastJumpEvent&&this.bus.emit("jump",{car:r}),r.dodgeEvent&&this.bus.emit("dodge",{car:r});n.beginStep(e,t),this.P.step(),this.simTime+=t;for(let r of e)r.postStep();n.endStep(e,t,this.simTime);for(let r of e)r.landedEvent>.05&&this.bus.emit("land",{car:r,power:r.landedEvent});for(let r of n.hitEvents)this.stats.touches[r.car.team]++,this.bus.emit("ballHit",r);if(!n.hitEvents.length){let r=ga.copy(n.vel).sub(this.ballPrevVel).length();r>3.5&&this.bus.emit("ballImpact",{power:r,pos:n.pos})}this.P.events.drainCollisionEvents((r,a,o)=>{o&&this.carCollision(r,a)}),this.pads.update(t,e,this.simTime);for(let r of this.pads.events)this.bus.emit(r.respawned?"padRespawn":"padPickup",r);switch(this.stateTime+=t,this.state){case"countdown":{this.countdown-=t;let r=Math.ceil(this.countdown);r!==this.lastCountInt&&r>0&&(this.lastCountInt=r,this.bus.emit("count",{n:r})),this.countdown<=0&&(this.state="playing",this.stateTime=0,this.bus.emit("go",{}));break}case"playing":this.playing(t);break;case"goal":this.stateTime>=Bn.goalCelebration&&this.beginReplay();break;default:break}this.mode==="freeplay"&&this.freeplayGoalCheck(),this.recordFrame()}lastTouchless(){return this.ball.lastHitCar===null}playing(t){if(this.mode!=="versus")return;if(this.overtime)this.overtimeTime+=t;else if(this.timeLeft-=t,this.timeLeft<=0){if(this.timeLeft=0,this.scores[0]!==this.scores[1])return this.finish();this.overtime=!0,this.overtimeTime=0,this.bus.emit("overtime",{})}let e=this.goalCheck();e>=0&&this.scoreGoal(e)}goalCheck(){let t=this.ball.pos;return Math.abs(t.z)>gl.halfLength+hs&&Math.abs(t.x)<gl.goalHalfWidth&&t.y<gl.goalHeight+hs?t.z>0?0:1:-1}freeplayGoalCheck(){if(this.state!=="playing")return;let t=this.goalCheck();t>=0&&(this.scores[t]++,this.lastScorer=t,this.state="goal",this.stateTime=0,this.bus.emit("goal",{team:t,freeplay:!0,ball:this.ball.pos.clone(),by:this.ball.lastHitCar}))}scoreGoal(t){this.scores[t]++,this.lastScorer=t;let e=this.ball.lastHitCar;this.lastGoalInfo={team:t,by:e,speed:ge(this.ball.vel.length()),overtime:this.overtime},this.stats.shots[t]++,this.state="goal",this.stateTime=0,this.goalFrame=this.record.length,this.bus.emit("goal",{team:t,ball:this.ball.pos.clone(),by:e,speed:this.lastGoalInfo.speed})}finish(){this.state="ended",this.stateTime=0;let t=this.scores[0]===this.scores[1]?-1:this.scores[0]>this.scores[1]?0:1;this.bus.emit("ended",{scores:this.scores.slice(),winner:t,stats:this.stats})}carCollision(t,e){let n=this.cars.find(u=>u.collider.handle===t),i=this.cars.find(u=>u.collider.handle===e);if(!n||!i||n===i||n.demolished||i.demolished||n.team===i.team)return;let r=gt.car.supersonic,a=(u,d)=>u.prevSpeed<r?!1:(Fh.copy(d.currT).sub(u.currT).normalize(),u.prevVel.dot(Fh)>.4*u.prevSpeed),o=a(n,i),l=a(i,n),c=null,h=null;if(o&&(!l||n.prevSpeed>=i.prevSpeed)?(c=n,h=i):l&&(c=i,h=n),!c){this.bus.emit("carBump",{a:n,b:i,power:ga.copy(n.vel).sub(i.vel).length()});return}this.stats.demos[c.team]++,this.bus.emit("demolish",{victim:h,attacker:c,pos:h.currT.clone()}),h.demolish()}recordFrame(){let t={b:[this.ball.pos.x,this.ball.pos.y,this.ball.pos.z,this.ball.quat.x,this.ball.quat.y,this.ball.quat.z,this.ball.quat.w],c:[]};for(let e of this.cars)t.c.push([e.currT.x,e.currT.y,e.currT.z,e.currQ.x,e.currQ.y,e.currQ.z,e.currQ.w,e.boosting?1:0,e.demolished?1:0]);this.record.push(t),this.record.length>this.maxRecord&&this.record.shift()}beginReplay(){let t=Math.min(this.record.length,Math.ceil((Bn.replayDuration-.5)*gt.sim.hz)),e=this.record.length-Math.ceil((Bn.goalCelebration-.8)*gt.sim.hz),n=Math.max(0,e-t);this.replay={frames:this.record.slice(n,Math.max(n+2,e)),t:0},this.state="replay",this.stateTime=0,this.bus.emit("replayStart",{})}stepReplay(t){let e=this.replay;if(!e)return this.endReplay();e.t+=t*Bn.replaySpeed*gt.sim.hz,this.stateTime+=t;let n=Math.floor(e.t),i=e.t-n;if(n>=e.frames.length-1)return this.endReplay();let r=e.frames[n],a=e.frames[n+1];this.rBall.pos.set(r.b[0],r.b[1],r.b[2]).lerp(ga.set(a.b[0],a.b[1],a.b[2]),i),this.rBall.quat.set(r.b[3],r.b[4],r.b[5],r.b[6]).slerp(new Jt(a.b[3],a.b[4],a.b[5],a.b[6]),i),this.cars.forEach((o,l)=>{let c=r.c[l],h=a.c[l];!c||!h||(o.rPos||(o.rPos=new C),o.rQuat||(o.rQuat=new Jt),o.rPos.set(c[0],c[1],c[2]).lerp(ga.set(h[0],h[1],h[2]),i),o.rQuat.set(c[3],c[4],c[5],c[6]).slerp(new Jt(h[3],h[4],h[5],h[6]),i),o.replayBoost=!!c[7],o.replayHidden=!!c[8])})}skipReplay(){this.state==="replay"&&this.endReplay()}endReplay(){this.replay=null;for(let t of this.cars)t.replayBoost=!1,t.replayHidden=!1;if(this.bus.emit("replayEnd",{}),this.mode==="freeplay"){this.state="playing",this.setPreset(this.preset);return}if(this.overtime)return this.finish();this.kickoff()}dispose(){this.clearCars(),this.P.world.removeRigidBody(this.ball.body)}restart(){this.mode==="freeplay"?this.startFreePlay():this.mode==="versus"&&this.startVersus(this.difficulty)}quitToMenu(){this.mode="menu",this.state="idle",this.paused=!1,this.clearCars(),this.replay=null,this.ball.reset(0,hs+.02,0)}};var Pe=gt.arena,cn=gt.car,ze=[{body:2063615,accent:8376575,glow:new Ct(.25,.65,1),css:"#3b9bff"},{body:16742938,accent:16765066,glow:new Ct(1,.5,.12),css:"#ff8a2b"}],us=(s,t,e)=>Math.max(t,Math.min(e,s)),te=new C,ri=new C,o_=new Jt,A0=new C(0,1,0),R0=new Jt().setFromAxisAngle(new C(1,0,0),-Math.PI/2);function Vs(s,t,e,n={}){let i=document.createElement("canvas");i.width=s,i.height=t,e(i.getContext("2d"),s,t);let r=new Wr(i);return r.colorSpace=xe,r.anisotropy=8,n.repeat&&(r.wrapS=r.wrapT=As),n.noFlip&&(r.flipY=!1),r}var ya=class{constructor(t,e,n){this.max=t,this.n=0,this.cursor=0,this.pos=new Float32Array(t*3),this.col=new Float32Array(t*4),this.size=new Float32Array(t),this.vel=new Float32Array(t*3),this.life=new Float32Array(t),this.maxLife=new Float32Array(t),this.s0=new Float32Array(t),this.s1=new Float32Array(t),this.a0=new Float32Array(t),this.drag=new Float32Array(t),this.grav=new Float32Array(t),this.base=new Float32Array(t*3);let i=new Re;i.setAttribute("position",new jt(this.pos,3)),i.setAttribute("color",new jt(this.col,4)),i.setAttribute("size",new jt(this.size,1)),this.uniforms={uScale:{value:600}},this.mat=new nn({uniforms:this.uniforms,transparent:!0,depthWrite:!1,blending:e?mn:Jn,vertexShader:"attribute float size; attribute vec4 color; varying vec4 vC; uniform float uScale; void main(){ vC=color; vec4 mv=modelViewMatrix*vec4(position,1.0); gl_PointSize=max(size*uScale/-mv.z,0.0); gl_Position=projectionMatrix*mv; }",fragmentShader:"varying vec4 vC; void main(){ float d=length(gl_PointCoord-0.5); float a=smoothstep(0.5,0.05,d); gl_FragColor=vec4(vC.rgb,vC.a*a); }"}),this.points=new Ds(i,this.mat),this.points.frustumCulled=!1,n.add(this.points);for(let r=0;r<t;r++)this.life[r]=0,this.size[r]=0,this.pos[r*3+1]=-999}emit(t,e,n,i,r,a,o,l,c,h,u,d,f,g=0,y=0){let m=this.cursor;this.cursor=(this.cursor+1)%this.max,this.pos[m*3]=t,this.pos[m*3+1]=e,this.pos[m*3+2]=n,this.vel[m*3]=i,this.vel[m*3+1]=r,this.vel[m*3+2]=a,this.col[m*4]=o,this.col[m*4+1]=l,this.col[m*4+2]=c,this.col[m*4+3]=h,this.a0[m]=h,this.s0[m]=u,this.s1[m]=d,this.life[m]=f,this.maxLife[m]=f,this.drag[m]=g,this.grav[m]=y,this.size[m]=u}update(t){for(let n=0;n<this.max;n++){if(this.life[n]<=0){this.size[n]!==0&&(this.size[n]=0);continue}if(this.life[n]-=t,this.life[n]<=0){this.size[n]=0,this.pos[n*3+1]=-999;continue}let i=1-this.life[n]/this.maxLife[n],r=Math.exp(-this.drag[n]*t);this.vel[n*3]*=r,this.vel[n*3+1]=this.vel[n*3+1]*r-this.grav[n]*t,this.vel[n*3+2]*=r,this.pos[n*3]+=this.vel[n*3]*t,this.pos[n*3+1]+=this.vel[n*3+1]*t,this.pos[n*3+2]+=this.vel[n*3+2]*t,this.pos[n*3+1]<.02&&this.grav[n]>0&&(this.pos[n*3+1]=.02,this.vel[n*3+1]*=-.4),this.size[n]=this.s0[n]+(this.s1[n]-this.s0[n])*i,this.col[n*4+3]=this.a0[n]*(1-i)*(1-i*.3)}let e=this.points.geometry;e.attributes.position.needsUpdate=!0,e.attributes.color.needsUpdate=!0,e.attributes.size.needsUpdate=!0}};function _l(s){let t=ze[s],e=new tn,n=new Le({color:t.body,metalness:.35,roughness:.38,envMapIntensity:.7}),i=new Le({color:1382431,metalness:.5,roughness:.45}),r=new Le({color:659228,metalness:.95,roughness:.06}),a=new Le({color:t.accent,metalness:.3,roughness:.4,emissive:t.accent,emissiveIntensity:.35}),o=(T,E,R,U)=>{let v=new Ns;v.moveTo(T[0][0],T[0][1]);for(let H=1;H<T.length;H++)v.lineTo(T[H][0],T[H][1]);let S=new $r(v,{depth:E,bevelEnabled:!!U,bevelSize:U||0,bevelThickness:U||0,bevelSegments:2,steps:1});return S.translate(0,0,-E/2),S.rotateY(Math.PI/2),new It(S,R)};e.add(o([[-.6,-.12],[-.62,-.02],[-.58,.05],[-.3,.07],[-.14,.185],[.1,.19],[.3,.06],[.5,.03],[.62,-.02],[.63,-.1],[.5,-.14],[-.5,-.14]],.74,n,.03)),e.add(o([[-.2,.07],[-.11,.165],[.09,.17],[.25,.065]],.8,r,.005));let l=new It(new ye(.1,.012,.9),a);l.position.set(0,.075,.32),e.add(l);let c=new It(new ye(.78,.025,.2),n);c.position.set(0,.2,.55),e.add(c);for(let T of[-1,1]){let E=new It(new ye(.03,.12,.07),i);E.position.set(T*.2,.14,.55),e.add(E);let R=new It(new ye(.02,.07,.22),a);R.position.set(T*.39,.2,.55),e.add(R)}let h=new me({color:16774872}),u=new me({color:16722474});for(let T of[-1,1]){let E=new It(new ye(.15,.04,.02),h);E.position.set(T*.24,-.015,-.628),e.add(E);let R=new It(new ye(.16,.035,.02),u);R.position.set(T*.25,0,.62),e.add(R)}let d=new It(new ye(.8,.02,.1),i);d.position.set(0,-.145,-.6),e.add(d);let f=new It(new ye(.7,.03,1.2),i);f.position.set(0,-.145,0),e.add(f);let g=[],y=new me({color:t.glow,transparent:!0,opacity:.6,blending:mn,depthWrite:!1}),m=new me({color:13625599,transparent:!0,opacity:.55,blending:mn,depthWrite:!1});for(let T of[-1,1]){let E=new It(new rn(.045,.06,.1,12),i);E.rotation.x=Math.PI/2,E.position.set(T*.17,-.07,.64),e.add(E);let R=new ji(.06,.6,12,1,!0);R.translate(0,.3,0),R.rotateX(Math.PI/2);let U=new It(R,y);U.position.set(T*.17,-.07,.69),U.visible=!1,e.add(U);let v=new ji(.03,.3,10,1,!0);v.translate(0,.15,0),v.rotateX(Math.PI/2);let S=new It(v,m);S.position.copy(U.position),S.visible=!1,e.add(S),g.push(U,S)}let p=[],x=new Le({color:855312,roughness:.85,metalness:.05}),_=new Le({color:14212584,metalness:.9,roughness:.25}),M=[[-cn.wheelX,cn.wheelZFront,!0],[cn.wheelX,cn.wheelZFront,!0],[-cn.wheelX,cn.wheelZRear,!1],[cn.wheelX,cn.wheelZRear,!1]];for(let[T,E,R]of M){let U=new tn;U.position.set(T,-.065,E);let v=new tn;U.add(v);let S=R?cn.wheelRadius*.95:cn.wheelRadius*1.05,N=new It(new rn(S,S,.17,24),x);N.rotation.z=Math.PI/2,v.add(N);let H=new It(new rn(S*.66,S*.66,.178,18),_);H.rotation.z=Math.PI/2,v.add(H);for(let et=0;et<5;et++){let L=new It(new ye(.182,S*.12,S*1.2),i);L.rotation.x=et/5*Math.PI,v.add(L)}e.add(U),p.push({pivot:U,spin:v,front:R,baseY:-.065,radius:S,x:T,z:E})}return e.traverse(T=>{T.isMesh&&(T.frustumCulled=!0)}),{group:e,wheels:p,flames:g,bodyMat:n}}var va=class{constructor(t,e,n){this.canvas=t,this.geo=e,this.bus=n,this.gl=new Ls({canvas:t,antialias:!0,powerPreference:"high-performance"}),this.gl.setPixelRatio(Math.min(window.devicePixelRatio||1,1.75)),this.gl.outputColorSpace=xe,this.gl.toneMapping=rl,this.gl.toneMappingExposure=.95,this.scene=new Is,this.camera=new Oe(70,16/9,.1,600),this.time=0,this.carViews=new Map,this.padViews=[],this.flash=0,this.rings=[],this.buildEnvironmentMap(),this.buildLights(),this.buildArena(),this.buildStands(),this.buildSky(),this.buildPads(),this.buildBall(),this.buildEffects(),this.buildShowcase(),this.resize(),this.subscribe()}adaptQuality(t,e){this._q=this._q||{scale:Math.min(window.devicePixelRatio||1,1.75),max:Math.min(window.devicePixelRatio||1,1.75),low:0,high:0};let n=this._q;t<45?(n.low+=e,n.high=0):t>57?(n.high+=e,n.low=0):n.low=n.high=0;let i=!1;n.low>1.5&&n.scale>.6&&(n.scale=Math.max(.6,n.scale-.15),n.low=0,i=!0),n.high>6&&n.scale<n.max&&(n.scale=Math.min(n.max,n.scale+.1),n.high=0,i=!0),i&&(this.gl.setPixelRatio(n.scale),this.resize())}resize(){let t=this.canvas.clientWidth||window.innerWidth,e=this.canvas.clientHeight||window.innerHeight;return this.gl.setSize(t,e,!1),this.width=t,this.height=e,this.camera.aspect=t/e,this.camera.updateProjectionMatrix(),t/e}buildEnvironmentMap(){let t=new Is,e=new It(new yi(50,24,12),new me({side:Te,vertexColors:!0})),n=e.geometry.attributes.position,i=[];for(let a=0;a<n.count;a++){let o=(n.getY(a)/50+1)/2;i.push(.06+o*.25,.08+o*.3,.16+o*.55)}e.geometry.setAttribute("color",new re(i,3)),t.add(e);for(let a=0;a<6;a++){let o=new It(new ye(18,.5,6),new me({color:new Ct(6,6,6.5)}));o.position.set((a-2.5)*14,40,a%2*18-9),t.add(o)}let r=new Qi(this.gl);this.scene.environment=r.fromScene(t,.03).texture,this.scene.environmentIntensity=.45,r.dispose()}buildLights(){this.scene.add(new jr(10204415,3156026,.55));let t=new ea(16777215,.85);t.position.set(18,60,10),this.scene.add(t),this.blueLight=new es(3837183,260,70,1.6),this.blueLight.position.set(0,18,-28),this.scene.add(this.blueLight),this.orangeLight=new es(16747050,260,70,1.6),this.orangeLight.position.set(0,18,28),this.scene.add(this.orangeLight),this.flashLight=new es(16777215,0,120,1.2),this.flashLight.position.set(0,14,0),this.scene.add(this.flashLight)}buildSky(){let t=new It(new yi(300,24,12),new me({side:Te,vertexColors:!0,fog:!1})),e=t.geometry.attributes.position,n=[];for(let i=0;i<e.count;i++){let r=us(e.getY(i)/300,-.3,1);n.push(.02+r*.05,.03+r*.06,.07+r*.14)}t.geometry.setAttribute("color",new re(n,3)),this.scene.add(t),this.scene.fog=new Hr(461334,.0035)}buildArena(){let{floor:t,shell:e,goalBlue:n,goalOrange:i}=this.geo.groups,r=Pe.halfWidth,a=Pe.halfLength,o=x=>{let _=new Re;return _.setAttribute("position",new jt(x.positions,3)),_.setAttribute("normal",new jt(x.normals,3)),_.setAttribute("uv",new jt(x.uvs,2)),_.setIndex(new jt(x.indices,1)),_},l=Vs(1024,1280,(x,_,M)=>{let T=x.createLinearGradient(0,0,0,M);T.addColorStop(0,"#102a52"),T.addColorStop(.47,"#17345f"),T.addColorStop(.5,"#1a2a44"),T.addColorStop(.53,"#4a2f2c"),T.addColorStop(1,"#5a2e1a"),x.fillStyle=T,x.fillRect(0,0,_,M),x.strokeStyle="rgba(255,255,255,0.05)",x.lineWidth=1;for(let v=0;v<=_;v+=_/16)x.beginPath(),x.moveTo(v,0),x.lineTo(v,M),x.stroke();for(let v=0;v<=M;v+=M/20)x.beginPath(),x.moveTo(0,v),x.lineTo(_,v),x.stroke();x.strokeStyle="rgba(255,255,255,0.75)",x.lineWidth=5;let E=_/(2*r),R=M/(2*a),U=(v,S)=>[(v+r)*E,(S+a)*R];x.beginPath(),x.moveTo(...U(-r,0)),x.lineTo(...U(r,0)),x.stroke(),x.beginPath(),x.ellipse(...U(0,0),9.2*E,9.2*R,0,0,Math.PI*2),x.stroke(),x.beginPath(),x.arc(...U(0,0),.5*E,0,Math.PI*2),x.fillStyle="#fff",x.fill(),x.lineWidth=4;for(let v of[-1,1]){let S=v<0?"rgba(90,170,255,0.9)":"rgba(255,150,70,0.9)";x.strokeStyle=S,x.strokeRect(...U(-18,v<0?-a:a-12.5),36*E,12.5*R),x.beginPath(),x.ellipse(...U(0,v*(a-12.5)),12*E,5*R,0,v<0?0:Math.PI,v<0?Math.PI:Math.PI*2),x.stroke()}x.strokeStyle="rgba(255,255,255,0.6)",x.lineWidth=6,x.strokeRect(2,2,_-4,M-4)},{noFlip:!0}),c=new Le({map:l,roughness:.55,metalness:.12,envMapIntensity:.6});this.floorMesh=new It(o(t),c),this.scene.add(this.floorMesh);let h=o(e),u=e.positions,d=new Float32Array(u.length/3*4);for(let x=0;x<u.length/3;x++){let _=u[x*3+1],M=u[x*3+2],T=us(M/a,-1,1),E=Math.abs(T)>.15?Math.min(1,(Math.abs(T)-.15)/.6):0,R=.35+(T>0?E*.65:-E*.15),U=.45+(T>0,E*.1),v=.8+(T<0?E*.2:-E*.5),S;_>Pe.height-Pe.ceilingRampRadius*.5?S=.92:_<Pe.floorRampRadius+.01?S=.8:S=.3+.35*Math.pow(Math.min(1,Math.abs(_-Pe.height/2)/(Pe.height/2)),2),d[x*4]=R,d[x*4+1]=U,d[x*4+2]=v,d[x*4+3]=S}h.setAttribute("color",new jt(d,4));let f=Vs(256,256,(x,_,M)=>{x.fillStyle="#28365a",x.fillRect(0,0,_,M),x.strokeStyle="rgba(150,190,255,0.55)",x.lineWidth=3;let T=64;for(let E=0;E<=M;E+=T)for(let R=0;R<=_;R+=T)x.strokeRect(R+3,E+3,T-6,T-6);x.fillStyle="rgba(255,255,255,0.05)";for(let E=0;E<40;E++)x.fillRect(Math.random()*_,Math.random()*M,3,3)},{repeat:!0}),g=new Le({map:f,vertexColors:!0,transparent:!0,side:Ge,roughness:.75,metalness:.2,emissive:1450570,emissiveIntensity:.9,depthWrite:!1});this.shellMesh=new It(h,g),this.shellMesh.renderOrder=2,this.scene.add(this.shellMesh);let y=x=>Vs(256,256,(_,M,T)=>{_.fillStyle="rgba(8,12,24,0.0)",_.clearRect(0,0,M,T),_.strokeStyle=x,_.lineWidth=2,_.globalAlpha=.85;for(let E=0;E<=8;E++)_.beginPath(),_.moveTo(E*M/8,0),_.lineTo(E*M/8,T),_.stroke(),_.beginPath(),_.moveTo(0,E*T/8),_.lineTo(M,E*T/8),_.stroke()},{repeat:!0}),m=(x,_)=>{let M=new It(o(x),new Le({map:y(_?"#ffb070":"#7cc4ff"),transparent:!0,opacity:.8,side:Ge,emissive:_?8008976:1063546,emissiveIntensity:.9,roughness:.6,depthWrite:!1}));return M.geometry.attributes.uv.array.forEach((T,E,R)=>{R[E]=T*6}),this.scene.add(M),M};m(n,0),m(i,1);for(let x of this.geo.frame){let _=x.z<0?0:1,M=new Le({color:ze[_].body,emissive:ze[_].body,emissiveIntensity:.6,metalness:.5,roughness:.3}),T;x.kind==="post"?(T=new It(new rn(x.radius,x.radius,x.halfHeight*2,14),M),T.position.set(x.x,x.y,x.z)):(T=new It(new rn(x.radius,x.radius,x.halfLength*2,14),M),T.rotation.z=Math.PI/2,T.position.set(x.x,x.y,x.z)),this.scene.add(T)}for(let x of[-1,1]){let _=new It(new Ki(Pe.goalHalfWidth*2,Pe.goalHeight),new me({color:ze[x<0?0:1].body,transparent:!0,opacity:.06,side:Ge,depthWrite:!1,blending:mn}));_.position.set(0,Pe.goalHeight/2,x*(Pe.halfLength+Pe.goalDepth*.5)),this.scene.add(_)}let p=new me({color:new Ct(2.2,2.2,2.4)});for(let x=-4;x<=4;x++){let _=new It(new ye(Pe.halfWidth*1.4,.12,.5),p);_.position.set(0,Pe.height-.08,x*10),this.scene.add(_)}}buildStands(){let e=new Gr(new ye(.7,1.1,.7),new Le({roughness:.9}),2600),n=new Ae,i=new Ct,r=0,a=Pe.halfWidth,o=Pe.halfLength,l=[2833003,7023403,2845514,5982763,4210795,9079450,1976900,8010598],c=(p,x,_)=>{r>=2600||(n.position.set(p,x,_),n.scale.setScalar(.85+Math.random()*.3),n.updateMatrix(),e.setMatrixAt(r,n.matrix),i.setHex(l[Math.random()*l.length|0]).multiplyScalar(.7+Math.random()*.6),e.setColorAt(r,i),r++)};for(let p=0;p<9;p++){let x=4.5+p*1.5,_=1+p*1.25;for(let M=-o+14;M<=o-14;M+=1.5)c(-a-x,_,M+(Math.random()-.5)*.3),c(a+x,_,M+(Math.random()-.5)*.3);for(let M=-a+14;M<=a-14;M+=1.5)p>1&&(c(M,_,-o-x-Pe.goalDepth*.6),c(M,_,o+x+Pe.goalDepth*.6))}e.count=r,e.instanceMatrix.needsUpdate=!0,e.instanceColor&&(e.instanceColor.needsUpdate=!0),this.scene.add(e);let h=new Le({color:856608,roughness:1});for(let p of[-1,1]){let x=new It(new ye(30,1,o*2+40),h);x.position.set(p*(a+20),-.6,0),this.scene.add(x);let _=new It(new ye(a*2+60,1,40),h);_.position.set(0,-.6,p*(o+28)),this.scene.add(_)}let u=220,d=new Float32Array(u*3),f=new Float32Array(u);for(let p=0;p<u;p++){let x=Math.random()<.5?-1:1;d[p*3]=x*(a+6+Math.random()*14),d[p*3+1]=3+Math.random()*11,d[p*3+2]=(Math.random()*2-1)*(o-5),f[p]=Math.random()*100}let g=new Re;g.setAttribute("position",new jt(d,3)),g.setAttribute("seed",new jt(f,1)),this.twinkle={value:0};let y=new nn({transparent:!0,depthWrite:!1,blending:mn,uniforms:{uT:this.twinkle,uScale:{value:600}},vertexShader:"attribute float seed; uniform float uT; uniform float uScale; varying float vA; void main(){ float ph=fract(uT*0.35+seed*0.137); vA=smoothstep(0.0,0.04,ph)*smoothstep(0.12,0.04,ph); vec4 mv=modelViewMatrix*vec4(position,1.0); gl_PointSize=vA*1.6*uScale/-mv.z; gl_Position=projectionMatrix*mv; }",fragmentShader:"varying float vA; void main(){ float d=length(gl_PointCoord-0.5); gl_FragColor=vec4(vec3(1.0),vA*smoothstep(0.5,0.0,d)); }"});this.twinkleUniforms=y.uniforms;let m=new Ds(g,y);m.frustumCulled=!1,this.scene.add(m)}buildPads(){let t=new rn(.95,1.05,.06,6),e=new rn(1.45,1.55,.08,8),n=new Kr(.62,1),i=new rn(.9,1.2,7,16,1,!0);i.translate(0,3.5,0);for(let r of this.geo.boostPads){let a=new tn;a.position.set(r.x,.04,r.z);let o=new Le({color:16756782,emissive:16747008,emissiveIntensity:.9,metalness:.3,roughness:.4}),l=new It(r.large?e:t,o);a.add(l);let c=new It(new ji(.4,.8,3),new me({color:16773296}));c.rotation.x=-Math.PI/2,c.position.y=.06,c.scale.set(1,1,.2),a.add(c);let h=null,u=null;r.large&&(h=new It(n,new me({color:16765034,transparent:!0,opacity:.95})),h.position.y=1.4,a.add(h),u=new It(i,new me({color:16752672,transparent:!0,opacity:.16,blending:mn,depthWrite:!1,side:Ge})),a.add(u)),this.scene.add(a),this.padViews.push({grp:a,mat:o,orb:h,beam:u,base:l,arrow:c,pad:r,glow:1,spawnAnim:1})}}buildBall(){let t=gt.ball.radius,e=Vs(512,256,(n,i,r)=>{n.fillStyle="#e8edf8",n.fillRect(0,0,i,r),n.strokeStyle="#263055",n.lineWidth=4;for(let a=0;a<r;a+=64)for(let o=0;o<i;o+=64){let l=a/64%2?32:0;n.beginPath();for(let c=0;c<6;c++){let h=c/6*Math.PI*2,u=o+l+32+Math.cos(h)*30,d=a+32+Math.sin(h)*30;c?n.lineTo(u,d):n.moveTo(u,d)}n.closePath(),n.stroke(),(o/64+a/64)%3===0&&(n.fillStyle="#34406e",n.fill())}});this.ballMat=new Le({map:e,roughness:.28,metalness:.25,emissive:2241365,emissiveIntensity:.35}),this.ballMesh=new It(new yi(t,40,28),this.ballMat),this.scene.add(this.ballMesh),this.ballGlow=new It(new yi(t*1.12,24,16),new me({color:6728447,transparent:!0,opacity:0,blending:mn,depthWrite:!1,side:Te})),this.scene.add(this.ballGlow),this.ballShadow=this.makeShadow(t*1.3),this.ballTrail=0}makeShadow(t){let e=Vs(64,64,(i,r,a)=>{let o=i.createRadialGradient(32,32,2,32,32,32);o.addColorStop(0,"rgba(0,0,0,0.85)"),o.addColorStop(1,"rgba(0,0,0,0)"),i.fillStyle=o,i.fillRect(0,0,r,a)}),n=new It(new Ki(t*2,t*2),new me({map:e,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2}));return n.rotation.x=-Math.PI/2,n.renderOrder=1,this.scene.add(n),n.userData.r=t,n}buildEffects(){this.addP=new ya(2600,!0,this.scene),this.smokeP=new ya(1400,!1,this.scene),this.markMax=1800,this.markN=0,this.markPtr=0;let t=new Re;this.markPos=new Float32Array(this.markMax*4*3),this.markCol=new Float32Array(this.markMax*4*4);let e=new Uint32Array(this.markMax*6);for(let n=0;n<this.markMax;n++){let i=n*4;e.set([i,i+1,i+2,i+2,i+1,i+3],n*6)}t.setAttribute("position",new jt(this.markPos,3)),t.setAttribute("color",new jt(this.markCol,4)),t.setIndex(new jt(e,1)),this.markMesh=new It(t,new me({vertexColors:!0,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-3})),this.markMesh.frustumCulled=!1,this.markMesh.renderOrder=1,this.scene.add(this.markMesh),this.ringGeo=new Qr(.85,1,48)}addRing(t,e,n,i,r=!1){let a=new It(this.ringGeo,new me({color:e,transparent:!0,opacity:.9,blending:mn,depthWrite:!1,side:Ge}));a.position.copy(t),r||(a.rotation.x=-Math.PI/2),this.scene.add(a),this.rings.push({m:a,t:0,life:i,maxR:n})}burst(t,e,n,i,r=.3,a=.8,o=!0,l=6){let c=o?this.addP:this.smokeP;for(let h=0;h<e;h++){let u=Math.random()*Math.PI*2,d=Math.acos(2*Math.random()-1),f=n*(.3+Math.random()*.7);c.emit(t.x,t.y,t.z,Math.sin(d)*Math.cos(u)*f,Math.cos(d)*f,Math.sin(d)*Math.sin(u)*f,i.r,i.g,i.b,1,r,r*.3,a*(.5+Math.random()*.8),1.2,l)}}subscribe(){let t=this.bus;t.on("ballHit",e=>{let n=us(ge(e.power)/2300,.1,1.6),i=ze[e.car.team].glow;this.burst(e.point,Math.round(10+n*26),6+n*12,new Ct(1,.9,.6).lerp(i,.4),.16,.5),n>.45&&this.addRing(e.point,ze[e.car.team].body,1.2+n*2,.35,!0),this.ballGlowT=1,this.glowTeam=e.car.team,this.camShake=Math.max(this.camShake||0,n*.5)}),t.on("ballImpact",e=>{e.power>5&&this.burst(e.pos,8,5,new Ct(.8,.9,1),.14,.4)}),t.on("land",e=>{let n=e.car;if(e.power>.2)for(let i of n.wheels)i.contact&&this.dust(te.set(i.px,.05,i.pz),2,3*e.power)}),t.on("padPickup",e=>{let n=this.padViews[e.pad.id];n&&(n.spawnAnim=0);let i=te.set(e.pad.x,.2,e.pad.z);this.burst(i,e.pad.large?36:12,e.pad.large?9:5,new Ct(1,.75,.2),.2,.7),e.pad.large&&this.addRing(i,16760896,4,.5)}),t.on("goal",e=>{let n=ze[e.team].glow,i=e.ball.clone();i.y=Math.max(i.y,1.5),this.burst(i,320,26,n,.55,1.8,!0,4),this.burst(i,160,38,new Ct(1,1,1),.3,1.4,!0,3),this.addRing(i,ze[e.team].body,16,1,!0),this.addRing(new C(i.x,.1,i.z),ze[e.team].body,22,1.2),this.flash=1,this.flashColor=ze[e.team].body,this.camShake=1.2}),t.on("demolish",e=>{let n=e.pos;this.burst(n,140,18,new Ct(1,.55,.2),.45,1.1),this.burst(n,80,12,new Ct(.4,.45,.5),.6,1.4,!1,2),this.addRing(n,16744496,6,.6),this.camShake=.8}),t.on("carBump",e=>{e.power>4&&(te.copy(e.a.currT).add(e.b.currT).multiplyScalar(.5),this.burst(te,14,6,new Ct(1,.9,.6),.14,.4))}),t.on("jump",e=>{for(let n of e.car.wheels)this.dust(te.set(n.px,.05,n.pz),1,2)}),t.on("dodge",e=>{te.copy(e.car.currT),this.burst(te,12,4,ze[e.car.team].glow,.12,.4,!0,0)})}dust(t,e,n){for(let i=0;i<e;i++)this.smokeP.emit(t.x+(Math.random()-.5)*.3,t.y,t.z+(Math.random()-.5)*.3,(Math.random()-.5)*n,Math.random()*n*.6,(Math.random()-.5)*n,.7,.74,.82,.16,.2,.9,.8,1.8,-.3)}getCarView(t){let e=this.carViews.get(t);if(!e){let n=_l(t.team);this.scene.add(n.group);let i=this.makeShadow(1);i.scale.set(1.15,1,1.8),e={car:t,model:n,shadow:i,wheelY:[0,0,0,0],lastMark:[null,null,null,null],flame:0},this.carViews.set(t,e)}return e}dropCars(t){for(let[e,n]of this.carViews)t.includes(e)||(this.scene.remove(n.model.group),this.scene.remove(n.shadow),this.carViews.delete(e))}buildShowcase(){this.showcase=new tn;let t=_l(0),e=_l(1);t.group.position.set(-3,.205,-42),t.group.rotation.y=Math.PI*.85,e.group.position.set(3,.205,42),e.group.rotation.y=-Math.PI*.15,this.showcase.add(t.group,e.group),this.showcase.visible=!1,this.scene.add(this.showcase)}updateCar(t,e,n){let i=t.car,r=t.model.group,a=i.demolished||i.replayHidden;if(r.visible=!a,t.shadow.visible=!a,a)return;r.position.copy(i.rPos),r.quaternion.copy(i.rQuat);let o=n?i.replayBoost:i.boosting;t.model.wheels.forEach((f,g)=>{let y=i.wheels[g],m=n?f.baseY:-cn.wheelAttachY*0+cn.wheelAttachY-Math.min(y.dist??i.rayLen,i.rayLen)+f.radius;t.wheelY[g]+=(m-t.wheelY[g])*(1-Math.exp(-e*30)),isFinite(t.wheelY[g])||(t.wheelY[g]=f.baseY),f.pivot.position.y=t.wheelY[g],f.pivot.rotation.y=f.front?-(y.steer||0):0,f.spin.rotation.x=-(y.spin||0)}),t.flame+=((o?1:0)-t.flame)*(1-Math.exp(-e*(o?30:12)));let l=t.flame,c=.75+Math.random()*.5;t.model.flames.forEach((f,g)=>{f.visible=l>.05,f.scale.set(1,1,l*c*(g%2?.6:1))});let h=i.rPos.y,u=ri.set(0,1,0).applyQuaternion(i.rQuat);if(t.shadow.visible=u.y>.3||h<3,t.shadow.position.set(i.rPos.x,.025,i.rPos.z),t.shadow.material.opacity=us(.8-h/7,0,.8),te.set(0,0,-1).applyQuaternion(i.rQuat),t.shadow.quaternion.setFromAxisAngle(A0,Math.atan2(-te.x,-te.z)).multiply(R0),n)return;let d=i.speed;if(o){let f=ze[i.team].glow;for(let g of[-1,1]){te.set(g*.17,-.07,.7).applyQuaternion(i.rQuat).add(i.rPos),ri.copy(i.fwd).multiplyScalar(-9).addScaledVector(i.vel,.45);for(let y=0;y<2;y++)this.addP.emit(te.x,te.y,te.z,ri.x+(Math.random()-.5)*2,ri.y+(Math.random()-.5)*2,ri.z+(Math.random()-.5)*2,f.r*1.2,f.g*1.1,f.b*1.1+.2,.9,.34,.06,.35,2.5,0);this.addP.emit(te.x,te.y,te.z,ri.x*.5,ri.y*.5,ri.z*.5,1,.95,.85,1,.22,.04,.22,3,0)}}if(i.supersonic){te.set(0,0,.5).applyQuaternion(i.rQuat).add(i.rPos);let f=ze[i.team].glow;this.addP.emit(te.x,te.y,te.z,0,0,0,f.r*.6+.4,f.g*.6+.4,f.b*.6+.4,.55,.28,.02,.5,0,0);for(let g of[-1,1])te.set(g*.42,0,.3).applyQuaternion(i.rQuat).add(i.rPos),this.addP.emit(te.x,te.y,te.z,0,0,0,.7,.85,1,.5,.12,.01,.4,0,0)}i.wheels.forEach((f,g)=>{if(f.contact&&Math.abs(f.slip)>3.2&&f.ny>.9){let m=f.px,p=f.pz,x=t.lastMark[g];x&&(x.x-m)**2+(x.z-p)**2>.04&&(x.x-m)**2+(x.z-p)**2<25&&this.addMark(x,{x:m,z:p},us(Math.abs(f.slip)/12,.2,.7)),(!x||(x.x-m)**2+(x.z-p)**2>.04)&&(t.lastMark[g]={x:m,z:p}),Math.random()<.5&&this.dust(te.set(m,.05,p),1,2.2)}else t.lastMark[g]=null;f.contact&&d>18&&Math.random()<.12&&f.ny>.9&&this.dust(te.set(f.px,.05,f.pz),1,1.2)})}addMark(t,e,n){let i=e.x-t.x,r=e.z-t.z,a=Math.hypot(i,r)||1,o=-r/a*.07,l=i/a*.07,c=this.markPtr,h=c*12,u=c*16,d=.012,f=this.markPos;f[h]=t.x+o,f[h+1]=d,f[h+2]=t.z+l,f[h+3]=t.x-o,f[h+4]=d,f[h+5]=t.z-l,f[h+6]=e.x+o,f[h+7]=d,f[h+8]=e.z+l,f[h+9]=e.x-o,f[h+10]=d,f[h+11]=e.z-l;for(let g=0;g<4;g++)this.markCol[u+g*4]=.02,this.markCol[u+g*4+1]=.02,this.markCol[u+g*4+2]=.03,this.markCol[u+g*4+3]=n;this.markPtr=(this.markPtr+1)%this.markMax,this.markN=Math.min(this.markMax,this.markN+1),this.markDirty=!0}render(t,e,n){this.time+=e;let i=t.state==="replay",r=t.mode!=="menu";this.showcase.visible=!r,this.dropCars(t.cars);let a=t.rBall.quat,o=t.rBall.pos;this.ballMesh.position.copy(o),this.ballMesh.quaternion.copy(a),this.ballGlow.position.copy(o),this.ballGlowT=Math.max(0,(this.ballGlowT||0)-e*1.6);let l=this.ballGlow.material;l.opacity=this.ballGlowT*.55,this.glowTeam!==void 0&&l.color.copy(ze[this.glowTeam].glow),this.ballMat.emissiveIntensity=.35+this.ballGlowT*.8,this.glowTeam!==void 0&&this.ballMat.emissive.copy(ze[this.glowTeam].glow).multiplyScalar(.25+0),this.ballShadow.position.set(o.x,.026,o.z),this.ballShadow.material.opacity=us(.85-o.y/14,0,.85);let c=1+o.y*.02;if(this.ballShadow.scale.set(c,c,c),r&&!i&&ge(t.ball.vel.length())>2500&&Math.random()<.8){let f=this.glowTeam!==void 0?ze[this.glowTeam].glow:new Ct(.6,.8,1);this.addP.emit(o.x,o.y,o.z,0,0,0,f.r,f.g,f.b,.7,.9,.1,.45,0,0)}for(let d of t.cars)d.rPos&&this.updateCar(this.getCarView(d),e,i);this.padViews.forEach((d,f)=>{let g=d.pad,y=t.pads.pads[f].active;d.spawnAnim=Math.min(1,d.spawnAnim+e*2.2);let m=y?1:0;d.glow+=(m-d.glow)*(1-Math.exp(-e*10)),d.mat.emissiveIntensity=.05+d.glow*.8,d.mat.color.setRGB(.25+d.glow*.75,.18+d.glow*.42,.05+d.glow*.03),d.arrow.visible=y,d.arrow.rotation.z=0,d.orb?(d.orb.visible=y,d.orb.position.y=1.4+Math.sin(this.time*2.2+f)*.18,d.orb.rotation.y=this.time*1.5,d.orb.rotation.x=this.time*.9,d.orb.scale.setScalar(.2+.8*d.spawnAnim),d.beam.visible=y,d.beam.material.opacity=.1+.07*Math.sin(this.time*3+f)):d.base.scale.setScalar(y?.85+.15*d.spawnAnim:.8)}),this.addP.update(e),this.smokeP.update(e);let h=this.camera.fov*Math.PI/180,u=this.height*.5/Math.tan(h/2);if(this.addP.uniforms.uScale.value=u,this.smokeP.uniforms.uScale.value=u,this.twinkleUniforms.uScale.value=u,this.twinkle.value=this.time,this.markDirty){let d=this.markMesh.geometry;d.attributes.position.needsUpdate=!0,d.attributes.color.needsUpdate=!0,d.setDrawRange(0,this.markMax*6),this.markDirty=!1}for(let d=this.rings.length-1;d>=0;d--){let f=this.rings[d];f.t+=e;let g=f.t/f.life;if(g>=1){this.scene.remove(f.m),f.m.material.dispose(),this.rings.splice(d,1);continue}f.m.scale.setScalar(.3+f.maxR*Math.sqrt(g)),f.m.material.opacity=.9*(1-g),f.m.rotation.x===0&&f.m.lookAt(this.camera.position)}this.flash=Math.max(0,this.flash-e*1.4),this.flashLight.intensity=this.flash*2500,this.flashColor!==void 0&&this.flashLight.color.setHex(this.flashColor),this.gl.toneMappingExposure=.95+this.flash*.5,this.gl.render(this.scene,this.camera)}};var xl=(s,t,e)=>Math.max(t,Math.min(e,s)),fe=new C,be=new C,Oh=new C,Ma=new C,ds=new se,yl=new Jt,C0=new Jt,ba=class{constructor(t,e){this.cam=t,this.P=e,this.settings={...gt.camera},this.up=new C(0,1,0),this.heading=new C(0,0,-1),this.carHeading=new C(0,0,-1),this.pos=new C(0,5,10),this.ballBlend=1,this.ballCamActive=!0,this.lookYaw=0,this.lookPitch=0,this.distScale=1,this.fovBonus=0,this.aspect=16/9,this.replayPos=new C,this.initialized=!1,this.shake=0,this.setAspect(this.aspect)}setAspect(t){this.aspect=t,this.applyFov(0)}applyFov(t){let e=(this.settings.hFov+t)*Math.PI/180,n=2*Math.atan(Math.tan(e/2)/this.aspect);this.cam.fov=xl(n*180/Math.PI,20,120),this.cam.aspect=this.aspect,this.cam.updateProjectionMatrix()}snap(t,e){this.heading.copy(e).setY(0).normalize(),this.carHeading.copy(this.heading),this.initialized=!1}update(t){let e=this.settings,n=Math.min(t.dt,.1),i=F=>1-Math.exp(-F*n),r=3+e.stiffness*14;fe.copy(t.onSurface?t.surfaceNormal:new C(0,1,0)),t.onSurface&&t.surfaceNormal.y<-.5&&fe.set(0,1,0),this.up.lerp(fe,i(4)).normalize();let a=this.up;be.copy(t.carFwd).addScaledVector(a,-t.carFwd.dot(a));let o=Math.abs(t.carFwd.dot(a)),l=xl((.8-o)/.3,0,1);be.lengthSq()>1e-4?be.normalize():be.copy(this.carHeading),be.lerp(this.carHeading,1-l).normalize();let c=this.carHeading.angleTo(be);if(c>1e-4){let F=Math.min(c*i(r),6.5*n);yl.setFromUnitVectors(this.carHeading,be),yl.slerp(C0,1-Math.min(1,F/c)),this.carHeading.applyQuaternion(yl)}this.carHeading.addScaledVector(a,-this.carHeading.dot(a)).normalize();let h=Ma.copy(t.ballPos).sub(t.carPos),u=h.length(),d=t.ballCam&&t.hasCar&&u>.5;this.ballBlend+=((d?1:0)-this.ballBlend)*i(e.transitionSpeed),h.multiplyScalar(1/Math.max(u,1e-4));let f=Math.sin(e.ballCamPitchMax*Math.PI/180);h.y>f&&(h.y=f,h.normalize()),h.y<-.5&&(h.y=-.5,h.normalize()),fe.copy(this.carHeading).multiplyScalar(1-this.ballBlend).addScaledVector(h,this.ballBlend),fe.lengthSq()<1e-4&&fe.copy(this.carHeading),fe.normalize();let g=this.ballBlend>.5?r*1.8:r*3;this.heading.lerp(fe,i(g)).normalize();let y=t.look,m=(y.x||0)*e.freeLookMax,p=(y.y||0)*.8,x=Math.abs(y.x)+Math.abs(y.y)>.01?e.swivelSpeed*2.2:e.swivelSpeed*1.6;this.lookYaw+=(m-this.lookYaw)*i(x),this.lookPitch+=(p-this.lookPitch)*i(x);let _=Oh.copy(this.heading);ds.makeRotationAxis(a,-this.lookYaw),_.applyMatrix4(ds);let M=be.copy(_).cross(a).normalize();ds.makeRotationAxis(M,-this.lookPitch),_.applyMatrix4(ds);let T=xl(t.speed/gt.car.maxSpeed,0,1),E=e.distance*.01*(1+.1*T+(t.boosting?.04:0)),R=e.height*.01;fe.copy(t.carPos).addScaledVector(a,.25);let U=Ma.copy(fe).addScaledVector(_,-E).addScaledVector(a,R);be.copy(U).sub(fe);let v=be.length();be.multiplyScalar(1/v);let S=this.P.rayArenaCast(fe.x,fe.y,fe.z,be.x,be.y,be.z,v+.4),N=v;S&&(N=Math.max(1,S.toi-.35)),this.distScale+=(N/v-this.distScale)*i(N/v<this.distScale?18:3),this.distScale=Math.min(this.distScale,N/v),U.copy(fe).addScaledVector(be,v*this.distScale),this.initialized||(this.pos.copy(U),this.initialized=!0),this.pos.copy(U),this.cam.position.copy(this.pos),this.shake>0&&(this.cam.position.x+=(Math.random()-.5)*this.shake*.3,this.cam.position.y+=(Math.random()-.5)*this.shake*.3,this.shake=Math.max(0,this.shake-n*2.5));let H=e.angle*Math.PI/180,et=be.copy(_),L=fe.copy(_).cross(a).normalize();ds.makeRotationAxis(L,H),et.applyMatrix4(ds),this.cam.up.copy(a),Ma.copy(this.cam.position).add(et),this.cam.lookAt(Ma),this.applyFov(T*4+(t.boosting?2:0))}updateReplay(t,e,n){let i=1-Math.exp(-t*2.5);fe.copy(e).sub(n),fe.y=0,fe.lengthSq()<1e-4&&fe.set(0,0,1),fe.normalize(),be.copy(e).addScaledVector(fe,14).add(Oh.set(0,5.5,0)),this.initialized||(this.replayPos.copy(be),this.initialized=!0),this.replayPos.lerp(be,i),this.cam.position.copy(this.replayPos),this.cam.up.set(0,1,0),this.cam.lookAt(e),this.applyFov(-25)}orbit(t,e=55,n=22){this.cam.position.set(Math.cos(t*.15)*e,n,Math.sin(t*.15)*e*1.4),this.cam.up.set(0,1,0),this.cam.lookAt(0,3,0),this.applyFov(-40),this.initialized=!1}};var kn=(s,t,e)=>Math.max(t,Math.min(e,s)),Sa=class{constructor(t){this.ctx=null,this.muted=gt.audio.mute,this.volume=gt.audio.master,this.engines=new Map,this.bus=t,this.ready=!1;let e=()=>{this.init()};for(let n of["pointerdown","keydown","touchstart"])window.addEventListener(n,e,{once:!1,passive:!0});this.subscribe()}init(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume().catch(()=>{});return}let t=window.AudioContext||window.webkitAudioContext;if(!t)return;try{this.ctx=new t}catch{return}let e=this.ctx;this.master=e.createGain(),this.master.gain.value=this.muted?0:this.volume;let n=e.createDynamicsCompressor();n.threshold.value=-14,n.ratio.value=4,this.master.connect(n),n.connect(e.destination);let i=e.sampleRate*2,r=e.createBuffer(1,i,e.sampleRate),a=r.getChannelData(0);for(let l=0;l<i;l++)a[l]=Math.random()*2-1;this.noiseBuf=r;let o=(l,c,h)=>{let u=e.createBufferSource();u.buffer=r,u.loop=!0,u.playbackRate.value=.7+Math.random()*.6;let d=e.createBiquadFilter();d.type=l,d.frequency.value=c,d.Q.value=h;let f=e.createGain();return f.gain.value=0,u.connect(d),d.connect(f),f.connect(this.master),u.start(),{s:u,f:d,g:f}};this.boostSnd=o("bandpass",700,.7),this.tireSnd=o("bandpass",1500,2.5),this.windSnd=o("highpass",2200,.5),this.crowd=o("lowpass",650,.4),this.crowd.g.gain.value=.05,this.crowd2=o("bandpass",1100,.6),this.crowd2.g.gain.value=.03,this.ready=!0,e.state==="suspended"&&e.resume().catch(()=>{})}setMute(t){this.muted=t,this.master&&this.master.gain.setTargetAtTime(t?0:this.volume,this.ctx.currentTime,.02)}setVolume(t){this.volume=t,this.master&&!this.muted&&this.master.gain.setTargetAtTime(t,this.ctx.currentTime,.02)}env(t,e,n,i,r){t.gain.cancelScheduledValues(e),t.gain.setValueAtTime(1e-4,e),t.gain.exponentialRampToValueAtTime(i,e+n),t.gain.exponentialRampToValueAtTime(1e-4,e+n+r)}tone(t,e,n=.2,i="sine",r=null,a=0){if(!this.ready)return;let o=this.ctx,l=o.currentTime+a,c=o.createOscillator(),h=o.createGain();c.type=i,c.frequency.setValueAtTime(t,l),r&&c.frequency.exponentialRampToValueAtTime(r,l+e),this.env(h,l,.005,n,e),c.connect(h),h.connect(this.master),c.start(l),c.stop(l+e+.05)}noise(t,e,n=.2,i="lowpass",r=.7,a=0,o=null){if(!this.ready)return;let l=this.ctx,c=l.currentTime+a,h=l.createBufferSource();h.buffer=this.noiseBuf,h.playbackRate.value=.6+Math.random()*.8;let u=l.createBiquadFilter();u.type=i,u.frequency.setValueAtTime(e,c),u.Q.value=r,o&&u.frequency.exponentialRampToValueAtTime(o,c+t);let d=l.createGain();this.env(d,c,.004,n,t),h.connect(u),u.connect(d),d.connect(this.master),h.start(c,Math.random()),h.stop(c+t+.05)}subscribe(){let t=this.bus;t.on("ballHit",e=>{let n=kn(ge(e.power)/2300,.05,1.5);this.tone(130+60*(1-n),.22,.28+n*.3,"sine",55),this.noise(.12,2500,.15+n*.3,"bandpass",1.2),n>.6&&this.tone(900,.08,.1,"square",300)}),t.on("ballImpact",e=>{let n=kn(e.power/20,.05,1);this.tone(100+40*(1-n),.18,.08+n*.25,"sine",50),this.noise(.08,1800,.05+n*.15,"bandpass",1.5)}),t.on("jump",()=>{this.noise(.12,600,.12,"lowpass",.8,0,200),this.tone(180,.1,.1,"triangle",120)}),t.on("dodge",()=>{this.noise(.28,1200,.2,"bandpass",1,0,3500)}),t.on("land",e=>{let n=kn(e.power,.1,1);this.tone(90,.16,.2*n+.05,"sine",45),this.noise(.1,700,.1*n,"lowpass")}),t.on("carBump",e=>{this.noise(.15,900,kn(e.power/30,.05,.4),"bandpass",.8),this.tone(70,.18,.2,"sine",40)}),t.on("demolish",()=>{this.noise(.9,1800,.6,"lowpass",.6,0,120),this.tone(80,.7,.5,"sawtooth",25),this.tone(300,.2,.2,"square",60)}),t.on("padPickup",e=>{e.car&&!e.car.isHuman||(this.tone(e.pad.large?520:760,.14,.14,"sine",e.pad.large?980:1100),this.tone(e.pad.large?780:1140,.18,.08,"triangle",null,.04))}),t.on("count",()=>this.tone(520,.2,.25,"square")),t.on("go",()=>{this.tone(1040,.5,.28,"square"),this.tone(1560,.5,.12,"sine")}),t.on("goal",e=>{for(let[n,i]of[[262,0],[330,.02],[392,.04],[523,.06]])this.tone(n,1.8,.14,"sawtooth",n*.99,i);this.noise(1.6,900,.4,"bandpass",.5,0,300),this.tone(60,1.2,.5,"sine",30),this.crowdBoost=3.5}),t.on("overtime",()=>{this.tone(220,1,.2,"sawtooth",440)}),t.on("ended",()=>{this.tone(392,.4,.2,"triangle"),this.tone(523,.6,.2,"triangle",null,.25),this.tone(659,.9,.2,"triangle",null,.5)}),t.on("ui",()=>this.tone(660,.06,.1,"square"))}uiClick(){this.tone(700,.05,.08,"square")}engine(t){let e=this.engines.get(t);if(!e){let n=this.ctx,i=n.createOscillator(),r=n.createOscillator(),a=n.createOscillator(),o=n.createBiquadFilter(),l=n.createGain(),c=n.createStereoPanner();i.type="sawtooth",r.type="square",a.type="sine",o.type="lowpass",o.frequency.value=600,o.Q.value=3,l.gain.value=0;let h=n.createGain(),u=n.createGain();h.gain.value=.4,u.gain.value=.6,i.connect(o),r.connect(h),h.connect(o),a.connect(u),u.connect(o),o.connect(l),l.connect(c),c.connect(this.master),i.start(),r.start(),a.start(),e={o1:i,o2:r,o3:a,f:o,g:l,p:c},this.engines.set(t,e)}return e}update(t,e,n,i,r){if(!this.ready)return;let a=this.ctx.currentTime;for(let[u,d]of this.engines)t.cars.includes(u)||(d.g.gain.setTargetAtTime(0,a,.05),setTimeout(()=>{try{d.o1.stop(),d.o2.stop(),d.o3.stop()}catch{}},300),this.engines.delete(u));let o=0,l=0,c=0;for(let u of t.cars){let d=this.engine(u);if(!r||u.demolished){d.g.gain.setTargetAtTime(0,a,.05);continue}let f=kn(u.speed/gt.car.maxSpeed,0,1.1),g=Math.abs(u.ctrl.throttle)+(u.boosting?.6:0),y=48+f*150+g*22+(u.contacts===0?20:0);d.o1.frequency.setTargetAtTime(y,a,.04),d.o2.frequency.setTargetAtTime(y*.5,a,.04),d.o3.frequency.setTargetAtTime(y*.25,a,.04),d.f.frequency.setTargetAtTime(350+f*900+g*500,a,.05),vl.copy(u.currT).sub(n);let m=vl.length(),p=u.isHuman?1:1/(1+m*.07);d.g.gain.setTargetAtTime((.05+g*.035+f*.03)*p,a,.05),d.p.pan.setTargetAtTime(u.isHuman?0:kn(vl.normalize().dot(i),-1,1),a,.05);let x=p;u.boosting&&(l=Math.max(l,x)),o=Math.max(o,kn(u.slipAmount/10,0,1)*x*(u.contacts?1:0)),c=Math.max(c,kn(f-.55,0,.5)*2*(u.isHuman?1:.4))}this.boostSnd.g.gain.setTargetAtTime(l*.16,a,.04),this.boostSnd.f.frequency.setTargetAtTime(600+l*500,a,.1),this.tireSnd.g.gain.setTargetAtTime(o*.12,a,.05),this.windSnd.g.gain.setTargetAtTime(c*.06,a,.1),this.crowdBoost=Math.max(0,(this.crowdBoost||0)-e);let h=kn(this.crowdBoost,0,1)+(t.mode==="versus"?.08:0);this.crowd.g.gain.setTargetAtTime(.03+h*.18+.02*Math.sin(performance.now()/1500),a,.2),this.crowd2.g.gain.setTargetAtTime(.015+h*.1,a,.2)}silenceAll(){if(!this.ready)return;let t=this.ctx.currentTime;for(let e of this.engines.values())e.g.gain.setTargetAtTime(0,t,.05);this.boostSnd.g.gain.setTargetAtTime(0,t,.05),this.tireSnd.g.gain.setTargetAtTime(0,t,.05),this.windSnd.g.gain.setTargetAtTime(0,t,.05)}},vl=new C;var Bt=s=>document.getElementById(s),zh="rl3d.ui.v2",P0=[["throttle","Throttle / Pitch down"],["brake","Brake / Reverse / Pitch up"],["left","Steer left / Yaw"],["right","Steer right / Yaw"],["jump","Jump / Dodge"],["boost","Boost"],["powerslide","Powerslide / Air roll"],["rollLeft","Air roll left"],["rollRight","Air roll right"],["ballCam","Toggle ball cam"],["reset","Reset (Free Play)"],["pause","Pause"],["lookLeft","Look left"],["lookRight","Look right"],["lookUp","Look up"],["lookDown","Look down"]],Ea=class{constructor(t){this.app=t,this.settings={volume:gt.audio.master,mute:!1,showFps:!1,fov:gt.camera.hFov,dist:gt.camera.distance,height:gt.camera.height,angle:gt.camera.angle,stiff:gt.camera.stiffness,swivel:gt.camera.swivelSpeed},this.load(),this.current=null,this.msgTimer=0,this.subTimer=0,this.prevScreen=null,this.wire(),this.applySettings()}load(){try{Object.assign(this.settings,JSON.parse(localStorage.getItem(zh)||"{}"))}catch{}}save(){try{localStorage.setItem(zh,JSON.stringify(this.settings))}catch{}}applySettings(){let t=this.settings,e=this.app;Object.assign(e.cam.settings,{hFov:t.fov,distance:t.dist,height:t.height,angle:t.angle,stiffness:t.stiff,swivelSpeed:t.swivel}),e.cam.applyFov(0),e.audio.setVolume(t.volume),e.audio.setMute(t.mute),Bt("fps").classList.toggle("hidden",!t.showFps)}wire(){let t=this.app;document.querySelectorAll("[data-start]").forEach(a=>a.addEventListener("click",()=>{t.audio.init(),t.bus.emit("ui"),t.startGame(a.dataset.start,Bt("difficulty").value)})),Bt("btn-settings").addEventListener("click",()=>this.openSettings("menu")),Bt("btn-pause-settings").addEventListener("click",()=>this.openSettings("pause")),Bt("btn-resume").addEventListener("click",()=>t.setPaused(!1)),Bt("btn-restart").addEventListener("click",()=>{t.match.restart(),t.setPaused(!1)}),Bt("btn-quit").addEventListener("click",()=>t.quitToMenu()),Bt("btn-rematch").addEventListener("click",()=>{t.match.restart(),this.showScreen(null),this.showHud(!0)}),Bt("btn-res-menu").addEventListener("click",()=>t.quitToMenu()),Bt("btn-settings-close").addEventListener("click",()=>this.closeSettings()),document.querySelectorAll("#practice [data-preset]").forEach(a=>a.addEventListener("click",()=>t.match.setPreset(a.dataset.preset))),document.querySelectorAll("#practice [data-act]").forEach(a=>a.addEventListener("click",()=>t.practiceAction(a.dataset.act))),document.querySelectorAll(".tabs button").forEach(a=>a.addEventListener("click",()=>{document.querySelectorAll(".tabs button").forEach(o=>o.classList.toggle("on",o===a)),document.querySelectorAll(".tab").forEach(o=>o.classList.toggle("on",o.id===a.dataset.tab))}));let e=(a,o,l,c=h=>h)=>{let h=Bt(a),u=h.parentElement.querySelector("output");h.value=o(),u.textContent=c(+h.value),h.addEventListener("input",()=>{l(+h.value),u.textContent=c(+h.value),this.save(),t.input.save(),this.applySettings()})},n=this.settings,i=t.input.settings;e("s-volume",()=>n.volume,a=>n.volume=a,a=>Math.round(a*100)+"%"),e("s-fov",()=>n.fov,a=>n.fov=a,a=>a+"\xB0"),e("s-dist",()=>n.dist,a=>n.dist=a),e("s-height",()=>n.height,a=>n.height=a),e("s-angle",()=>n.angle,a=>n.angle=a,a=>a.toFixed(1)),e("s-stiff",()=>n.stiff,a=>n.stiff=a,a=>a.toFixed(2)),e("s-swivel",()=>n.swivel,a=>n.swivel=a,a=>a.toFixed(1)),e("s-steer",()=>i.steerSensitivity,a=>i.steerSensitivity=a,a=>a.toFixed(2)),e("s-dz",()=>i.stickDeadzone,a=>i.stickDeadzone=a,a=>a.toFixed(2)),e("s-dodge",()=>i.dodgeDeadzone,a=>i.dodgeDeadzone=a,a=>a.toFixed(2)),e("s-mouse",()=>i.mouseSensitivity,a=>i.mouseSensitivity=a,a=>a.toFixed(4));let r=(a,o,l)=>{let c=Bt(a);c.checked=o(),c.addEventListener("change",()=>{l(c.checked),this.save(),t.input.save(),this.applySettings()})};r("s-mute",()=>n.mute,a=>n.mute=a),r("s-fps",()=>n.showFps,a=>n.showFps=a),r("s-ballcam",()=>i.ballCamDefault!==!1,a=>i.ballCamDefault=a),Bt("btn-keys-reset").addEventListener("click",()=>{t.input.resetBindings(),this.buildKeys()}),this.buildKeys()}buildKeys(){let t=Bt("keylist");t.innerHTML="";for(let[e,n]of P0){let i=document.createElement("div");i.className="k";let r=document.createElement("span");r.textContent=n;let a=document.createElement("button");a.textContent=this.app.input.bindings[e].map(Uh).join(" / "),a.addEventListener("click",()=>{a.textContent="press a key\u2026",a.classList.add("wait"),this.app.input.captureNext(o=>{a.classList.remove("wait"),o&&this.app.input.rebind(e,o),this.buildKeys()})}),i.append(r,a),t.append(i)}}showScreen(t){for(let e of["menu","pause","results","settings"])Bt(e).classList.toggle("hidden",e!==t);this.current=t}showHud(t){Bt("hud").classList.toggle("hidden",!t)}openSettings(t){this.prevScreen=t,this.buildKeys(),this.showScreen("settings")}closeSettings(){this.showScreen(this.prevScreen==="pause"?"pause":"menu"),this.save(),this.app.input.save()}showResults(t){let n=t.winner;Bt("res-title").textContent=n===-1?"DRAW":n===0?"VICTORY":"DEFEAT",Bt("res-score").innerHTML=`<span class="blue">${t.scores[0]}</span> \u2013 <span class="orange">${t.scores[1]}</span>`;let i=t.stats,r=(a,o,l)=>`<tr><td>${a}</td><td>${o}</td><td>${l}</td></tr>`;Bt("res-stats").innerHTML=r("","You","Bot")+r("Goals",t.scores[0],t.scores[1])+r("Ball touches",i.touches[0],i.touches[1])+r("Demolitions",i.demos[0],i.demos[1]),this.showScreen("results")}say(t,e,n,i=1.4,r=!0){let a=Bt("center-msg");a.textContent=t,a.style.color=e||"#fff",a.style.opacity=1,a.classList.remove("pop"),r&&(a.offsetWidth,a.classList.add("pop")),this.msgTimer=i,n!==void 0&&(Bt("sub-msg").textContent=n,this.subTimer=i)}sub(t,e=2){Bt("sub-msg").textContent=t,this.subTimer=e}update(t,e){this.msgTimer>0&&(this.msgTimer-=t,this.msgTimer<=0&&(Bt("center-msg").textContent="")),this.subTimer>0&&(this.subTimer-=t,this.subTimer<=0&&(Bt("sub-msg").textContent=""));let n=e.match;Bt("score-blue").textContent=n.scores[0],Bt("score-orange").textContent=n.scores[1];let i=Bt("clock");if(n.mode==="freeplay")i.textContent="\u221E",Bt("clock-sub").textContent="Free play",i.classList.remove("low");else if(n.overtime){let c=n.overtimeTime;i.textContent="+"+Math.floor(c/60)+":"+String(Math.floor(c%60)).padStart(2,"0"),Bt("clock-sub").textContent="Overtime",i.classList.add("low")}else{let c=Math.max(0,Math.ceil(n.timeLeft));i.textContent=Math.floor(c/60)+":"+String(c%60).padStart(2,"0"),Bt("clock-sub").textContent="",i.classList.toggle("low",c<=30)}let r=n.human;if(r){let c=Math.round(r.boost),h=Bt("boost-ring");Bt("boost-num").textContent=r.unlimitedBoost?"\u221E":c,h.style.strokeDashoffset=String(326.7*(1-(r.unlimitedBoost?1:r.boost/100))),Bt("boost").classList.toggle("boosting",r.boosting);let u=Math.round(ge(r.speed)*.036);Bt("speed-num").textContent=u;let d=Math.max(0,Math.min(1,(ge(r.speed)-1500)/800));Bt("speedfx").style.opacity=String(d*.9)}let a=Bt("camstatus");a.textContent=e.ballCam?"BALL CAM":"CAR CAM",a.classList.toggle("on",e.ballCam),Bt("practice").classList.toggle("hidden",n.mode!=="freeplay"||!e.practiceVisible),Bt("ub-state").textContent=n.unlimitedBoost?"on":"off",Bt("replay-tag").classList.toggle("hidden",n.state!=="replay");let o=Bt("ball-ind");e.ballScreen&&e.ballScreen.off&&n.state!=="replay"?(o.style.display="block",o.style.left=e.ballScreen.x+"px",o.style.top=e.ballScreen.y+"px",o.style.transform=`rotate(${e.ballScreen.angle}rad)`):o.style.display="none";let l=Bt("flashfx");l.style.opacity=String(e.flash||0),e.fps!==void 0&&this.settings.showFps&&(Bt("fps").textContent=e.fps.toFixed(0)+" fps")}};var Gs=document.getElementById("loading"),Ml=document.getElementById("loading-text");function Bh(s){console.error(s),Gs.classList.add("err"),Gs.classList.remove("hidden"),Ml.innerHTML="Failed to start the game.<br><small>"+String(s&&s.message||s).replace(/</g,"&lt;")+"</small><br><small>Serve this folder over HTTP (e.g. <code>python3 -m http.server 8000</code>) and use a WebGL2-capable browser.</small>"}window.addEventListener("error",s=>{Gs&&!Gs.classList.contains("hidden")&&Bh(s.error||s.message)});async function L0(){let s=document.getElementById("game"),t=Lh();Ml.textContent="Starting physics engine (WebAssembly)\u2026";let e=await oa.create(t);Ml.textContent="Building arena\u2026";let n=new _a,i=new la(s),r=new xa(e,t,i,n),a=new va(s,t,n),o=new ba(a.camera,e),l=new Sa(n),c={match:r,input:i,renderer:a,cam:o,audio:l,bus:n,physics:e,ui:null,practiceVisible:!0};c.setPaused=T=>{r.mode==="menu"||r.state==="ended"||(r.paused=T,c._pauseT=performance.now(),c.ui.showScreen(T?"pause":null),c.ui.showHud(!0),T?(i.releasePointerLock(),l.silenceAll()):i.requestPointerLock())},c.startGame=(T,E)=>{i.ballCam=i.settings.ballCamDefault!==!1,T==="freeplay"?r.startFreePlay():r.startVersus(E),a.markN=0,o.initialized=!1,c.ui.showScreen(null),c.ui.showHud(!0),i.requestPointerLock()},c.quitToMenu=()=>{r.quitToMenu(),c.ui.showScreen("menu"),c.ui.showHud(!1),i.releasePointerLock(),l.silenceAll(),document.getElementById("speedfx").style.opacity=0},c.practiceAction=T=>{r.mode==="freeplay"&&(T==="resetAll"?r.resetAll():T==="resetBall"?r.resetBall():T==="launch"?r.launchBall():T==="boost"&&r.toggleUnlimitedBoost())};let h=c.ui=new Ea(c),u=["#3b9bff","#ff8a2b"];n.on("count",T=>h.say(String(T.n),"#fff",void 0,.95)),n.on("go",()=>h.say("GO!","#7dffa0","",.8)),n.on("kickoff",()=>{o.initialized=!1}),n.on("goal",T=>{let E=T.by?T.by.isHuman?"You":"Bot":"";h.say((T.freeplay,"GOAL!"),u[T.team],E?`${E} scored \xB7 ${Math.round(T.speed||0)} uu/s`:"",2.2)}),n.on("overtime",()=>h.say("OVERTIME","#ffd36b","Next goal wins",2.5)),n.on("demolish",T=>{T.victim.isHuman?h.say("DEMOLISHED","#ff6a6a","Respawning\u2026",2.6,!1):T.attacker.isHuman&&h.sub("DEMOLITION",1.5)}),n.on("replayStart",()=>{o.initialized=!1}),n.on("ended",T=>{setTimeout(()=>{r.state==="ended"&&r.mode==="versus"&&(h.showResults(T),i.releasePointerLock())},gt.match.resultsDelay*1e3),h.say("FULL TIME","#fff","",1.6)}),n.on("matchStart",()=>{document.getElementById("boost").classList.toggle("orange",!1)}),window.addEventListener("keydown",T=>{if(!(T.target&&/^(INPUT|SELECT|TEXTAREA)$/.test(T.target.tagName))&&!i.capturing){if(r.state==="replay"&&(T.code==="Space"||T.code==="Enter")){r.skipReplay();return}if(r.mode==="freeplay"&&!r.paused&&h.current===null){let E=T.code;E==="KeyT"?r.resetBall():E==="KeyG"?r.launchBall():E==="KeyB"?r.toggleUnlimitedBoost():E==="Tab"?(T.preventDefault(),c.practiceVisible=!c.practiceVisible):/^Digit[1-6]$/.test(E)&&r.setPreset(["kickoff","shot","dribble","aerial","wall","defend"][+E.slice(5)-1])}}}),s.addEventListener("click",()=>{l.init(),r.mode!=="menu"&&!r.paused&&h.current===null&&i.requestPointerLock()}),document.addEventListener("pointerlockchange",()=>{!document.pointerLockElement&&r.mode!=="menu"&&!r.paused&&r.state!=="ended"&&h.current===null&&c._lockWanted&&performance.now()-(c._pauseT||0)>400&&c.setPaused(!0)}),setInterval(()=>{c._lockWanted=i.pointerLocked},100),window.addEventListener("resize",()=>o.setAspect(a.resize())),window.addEventListener("blur",()=>{r.mode!=="menu"&&!r.paused&&r.state!=="ended"&&h.current===null&&c.setPaused(!0)}),o.setAspect(a.resize());let d=new C,f=new C,g=new C,y=new C,m=performance.now(),p=0,x=0,_=60;c.practiceVisible=!0;function M(T){requestAnimationFrame(M);let E=(T-m)/1e3;m=T,E=Math.min(Math.max(E,1e-4),.1),p+=E,x++,p>.5&&(_=x/p,p=0,x=0);let R=r.mode!=="menu",U=R&&!r.paused&&h.current===null,v=i.get(E);R&&(i.edges.pause&&r.state!=="ended"&&performance.now()-(c._pauseT||0)>400&&c.setPaused(!r.paused&&h.current===null),i.edges.reset&&r.mode==="freeplay"&&U&&r.resetAll()),r.human&&(r.human.dodgeDeadzone=i.settings.dodgeDeadzone),r.humanCtrl=U?v:i.neutral(),r.human&&i.settings.steerSensitivity!==1&&(r.humanCtrl.steer=Math.max(-1,Math.min(1,r.humanCtrl.steer*i.settings.steerSensitivity))),r.frame(U||R&&h.current==="results"?E:R?0:E);let S=r.human;if(!R||!S)o.orbit(a.time+6);else if(r.state==="replay"||r.state==="goal"){let et=r.lastScorer===0?gt.arena.halfLength:-gt.arena.halfLength;o.updateReplay(E,r.rBall.pos,d.set(0,0,et))}else r.state==="ended"?o.orbit(a.time):(f.set(0,0,-1).applyQuaternion(S.rQuat),o.update({dt:E,carPos:S.rPos,carFwd:f,surfaceNormal:S.surfaceNormal,onSurface:S.contacts>=2,speed:S.speed,boosting:S.boosting,ballPos:r.rBall.pos,ballCam:i.ballCam,look:i.look,hasCar:!0}));a.camShake&&(o.shake=Math.max(o.shake,a.camShake),a.camShake=0),a.render(r,E),R&&!r.paused&&a.adaptQuality(_,E);let N=R&&!r.paused&&(r.state==="playing"||r.state==="goal"||r.state==="countdown");y.set(1,0,0).applyQuaternion(a.camera.quaternion),l.update(r,E,a.camera.position,y,N);let H=null;if(R&&S){g.copy(r.rBall.pos).project(a.camera);let et=g.z>1,L=g.x,F=g.y;et&&(L=-L,F=-F);let X=et||Math.abs(L)>.94||Math.abs(F)>.9;if(X){let $=Math.max(Math.abs(L)/.9,Math.abs(F)/.84,.001);L/=$,F/=$,et&&Math.abs(L)<.05&&Math.abs(F)<.05&&(F=-.84)}let nt=a.width,Z=a.height;H={off:X,x:(L*.5+.5)*nt,y:(-F*.5+.5)*Z,angle:Math.atan2(L,F)*1+0},H.angle=Math.atan2(- -F,L)+Math.PI/2,H.angle=Math.atan2(L,F)}h.update(E,{match:r,ballCam:i.ballCam,ballScreen:H,fps:_,flash:0,practiceVisible:c.practiceVisible})}Gs.classList.add("hidden"),h.showScreen("menu"),requestAnimationFrame(M),window.__game=c}L0().catch(Bh);
/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */
